"""Single fail-closed HTTPS boundary for matrix recipes and the model envelope.
Business endpoints, header bindings, transient auth dependencies and empty-body
rules are catalogue data. No response/endpoint-specific business branches.
"""
from __future__ import annotations
import json,time,urllib.request,urllib.error
from decimal import Decimal
from email.utils import parsedate_to_datetime
from pathlib import Path
from engine import CallError
from semantics import strict_json
from registry import REGISTRY_HASH
from query_program import model_system
from semantic_catalog import EXPRESSION_CATALOG
from table_analytics import HASH as TABLE_HASH,SOURCE_MATRIX as ROW_SOURCES
from scalar_runtime import MATRIX as SCALARS,SOURCES as SCALAR_SOURCES
from matrix_core import MatrixError
import providers

if set(ROW_SOURCES.sources)&set(SCALAR_SOURCES.sources):raise ValueError('ambiguous source operation')
MATRICES={**{k:ROW_SOURCES for k in ROW_SOURCES.sources},**{k:SCALAR_SOURCES for k in SCALAR_SOURCES.sources}}
ENDPOINTS={k:m.recipe(k)['url'] for k,m in MATRICES.items()}
ENDPOINTS['deepseek_parse']='https://api.deepseek.com/chat/completions'

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

class HTTPTransport:
    def __init__(self,credential_directory,bindings,qualifications,enabled=False):
        self.directory=Path(credential_directory);self.bindings=dict(bindings)
        self.qualifications=dict(qualifications);self.enabled=enabled;self._tokens={}

    def _credential(self,name):
        if not isinstance(name,str) or not name or Path(name).name!=name or name in ('.','..'):raise CallError('CREDENTIAL_NAME')
        p=self.directory/name
        if p.is_symlink() or not p.is_file():raise CallError('CREDENTIAL_UNAVAILABLE')
        value=p.read_text().strip()
        if not 12<=len(value)<=8192:raise CallError('CREDENTIAL_SIZE')
        return value

    def _scope(self,request,store):
        if store is None or store['id']!=request.store_id or store['id'] not in self.bindings:raise CallError('CREDENTIAL_SCOPE')

    def _cache_key(self,store,profile):
        dependency=SCALARS.auth[profile]['operation']
        return (store['id'],store['identity'],store['access_revision'],store['source_revision'],self.bindings.get(store['id']),profile,SCALAR_SOURCES.fingerprint(dependency))

    def _qualification(self,operation):
        if not self.enabled:raise CallError('LIVE_DISABLED')
        if operation not in MATRICES:raise CallError('ENDPOINT_NOT_ALLOWED')
        proof=self.qualifications.get(operation,{})
        if (not isinstance(proof,dict) or proof.get('status') not in ('LIVE_LAB_VERIFIED','READ_ONLY_CANARY') or proof.get('registry_hash')!=REGISTRY_HASH or not proof.get('evidence_ref')):raise CallError('DECODER_NOT_LIVE_QUALIFIED')
        matrix=MATRICES[operation]
        if matrix is ROW_SOURCES and proof.get('table_hash')!=TABLE_HASH:raise CallError('TABLE_DECODER_NOT_QUALIFIED')
        if matrix is SCALAR_SOURCES and proof.get('scalar_hash')!=SCALARS.hash:raise CallError('SCALAR_DECODER_NOT_QUALIFIED')
        return matrix

    def prepare(self,request,store):
        profile=SCALARS.profile_for(request.operation)
        if profile is None:return None
        self._scope(request,store)
        # Qualify the requested data source before spending a grant call.
        matrix=self._qualification(request.operation)
        if matrix.recipe(request.operation)['platform']!=store['platform']:raise CallError('CREDENTIAL_PLATFORM')
        settings=SCALARS.auth[profile];cached=self._tokens.get(self._cache_key(store,profile))
        if cached and cached[1]>time.time()+settings['refresh_margin']:return None
        operation=settings['operation'];self._qualification(operation);spec=SCALAR_SOURCES.recipe(operation)
        # Secret request data are deliberately absent. They are bound only in execute().
        return providers.Request(operation,store['platform']+':'+store['identity']+':'+spec['quota_operation'],store['id'],{},spec['interval'],spec['daily_limit'])

    def execute(self,request,store):
        operation=request.operation
        if not self.enabled:raise CallError('LIVE_DISABLED')
        if operation not in ENDPOINTS:raise CallError('ENDPOINT_NOT_ALLOWED')
        specification=None
        if operation=='deepseek_parse':
            payload={'model':'deepseek-flash','thinking':{'type':'disabled'},'temperature':0,'max_tokens':1800,'response_format':{'type':'json_object'},
                     'messages':[{'role':'system','content':model_system(request.body.get('catalog',EXPRESSION_CATALOG))},
                                 {'role':'user','content':json.dumps({'question':request.body['question'],'server_scope':request.body.get('slots',{})},ensure_ascii=False)}]}
            method='POST';url=ENDPOINTS[operation];headers={'Authorization':'Bearer '+self._credential('deepseek')}
        else:
            matrix=self._qualification(operation);specification=matrix.recipe(operation)
            self._scope(request,store)
            credentials=strict_json(self._credential(self.bindings[store['id']]))
            profile=SCALARS.profile_for(operation);ephemeral={}
            if profile is not None:
                cached=self._tokens.get(self._cache_key(store,profile))
                if not cached or cached[1]<=time.time():raise CallError(SCALARS.auth[profile]['missing_error'])
                ephemeral={'token':cached[0]}
            try:method,url,headers,payload=matrix.http(operation,request.body,store,credentials,ephemeral)
            except MatrixError as exc:raise CallError(exc.code) from None
        encoded=None if payload is None else json.dumps(payload,ensure_ascii=False,allow_nan=False).encode()
        request_http=urllib.request.Request(url,data=encoded,headers={**headers,'Content-Type':'application/json'},method=method)
        start=time.monotonic();opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
        try:
            with opener.open(request_http,timeout=25) as response:
                raw=response.read(12000001);status=response.status
        except urllib.error.HTTPError as exc:
            retry=exc.headers.get('Retry-After');retry_at=None
            try:
                if retry:retry_at=time.time()+max(0,int(retry))
            except (ValueError,TypeError):
                try:retry_at=parsedate_to_datetime(retry).timestamp()
                except (ValueError,TypeError,OverflowError):pass
            status=exc.code;exc.close()
            raise CallError('HTTP_'+str(status),status=status,retry_at=retry_at) from None
        except (urllib.error.URLError,TimeoutError,ConnectionError,OSError):
            raise CallError('NETWORK_OUTCOME_UNKNOWN',unknown=True) from None
        if len(raw)>12000000:raise CallError('RESPONSE_SIZE',status=status)
        try:data=[] if specification and status in specification.get('options',{}).get('empty_statuses',[]) and not raw else strict_json(raw,parse_float=Decimal)
        except (ValueError,UnicodeError):raise CallError('RESPONSE_JSON',status=status) from None
        meta={'status':status,'elapsed_ms':round(1000*(time.monotonic()-start)),'bytes':len(raw)}
        token_profiles=[(name,a) for name,a in SCALARS.auth.items() if a['operation']==operation]
        if token_profiles:
            for name,policy in token_profiles:
                try:
                    token=data;ttl=data
                    for component in policy['token_path']:token=token[component]
                    for component in policy['expires_path']:ttl=ttl[component]
                    if not isinstance(token,str) or not 12<=len(token)<=8192 or '\r' in token or '\n' in token or type(ttl)is not int or not policy['min_ttl']<ttl<=policy['max_ttl']:raise ValueError('schema')
                except (KeyError,TypeError,ValueError):raise CallError(policy['schema_error'],status=status) from None
                now=time.time()
                self._tokens={k:v for k,v in self._tokens.items() if v[1]>now}
                if len(self._tokens)>=128:self._tokens.pop(min(self._tokens,key=lambda k:self._tokens[k][1]))
                self._tokens[self._cache_key(store,name)]=(token,now+ttl)
            data={'authorized':True}
        if operation=='deepseek_parse':
            try:
                choice=data['choices'][0];data={'content':choice['message']['content'],'finish_reason':choice['finish_reason']}
            except (KeyError,TypeError,IndexError):raise CallError('MODEL_ENVELOPE',status=status) from None
        return data,meta
