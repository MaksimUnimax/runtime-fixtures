# RT-JOB-R01.1 · runtime-only candidate

Читайте [README_RT_JOB_R01.md](README_RT_JOB_R01.md).

Кандидат не установлен. Рабочий сервис r4 и платформа второго исполнителя не изменены.

Полный тест: `python3 -B run_checks.py`.
