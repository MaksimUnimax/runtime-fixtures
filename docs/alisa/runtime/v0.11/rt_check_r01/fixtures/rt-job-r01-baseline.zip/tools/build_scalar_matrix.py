"""One-off reviewed catalogue authoring, never imported by request execution."""
from pathlib import Path
import json,copy
ROOT=Path(__file__).resolve().parent.parent
reg=json.loads((ROOT/'registry.json').read_text());DEFS=reg['metric_definitions']
P=lambda *x:{'$path':list(x)}
D=lambda path,default:{'$path':path,'default':default}
F=lambda name,*args:{'$fn':[name,*args]}
IF=lambda cond,a,b:{'$if':[cond,a,b]}
MAP=lambda src,name,expr:{'$map':[src,name,expr]}
FLT=lambda src,name,expr:{'$filter':[src,name,expr]}
G=lambda cond,code:{'test':cond,'code':code}
LET=lambda name,value,code:{'name':name,'value':value,'code':code}
def AND(*xs):
 x=xs[0]
 for v in xs[1:]:x=F('and',x,v)
 return x
def OR(*xs):
 x=xs[0]
 for v in xs[1:]:x=F('or',x,v)
 return x
def at(obj,key):return F('get',obj,key)
def amount(expr,metric):return IF(at(P('params','integer'),metric),F('natural',expr),IF(at(P('params','signed'),metric),F('decimal',expr),F('nonnegative',expr)))
def selected_values(expr):return F('pairs_object',MAP(P('params','metrics'),'metric',[P('metric'),amount(expr(P('metric')),P('metric'))]))
def fields_values(obj):return selected_values(lambda m:at(obj,at(P('params','fields'),m)))
def sum_values(field='values'):return F('pairs_object',MAP(P('params','metrics'),'metric',[P('metric'),F('sum_values',MAP(P('rows'),'summand',at(P('summand',field),P('metric'))))]))
def schema(props,required=None):
 d={'type':'object','properties':props}
 if required is not None:d['required']=required
 return d
STR={'type':'string','max_length':4096};DATE={'type':'string','format':'iso_date','max_length':10};INT={'type':'integer','minimum':0};BOOL={'type':'boolean'}
ARR={'type':'array','items':STR};EMPTY=schema({})
origins={'ozon':['https://api-seller.ozon.ru','https://api-performance.ozon.ru'],'wb':['https://seller-analytics-api.wildberries.ru','https://advert-api.wildberries.ru','https://finance-api.wildberries.ru']}
base_auth={'ozon':{'headers':{'Client-Id':P('credentials','seller_client_id'),'Api-Key':P('credentials','seller_api_key')},'claims':None},'wb':{'headers':{'Authorization':P('credentials','seller_token')},'claims':None}}
sources={};recipes={};http_aux={}
def source(op,platform,url,method,request,payload,items,*,currency=None,mode='single',size=1000):
 spec={'platform':platform,'url':url,'method':method,'quota_operation':op,'interval':61,'daily_limit':50,'auth':copy.deepcopy(base_auth[platform]),'request':request,'payload_schema':payload,'proof_requirements':{},'availability':[],'axis':'source_defined',
 'response':{'items':items,'root_asserts':[],'lets':[],'row_asserts':[],'map':{},'include':True,'currency':currency if currency is not None else P('store','currency'),'identity':F('hash',P('row_index')),'duplicate_code':'DUPLICATE_ROW','page_duplicate_code':'DUPLICATE_ROW','pagination':{'mode':mode,'size':size,'cursor':None,'initial':'','order_code':'CURSOR_ORDER','stalled_code':'CURSOR_STALLED'},'totals':None,'totals_changed_code':'TOTAL_CHANGED','dataset_asserts':[]},'options':{'allow_null_currency':True}}
 sources[op]=spec;return spec
for key,r in reg['recipes'].items():
 platform='ozon' if key.startswith('ozon') else 'wb'
 family=next(d['source'] for m,d in DEFS.items() if 'source' in d and m in r['metrics'])
 recipes[key]={'platform':platform,'family':family,'operation':r['operation'],'max_days':r.get('max_days',366),'paired_periods':key=='wb','fields':r['metrics'],'output':{'values':sum_values(),'rows':F('len',P('rows'))},'error_code':'SOURCE_RESPONSE_SCHEMA','workflow':None}
# Orders with metrics in requested order and independent total reconciliation.
s=source('ozon_orders','ozon',reg['recipes']['ozon']['url'],'POST',{'date_from':P('period','from'),'date_to':P('period','to'),'metrics':MAP(P('params','metrics'),'metric',at(P('params','fields'),P('metric'))),'dimension':['month'],'filters':[],'limit':1000,'offset':0},schema({'date_from':DATE,'date_to':DATE,'metrics':ARR,'dimension':ARR,'filters':{'type':'array','items':EMPTY},'limit':INT,'offset':INT}),P('response','result','data'))
d=s['response'];d['root_asserts']=[G(AND(F('lt',F('len',P('records')),1000),F('eq',F('len',P('response','result','totals')),F('len',P('params','metrics')))),'OZON_SHAPE')]
d['lets']=[LET('month',F('month',P('row','dimensions',0,'id')),'OZON_DIMENSION_UNQUALIFIED')]
d['row_asserts']=[G(AND(F('eq',F('len',P('row','dimensions')),1),F('eq',F('len',P('row','metrics')),F('len',P('params','metrics')))),'OZON_ROW_SHAPE'),G(AND(F('le',F('prefix',P('period','from'),7),P('v','month')),F('le',P('v','month'),F('prefix',P('period','to'),7))),'OZON_MONTH_COVERAGE')]
d['identity']=P('v','month');d['duplicate_code']=d['page_duplicate_code']='OZON_MONTH_COVERAGE'
d['map']={'values':selected_values(lambda m:at(P('row','metrics'),F('index',P('params','metrics'),m)))}
d['totals']=selected_values(lambda m:at(P('response','result','totals'),F('index',P('params','metrics'),m)))
d['dataset_asserts']=[G(F('eq',sum_values(),P('totals')),'OZON_TOTAL_MISMATCH')];recipes['ozon']['error_code']='OZON_SCHEMA'
# WB order cohorts: one source returns both current/previous.
req={'selectedPeriod':{'start':P('period','from'),'end':P('period','to')},'nmIds':D(['filters','nm_ids'],[]),'brandNames':[],'subjectIds':[],'tagIds':[],'skipDeletedNm':False,'orderBy':{'field':'orderSum','mode':'desc'},'limit':1000,'offset':D(['progress','offset'],0)}
request=F('merge',req,IF(F('ne',D(['params','comparison'],None),None),{'pastPeriod':{'start':P('params','comparison','from'),'end':P('params','comparison','to')}},{}))
props={'selectedPeriod':schema({'start':DATE,'end':DATE}),'nmIds':{'type':'array','items':INT},'brandNames':ARR,'subjectIds':{'type':'array','items':INT},'tagIds':{'type':'array','items':INT},'skipDeletedNm':BOOL,'orderBy':schema({'field':STR,'mode':STR}),'limit':INT,'offset':INT,'pastPeriod':schema({'start':DATE,'end':DATE})}
s=source('wb_orders','wb',reg['recipes']['wb']['url'],'POST',request,schema(props,[k for k in props if k!='pastPeriod']),P('response','data','products'),currency=P('response','data','currency'),mode='offset');s['options'].update(currency_code='WB_SHAPE_CURRENCY',currency_changed_code='WB_CURRENCY_CHANGED',allow_null_currency=False)
s['interval']=21;s['daily_limit']=48;d=s['response']
d['identity']=F('positive_integer',P('row','product','nmId'));d['duplicate_code']=d['page_duplicate_code']='WB_DUPLICATE_PRODUCT'
d['row_asserts']=[G(F('eq',P('row','statistic','selected','period'),{'start':P('period','from'),'end':P('period','to')}),'WB_PERIOD'),G(IF(F('ne',D(['params','comparison'],None),None),F('eq',P('row','statistic','past','period'),{'start':P('params','comparison','from'),'end':P('params','comparison','to')}),True),'WB_PERIOD')]
# Validate every financial field even on an excluded item, matching old fail-closed behavior.
d['lets']=[LET('values',fields_values(P('row','statistic','selected')),'WB_SCHEMA'),LET('previous',IF(F('ne',D(['params','comparison'],None),None),fields_values(P('row','statistic','past')),{}),'WB_COMPARISON_SCHEMA')]
d['include']=AND(OR(F('eq',D(['filters','nm_ids'],[]),[]),F('in',P('row','product','nmId'),D(['filters','nm_ids'],[]))),F('not',F('in',P('row','product','nmId'),D(['filters','exclude_nm_ids'],[]))),IF(F('ne',D(['filters','brands'],[]),[]),F('in',F('brand',P('row','product','brandName')),P('filters','brands')),True))
d['map']={'values':P('v','values'),'previous_values':P('v','previous')};recipes['wb']['output']['previous_values']=IF(F('ne',D(['params','comparison'],None),None),sum_values('previous_values'),{});recipes['wb']['error_code']='WB_SCHEMA'
# Expense sources use the same map/reduce primitives, source-specific fields remain data.
for key in ('ozon_ads','wb_ads'):
 r=reg['recipes'][key];platform=recipes[key]['platform'];op=r['operation'];is_o=platform=='ozon'
 req={'dateFrom':P('period','from'),'dateTo':P('period','to')} if is_o else {'from':P('period','from'),'to':P('period','to')}
 s=source(op,platform,r['url'],'GET',req,schema({k:DATE for k in req}),P('response','rows') if is_o else P('response'),size=20000)
 s['interval']=2;s['daily_limit']=100;d=s['response'];d['options']={} if False else d.get('options',{})
 d.pop('options',None)
 if is_o:
  d['identity']=F('hash',[F('nonempty',P('row','id')),P('row','date')]);d['duplicate_code']=d['page_duplicate_code']='ADS_DUPLICATE'
  d['lets']=[LET('day',F('day',P('row','date')),'ADS_SCHEMA')]
 else:
  d['lets']=[LET('day',F('optional_event_day',D(['row','updTime'],None),'Europe/Moscow'),'ADS_DATE_TIMEZONE')]
  d['row_asserts']=[G(F('eq',P('row','currency'),P('store','currency')),'ADS_CURRENCY_CHANGED'),G(F('gt',P('row','advertId'),0),'ADS_ID')]
 d['row_asserts'].append(G(IF(F('eq',P('v','day'),None),True,AND(F('le',P('period','from'),P('v','day')),F('le',P('v','day'),P('period','to')))),'ADS_PERIOD'))
 d['map']={'values':F('pairs_object',MAP(P('params','metrics'),'metric',[P('metric'),F('decimal_comma',at(P('row'),at(P('params','fields'),P('metric'))))]))}
 recipes[key]['error_code']='ADS_SCHEMA'
# Financial total contains nested collections; all transforms are data expressions.
key='ozon_finance';r=reg['recipes'][key]
s=source(key,'ozon',r['url'],'POST',{'date_from':P('period','from'),'date_to':P('period','to')},schema({'date_from':DATE,'date_to':DATE}),[P('response')]);s['options'].update(allow_null_currency=False,currency_code='FINANCE_CURRENCY',currency_changed_code='FINANCE_CURRENCY_CHANGED');d=s['response']
def money(expr):return F('checked',F('decimal',at(expr,'value')),F('eq',at(expr,'currency_code'),P('store','currency')),'FINANCE_CURRENCY_CHANGED')
services=MAP(P('row','cashflows','services'),'service',{'name':F('nonempty',P('service','name')),'amount':money(P('service','amount'))})
d['lets']=[LET('services',services,'OZON_FINANCE_SCHEMA')]
d['row_asserts']=[G(F('distinct',MAP(P('v','services'),'entry',P('entry','name'))),'OZON_FINANCE_SERVICE_DUPLICATE')]
def cost(names):return F('negate',F('sum_values',MAP(FLT(P('v','services'),'entry',F('in',P('entry','name'),names)),'costrow',P('costrow','amount'))))
vals={'finance_sales':money(P('row','cashflows','sales','amount')),'finance_storage_cost':cost(['product_placement_in_ozon_warehouses','temporary_placement_agent']),'finance_logistics_cost':cost(['logistics','reverse_logistics']),'finance_commission_cost':F('negate',F('add_numbers',money(P('row','cashflows','sales','fee')),money(P('row','cashflows','returns','fee')))),'finance_acquiring_cost':cost(['acquiring']),'finance_return_amount':money(P('row','cashflows','returns','amount')),'finance_accrued':money(P('row','total','accrued')),'finance_payments':F('sum_values',MAP(P('row','total','payments'),'payment',money(P('payment')))),'finance_services_cost':F('negate',F('sum',P('v','services'),'amount')),'finance_opening_balance':money(P('row','total','opening_balance')),'finance_closing_balance':money(P('row','total','closing_balance'))}
d['lets'].append(LET('all_values',vals,'OZON_FINANCE_SCHEMA'))
d['map']={'values':selected_values(lambda m:at(P('v','all_values'),m)),'count':F('len',P('v','services'))}
recipes[key]['output']['rows']=F('count_integer',F('sum',P('rows'),'count'));recipes[key]['error_code']='OZON_FINANCE_SCHEMA'
# Daily financial documents with exact period coverage.
key='wb_finance';r=reg['recipes'][key]
fields={'finance_sales':'retailAmountSum','finance_storage_cost':'paidStorageSum','finance_logistics_cost':'deliveryServiceSum','finance_for_pay':'forPaySum','finance_acceptance_cost':'paidAcceptanceSum','finance_deductions':'deductionSum','finance_penalties':'penaltySum','finance_additional_payments':'additionalPaymentSum','finance_bank_scheduled':'bankPaymentSum'}
recipes[key]['fields']=fields
s=source(key,'wb',r['url'],'POST',{'dateFrom':P('period','from'),'dateTo':P('period','to'),'period':'daily','limit':1000,'offset':D(['progress','offset'],0)},schema({'dateFrom':DATE,'dateTo':DATE,'period':{'type':'string','enum':['daily']},'limit':INT,'offset':INT}),P('response'),mode='offset')
s['options'].update(currency_code='FINANCE_CURRENCY',currency_changed_code='FINANCE_CURRENCY_CHANGED',empty_statuses=[204]);d=s['response'];d['identity']=F('positive_integer',P('row','reportId'));d['duplicate_code']=d['page_duplicate_code']='WB_FINANCE_DUPLICATE'
d['row_asserts']=[G(F('eq',P('row','currency'),P('store','currency')),'FINANCE_CURRENCY_CHANGED'),G(AND(F('eq',P('row','dateFrom'),P('row','dateTo')),F('le',P('period','from'),P('row','dateFrom')),F('le',P('row','dateTo'),P('period','to'))),'WB_FINANCE_PERIOD')]
d['map']={'day':F('day',P('row','dateFrom')),'values':fields_values(P('row'))}
d['dataset_asserts']=[G(F('days_cover',P('rows'),'day',P('period','from'),P('period','to')),'FINANCIAL_REPORT_NOT_READY')];recipes[key]['error_code']='WB_FINANCE_SCHEMA'
# Product stock cursor with declared total.
key='ozon_stocks';r=reg['recipes'][key]
request=F('merge',{'filter':{},'limit':1000},IF(F('ne',D(['progress','cursor'],None),None),{'cursor':P('progress','cursor')},{}))
s=source(key,'ozon',r['url'],'POST',request,schema({'filter':EMPTY,'limit':INT,'cursor':STR},['filter','limit']),P('response','items'),mode='cursor_total');s['interval']=2;s['daily_limit']=100;d=s['response'];d['currency']=None
d['totals']=D(['response','total_items'],P('response','total'));d['totals_changed_code']='OZON_STOCK_TOTAL_CHANGED'
d['root_asserts']=[G(IF(AND(F('ne',D(['response','total'],None),None),F('ne',D(['response','total_items'],None),None)),F('eq',P('response','total'),P('response','total_items')),True),'OZON_STOCK_TOTAL_CHANGED')]
d['identity']=F('positive_integer',P('row','product_id'));d['duplicate_code']=d['page_duplicate_code']='OZON_STOCK_DUPLICATE'
d['pagination']['cursor']=D(['response','cursor'],None);d['pagination']['stalled_code']='OZON_STOCK_CURSOR'
d['lets']=[LET('stocks',MAP(P('row','stocks'),'stock',{'type':F('checked',P('stock','type'),F('in',P('stock','type'),['fbo','fbs']),'OZON_STOCK_TYPE_OR_DUPLICATE'),'sku':P('stock','sku'),'shipment':P('stock','shipment_type'),'present':F('natural',P('stock','present')),'reserved':F('natural',P('stock','reserved'))}),'OZON_STOCK_ROW')]
d['row_asserts']=[G(F('distinct',MAP(P('v','stocks'),'stock',[P('stock','type'),P('stock','sku'),P('stock','shipment')])),'OZON_STOCK_TYPE_OR_DUPLICATE')]
vals={}
for kind in ['fbo','fbs']:
 for metric,field in [('units','present'),('reserved','reserved')]:vals['stock_'+kind+'_'+metric]=F('sum',FLT(P('v','stocks'),'stock',F('eq',P('stock','type'),kind)),field)
d['lets'].append(LET('all_values',vals,'OZON_STOCK_ROW'));d['map']={'values':selected_values(lambda m:at(P('v','all_values'),m))};recipes[key]['error_code']='OZON_STOCK_SCHEMA'
# One generic state machine, declared phases and captures.
base='https://seller-analytics-api.wildberries.ru/api/v1/warehouse_remains'
UUID={'type':'string','format':'uuid','max_length':36,'min_length':36}
for phase,url,request,payload in [('create',base,{'locale':'ru','groupByNm':'true'},schema({'locale':{'type':'string','enum':['ru']},'groupByNm':{'type':'string','enum':['true']}})),('status',base+'/tasks/{task_id}/status',{'task_id':P('progress','task_id')},schema({'task_id':UUID})),('download',base+'/tasks/{task_id}/download',{'task_id':P('progress','task_id')},schema({'task_id':UUID}))]:
 s=source('wb_stocks_'+phase,'wb',url,'GET',request,payload,P('response') if phase=='download' else [],size=20000);s['response']['currency']=None;s['daily_limit']=120 if phase=='status' else 30;s['interval']=5 if phase=='status' else 61
 if phase!='create':s['options']['path_fields']=['task_id']
 if phase=='download':s['options']['empty_statuses']=[204]
d=sources['wb_stocks_download']['response'];d['identity']=F('positive_integer',P('row','nmId'));d['duplicate_code']=d['page_duplicate_code']='WB_STOCK_DUPLICATE'
d['lets']=[LET('warehouses',MAP(P('row','warehouses'),'warehouse',{'name':F('nonempty',P('warehouse','warehouseName')),'quantity':F('natural',P('warehouse','quantity'))}),'WB_STOCK_ROW')]
d['row_asserts']=[G(F('distinct',MAP(P('v','warehouses'),'warehouse',P('warehouse','name'))),'WB_STOCK_WAREHOUSE_DUPLICATE')]
def warehouse_total(names,include=True):return F('sum',FLT(P('v','warehouses'),'warehouse',F('in',P('warehouse','name'),names) if include else F('not',F('in',P('warehouse','name'),names))),'quantity')
special=['Всего находится на складах','В пути до получателей','В пути возвраты на склад WB']
d['row_asserts'].append(G(F('eq',warehouse_total(special,False),warehouse_total(special[:1])),'WB_STOCK_TOTAL_MISMATCH'))
vals={'stock_fbo_units':warehouse_total(special[:1]),'stock_to_customer':warehouse_total(special[1:2]),'stock_return_transit':warehouse_total(special[2:])}
d['lets'].append(LET('all_values',vals,'WB_STOCK_ROW'));d['map']={'values':selected_values(lambda m:at(P('v','all_values'),m))}
recipes['wb_stocks']['error_code']='WB_STOCK_SCHEMA'
recipes['wb_stocks']['workflow']={'initial':'create','steps':{
 'create':{'operation':'wb_stocks_create','capture':{'phase':'status','task_id':F('uuid',P('response','data','taskId')),'polls':0},'guards':[],'error':'PROVIDER_TASK_ID','final':False},
 'status':{'operation':'wb_stocks_status','capture':{'phase':IF(F('eq',P('response','data','status'),'done'),'download','status'),'task_id':F('uuid',P('response','data','id')),'polls':F('integer_add',P('progress','polls'),1)},'guards':[G(F('eq',F('uuid',P('response','data','id')),P('progress','task_id')),'PROVIDER_TASK_MISMATCH'),G(F('in',P('response','data','status'),['new','processing','done','canceled','purged']),'PROVIDER_TASK_STATE'),G(F('not',F('in',P('response','data','status'),['canceled','purged'])),'PROVIDER_REPORT_UNAVAILABLE'),G(F('lt',P('progress','polls'),120),'PROVIDER_REPORT_NOT_READY')],'error':'WB_STOCK_SCHEMA','final':False},
 'download':{'operation':'wb_stocks_download','capture':None,'guards':[],'error':'WB_STOCK_SCHEMA','final':True}}}
# Current monetary balance.
key='wb_balance';r=reg['recipes'][key];s=source(key,'wb',r['url'],'GET',{},EMPTY,[P('response')],currency=P('response','currency'));s['options'].update(allow_null_currency=False,currency_code='FINANCE_CURRENCY',currency_changed_code='FINANCE_CURRENCY_CHANGED');s['response']['map']={'values':fields_values(P('row'))};recipes[key]['error_code']='BALANCE_SCHEMA'
# Confidential, short-lived token grant; data bindings never leave transport.
op='ozon_ads_token';s=source(op,'ozon','https://api-performance.ozon.ru/api/client/token','POST',{},EMPTY,[]);s['interval']=2;s['daily_limit']=100;s['auth']={'headers':{},'claims':None,'body':{'client_id':P('credentials','performance_client_id'),'client_secret':P('credentials','performance_client_secret'),'grant_type':'client_credentials'}}
sources['ozon_expense']['auth']={'headers':{'Authorization':F('concat','Bearer ',P('ephemeral','token'))},'claims':None}
auth={'performance':{'operation':op,'token_path':['access_token'],'expires_path':['expires_in'],'min_ttl':60,'max_ttl':86400,'refresh_margin':60,'schema_error':'PERFORMANCE_TOKEN_SCHEMA','missing_error':'PERFORMANCE_AUTH_REQUIRED'}}
recipes['ozon_ads']['auth_profile']='performance'
for priority,(key,r) in enumerate(recipes.items()):
 r['priority']=priority
 r.setdefault('auth_profile',None)
 r['comparison_error']='WB_COMPARISON_SCHEMA' if r['operation']=='wb_orders' else r['error_code']
 if r['workflow']:r['workflow'].update(max_steps=128,limit_error='PROVIDER_REPORT_NOT_READY')
 # preserve existing explicitly reviewed source rates
 primary=sources[r['operation']];legacy=reg['recipes'][key]
 primary['interval']=legacy['min_interval'];primary['daily_limit']=legacy['daily_limit']
# Endpoints/normalization data + planning/workflow data are independent of Python.
(ROOT/'scalar_source_catalog.json').write_text(json.dumps({'schema':'alice-source-matrix/v2','version':'20261104-scalar-r1','origins':origins,'sources':sources},ensure_ascii=False,indent=2)+'\n')
(ROOT/'scalar_catalog.json').write_text(json.dumps({'schema':'alice-scalar-catalog/v1','version':'20261104-r1','recipes':recipes,'auth_profiles':auth},ensure_ascii=False,indent=2)+'\n')
print('WROTE',len(sources),'operations',len(recipes),'families')
