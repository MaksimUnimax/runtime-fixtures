# RT-JOB-R01.1 — runtime-side integration handoff

Дата: 04.11.2026. Статус: **READY_FOR_INTEGRATION_REVIEW (runtime only, offline)**.
Рабочая версия Alisa остаётся `20261104-v010-scalar-matrix-r4`. Этот пакет НЕ установлен и не открывает production listener.

## Основания и граница владельцев

Точное основание: пакет `ALISA_IMPLEMENTATION_DOCS_v0.5_2026-11-04(1).zip`, SHA256 `704e24651509a26189fa82cd7bfb56be91fd81c3472e6f0b4d56ea4e5ed4ef7d`; API_AND_EVENTS §3; ROADMAP AL-S07; runtime_task_v1.schema.json; AL-T06-01/03/04/05, AL-N07-01/02/03. Пакет документации прошёл manifest/validate_pack. Исходный runtime ZIP: `ALISA_MATRIX_0.10_R4_DEPLOYED_2026-11-04.zip`.

Автор этой поставки владеет только матрицей, исполнителем и runtime-стороной порта. Не изменены products/alisa, platform adapter, identity/OIDC, BFF/web/admin, PostgreSQL, platform STATUS/roadmap, TLS/DNS, OAuth, ключи, реестр API, формулы и рабочая конфигурация. AL-S07 как полный продуктовый шаг НЕ принят: настоящий кабинет и совместный путь требуют зависимостей AL-S04–06 и работы второго исполнителя.

В предыдущем оборванном продолжении в Git найдены только scope и строгий validator. Законченная реализация/проверки порта не найдены в сохранённых доступных каталогах; они реализованы заново в этой поставке от проверенного baseline, не объявлены восстановленным прежним PASS.

## Поставленные операции

| Операция | Поведение |
|---|---|
| current_versions | Версия контракта, SHA схемы и каталогов, версия языка и проекции; только разрешённый peer |
| capabilities | Аутентификация контекста, точный список реализованных возможностей |
| submit | Принятие utterance через существующий Engine/Repository/Worker; durable UUID job_ref |
| status | Состояние по конкретному job_ref; не по глобальному голосовому указателю |
| read_result | Все сохранённые страницы с expiry, без нового расчёта/HTTP и изменения голосовой страницы |
| cancel | Отмена только по конкретному ref; идемпотентный эффект; уже отправленное внешнее действие отменить не обещает |

Открыто: `template`-submit, remote `revoke_scope`, произвольные timezone. capabilities сообщает эти ограничения. Известная schema не гарантирует возможность исполнения: поддержанный текст ограничен прежним ядром 1200 символами, timezone — Europe/Moscow. Неподдержанные виды возвращают CAPABILITY_UNAVAILABLE, не переводятся в другую фразу. Для широких голосовых уточнений остаётся существующий dialogue-контур; R01 принимает квалифицированный законченный вопрос, а не закрывает всю платформенную беседу.

## Authority — обязательный стык второго исполнителя

Поставляется Protocol, НЕ permissive production verifier и НЕ собственный issuer. Необходимо предоставить:

```python
class Authority:
    def verify(self, ticket: str, service_id: str) -> dict:
        # Верифицировать issuer/signature/audience/product/revocation/срок.
        # Вернуть проверенные поля context БЕЗ execution_ticket,
        # плюс product_id='alisa_market'.
        ...

    def resolve(self, pins: dict, action: str) -> Scope:
        # Проверить актуальный grant, account block, security/access revisions,
        # выбранные магазины, credential/scope revisions, catalog assignment.
        # Вернуть точное доверенное отображение публичных UUID в runtime Scope.
        ...
```

`resolve` вызывается с submit/status/read_result/cancel/capabilities и execute. В execute нет старого приёмочного ticket/not_after: естественное истечение короткого ticket после durable acceptance не означает отзыв grant. Актуальная authority по nonsecret pins всё равно обязательна. При новом чтении/status/cancel нужен свежий действующий ticket.

Scope — существующий тип `semantics.Scope`, а не публичные UUID, автоматически принятые как runtime IDs. Платформенные revisions не приводятся в строковые runtime revisions по догадке. Число отображённых магазинов должно совпасть; изменения mapping отзывают прежний guard даже при ошибочно неизменённой внешней revision.

Ошибка authority → DEPENDENCY_UNAVAILABLE/отказ; отсутствующая authority → AUTH_REQUIRED. JSON shape сам по себе не подтверждает ticket. Product отсутствует в schema v0.5: он привязан к серверной Peer service identity и подтверждённым claims; клиентское лишнее поле product_id отклоняется.

Authority должна давать ограниченный по времени ответ и fail-closed при недоступности. Настоящий issuer, live-authority latency и межхостовый mTLS этой поставкой не реализованы и не испытаны.

## Подключение без двух конкурирующих исполнителей

1. Проверить pinned runtime/схему/версию каталогов; подготовить доверенные verify/resolve и явное catalog_release_id.
2. Создать RuntimePort на **том же Engine**, который использует один Worker. Порт устанавливает execution_policy. Нельзя запускать новый порт против live SQLite вместе с прежним worker, который не знает guard.
3. Новый Unix listener отдельно от прежнего голосового gateway. Явные allowed_uid и service_id; нет trust из поля JSON, нет режима отключения проверки peer, нет автозапуска при import.
4. Клиент platform adapter вызывает IPC по контракту ниже. Он не пишет runtime SQLite и не импортирует ядро для собственной аналитики.
5. Только после совместной квалификации — интеграционный выпуск. В этом пакете нет установщика, изменения systemd или configuration bypass.

Минимальная композиция (с уже подготовленными repo/transport/authority, не самодостаточный production startup):

```python
engine = Engine(repo, legacy_scope_for, table_capabilities=current_capabilities)
port = RuntimePort(engine, authority,
                   catalog_release_id=assigned_release_id,
                   service_id=approved_service_id)
worker = Worker(engine, transport)
server = runtime_port_ipc.Gateway(new_socket_path, port,
                                 allowed_uid=approved_platform_uid,
                                 service_id=approved_service_id)
```

Действующий legacy gateway и его методы сохранены. Старое ядро без authority не сможет отправить защищённый job: обязательный guard отклоняет dispatch. Базовые аналитические рецепты остаются в JSON; никаких новых функций под Ozon/WB не добавлено.

## Wire-контракт R01

Один bounded JSON line (до 256 КиБ); ответ до 512 КиБ. Linux Unix socket SO_PEERCRED; не более 8 одновременных обработчиков по умолчанию, диапазон 1–32. Существующий socket/path автоматически не удаляется. Неизвестные поля/операции/версии отклоняются.

```json
{"schema_version":"runtime_port_v1","operation":"submit","payload":{}}
```

Для submit payload — **целый runtime_task_v1**, согласно приложенной неизменённой схеме. Для capabilities — `{context}`; status/read_result — `{job_ref,context}`; cancel — `{job_ref,context,request_id}`; current_versions — пустой object. Контекст строго тот же schema v0.5.

Успех `{ok:true,data:...}`; ошибка `{ok:false,error:{code,message,trace_id,retryable:false}}`. Это IPC, не public HTTP: платформенный adapter отображает, например, RESULT_EXPIRED в HTTP 410, NOT_FOUND в безопасный 404, IDEMPOTENCY_CONFLICT в 409. Внутренние исключения/адреса/произвольный provider text не выдаются.

Submit receipt: schema_version runtime_acceptance_v1, UUID job_ref, logical_query_id, state ACCEPTED, accepted_at, trace_id. Это durable принятие, не фиктивный READY. Status читает текущее состояние. Read_result возвращает schema_version runtime_result_v1, job_ref/state, expires, fetched_at, complete и pages; не возвращает внутренние store IDs/сырые строки. Read не пересчитывает истёкший отчёт, не вызывает модель/маркетплейс, не изменяет page/delivered/pointer голосового режима.

UNKNOWN → UNKNOWN_OUTCOME, retryable=false. Сетевой обрыв клиента может произойти уже после durable acceptance: повторять тот же request_id с тем же смыслом, не создавать новый ID вслепую. Статус/чтение идут только по разрешённому ref.

## Идемпотентность и права

Ключ — tenant+actor+request_id. Fingerprint включает query, logical_query_id и закреплённые claims/mapping/catalog; не включает обновляемый ticket/not_after/trace. Обновление ticket не создаёт расчёт заново. Изменённое тело — IDEMPOTENCY_CONFLICT. Тот же logical_query_id с другим request_id сохраняет ref; изменённый вопрос в том же logical id отклоняется. Явный новый расчёт использует новый logical id/request id и предусмотренное ядром refresh.

Публичные refs отделены от внутренних canonical/alias jobs. Разные actors не разделяют guard/cache. Совместимые повторные запросы одного scope могут ссылаться на один полный exact-ready результат. Отмена общего canonical job тогда видна его refs; нельзя отменой одного ref создать второй скрытый расчёт.

Проверки перед началом worker, непосредственно перед каждым физическим dispatch и перед публикацией/выдачей. Credentials/revisions проверяет authority; cache hit не обходит проверку. Есть отрицательные тесты отзыва между страницами и после transport.prepare, до реального dispatch. Уже начатый HTTP физически не отменяется задним числом; его результат после отмены/отзыва не публикуется.

## Хранение

В новых rt_job_refs — только UUID/ссылки/хеши/время. В rt_job_receipts — небольшие acceptance/cancel receipts, без отчёта, исходного текста или ticket. Никакая execution_ticket строка не сохраняется в jobs/SQLite/WAL и не передаётся LLM/provider.

Полный query остаётся в прежнем jobs.draft на прежний TTL; guard содержит лишь nonsecret claims/revisions. Новые metadata очищаются через уже существующий retention.sweep: срок повторов 24 часа, bounded batch, предел 100000 записей/таблицу и 5000 на tenant плюс прежний лимит используемой БД. Активный job и alias на активный canonical job не удаляются. Ошибка старого дизайна очистки для такого alias устранена рекурсивной проверкой (глубина ограничена). UNKNOWN не превращается в новый автоматический вызов после очистки payload.

## Проверки

`python3 -B run_checks.py` из чистой копии: **800/800 = 717 прежних + 83 новых**, ошибок/пропусков нет, TCP/DNS attempts=0. 12 прежних test-файлов неизменны побайтово. Schema/две исходные fixtures скопированы из пользовательского v0.5 без изменения.

Новые тесты: строгая форма/продукт/peer/claims; отсутствие verifier; UUID/mapping/ревизии; повтор/concurrency/rollback; read/cancel точного ref; P2; cache; restart; отмена/отзыв до и после dispatch; UNKNOWN; expiry; удаление payload/metadata; active-alias retention; настоящий локальный IPC; потеря ответа; размер; запрет приватных ошибок; отсутствие ticket в SQLite/WAL.

Authority и provider в этих проверках **искусственные**, SQLite/worker/queue/Unix IPC настоящие. Никаких новых реальных API-запросов, live-config изменений, новых таблиц в рабочей БД, listener или платформенной приёмки этим тестом не выполнено. Серверный stage, если создан, — отдельная копия исходников, не установка.

## Открытые стыки

От второго исполнителя требуются service identity/UID, настоящее verify/resolve, явная mapping/capability policy, catalog assignment, adapter и общий staging-путь. Следующая совместная приёмка AL-S07: Алиса принимает реальный вопрос → этот RuntimePort → тот же ref открывается в кабинете без новых бизнес-вызовов. До неё статус всего AL-S07 не изменять.
