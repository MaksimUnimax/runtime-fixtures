"""Reproducible offline acceptance: block all TCP/DNS, allow local Unix IPC only."""
import json
import socket
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

attempts=[]
original_connect=socket.socket.connect
original_connect_ex=socket.socket.connect_ex

def connect(sock,address):
    if sock.family in (socket.AF_INET,socket.AF_INET6):
        attempts.append('TCP_CONNECT')
        raise AssertionError('External networking forbidden in offline checks')
    return original_connect(sock,address)

def connect_ex(sock,address):
    if sock.family in (socket.AF_INET,socket.AF_INET6):
        attempts.append('TCP_CONNECT_EX')
        raise AssertionError('External networking forbidden in offline checks')
    return original_connect_ex(sock,address)

def deny_dns(*args,**kwargs):
    attempts.append('DNS')
    raise AssertionError('DNS forbidden in offline checks')

if __name__=='__main__':
    with patch.object(socket.socket,'connect',connect), patch.object(socket.socket,'connect_ex',connect_ex), patch.object(socket,'getaddrinfo',deny_dns):
        suite=unittest.defaultTestLoader.discover(str(Path(__file__).with_name('tests')))
        result=unittest.TextTestRunner(verbosity=2).run(suite)
    record={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
            'skipped':len(result.skipped),'forbidden_network_attempts':len(attempts),
            'external_api_calls':0,'mode':'OFFLINE_TCP_DNS_BLOCKED_UNIX_IPC_ALLOWED'}
    print(json.dumps(record,ensure_ascii=False))
    sys.exit(0 if result.wasSuccessful() and not attempts else 1)
