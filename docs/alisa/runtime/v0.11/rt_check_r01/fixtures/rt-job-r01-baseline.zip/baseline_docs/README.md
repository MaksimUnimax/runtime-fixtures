# Octoport Market / Alisa — installed matrix runtime 0.10 r4

Installed on Alisa on 2026-11-04 09:05:47 UTC. Read ACCEPTANCE_R4.md first.
This is the voice-service project, not the separate browser extension.

## Reproduce the included offline baseline
From this directory with Python 3:
```
python3 -B architecture_gate.py
python3 -B run_checks.py
```
No real credentials or external networking are required for these tests.
The baseline comprises 717 tests. Additional exact 21-test proof/source location
is documented in ADDITIONAL_TESTS_21_PROOF.json and ACCEPTANCE_R4.md.

Source data/catalog authoring:
`python3 -B tools/build_scalar_matrix.py` regenerates the included scalar JSON
catalogues from the reviewed definitions; it is a developer authoring tool,
not part of per-question execution.

Do not deploy from config examples or assign LIVE_VERIFIED by copying fixtures.
Existing credentials, account scopes, API qualification, read-only canary and
source-version checks remain mandatory. No installer or private configuration
is included in this package. Active server configuration is managed separately.

DEPLOY_EXPECTED_HASHES.json matches the 31 installed runtime files.
MANIFEST.json covers this entire artifact. No fonts, credentials, financial raw
bodies, production SQLite databases or access tokens are distributed.
