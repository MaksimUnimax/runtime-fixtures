globalThis.__SELLER_AGENTS_PACKAGED_CONFIG__="{\"environment\":\"PREPRODUCTION\",\"controlApiOrigin\":\"https://api.octoport.ru\",\"portalOrigin\":\"https://app.octoport.ru\",\"extensionVersion\":\"0.2.37\",\"contractVersion\":\"control_plane_v2\",\"trustBundle\":{\"algorithm\":\"Ed25519\",\"fingerprintAlgorithm\":\"sha256\",\"fingerprintEncoding\":\"lowercase_hex\",\"keys\":[{\"fingerprintSha256\":\"edc47821df296868c7061069ed50fa742f70a75889bd010dadef5166fadc4645\",\"keyId\":\"octoport-preprod-2026-09-19\",\"lifecycle\":\"ACTIVE\",\"publicKey\":\"MCowBQYDK2VwAyEAyljM6ud9vS/fyIX8YCK6AbJGO7tR1ct+5F0HM3T3G9c=\",\"trustEligibility\":\"SIGNING_AND_VERIFICATION\"}],\"publicKeyEncoding\":\"base64\",\"publicKeyFormat\":\"spki_der\",\"trustBundleVersion\":\"bootstrap_trust_bundle_v1\"}}";
/* Store package requires the build-time packaged authority; no development fallback. */
(() => {
  "use strict";
  const override = globalThis.__SELLER_AGENTS_PACKAGED_CONFIG__;
  if (!override) throw new Error("PACKAGED_CONFIG_REQUIRED");
  const value = typeof override === "string" ? JSON.parse(override) : override;
  globalThis.SellerAgentsControlConfig = Object.freeze(value);
})();

;
/* Data-only prompt trees. No provider API, Send, DOM profiles or access grants. */
(() => {
  "use strict";
  const FORMAT = "octoport_prompt_tree_v1", KEY = "octoport_prompt_trees_v1";
  const id = value => typeof value === "string" && /^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}$/.test(value);
  const clone = value => JSON.parse(JSON.stringify(value));
  const exact = (value, keys) => value && typeof value === "object" && !Array.isArray(value) &&
    Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value,key));
  const failure = code => Object.assign(new Error(code),{code});
  function validateBody(body) {
    if (!exact(body,["format","root","nodes"]) || body.format !== FORMAT || !Array.isArray(body.nodes) || body.nodes.length > 128 ||
      new TextEncoder().encode(JSON.stringify(body)).length > 65536 || (body.root !== null && !id(body.root))) return false;
    const nodes = new Map();
    for (const node of body.nodes) {
      if (!exact(node,["id","text","children"]) || !id(node.id) || nodes.has(node.id) || typeof node.text !== "string" ||
        node.text.length > 8192 || !Array.isArray(node.children) || node.children.length > 64 || !node.children.every(id)) return false;
      nodes.set(node.id,node);
    }
    if (body.root === null) return body.nodes.length === 0;
    const seen = new Set();
    const visit = key => {
      if (seen.has(key) || !nodes.has(key)) return false;
      seen.add(key);return nodes.get(key).children.every(visit);
    };
    return visit(body.root) && seen.size === nodes.size;
  }
  function canonicalBody(body) {
    if (!validateBody(body)) throw failure("AI_TREE_INVALID_BODY");
    return JSON.stringify({format:body.format,root:body.root,nodes:[...body.nodes]
      .sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0).map(n=>({id:n.id,text:n.text,children:[...n.children]}))});
  }
  async function digest(body) {
    const value = await crypto.subtle.digest("SHA-256",new TextEncoder().encode(canonicalBody(body)));
    return [...new Uint8Array(value)].map(x=>x.toString(16).padStart(2,"0")).join("");
  }
  function render(body) {
    if (!validateBody(body) || !body.root) throw failure("AI_TREE_NOT_PUBLISHED");
    const byId = new Map(body.nodes.map(node=>[node.id,node]));
    const lines=[];
    const visit=(key,depth)=>{const n=byId.get(key);lines.push(`${"  ".repeat(depth)}${n.text}`);n.children.forEach(child=>visit(child,depth+1));};
    visit(body.root,0);return lines.join("\n\n");
  }
  function createCache({storage,verifier,trustBundle,authorize,fetchManifest,now=()=>Date.now(),intervalMs=6*60*60*1000}) {
    let state=null,loadFlight=null,writer=Promise.resolve(),storageFailed=false;
    const flights=new Map();
    const aliasKey=(ctx,detected)=>JSON.stringify([ctx.origin,ctx.accountId,detected.family,detected.surface,detected.variant??null]);
    const entryKey=(ctx,aiId)=>JSON.stringify([ctx.origin,ctx.accountId,aiId]);
    async function load() {
      if(state)return;
      if(!loadFlight)loadFlight=(async()=>{
        const saved=(await storage.get(KEY))[KEY];
        if(saved && (!exact(saved,["schema","entries","aliases"]) || saved.schema!==1 ||
          !saved.entries || !saved.aliases || Array.isArray(saved.entries) || Array.isArray(saved.aliases)))throw failure("AI_TREE_CACHE_CORRUPT");
        state=saved?clone(saved):{schema:1,entries:{},aliases:{}};
      })().finally(()=>{loadFlight=null;});
      await loadFlight;
    }
    async function stillCurrent(detected,ctx) {
      const current=await authorize(detected);
      if(!current || JSON.stringify(current)!==JSON.stringify(ctx))throw failure("AI_TREE_CONTEXT_CHANGED");
    }
    async function validateEntry(entry,ctx,detected) {
      if(!entry)return null;
      const verified=await verifier.verifyPromptTreeV1(entry.envelope,trustBundle);
      const claim=verified.payload,p=claim?.publication;
      if(!verified.ok || claim.accountId!==ctx.accountId || JSON.stringify(claim.detected)!==JSON.stringify(detected) ||
        !p?.body || claim.aiId!==entry.aiId || p.version!==entry.version || p.sha256!==entry.sha256 || entry.format!==p.format ||
        !validateBody(entry.body) || await digest(entry.body)!==p.sha256)throw failure("AI_TREE_CACHE_UNVERIFIED");
      return entry;
    }
    async function install(next,detected,ctx) {
      const run=async()=>{
        if(storageFailed)throw failure("AI_TREE_STORAGE_UNCONFIRMED");
        await stillCurrent(detected,ctx);
        const updated=clone(state),key=entryKey(ctx,next.aiId),old=updated.entries[key];
        if(old && (next.version<old.version || (next.version===old.version && next.sha256!==old.sha256)))throw failure("AI_TREE_VERSION_REGRESSION");
        updated.entries[key]=clone(next);updated.aliases[aliasKey(ctx,detected)]=next.aiId;
        if(new TextEncoder().encode(JSON.stringify(updated)).length>4*1024*1024)throw failure("AI_TREE_CACHE_LIMIT");
        try {
          await storage.set({[KEY]:updated});const readback=(await storage.get(KEY))[KEY];
          // Chrome storage may reorder object keys; values and array order must remain exact.
          if(!readback || verifier.canonicalJson(readback)!==verifier.canonicalJson(updated))throw failure("AI_TREE_STORAGE_READBACK_FAILED");
        }catch(error){storageFailed=true;throw error;}
        // A response cannot become usable through a logout/deny while storage was pending.
        await stillCurrent(detected,ctx);state=updated;
      };
      const pending=writer.then(run,run);writer=pending.catch(()=>{});return pending;
    }
    async function get(input,options={}) {
      const detected={family:input.family,surface:input.surface,variant:input.variant??null};
      const ctx=await authorize(detected);if(!ctx)throw failure("AI_TREE_ACCESS_REQUIRED");
      await load();const aiId=state.aliases[aliasKey(ctx,detected)];
      const candidate=aiId?state.entries[entryKey(ctx,aiId)]:null;
      if(candidate && candidate.aiId!==aiId)throw failure("AI_TREE_CACHE_ID_MISMATCH");
      const saved=await validateEntry(candidate,ctx,detected);
      if(options.offline || (!options.refresh && saved && Number.isFinite(saved.checkedAt) && now()>=saved.checkedAt && now()-saved.checkedAt<intervalMs)) {
        if(!saved)throw failure("AI_TREE_CACHE_MISSING");await stillCurrent(detected,ctx);return clone(saved);
      }
      const key=JSON.stringify([ctx,detected]);
      if(flights.has(key))return clone(await flights.get(key));
      const pending=(async()=>{
        const requestNonce=crypto.randomUUID();
        const envelope=await fetchManifest({detected,context:ctx,requestNonce,
          known:saved?{aiId:saved.aiId,version:saved.version,sha256:saved.sha256}:null});
        const verified=await verifier.verifyPromptTreeV1(envelope,trustBundle),claim=verified.payload;
        if(!verified.ok)throw failure(`AI_TREE_${verified.error}`);
        if(claim.requestNonce!==requestNonce || claim.accountId!==ctx.accountId || claim.deviceId!==ctx.deviceId || claim.sessionId!==ctx.sessionId ||
          JSON.stringify(claim.detected)!==JSON.stringify(detected))throw failure("AI_TREE_RESPONSE_MISMATCH");
        await stillCurrent(detected,ctx);
        if(!claim.publication)throw failure("AI_TREE_NOT_PUBLISHED");
        const p=claim.publication;
        const same=saved && saved.aiId===claim.aiId && saved.version===p.version && saved.sha256===p.sha256;
        const body=p.body ?? (same?saved.body:null);
        if(!body || !validateBody(body) || !body.root || await digest(body)!==p.sha256)throw failure("AI_TREE_HASH_MISMATCH");
        if(saved?.aiId===claim.aiId && (p.version<saved.version || (p.version===saved.version && p.sha256!==saved.sha256)))throw failure("AI_TREE_VERSION_REGRESSION");
        const next={aiId:claim.aiId,version:p.version,sha256:p.sha256,format:p.format,body:clone(body),
          envelope:p.body?clone(envelope):clone(saved.envelope),checkedAt:now()};
        await install(next,detected,ctx);return next;
      })();
      flights.set(key,pending);
      try{return clone(await pending);}finally{if(flights.get(key)===pending)flights.delete(key);}
    }
    async function validatePinned(input,pin) {
      const detected={family:input.family,surface:input.surface,variant:input.variant??null};
      const ctx=await authorize(detected);if(!ctx)throw failure("AI_TREE_ACCESS_REQUIRED");
      await load();
      if(!pin || state.aliases[aliasKey(ctx,detected)]!==pin.aiId)throw failure("AI_TREE_PIN_ID_MISMATCH");
      const verified=await validateEntry(pin,ctx,detected);
      await stillCurrent(detected,ctx);return clone(verified);
    }
    return Object.freeze({get,validatePinned});
  }
  globalThis.OctoportPromptTrees=Object.freeze({validateBody,canonicalBody,digest,render,createCache});
})();

;
/* Browser-only strict verifier for bootstrap_snapshot_v2. No Node imports. */
(() => {
  "use strict";
  const textEncoder = new TextEncoder();
  const DOMAIN = textEncoder.encode("product-control-plane/bootstrap-snapshot/v1\0");
  /* Must remain byte-for-byte compatible with StableMachineIdentifierV1. */
  const MACHINE = /^[a-z0-9][a-z0-9._-]*$/;
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  /* Browser-safe copy of packages/shared/src/index.ts SemVerV1Schema. */
  const SEMVER = /^(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)(?:-(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
  function semver(value) { return typeof value === "string" && value.length >= 1 && value.length <= 64 && SEMVER.test(value); }
  const B64URL = /^[A-Za-z0-9_-]+$/;
  const B64 = /^[A-Za-z0-9+/]+={0,2}$/;
  const hex = bytes => [...new Uint8Array(bytes)].map(x => x.toString(16).padStart(2, "0")).join("");
  function fail(error) { return { ok: false, error }; }
  function record(value) { return value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype; }
  function exact(value, keys) {
    if (!record(value)) return false;
    const expected = new Set(keys);
    return Object.keys(value).every(k => expected.has(k)) && Object.keys(value).length === expected.size;
  }
  function exactWithOptional(value, required, optional) {
    if (!record(value)) return false;
    const allowed = new Set(required.concat(optional));
    const actual = Object.keys(value);
    return actual.every(k => allowed.has(k)) && required.every(k => Object.hasOwn(value, k));
  }
  function b64url(value) {
    if (typeof value !== "string" || !value || !B64URL.test(value)) return null;
    try {
      const pad = value.length % 4 ? "=".repeat(4 - value.length % 4) : "";
      const bytes = Uint8Array.from(atob(value.replace(/-/g, "+").replace(/_/g, "/") + pad), c => c.charCodeAt(0));
      const encoded = b64urlEncode(bytes);
      return encoded === value ? bytes : null;
    } catch (_) { return null; }
  }
  function b64(value) {
    if (typeof value !== "string" || !value || !B64.test(value) || value.length % 4) return null;
    try { return Uint8Array.from(atob(value), c => c.charCodeAt(0)); } catch (_) { return null; }
  }
  function b64urlEncode(bytes) {
    let result = "";
    for (let i = 0; i < bytes.length; i += 0x8000) result += btoa(String.fromCharCode(...bytes.slice(i, i + 0x8000)));
    return result.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }
  function canonical(value) {
    if (value === null) return "null";
    if (typeof value === "boolean") return value ? "true" : "false";
    if (typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      if (!Number.isSafeInteger(value) || Object.is(value, -0)) throw new Error("NON_CANONICAL_NUMBER");
      return String(value);
    }
    if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
    if (record(value)) return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(",")}}`;
    throw new Error("INVALID_CANONICAL_VALUE");
  }
  /* JSON.parse silently accepts duplicate names. This small parser rejects
   * duplicates before parsing, then canonical byte equality rejects all other
   * spelling/ordering changes. */
  function parseStrictJson(source) {
    let i = 0;
    const ws = () => { while (/\s/.test(source[i] || "")) i++; };
    const string = () => {
      const start = i++; let escaped = false;
      while (i < source.length) {
        const c = source[i++];
        if (escaped) {
          escaped = false;
          if (c === "u") {
            if (!/^[0-9a-fA-F]{4}$/.test(source.slice(i, i + 4))) throw new Error("INVALID_JSON");
            i += 4;
          } else if (!/["\\/bfnrt]/.test(c)) throw new Error("INVALID_JSON");
          continue;
        }
        if (c === "\\") { escaped = true; continue; }
        if (c < " ") throw new Error("INVALID_JSON");
        if (c === '"') return JSON.parse(source.slice(start, i));
      }
      throw new Error("INVALID_JSON");
    };
    const value = () => {
      ws(); const c = source[i];
      if (c === '"') return string();
      if (c === "{") {
        i++; ws(); const out = Object.create(Object.prototype), seen = new Set();
        if (source[i] === "}") { i++; return out; }
        while (true) {
          ws(); if (source[i] !== '"') throw new Error("INVALID_JSON");
          const key = string(); if (seen.has(key)) throw new Error("DUPLICATE_FIELD"); seen.add(key);
          ws(); if (source[i++] !== ":") throw new Error("INVALID_JSON"); out[key] = value(); ws();
          if (source[i] === "}") { i++; return out; }
          if (source[i++] !== ",") throw new Error("INVALID_JSON");
        }
      }
      if (c === "[") {
        i++; ws(); const out = []; if (source[i] === "]") { i++; return out; }
        while (true) { out.push(value()); ws(); if (source[i] === "]") { i++; return out; } if (source[i++] !== ",") throw new Error("INVALID_JSON"); }
      }
      const match = source.slice(i).match(/^(true|false|null|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)/);
      if (!match) throw new Error("INVALID_JSON"); i += match[0].length; return JSON.parse(match[0]);
    };
    const result = value(); ws(); if (i !== source.length) throw new Error("INVALID_JSON"); return result;
  }
  function iso(value) { return typeof value === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/.test(value) && !Number.isNaN(Date.parse(value)); }
  function machine(value) { return typeof value === "string" && value.length <= 64 && MACHINE.test(value); }
  function detected(value) { return exact(value, ["family", "surface", "variant"]) && machine(value.family) && machine(value.surface) && (value.variant === null || machine(value.variant)); }
  function jsonObject(value) { return record(value) && Object.keys(value).length <= 128; }
  function ai(value) {
    if (!record(value) || typeof value.status !== "string") return false;
    if (value.status === "UNCONFIGURED") return exact(value, ["status"]);
    if (value.status === "UNAVAILABLE") return exact(value, ["status", "detected", "reason"]) && detected(value.detected) && ["UNSUPPORTED_DETECTED_AI", "AI_DISABLED", "NO_PROFILE", "PROFILE_INCOMPATIBLE"].includes(value.reason);
    if (value.status !== "RESOLVED" || !exact(value, ["status", "detected", "profile"]) || !detected(value.detected)) return false;
    const p = value.profile;
    return exact(p, ["profileKey", "revision", "scopeVariant", "schemaVersion", "contentSha256", "content", "compatibility"]) && machine(p.profileKey) && Number.isSafeInteger(p.revision) && p.revision > 0 && (p.scopeVariant === null || machine(p.scopeVariant)) && p.schemaVersion === "adapter_profile_v1" && /^[0-9a-f]{64}$/.test(p.contentSha256) && jsonObject(p.content) && jsonObject(p.compatibility);
  }
  const BROWSER_FAMILIES = ["chrome", "opera", "yandex_chromium", "firefox", "safari"];
  function localAi(value) {
    if (!record(value) || typeof value.status !== "string") return false;
    if (value.status === "UNCONFIGURED") return exact(value, ["status"]);
    if (!exact(value, ["status", "detected", "candidates"]) || value.status !== "CANDIDATES" || !detected(value.detected) || !Array.isArray(value.candidates) || value.candidates.length > BROWSER_FAMILIES.length) return false;
    const seen = new Set();
    return value.candidates.every(candidate => {
      if (!exact(candidate, ["browserFamily", "resolution"]) || !BROWSER_FAMILIES.includes(candidate.browserFamily) || seen.has(candidate.browserFamily)) return false;
      seen.add(candidate.browserFamily);
      const resolution = candidate.resolution;
      if (resolution?.status === "UNAVAILABLE") return exact(resolution, ["status", "reason"]) && ["UNSUPPORTED_DETECTED_AI", "AI_DISABLED", "NO_PROFILE", "PROFILE_INCOMPATIBLE"].includes(resolution.reason);
      if (resolution?.status !== "RESOLVED" || !exact(resolution, ["status", "profile"])) return false;
      const p = resolution.profile;
      return exact(p, ["profileKey", "revision", "scopeVariant", "schemaVersion", "contentSha256", "content", "compatibility"]) && machine(p.profileKey) && Number.isSafeInteger(p.revision) && p.revision > 0 && (p.scopeVariant === null || machine(p.scopeVariant)) && p.schemaVersion === "adapter_profile_v1" && /^[0-9a-f]{64}$/.test(p.contentSha256) && jsonObject(p.content) && jsonObject(p.compatibility);
    });
  }
  function localAuthority(value) {
    if (!exact(value, ["schemaVersion", "contractVersion", "compatibility", "featureRules", "ai"]) || value.schemaVersion !== "local_client_authority_v1" || value.contractVersion !== "control_plane_v2") return false;
    const compatibility = value.compatibility;
    if (!exact(compatibility, ["releases", "policies"]) || !Array.isArray(compatibility.releases) || compatibility.releases.length > 64 || !Array.isArray(compatibility.policies) || compatibility.policies.length > 32) return false;
    const releaseVersions = new Set();
    if (!compatibility.releases.every(row => {
      if (!exact(row, ["extensionVersion", "contractVersions", "browserFamilies"]) || !semver(row.extensionVersion) || releaseVersions.has(row.extensionVersion) || !Array.isArray(row.contractVersions) || row.contractVersions.length === 0 || row.contractVersions.length > 8 || row.contractVersions.some(x => !["control_plane_v1", "control_plane_v2"].includes(x)) || new Set(row.contractVersions).size !== row.contractVersions.length || !Array.isArray(row.browserFamilies) || row.browserFamilies.length === 0 || row.browserFamilies.length > BROWSER_FAMILIES.length || row.browserFamilies.some(x => !BROWSER_FAMILIES.includes(x)) || new Set(row.browserFamilies).size !== row.browserFamilies.length) return false;
      releaseVersions.add(row.extensionVersion); return true;
    })) return false;
    const policyIds = new Set();
    if (!compatibility.policies.every(policy => {
      const id = `${policy?.policyKey}:${policy?.revision}`;
      if (!exact(policy, ["policyKey", "revision", "contractVersion", "browserFamily", "minimumExtensionVersion", "recommendedExtensionVersion", "minimumBrowserVersion", "maintenanceMode", "maintenanceCode", "blockedVersions"]) || !machine(policy.policyKey) || !Number.isSafeInteger(policy.revision) || policy.revision <= 0 || policyIds.has(id) || policy.contractVersion !== "control_plane_v2" || !(policy.browserFamily === null || BROWSER_FAMILIES.includes(policy.browserFamily)) || !(policy.minimumExtensionVersion === null || semver(policy.minimumExtensionVersion)) || !(policy.recommendedExtensionVersion === null || semver(policy.recommendedExtensionVersion)) || !(policy.minimumBrowserVersion === null || (policy.browserFamily !== null && typeof policy.minimumBrowserVersion === "string" && policy.minimumBrowserVersion.length <= 64 && /^\d+(?:\.\d+){0,3}$/.test(policy.minimumBrowserVersion))) || typeof policy.maintenanceMode !== "boolean" || !(policy.maintenanceCode === null || machine(policy.maintenanceCode)) || !Array.isArray(policy.blockedVersions) || policy.blockedVersions.length > 128 || !policy.blockedVersions.every(semver) || new Set(policy.blockedVersions).size !== policy.blockedVersions.length) return false;
      policyIds.add(id); return true;
    })) return false;
    if (!Array.isArray(value.featureRules) || value.featureRules.length > 128) return false;
    const keys = new Set();
    if (!value.featureRules.every(rule => exact(rule, ["featureKey", "revision", "contractVersion", "enabled", "browserFamily", "minimumExtensionVersion"]) && machine(rule.featureKey) && !keys.has(rule.featureKey) && (keys.add(rule.featureKey), true) && Number.isSafeInteger(rule.revision) && rule.revision > 0 && rule.contractVersion === "control_plane_v2" && typeof rule.enabled === "boolean" && (rule.browserFamily === null || BROWSER_FAMILIES.includes(rule.browserFamily)) && (rule.minimumExtensionVersion === null || semver(rule.minimumExtensionVersion)))) return false;
    return localAi(value.ai);
  }
  function localAuthorityV3(value) {
    if (!exact(value, ["schemaVersion", "contractVersion", "compatibility", "featureRules", "ai"]) || value.schemaVersion !== "local_client_authority_v2" || value.contractVersion !== "control_plane_v3") return false;
    const compatibility = value.compatibility;
    if (!exact(compatibility, ["releases", "policies"]) || !Array.isArray(compatibility.releases) || compatibility.releases.length > 64 || !Array.isArray(compatibility.policies) || compatibility.policies.length > 32) return false;
    const releaseVersions = new Set();
    if (!compatibility.releases.every(row => {
      if (!exact(row, ["extensionVersion", "contractVersions", "browserFamilies"]) || !semver(row.extensionVersion) || releaseVersions.has(row.extensionVersion) || !Array.isArray(row.contractVersions) || row.contractVersions.length === 0 || row.contractVersions.length > 8 || row.contractVersions.some(x => !["control_plane_v1", "control_plane_v2", "control_plane_v3"].includes(x)) || new Set(row.contractVersions).size !== row.contractVersions.length || !Array.isArray(row.browserFamilies) || row.browserFamilies.length === 0 || row.browserFamilies.length > BROWSER_FAMILIES.length || row.browserFamilies.some(x => !BROWSER_FAMILIES.includes(x)) || new Set(row.browserFamilies).size !== row.browserFamilies.length) return false;
      releaseVersions.add(row.extensionVersion); return true;
    })) return false;
    const policyIds = new Set();
    if (!compatibility.policies.every(policy => {
      const id = `${policy?.policyKey}:${policy?.revision}`;
      if (!exact(policy, ["policyKey", "revision", "contractVersion", "browserFamily", "minimumExtensionVersion", "recommendedExtensionVersion", "minimumBrowserVersion", "maintenanceMode", "maintenanceCode", "blockedVersions"]) || !machine(policy.policyKey) || !Number.isSafeInteger(policy.revision) || policy.revision <= 0 || policyIds.has(id) || policy.contractVersion !== "control_plane_v3" || !(policy.browserFamily === null || BROWSER_FAMILIES.includes(policy.browserFamily)) || !(policy.minimumExtensionVersion === null || semver(policy.minimumExtensionVersion)) || !(policy.recommendedExtensionVersion === null || semver(policy.recommendedExtensionVersion)) || !(policy.minimumBrowserVersion === null || (policy.browserFamily !== null && typeof policy.minimumBrowserVersion === "string" && policy.minimumBrowserVersion.length <= 64 && /^\d+(?:\.\d+){0,3}$/.test(policy.minimumBrowserVersion))) || typeof policy.maintenanceMode !== "boolean" || !(policy.maintenanceCode === null || machine(policy.maintenanceCode)) || policy.maintenanceMode !== (policy.maintenanceCode !== null) || !Array.isArray(policy.blockedVersions) || policy.blockedVersions.length > 128 || !policy.blockedVersions.every(semver) || new Set(policy.blockedVersions).size !== policy.blockedVersions.length) return false;
      policyIds.add(id); return true;
    })) return false;
    if (!Array.isArray(value.featureRules) || value.featureRules.length > 128) return false;
    const keys = new Set();
    if (!value.featureRules.every(rule => exact(rule, ["featureKey", "revision", "contractVersion", "enabled", "browserFamily", "minimumExtensionVersion"]) && machine(rule.featureKey) && !keys.has(rule.featureKey) && (keys.add(rule.featureKey), true) && Number.isSafeInteger(rule.revision) && rule.revision > 0 && rule.contractVersion === "control_plane_v3" && typeof rule.enabled === "boolean" && (rule.browserFamily === null || BROWSER_FAMILIES.includes(rule.browserFamily)) && (rule.minimumExtensionVersion === null || semver(rule.minimumExtensionVersion)))) return false;
    return localAi(value.ai);
  }
  function subscriptionAccessV3(value, accessBasis, subscriptionState) {
    const paidCommercial = accessBasis === "COMMERCIAL" && ["ACTIVE", "GRACE", "CANCELED"].includes(subscriptionState);
    if (value === null) return !paidCommercial;
    if (!exact(value, ["schemaVersion", "paidThrough", "offlineHardUntil"]) || value.schemaVersion !== "subscription_access_v1" || !iso(value.paidThrough) || !iso(value.offlineHardUntil) || !paidCommercial) return false;
    return Date.parse(value.offlineHardUntil) - Date.parse(value.paidThrough) === 72 * 60 * 60 * 1000;
  }
  function payloadV3(value) {
    const common = ["snapshotVersion", "contractVersion", "configVersion", "issuedAt", "expiresAt", "offlineGraceUntil", "serverTime", "accessBasis", "account", "subscription", "devicePolicy", "entitlements", "subscriptionAccess"];
    const neutral = Object.hasOwn(value || {}, "localClientAuthority");
    const keys = neutral ? [...common, "localClientAuthority"] : [...common, "compatibility", "features", "ai"];
    if (!exact(value, keys) || value.snapshotVersion !== "bootstrap_snapshot_v3" || value.contractVersion !== "control_plane_v3" || !exact(value.account, ["id", "status"]) || !UUID.test(value.account.id) || value.account.status !== "ACTIVE") return false;
    if (!Number.isSafeInteger(value.configVersion) || value.configVersion <= 0 || !["BETA", "COMMERCIAL", "NONE"].includes(value.accessBasis) || !iso(value.issuedAt) || !iso(value.expiresAt) || !iso(value.offlineGraceUntil) || !iso(value.serverTime)) return false;
    const issued = Date.parse(value.issuedAt), expires = Date.parse(value.expiresAt), grace = Date.parse(value.offlineGraceUntil), server = Date.parse(value.serverTime);
    if (issued > server || issued >= expires || expires >= grace) return false;
    if (!exact(value.subscription, ["state", "planRevision"]) || !["NONE", "TRIAL", "ACTIVE", "GRACE", "PAST_DUE", "CANCELED", "EXPIRED", "SUSPENDED"].includes(value.subscription.state) || (value.subscription.state === "NONE" ? value.subscription.planRevision !== null : !machine(value.subscription.planRevision))) return false;
    if (!subscriptionAccessV3(value.subscriptionAccess, value.accessBasis, value.subscription.state)) return false;
    if (!exact(value.devicePolicy, ["status"]) || value.devicePolicy.status !== "ACTIVE") return false;
    if (!record(value.entitlements) || Object.keys(value.entitlements).length > 128 || !Object.entries(value.entitlements).every(([k, v]) => machine(k) && (typeof v === "boolean" || (Number.isSafeInteger(v) && !Object.is(v, -0)) || machine(v)))) return false;
    if (neutral) return localAuthorityV3(value.localClientAuthority);
    if (!exact(value.compatibility, ["extension", "browser"]) || !exact(value.compatibility.extension, ["status", "minimumVersion"]) || !["SUPPORTED", "UPDATE_RECOMMENDED", "UPDATE_REQUIRED"].includes(value.compatibility.extension.status) || (value.compatibility.extension.minimumVersion !== null && !semver(value.compatibility.extension.minimumVersion)) || !exact(value.compatibility.browser, ["status"]) || !["SUPPORTED", "UNSUPPORTED_BROWSER", "MAINTENANCE"].includes(value.compatibility.browser.status)) return false;
    if (!record(value.features) || Object.keys(value.features).length > 128 || !Object.entries(value.features).every(([k, v]) => machine(k) && typeof v === "boolean")) return false;
    return ai(value.ai);
  }
  function payload(value) {
    const common = ["snapshotVersion", "contractVersion", "configVersion", "issuedAt", "expiresAt", "offlineGraceUntil", "serverTime", "accessBasis", "account", "subscription", "devicePolicy", "entitlements"];
    const neutral = Object.hasOwn(value || {}, "localClientAuthority");
    const keys = neutral ? [...common, "localClientAuthority"] : [...common, "compatibility", "features", "ai"];
    if (!exactWithOptional(value, keys.filter(k => k !== "accessBasis"), ["accessBasis"]) || value.snapshotVersion !== "bootstrap_snapshot_v2" || value.contractVersion !== "control_plane_v2" || !exact(value.account, ["id", "status"]) || !UUID.test(value.account.id) || value.account.status !== "ACTIVE") return false;
    if (!Number.isSafeInteger(value.configVersion) || value.configVersion <= 0 || !["BETA", "COMMERCIAL", "NONE", undefined].includes(value.accessBasis) || !iso(value.issuedAt) || !iso(value.expiresAt) || !iso(value.offlineGraceUntil) || !iso(value.serverTime)) return false;
    const issued = Date.parse(value.issuedAt), expires = Date.parse(value.expiresAt), grace = Date.parse(value.offlineGraceUntil), server = Date.parse(value.serverTime);
    if (issued > server || issued >= expires || expires >= grace) return false;
    if (!exact(value.subscription, ["state", "planRevision"]) || !["NONE", "TRIAL", "ACTIVE", "GRACE", "PAST_DUE", "CANCELED", "EXPIRED", "SUSPENDED"].includes(value.subscription.state) || (value.subscription.state === "NONE" ? value.subscription.planRevision !== null : !machine(value.subscription.planRevision))) return false;
    if (!exact(value.devicePolicy, ["status"]) || value.devicePolicy.status !== "ACTIVE") return false;
    if (!neutral && (!exact(value.compatibility, ["extension", "browser"]) || !exact(value.compatibility.extension, ["status", "minimumVersion"]) || !["SUPPORTED", "UPDATE_RECOMMENDED", "UPDATE_REQUIRED"].includes(value.compatibility.extension.status) || (value.compatibility.extension.minimumVersion !== null && !semver(value.compatibility.extension.minimumVersion)) || !exact(value.compatibility.browser, ["status"]) || !["SUPPORTED", "UNSUPPORTED_BROWSER", "MAINTENANCE"].includes(value.compatibility.browser.status))) return false;
    if (!record(value.entitlements) || Object.keys(value.entitlements).length > 128 || !Object.entries(value.entitlements).every(([k, v]) => machine(k) && (typeof v === "boolean" || (Number.isSafeInteger(v) && !Object.is(v, -0)) || machine(v)))) return false;
    if (neutral) return localAuthority(value.localClientAuthority);
    if (!record(value.features) || Object.keys(value.features).length > 128 || !Object.entries(value.features).every(([k, v]) => machine(k) && typeof v === "boolean")) return false;
    return ai(value.ai);
  }
  function validateBundle(bundle) {
    if (!exact(bundle, ["trustBundleVersion", "algorithm", "publicKeyFormat", "publicKeyEncoding", "fingerprintAlgorithm", "fingerprintEncoding", "keys"]) || bundle.trustBundleVersion !== "bootstrap_trust_bundle_v1" || bundle.algorithm !== "Ed25519" || bundle.publicKeyFormat !== "spki_der" || bundle.publicKeyEncoding !== "base64" || bundle.fingerprintAlgorithm !== "sha256" || bundle.fingerprintEncoding !== "lowercase_hex" || !Array.isArray(bundle.keys) || bundle.keys.length > 8) throw new Error("INVALID_TRUST_BUNDLE");
    const ids = new Set(), fingerprints = new Set();
    for (const entry of bundle.keys) {
      if (!exact(entry, ["keyId", "publicKey", "fingerprintSha256", "lifecycle", "trustEligibility"]) || !machine(entry.keyId) || !B64.test(entry.publicKey) || entry.publicKey.length % 4 || !/^[0-9a-f]{64}$/.test(entry.fingerprintSha256) || !["ACTIVE", "RETIRED"].includes(entry.lifecycle) || entry.trustEligibility !== (entry.lifecycle === "ACTIVE" ? "SIGNING_AND_VERIFICATION" : "VERIFICATION_OVERLAP") || ids.has(entry.keyId) || fingerprints.has(entry.fingerprintSha256)) throw new Error("INVALID_TRUST_BUNDLE");
      ids.add(entry.keyId); fingerprints.add(entry.fingerprintSha256);
    }
    return bundle;
  }
  async function makeKeyRing(bundle) {
    validateBundle(bundle); const map = new Map();
    for (const entry of bundle.keys) {
      const der = b64(entry.publicKey); if (!der) throw new Error("INVALID_TRUST_KEY");
      const fingerprint = hex(await crypto.subtle.digest("SHA-256", der)); if (fingerprint !== entry.fingerprintSha256) throw new Error("TRUST_FINGERPRINT_MISMATCH");
      try { map.set(entry.keyId, await crypto.subtle.importKey("spki", der, { name: "Ed25519" }, false, ["verify"])); } catch (_) { throw new Error("UNSUPPORTED_CRYPTO"); }
    }
    return map;
  }
  async function verifyBootstrapV2(input, bundle) {
    let envelope;
    if (!exact(input, ["envelopeVersion", "algorithm", "keyId", "payload", "signature"]) || input.envelopeVersion !== "bootstrap_envelope_v2" || input.algorithm !== "Ed25519" || !machine(input.keyId) || typeof input.payload !== "string" || input.payload.length > 32768 || typeof input.signature !== "string" || input.signature.length > 256) return fail("INVALID_ENVELOPE");
    const keyRing = await makeKeyRing(bundle), key = keyRing.get(input.keyId); if (!key) return fail("UNKNOWN_SIGNING_KEY");
    const payloadBytes = b64url(input.payload), signature = b64url(input.signature); if (!payloadBytes || !signature) return fail("INVALID_PAYLOAD_ENCODING");
    let valid = false; try { const data = new Uint8Array(DOMAIN.length + input.keyId.length + 1 + payloadBytes.length); data.set(DOMAIN); data.set(textEncoder.encode(input.keyId), DOMAIN.length); data[DOMAIN.length + input.keyId.length] = 0; data.set(payloadBytes, DOMAIN.length + input.keyId.length + 1); valid = await crypto.subtle.verify("Ed25519", key, signature, data); } catch (_) { return fail("INVALID_SIGNATURE"); }
    if (!valid) return fail("INVALID_SIGNATURE");
    let json; try { json = parseStrictJson(new TextDecoder("utf-8", { fatal: true }).decode(payloadBytes)); } catch (error) { return fail(error.message === "DUPLICATE_FIELD" ? "INVALID_PAYLOAD_JSON" : "INVALID_PAYLOAD_JSON"); }
    if (!payload(json)) return fail("INVALID_PAYLOAD_SCHEMA");
    try { if (new TextEncoder().encode(canonical(json)).byteLength !== payloadBytes.byteLength || !cryptoEqual(new TextEncoder().encode(canonical(json)), payloadBytes)) return fail("NON_CANONICAL_PAYLOAD"); } catch (_) { return fail("INVALID_PAYLOAD_SCHEMA"); }
    return { ok: true, payload: json, envelope: input };
  }
  async function verifyBootstrapV3(input, bundle) {
    if (!exact(input, ["envelopeVersion", "algorithm", "keyId", "payload", "signature"]) || input.envelopeVersion !== "bootstrap_envelope_v3" || input.algorithm !== "Ed25519" || !machine(input.keyId) || typeof input.payload !== "string" || !input.payload || input.payload.length > 32768 || !B64URL.test(input.payload) || typeof input.signature !== "string" || !input.signature || input.signature.length > 256 || !B64URL.test(input.signature)) return fail("INVALID_ENVELOPE");
    const keyRing = await makeKeyRing(bundle), key = keyRing.get(input.keyId); if (!key) return fail("UNKNOWN_SIGNING_KEY");
    const payloadBytes = b64url(input.payload), signature = b64url(input.signature); if (!payloadBytes || !signature) return fail("INVALID_PAYLOAD_ENCODING");
    let valid = false; try { const data = new Uint8Array(DOMAIN.length + input.keyId.length + 1 + payloadBytes.length); data.set(DOMAIN); data.set(textEncoder.encode(input.keyId), DOMAIN.length); data[DOMAIN.length + input.keyId.length] = 0; data.set(payloadBytes, DOMAIN.length + input.keyId.length + 1); valid = await crypto.subtle.verify("Ed25519", key, signature, data); } catch (_) { return fail("INVALID_SIGNATURE"); }
    if (!valid) return fail("INVALID_SIGNATURE");
    let json; try { json = parseStrictJson(new TextDecoder("utf-8", { fatal: true }).decode(payloadBytes)); } catch (_) { return fail("INVALID_PAYLOAD_JSON"); }
    if (!payloadV3(json)) return fail("INVALID_PAYLOAD_SCHEMA");
    try { const canonicalBytes = new TextEncoder().encode(canonical(json)); if (canonicalBytes.byteLength !== payloadBytes.byteLength || !cryptoEqual(canonicalBytes, payloadBytes)) return fail("NON_CANONICAL_PAYLOAD"); } catch (_) { return fail("INVALID_PAYLOAD_SCHEMA"); }
    return { ok: true, payload: json, envelope: input };
  }
  const HEALTH_DOMAIN = textEncoder.encode("product-control-plane/health-authority/v1\0");
  const HEALTH_REASONS = ["PRODUCER_UNAVAILABLE", "PRODUCER_DENIED", "PROVENANCE_MISSING", "STALE_OBSERVATION", "INVALID_CONTEXT", "AI_UNAVAILABLE"];
  function healthAi(value) { return exact(value, ["family", "surface", "variant", "profileKey", "revision", "scopeVariant", "contentSha256"]) && machine(value.family) && machine(value.surface) && (value.variant === null || machine(value.variant)) && machine(value.profileKey) && Number.isSafeInteger(value.revision) && value.revision > 0 && (value.scopeVariant === null || machine(value.scopeVariant)) && /^[0-9a-f]{64}$/.test(value.contentSha256); }
  function healthContext(value) { return exact(value, ["accountId", "deviceId", "sessionId", "contractVersion", "configVersion", "bootstrapSnapshotSha256", "ai"]) && UUID.test(value.accountId) && UUID.test(value.deviceId) && UUID.test(value.sessionId) && value.contractVersion === "control_plane_v2" && Number.isSafeInteger(value.configVersion) && value.configVersion > 0 && /^[0-9a-f]{64}$/.test(value.bootstrapSnapshotSha256) && healthAi(value.ai); }
  function healthClaim(value) {
    if (!record(value) || value.healthClaimVersion !== "health_claim_v1" || value.target !== "WORK" || value.executionAuthority !== false) return false;
    if (value.status === "PASS") return exact(value, ["healthClaimVersion", "status", "target", "context", "observedAt", "expiresAt", "executionAuthority"]) && healthContext(value.context) && iso(value.observedAt) && iso(value.expiresAt) && Date.parse(value.observedAt) < Date.parse(value.expiresAt);
    return (value.status === "DENY" || value.status === "UNAVAILABLE") && exact(value, ["healthClaimVersion", "status", "target", "reason", "observedAt", "executionAuthority"]) && HEALTH_REASONS.includes(value.reason) && iso(value.observedAt);
  }
  async function verifyHealthV1(input, bundle) {
    if (!exact(input, ["healthEnvelopeVersion", "algorithm", "keyId", "payload", "signature"]) || input.healthEnvelopeVersion !== "health_envelope_v1" || input.algorithm !== "Ed25519" || !machine(input.keyId) || typeof input.payload !== "string" || input.payload.length > 32768 || typeof input.signature !== "string" || input.signature.length > 256) return fail("INVALID_ENVELOPE");
    const keyRing = await makeKeyRing(bundle), key = keyRing.get(input.keyId); if (!key) return fail("UNKNOWN_SIGNING_KEY");
    const payloadBytes = b64url(input.payload), signature = b64url(input.signature); if (!payloadBytes || !signature) return fail("INVALID_PAYLOAD_ENCODING");
    let valid = false; try { const data = new Uint8Array(HEALTH_DOMAIN.length + input.keyId.length + 1 + payloadBytes.length); data.set(HEALTH_DOMAIN); data.set(textEncoder.encode(input.keyId), HEALTH_DOMAIN.length); data[HEALTH_DOMAIN.length + input.keyId.length] = 0; data.set(payloadBytes, HEALTH_DOMAIN.length + input.keyId.length + 1); valid = await crypto.subtle.verify("Ed25519", key, signature, data); } catch (_) { return fail("INVALID_SIGNATURE"); }
    if (!valid) return fail("INVALID_SIGNATURE");
    let json; try { json = parseStrictJson(new TextDecoder("utf-8", { fatal: true }).decode(payloadBytes)); } catch (_) { return fail("INVALID_PAYLOAD_JSON"); }
    if (!healthClaim(json)) return fail("INVALID_PAYLOAD_SCHEMA");
    try { const canonicalBytes = new TextEncoder().encode(canonical(json)); if (canonicalBytes.byteLength !== payloadBytes.byteLength || !cryptoEqual(canonicalBytes, payloadBytes)) return fail("NON_CANONICAL_PAYLOAD"); } catch (_) { return fail("INVALID_PAYLOAD_SCHEMA"); }
    return { ok: true, payload: json, envelope: input };
  }
  const TREE_DOMAIN = textEncoder.encode("Octoport ai prompt tree v1\0");
  function promptTreeClaim(value) {
    if (!exact(value,["claimVersion","accountId","deviceId","sessionId","requestNonce","detected","aiId","issuedAt","publication"]) ||
      value.claimVersion !== "ai_prompt_tree_claim_v1" || ![value.accountId,value.deviceId,value.sessionId,value.requestNonce,value.aiId].every(x=>typeof x==="string"&&UUID.test(x)) ||
      typeof value.issuedAt!=="string" || !Number.isFinite(Date.parse(value.issuedAt)) ||
      !exact(value.detected,["family","surface","variant"]) || !machine(value.detected.family) || !machine(value.detected.surface) || !(value.detected.variant===null || machine(value.detected.variant))) return false;
    const p=value.publication;
    return p===null || (exact(p,["version","format","sha256","publishedAt","body"]) && Number.isSafeInteger(p.version) && p.version>0 &&
      p.format==="octoport_prompt_tree_v1" && typeof p.sha256==="string" && /^[0-9a-f]{64}$/.test(p.sha256) &&
      typeof p.publishedAt==="string" && Number.isFinite(Date.parse(p.publishedAt)) &&
      (p.body===null || globalThis.OctoportPromptTrees?.validateBody(p.body)===true));
  }
  async function verifyPromptTreeV1(input, bundle) {
    if (!exact(input, ["treeEnvelopeVersion", "algorithm", "keyId", "payload", "signature"]) || input.treeEnvelopeVersion !== "ai_prompt_tree_envelope_v1" || input.algorithm !== "Ed25519" || !machine(input.keyId) || typeof input.payload !== "string" || input.payload.length > 131072 || typeof input.signature !== "string" || input.signature.length > 256) return fail("INVALID_ENVELOPE");
    const keyRing = await makeKeyRing(bundle), key = keyRing.get(input.keyId); if (!key) return fail("UNKNOWN_SIGNING_KEY");
    const payloadBytes = b64url(input.payload), signature = b64url(input.signature); if (!payloadBytes || !signature) return fail("INVALID_PAYLOAD_ENCODING");
    let valid = false; try { const data = new Uint8Array(TREE_DOMAIN.length + input.keyId.length + 1 + payloadBytes.length); data.set(TREE_DOMAIN); data.set(textEncoder.encode(input.keyId), TREE_DOMAIN.length); data[TREE_DOMAIN.length + input.keyId.length] = 0; data.set(payloadBytes, TREE_DOMAIN.length + input.keyId.length + 1); valid = await crypto.subtle.verify("Ed25519", key, signature, data); } catch (_) { return fail("INVALID_SIGNATURE"); }
    if (!valid) return fail("INVALID_SIGNATURE");
    let json; try { json = parseStrictJson(new TextDecoder("utf-8", { fatal: true }).decode(payloadBytes)); } catch (_) { return fail("INVALID_PAYLOAD_JSON"); }
    if (!promptTreeClaim(json)) return fail("INVALID_PAYLOAD_SCHEMA");
    try { const canonicalBytes = new TextEncoder().encode(canonical(json)); if (canonicalBytes.byteLength !== payloadBytes.byteLength || !cryptoEqual(canonicalBytes, payloadBytes)) return fail("NON_CANONICAL_PAYLOAD"); } catch (_) { return fail("INVALID_PAYLOAD_SCHEMA"); }
    return { ok: true, payload: json, envelope: input };
  }
  function cryptoEqual(a, b) { if (a.length !== b.length) return false; let result = 0; for (let i = 0; i < a.length; i++) result |= a[i] ^ b[i]; return result === 0; }
  globalThis.SellerAgentsBootstrapVerifier = Object.freeze({ verifyV2: verifyBootstrapV2, verifyV3: verifyBootstrapV3, verifyHealthV1, verifyPromptTreeV1, validateBundle, canonicalJson: value => canonical(value), base64urlEncode: b64urlEncode });
})();

;
/* Privileged extension-context only. No content-script/page API is exposed. */
(() => {
  "use strict";
  const VERSION = "credential_transfer_envelope_v1";
  const VAULT_VERSION = "credential_transfer_recipient_v1";
  const VAULT_DB = "seller_agents_credential_transfer_v1";
  const VAULT_STORE = "recipient_requests";
  const VAULT_PHASES = Object.freeze(["PREPARED", "ACTIVE", "RECEIVING", "IMPORTED_PENDING_ACK", "ACKED_RESULT"]);
  const enc = new TextEncoder(), dec = new TextDecoder();
  const b64 = (bytes) => { let value = ""; for (const byte of new Uint8Array(bytes)) value += String.fromCharCode(byte); return btoa(value); };
  const unb64 = (value) => Uint8Array.from(atob(value), (char) => char.charCodeAt(0));
  const clone = (value) => structuredClone(value);
  const vaultError = (code) => Object.assign(new Error(code), { code });
  function aad(input) { return { version: VERSION, accountId: String(input.accountId), requestId: String(input.requestId), sourceDeviceId: String(input.sourceDeviceId), recipientDeviceId: String(input.recipientDeviceId), packetId: String(input.packetId) }; }
  function aadBytes(value) { return enc.encode(JSON.stringify(aad(value))); }
  async function importRecipientPublicKey(spki) { return crypto.subtle.importKey("spki", unb64(spki), { name: "ECDH", namedCurve: "P-256" }, false, []); }
  async function deriveAesKey(privateKey, publicKey, salt, info) {
    const bits = await crypto.subtle.deriveBits({ name: "ECDH", public: publicKey }, privateKey, 256);
    const hkdf = await crypto.subtle.importKey("raw", bits, "HKDF", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({ name: "HKDF", hash: "SHA-256", salt, info }, hkdf, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
  }
  async function generateRecipientKeyPair() {
    const pair = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]);
    const spki = await crypto.subtle.exportKey("spki", pair.publicKey);
    return { privateKey: pair.privateKey, publicKeySpki: b64(spki) };
  }
  async function encrypt(input) {
    if (!input?.payload || typeof input.payload !== "object") throw new Error("TRANSFER_PAYLOAD_INVALID");
    const recipientPublicKey = await importRecipientPublicKey(input.recipientPublicKeySpki);
    const ephemeral = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]);
    const ephemeralSpki = await crypto.subtle.exportKey("spki", ephemeral.publicKey);
    const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
    const header = aad(input), key = await deriveAesKey(ephemeral.privateKey, recipientPublicKey, salt, aadBytes(header));
    const plaintext = enc.encode(JSON.stringify(clone(input.payload)));
    const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: aadBytes(header), tagLength: 128 }, key, plaintext);
    return JSON.stringify({ envelopeVersion: VERSION, keyAgreement: "ECDH-P256", kdf: "HKDF-SHA-256", encryption: "AES-256-GCM", ephemeralPublicKeySpki: b64(ephemeralSpki), salt: b64(salt), iv: b64(iv), aad: header, ciphertext: b64(ciphertext) });
  }
  async function decrypt(input) {
    const envelope = typeof input.envelope === "string" ? JSON.parse(input.envelope) : input.envelope;
    if (!envelope || envelope.envelopeVersion !== VERSION || envelope.keyAgreement !== "ECDH-P256" || envelope.kdf !== "HKDF-SHA-256" || envelope.encryption !== "AES-256-GCM") throw new Error("TRANSFER_ENVELOPE_INVALID");
    const expected = aad(input), actual = JSON.stringify(envelope.aad);
    if (actual !== JSON.stringify(expected)) throw new Error("TRANSFER_AAD_MISMATCH");
    const sourcePublicKey = await crypto.subtle.importKey("spki", unb64(envelope.ephemeralPublicKeySpki), { name: "ECDH", namedCurve: "P-256" }, false, []);
    const key = await deriveAesKey(input.privateKey, sourcePublicKey, unb64(envelope.salt), aadBytes(expected));
    const plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(envelope.iv), additionalData: aadBytes(expected), tagLength: 128 }, key, unb64(envelope.ciphertext));
    return JSON.parse(dec.decode(plaintext));
  }

  let vaultDbFlight = null, vaultMutationQueue = Promise.resolve();
  function idbRequest(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || vaultError("TRANSFER_VAULT_REQUEST_FAILED"));
    });
  }
  function idbTransaction(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve(true);
      transaction.onabort = () => reject(transaction.error || vaultError("TRANSFER_VAULT_TRANSACTION_ABORTED"));
      transaction.onerror = () => reject(transaction.error || vaultError("TRANSFER_VAULT_TRANSACTION_FAILED"));
    });
  }
  async function settleIdb(request, done) {
    try { const result = await idbRequest(request); await done; return result; }
    catch (failure) { try { await done; } catch (_) {} throw failure; }
  }
  async function openVault() {
    if (!globalThis.indexedDB?.open) throw vaultError("TRANSFER_VAULT_UNAVAILABLE");
    if (!vaultDbFlight) {
      vaultDbFlight = new Promise((resolve, reject) => {
        const request = indexedDB.open(VAULT_DB, 1);
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(VAULT_STORE)) db.createObjectStore(VAULT_STORE, { keyPath: "requestId" });
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error || vaultError("TRANSFER_VAULT_OPEN_FAILED"));
        request.onblocked = () => reject(vaultError("TRANSFER_VAULT_BLOCKED"));
      }).catch((failure) => { vaultDbFlight = null; throw failure; });
    }
    return vaultDbFlight;
  }
  function queueVaultMutation(fn) {
    const run = vaultMutationQueue.then(fn);
    vaultMutationQueue = run.catch(() => {});
    return run;
  }
  function validPrivateKey(key) {
    return Boolean(key && key.type === "private" && key.extractable === false && key.algorithm?.name === "ECDH" && key.algorithm?.namedCurve === "P-256");
  }
  function validateVaultRecord(record) {
    if (!record || record.vaultVersion !== VAULT_VERSION || typeof record.requestId !== "string" || typeof record.accountId !== "string" || typeof record.recipientDeviceId !== "string" || typeof record.sessionId !== "string" || !VAULT_PHASES.includes(record.phase) || typeof record.publicKeySpki !== "string" || !Array.isArray(record.selectedStoreIds) || !record.selectedStoreIds.every((value) => typeof value === "string") || !Number.isInteger(record.expiresInSeconds) || record.expiresInSeconds < 60 || record.expiresInSeconds > 900 || typeof record.expiresAt !== "string" || !Number.isFinite(Date.parse(record.expiresAt))) throw vaultError("TRANSFER_VAULT_RECORD_INVALID");
    if (record.phase === "ACKED_RESULT") {
      if (record.privateKey !== null || !record.result || record.result.importState !== "IMPORTED") throw vaultError("TRANSFER_VAULT_RECORD_INVALID");
    } else if (!validPrivateKey(record.privateKey)) throw vaultError("TRANSFER_VAULT_KEY_INVALID");
    return record;
  }
  async function readUnlocked(requestId) {
    const db = await openVault(), tx = db.transaction(VAULT_STORE, "readonly"), done = idbTransaction(tx);
    const value = await settleIdb(tx.objectStore(VAULT_STORE).get(requestId), done);
    return value || null;
  }
  async function writeUnlocked(record) {
    validateVaultRecord(record);
    const db = await openVault(), tx = db.transaction(VAULT_STORE, "readwrite"), done = idbTransaction(tx);
    await settleIdb(tx.objectStore(VAULT_STORE).put(record), done);
    return record;
  }
  async function listUnlocked() {
    const db = await openVault(), tx = db.transaction(VAULT_STORE, "readonly"), done = idbTransaction(tx);
    const values = await settleIdb(tx.objectStore(VAULT_STORE).getAll(), done);
    return Array.isArray(values) ? values : [];
  }
  async function removeUnlocked(requestId) {
    const db = await openVault(), tx = db.transaction(VAULT_STORE, "readwrite"), done = idbTransaction(tx);
    await settleIdb(tx.objectStore(VAULT_STORE).delete(requestId), done);
    return true;
  }
  async function clearUnlocked() {
    const db = await openVault(), tx = db.transaction(VAULT_STORE, "readwrite"), done = idbTransaction(tx);
    const store = tx.objectStore(VAULT_STORE);
    await settleIdb(store.clear(), done);
    return true;
  }
  async function pruneUnlocked(nowMs) {
    const values = await listUnlocked();
    let removed = 0;
    for (const record of values) {
      if (!Number.isFinite(Date.parse(record?.expiresAt)) || Date.parse(record.expiresAt) > nowMs) continue;
      await removeUnlocked(record.requestId); removed += 1;
    }
    return removed;
  }
  const vault = Object.freeze({
    VERSION: VAULT_VERSION,
    phases: VAULT_PHASES,
    get: (requestId) => queueVaultMutation(() => readUnlocked(String(requestId || ""))).then(value => value ? clone(value) : null),
    list: () => queueVaultMutation(() => listUnlocked()).then(values => values.map(clone)),
    put: (record) => queueVaultMutation(() => writeUnlocked(clone(record))).then(value => clone(value)),
    update: (requestId, mutate) => queueVaultMutation(async () => {
      const current = await readUnlocked(String(requestId || ""));
      if (!current) throw vaultError("TRANSFER_VAULT_RECORD_MISSING");
      const next = mutate(clone(current));
      if (!next || next.requestId !== current.requestId) throw vaultError("TRANSFER_VAULT_RECORD_INVALID");
      await writeUnlocked(next);
      return clone(next);
    }),
    remove: (requestId) => queueVaultMutation(() => removeUnlocked(String(requestId || ""))),
    clear: () => queueVaultMutation(clearUnlocked),
    prune: (nowMs = Date.now()) => queueVaultMutation(() => pruneUnlocked(Number(nowMs))),
  });

  globalThis.SellerAgentsCredentialTransferCrypto = Object.freeze({ VERSION, generateRecipientKeyPair, encrypt, decrypt });
  globalThis.SellerAgentsCredentialTransferVault = vault;
})();

;
/* Packaged browser-family identity. Product compatibility must not alias one supported browser to another. */
(() => {
  "use strict";

  const families = Object.freeze([
    "chrome",
    "opera",
    "yandex_chromium",
    "firefox",
    "safari",
  ]);

  function version(ua, expression) {
    const match = String(ua || "").match(expression);
    return match ? match[1] : null;
  }

  function detect(userAgent) {
    const ua = String(userAgent ?? (typeof navigator === "object" ? navigator.userAgent || "" : ""));

    const yandex = version(ua, /YaBrowser\/(\d+(?:\.\d+){0,3})/i);
    if (yandex) return Object.freeze({ family: "yandex_chromium", version: yandex });

    const opera = version(ua, /(?:OPR|Opera)\/(\d+(?:\.\d+){0,3})/i);
    if (opera) return Object.freeze({ family: "opera", version: opera });

    const firefox = version(ua, /Firefox\/(\d+(?:\.\d+){0,3})/i);
    if (firefox) return Object.freeze({ family: "firefox", version: firefox });

    if (/Edg(?:A|iOS)?\//i.test(ua)) {
      return Object.freeze({ family: null, version: null });
    }

    const safari = /Safari\//i.test(ua) && !/(?:Chrome|Chromium|CriOS|HeadlessChrome|OPR|Opera|YaBrowser|FxiOS)\//i.test(ua)
      ? version(ua, /Version\/(\d+(?:\.\d+){0,3})/i)
      : null;
    if (safari) return Object.freeze({ family: "safari", version: safari });

    const chrome = version(ua, /(?:Chrome|Chromium|HeadlessChrome)\/(\d+(?:\.\d+){0,3})/i);
    if (chrome) return Object.freeze({ family: "chrome", version: chrome });

    return Object.freeze({ family: null, version: null });
  }

  function current() {
    return detect(typeof navigator === "object" ? navigator.userAgent || "" : "");
  }

  globalThis.SellerAgentsBrowserIdentity = Object.freeze({
    families,
    detect,
    current,
    family: () => current().family,
    version: () => current().version,
  });
})();

;
/* Firefox built-in data consent for optional technical metadata. */
(() => {
  "use strict";

  const CATEGORY = "technicalAndInteraction";
  const KINDS = new Set(["device_authorization", "bootstrap", "health_authority"]);
  const browserIdentity = globalThis.SellerAgentsBrowserIdentity;

  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function family() {
    return browserIdentity?.current?.().family || null;
  }

  function firefoxPermissions() {
    return globalThis.browser?.permissions || null;
  }

  async function consent() {
    if (family() !== "firefox") {
      return Object.freeze({ applicable: false, granted: true, source: "not_firefox" });
    }
    const permissions = firefoxPermissions();
    if (!permissions || typeof permissions.getAll !== "function") {
      return Object.freeze({ applicable: true, granted: false, source: "unavailable" });
    }
    try {
      const current = await permissions.getAll();
      const categories = Array.isArray(current?.data_collection) ? current.data_collection : [];
      return Object.freeze({
        applicable: true,
        granted: categories.includes(CATEGORY),
        source: "firefox_permission",
      });
    } catch (_) {
      return Object.freeze({ applicable: true, granted: false, source: "query_failed" });
    }
  }

  async function requestFromUserGesture() {
    if (family() !== "firefox") return true;
    const permissions = firefoxPermissions();
    if (!permissions || typeof permissions.request !== "function") return false;
    try {
      const requested = await permissions.request({ data_collection: [CATEGORY] });
      if (requested !== true) return false;
      return (await consent()).granted === true;
    } catch (_) {
      return false;
    }
  }

  async function revoke() {
    if (family() !== "firefox") return true;
    const permissions = firefoxPermissions();
    if (!permissions || typeof permissions.remove !== "function") return false;
    try {
      await permissions.remove({ data_collection: [CATEGORY] });
      return (await consent()).granted === false;
    } catch (_) {
      return false;
    }
  }

  function onWithdrawal(handler) {
    if (family() !== "firefox" || typeof handler !== "function") return () => {};
    const event = firefoxPermissions()?.onRemoved;
    if (!event || typeof event.addListener !== "function") return () => {};
    const listener = async () => {
      const current = await consent();
      if (current.applicable && !current.granted) await handler();
    };
    event.addListener(listener);
    return () => event.removeListener?.(listener);
  }

  function omitTechnicalFields(kind, body) {
    const projected = clone(body);
    if (kind === "device_authorization") {
      const deviceLabel = projected.deviceLabel;
      delete projected.browserFamily;
      delete projected.browserVersion;
      delete projected.extensionVersion;
      return deviceLabel === undefined
        ? { clientType: "browser_extension" }
        : { clientType: "browser_extension", deviceLabel };
    }
    if (kind === "bootstrap") {
      delete projected.extensionVersion;
      delete projected.browser;
      return projected;
    }
    if (kind === "health_authority") {
      if (projected?.bootstrap) projected.bootstrap = omitTechnicalFields("bootstrap", projected.bootstrap);
      return projected;
    }
    throw new Error("TECHNICAL_DATA_PROJECTION_KIND_INVALID");
  }

  async function projectControlRequest(kind, body) {
    if (!KINDS.has(kind)) throw new Error("TECHNICAL_DATA_PROJECTION_KIND_INVALID");
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      throw new Error("TECHNICAL_DATA_PROJECTION_BODY_INVALID");
    }
    const current = await consent();
    return Object.freeze({
      consent: current,
      body: current.applicable && !current.granted ? omitTechnicalFields(kind, body) : clone(body),
    });
  }

  globalThis.SellerAgentsTechnicalDataConsent = Object.freeze({
    CATEGORY,
    consent,
    requestFromUserGesture,
    revoke,
    onWithdrawal,
    projectControlRequest,
  });
})();

;
/* Local projection of verified privacy-neutral v2/v3 bootstrap bundles. */
(() => {
  "use strict";

  async function materialize(payload, environment) {
    const local = payload?.localClientAuthority;
    const browserFamily = environment?.browserFamily;
    const browserVersion = environment?.browserVersion;
    const extensionVersion = environment?.extensionVersion;
    const contractVersion = payload?.contractVersion;
    const v2 = local?.schemaVersion === "local_client_authority_v1" && local?.contractVersion === "control_plane_v2" && contractVersion === "control_plane_v2";
    const v3 = local?.schemaVersion === "local_client_authority_v2" && local?.contractVersion === "control_plane_v3" && contractVersion === "control_plane_v3";
    if ((!v2 && !v3) || !browserFamily || !browserVersion || !extensionVersion) return null;
    const release = local.compatibility.releases.find(row => row.extensionVersion === extensionVersion && row.contractVersions.includes(contractVersion));
    const applicable = local.compatibility.policies.filter(row => row.contractVersion === contractVersion && (row.browserFamily === null || row.browserFamily === browserFamily));
    const globals = applicable.filter(row => row.browserFamily === null), exact = applicable.filter(row => row.browserFamily === browserFamily);
    if (globals.length > 1 || exact.length > 1 || globals.some(row => row.minimumBrowserVersion !== null)) return null;
    const policies = [...globals, ...exact];
    if (policies.some(row => row.maintenanceMode !== (row.maintenanceCode !== null))) return null;
    const max = values => values.filter(Boolean).reduce((picked, value) => !picked || environment.compareSemver(value, picked) > 0 ? value : picked, null);
    const minimum = max(policies.map(row => row.minimumExtensionVersion));
    const recommended = max(policies.map(row => row.recommendedExtensionVersion));
    if (minimum && recommended && environment.compareSemver(recommended, minimum) < 0) return null;
    const blocked = policies.some(row => row.blockedVersions.includes(extensionVersion));
    let extensionStatus = "SUPPORTED";
    if (!release || blocked || minimum && !environment.versionAtLeast(extensionVersion, minimum)) extensionStatus = "UPDATE_REQUIRED";
    else if (recommended && !environment.versionAtLeast(extensionVersion, recommended)) extensionStatus = "UPDATE_RECOMMENDED";
    let browserStatus = "SUPPORTED";
    const exactPolicy = exact[0];
    if (policies.some(row => row.maintenanceMode)) browserStatus = "MAINTENANCE";
    else if (!release || !release.browserFamilies.includes(browserFamily)) browserStatus = "UNSUPPORTED_BROWSER";
    else if (exactPolicy?.minimumBrowserVersion && (environment.compareBrowser(browserVersion, exactPolicy.minimumBrowserVersion) ?? -1) < 0) browserStatus = "UNSUPPORTED_BROWSER";
    const features = {};
    for (const rule of local.featureRules) {
      features[rule.featureKey] = rule.enabled && (rule.browserFamily === null || rule.browserFamily === browserFamily) && (rule.minimumExtensionVersion === null || environment.versionAtLeast(extensionVersion, rule.minimumExtensionVersion));
    }
    let ai;
    if (local.ai.status === "UNCONFIGURED") ai = { status: "UNCONFIGURED" };
    else {
      const detected = local.ai.detected;
      const candidate = local.ai.candidates.find(row => row.browserFamily === browserFamily);
      const profile = candidate?.resolution?.status === "RESOLVED" ? candidate.resolution.profile : null;
      if (!profile || environment.requestedAi && detected.family !== environment.requestedAi || !environment.localAi[detected.family] || detected.surface !== environment.localAi[detected.family].surface || detected.variant !== null || !environment.profileValid(profile, browserFamily, browserVersion, extensionVersion)) {
        ai = { status: "UNAVAILABLE", detected, reason: candidate?.resolution?.status === "UNAVAILABLE" ? candidate.resolution.reason : profile ? "PROFILE_INCOMPATIBLE" : "NO_PROFILE" };
      } else if (await environment.profileFingerprint(profile) !== profile.contentSha256) {
        ai = { status: "UNAVAILABLE", detected, reason: "PROFILE_INCOMPATIBLE" };
      } else ai = { status: "RESOLVED", detected, profile };
    }
    return { ...payload, compatibility: { extension: { status: extensionStatus, minimumVersion: minimum }, browser: { status: browserStatus } }, features, ai };
  }

  globalThis.SellerAgentsLocalClientAuthority = Object.freeze({ materialize });
})();

;
/* Browser-safe strict mirror of signed_ai_profile_consumer_v1. No network or persistence. */
(() => {
  "use strict";

  const PROTOCOL_VERSION = "signed_ai_profile_consumer_v1";
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const MACHINE = /^[a-z0-9][a-z0-9._-]*$/;
  const DIGEST = /^[0-9a-f]{64}$/;
  const SEMVER = /^(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)(?:-(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
  const BROWSER_VERSION = /^(?:0|[1-9][0-9]*)(?:\.(?:0|[1-9][0-9]*)){0,3}$/;
  const BROWSER_FAMILIES = Object.freeze(["chrome", "opera", "yandex_chromium", "firefox", "safari"]);
  const ACCESSIBILITY_ROLES = new Set(["main", "article", "textbox", "button", "status"]);
  const EXPECTED_STATES = new Set(["PRESENT", "INTERACTIVE", "COMPLETES"]);
  const OBSERVATION_MODES = new Set(["mutation_observer", "polling"]);
  const UNAVAILABLE_REASONS = new Set([
    "NO_VERIFIED_AUTHORITY",
    "WORK_NOT_ALLOWED",
    "AI_SCOPE_MISMATCH",
    "PROFILE_UNSUPPORTED",
    "AUTHORITY_CHANGED",
  ]);
  const REJECT_REASONS = new Set(["INVALID_PROFILE", "STALE_REQUEST", "AI_SCOPE_MISMATCH"]);
  const SLOT = Object.freeze({
    conversation: Object.freeze({ strategy: "conversation_root", reference: "conversation-root" }),
    composer: Object.freeze({ strategy: "composer_root", reference: "composer-root" }),
    send: Object.freeze({ strategy: "send_control", reference: "send-control" }),
    assistantResponse: Object.freeze({ strategy: "assistant_response", reference: "assistant-response" }),
  });
  const CONTOUR_KEYS = new Set([
    "page_identity",
    "conversation_root",
    "composer_root",
    "send_control",
    "busy_state",
    "assistant_response",
    "copy_control",
  ]);

  function record(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value) &&
      Object.getPrototypeOf(value) === Object.prototype;
  }
  function exact(value, keys) {
    if (!record(value)) return false;
    const actual = Object.keys(value);
    const expected = new Set(keys);
    return actual.length === expected.size && actual.every((key) => expected.has(key));
  }
  function exactWithOptional(value, required, optional = []) {
    if (!record(value)) return false;
    const allowed = new Set([...required, ...optional]);
    return required.every((key) => Object.hasOwn(value, key)) &&
      Object.keys(value).every((key) => allowed.has(key));
  }
  function machine(value) {
    return typeof value === "string" && value.length >= 1 && value.length <= 64 && MACHINE.test(value);
  }
  function positiveSafeInt(value) {
    return Number.isSafeInteger(value) && value > 0;
  }
  function canonical(value) {
    if (value === null) return "null";
    if (typeof value === "boolean") return value ? "true" : "false";
    if (typeof value === "string") return JSON.stringify(value);
    if (typeof value === "number") {
      if (!Number.isSafeInteger(value) || Object.is(value, -0)) throw new Error("NON_CANONICAL_NUMBER");
      return String(value);
    }
    if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
    if (record(value)) {
      return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
    }
    throw new Error("INVALID_CANONICAL_VALUE");
  }
  async function sha256Hex(value) {
    const bytes = new TextEncoder().encode(String(value));
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function validScope(value) {
    return exact(value, ["family", "surface", "variant"]) &&
      ["chatgpt", "alice", "qwen", "kimi", "grok", "gemini", "claude", "deepseek"].includes(value.family) && value.surface === "web" && value.variant === null;
  }
  function validAuthority(value) {
    return exact(value, ["authGeneration", "bootstrapSnapshotSha256"]) &&
      positiveSafeInt(value.authGeneration) && typeof value.bootstrapSnapshotSha256 === "string" &&
      DIGEST.test(value.bootstrapSnapshotSha256);
  }
  function validIdentity(value) {
    return exact(value, ["profileKey", "revision", "scopeVariant", "contentSha256"]) &&
      machine(value.profileKey) && positiveSafeInt(value.revision) && value.scopeVariant === null &&
      typeof value.contentSha256 === "string" && DIGEST.test(value.contentSha256);
  }
  function validPrimitive(value, expectedReference) {
    if (!record(value) || value.reference !== expectedReference) return false;
    if (value.kind === "packaged_selector_reference") {
      return exact(value, ["kind", "reference"]);
    }
    if (value.kind === "accessibility_role_name") {
      return exact(value, ["kind", "role", "reference"]) && ACCESSIBILITY_ROLES.has(value.role);
    }
    return false;
  }
  function validPlan(value, expected) {
    if (!exact(value, ["strategy", "primary", "fallbacks", "timeoutMs", "observationMode"])) return false;
    if (value.strategy !== expected.strategy || !validPrimitive(value.primary, expected.reference)) return false;
    if (!Array.isArray(value.fallbacks) || value.fallbacks.length > 3 ||
        !value.fallbacks.every((primitive) => validPrimitive(primitive, expected.reference))) return false;
    if (!Number.isSafeInteger(value.timeoutMs) || value.timeoutMs < 250 || value.timeoutMs > 30000) return false;
    if (!OBSERVATION_MODES.has(value.observationMode)) return false;
    return value.observationMode !== "polling" || value.timeoutMs >= 500;
  }
  function validCompatibility(value) {
    if (!exact(value, ["schemaVersion", "contractVersion", "browserFamilies", "minimumBrowserVersions", "minimumExtensionVersion"])) return false;
    if (value.schemaVersion !== "profile_compatibility_v1" ||
        !["control_plane_v1", "control_plane_v2"].includes(value.contractVersion)) return false;
    if (!Array.isArray(value.browserFamilies) || value.browserFamilies.length < 1 ||
        value.browserFamilies.length > BROWSER_FAMILIES.length ||
        new Set(value.browserFamilies).size !== value.browserFamilies.length ||
        !value.browserFamilies.every((family) => BROWSER_FAMILIES.includes(family))) return false;
    if (!Array.isArray(value.minimumBrowserVersions) ||
        value.minimumBrowserVersions.length > BROWSER_FAMILIES.length ||
        new Set(value.minimumBrowserVersions.map((row) => row?.browserFamily)).size !== value.minimumBrowserVersions.length) return false;
    for (const row of value.minimumBrowserVersions) {
      if (!exact(row, ["browserFamily", "minimumVersion"]) ||
          !value.browserFamilies.includes(row.browserFamily) ||
          typeof row.minimumVersion !== "string" || row.minimumVersion.length > 64 ||
          !BROWSER_VERSION.test(row.minimumVersion)) return false;
    }
    return value.minimumExtensionVersion === null ||
      (typeof value.minimumExtensionVersion === "string" &&
       value.minimumExtensionVersion.length <= 64 && SEMVER.test(value.minimumExtensionVersion));
  }
  function validContent(value) {
    if (!exact(value, ["schemaVersion", "page", "selectors", "observation", "contours"]) ||
        value.schemaVersion !== "adapter_profile_v1") return false;
    if (!exact(value.page, ["identityStrategy", "conversationStrategy", "composerStrategy"]) ||
        value.page.identityStrategy !== "page_identity" ||
        value.page.conversationStrategy !== "conversation_root" ||
        value.page.composerStrategy !== "composer_root") return false;
    if (!exact(value.selectors, ["conversation", "composer", "send", "assistantResponse"])) return false;
    for (const slot of Object.keys(SLOT)) {
      if (!validPlan(value.selectors[slot], SLOT[slot])) return false;
    }
    if (!exact(value.observation, ["mode", "intervalMs"]) ||
        !OBSERVATION_MODES.has(value.observation.mode) ||
        !Number.isSafeInteger(value.observation.intervalMs) ||
        value.observation.intervalMs < 100 || value.observation.intervalMs > 5000 ||
        (value.observation.mode === "mutation_observer" && value.observation.intervalMs !== 100)) return false;
    if (!Array.isArray(value.contours) || value.contours.length < 4 || value.contours.length > 7) return false;
    if (new Set(value.contours.map((row) => row?.key)).size !== value.contours.length) return false;
    for (const contour of value.contours) {
      if (!exact(contour, ["key", "required", "expectedState", "strategy"]) ||
          !CONTOUR_KEYS.has(contour.key) || contour.strategy !== contour.key ||
          typeof contour.required !== "boolean" || !EXPECTED_STATES.has(contour.expectedState)) return false;
    }
    return true;
  }
  function validMaterialShape(value) {
    return exact(value, [
      "profileKey", "revision", "scopeVariant", "contentSha256",
      "schemaVersion", "content", "compatibility",
    ]) &&
      machine(value.profileKey) && positiveSafeInt(value.revision) && value.scopeVariant === null &&
      value.schemaVersion === "adapter_profile_v1" &&
      typeof value.contentSha256 === "string" && DIGEST.test(value.contentSha256) &&
      validContent(value.content) && validCompatibility(value.compatibility);
  }
  async function profileFingerprint(value) {
    if (!validMaterialShape(value)) return null;
    return sha256Hex(canonical({ content: value.content, compatibility: value.compatibility }));
  }
  async function validMaterial(value) {
    const fingerprint = await profileFingerprint(value);
    return fingerprint !== null && fingerprint === value.contentSha256;
  }
  function validRequest(value) {
    return exact(value, ["messageType", "protocolVersion", "requestId", "ai"]) &&
      value.messageType === "OZ_REQUEST_SIGNED_AI_PROFILE" &&
      value.protocolVersion === PROTOCOL_VERSION &&
      typeof value.requestId === "string" && UUID.test(value.requestId) &&
      validScope(value.ai);
  }
  async function validResponse(value) {
    if (!record(value) || value.messageType !== "OZ_SIGNED_AI_PROFILE" ||
        value.protocolVersion !== PROTOCOL_VERSION ||
        typeof value.requestId !== "string" || !UUID.test(value.requestId) ||
        !validScope(value.ai)) return false;
    if (value.status === "UNAVAILABLE") {
      return exact(value, ["messageType", "protocolVersion", "requestId", "ai", "status", "reason"]) &&
        UNAVAILABLE_REASONS.has(value.reason);
    }
    if (value.status !== "AVAILABLE" ||
        !exact(value, ["messageType", "protocolVersion", "requestId", "ai", "status", "authority", "profile"]) ||
        !validAuthority(value.authority)) return false;
    return validMaterial(value.profile);
  }
  function validReceipt(value) {
    if (!record(value) || value.messageType !== "OZ_SIGNED_AI_PROFILE_RECEIPT" ||
        value.protocolVersion !== PROTOCOL_VERSION ||
        typeof value.requestId !== "string" || !UUID.test(value.requestId) ||
        !validScope(value.ai)) return false;
    if (value.status === "CLEARED") {
      return exact(value, ["messageType", "protocolVersion", "requestId", "ai", "status", "reason"]) &&
        UNAVAILABLE_REASONS.has(value.reason);
    }
    if (value.status === "REJECTED") {
      return exact(value, ["messageType", "protocolVersion", "requestId", "ai", "status", "reason"]) &&
        REJECT_REASONS.has(value.reason);
    }
    const keys = value.status === "DEFERRED"
      ? ["messageType", "protocolVersion", "requestId", "ai", "status", "authority", "profile", "reason"]
      : ["messageType", "protocolVersion", "requestId", "ai", "status", "authority", "profile"];
    if (!["APPLIED", "DEFERRED"].includes(value.status) || !exact(value, keys) ||
        !validAuthority(value.authority) || !validIdentity(value.profile)) return false;
    return value.status !== "DEFERRED" || value.reason === "WORK_IN_FLIGHT";
  }

  globalThis.SellerAgentsSignedAiProfileConsumer = Object.freeze({
    PROTOCOL_VERSION,
    validRequest,
    validResponse,
    validReceipt,
    validMaterial,
    validMaterialShape,
    profileFingerprint,
    canonicalJson: canonical,
  });
})();

;
(() => {
  "use strict";

  const MAGIC = "seller_agents_store_backup";
  const ENVELOPE_VERSION = 1;
  const PAYLOAD_VERSION = "seller_agents_store_backup_payload_v1";
  const KDF_NAME = "PBKDF2-HMAC-SHA-256";
  const ENCRYPTION_NAME = "AES-256-GCM";
  const KDF_ITERATIONS = 210000;
  const LIMITS = Object.freeze({
    maxFileBytes: 8 * 1024 * 1024,
    minIterations: 100000,
    maxIterations: 600000,
    maxStores: 100,
    maxString: 8192,
    maxLabel: 80,
    maxDepth: 8,
    maxCiphertextBytes: 8 * 1024 * 1024,
  });
  const encoder = new TextEncoder();
  const decoder = new TextDecoder("utf-8", { fatal: true });
  const fail = (code) => { throw Object.assign(new Error(code), { code }); };
  const clone = (value) => structuredClone(value);
  const canonical = (value) => {
    if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
    if (value && typeof value === "object") return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
    return JSON.stringify(value);
  };
  const bytes = (value) => encoder.encode(typeof value === "string" ? value : JSON.stringify(value));
  const b64 = (value) => {
    const input = new Uint8Array(value), chunk = 0x8000;
    let output = "";
    for (let index = 0; index < input.length; index += chunk) output += String.fromCharCode(...input.subarray(index, index + chunk));
    return btoa(output);
  };
  const unb64 = (value, max = LIMITS.maxCiphertextBytes) => {
    if (typeof value !== "string" || value.length === 0 || value.length > Math.ceil(max / 3) * 4 + 4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) fail("BACKUP_ENCODING_INVALID");
    let raw;
    try { raw = atob(value); } catch (_) { fail("BACKUP_ENCODING_INVALID"); }
    if (raw.length > max) fail("BACKUP_RESOURCE_LIMIT");
    return Uint8Array.from(raw, (char) => char.charCodeAt(0));
  };
  const string = (value, name, max = LIMITS.maxString) => {
    if (typeof value !== "string" || value.length === 0 || value.length > max || /[\u0000-\u001f\u007f]/.test(value)) fail(`BACKUP_${name}_INVALID`);
    return value;
  };
  const exactKeys = (value, keys, code = "BACKUP_UNKNOWN_FIELDS") => {
    if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).sort().join("\0") !== [...keys].sort().join("\0")) fail(code);
  };
  const object = (value, name) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) fail(`BACKUP_${name}_INVALID`);
    return value;
  };
  function depth(value, level = 0) {
    if (level > LIMITS.maxDepth) fail("BACKUP_RESOURCE_LIMIT");
    if (value && typeof value === "object") for (const child of Object.values(value)) depth(child, level + 1);
  }
  function validRevision(value) { return string(value, "CREDENTIAL_REVISION", 128); }
  function validateCredentials(marketplace, value) {
    object(value, "CREDENTIALS");
    if (marketplace === "ozon") {
      exactKeys(value, ["type", "version", "seller", "performance"]);
      if (value.type !== "ozon" || value.version !== 1) fail("BACKUP_CREDENTIAL_SHAPE_INVALID");
      exactKeys(value.seller, ["clientId", "apiKey"]);
      string(value.seller.clientId, "SELLER_CLIENT_ID"); string(value.seller.apiKey, "SELLER_API_KEY");
      if (value.performance !== null) {
        exactKeys(value.performance, ["clientId", "clientSecret"]);
        string(value.performance.clientId, "PERFORMANCE_CLIENT_ID"); string(value.performance.clientSecret, "PERFORMANCE_CLIENT_SECRET");
      }
      return clone(value);
    }
    if (marketplace === "wildberries") {
      exactKeys(value, ["type", "version", "token", "tokenType"]);
      if (value.type !== "wildberries" || value.version !== 1 || value.tokenType !== "personal") fail("BACKUP_CREDENTIAL_SHAPE_INVALID");
      string(value.token, "WB_TOKEN");
      return clone(value);
    }
    fail("BACKUP_MARKETPLACE_INVALID");
  }
  function validatePayload(value, accountId) {
    object(value, "PAYLOAD"); depth(value);
    exactKeys(value, ["payloadVersion", "accountBinding", "createdAt", "stores"]);
    if (value.payloadVersion !== PAYLOAD_VERSION) fail("BACKUP_VERSION_UNSUPPORTED");
    exactKeys(value.accountBinding, ["accountId"]);
    if (string(value.accountBinding.accountId, "ACCOUNT_ID", 256) !== accountId) fail("BACKUP_ACCOUNT_MISMATCH");
    string(value.createdAt, "CREATED_AT", 64);
    if (!Array.isArray(value.stores) || value.stores.length > LIMITS.maxStores) fail("BACKUP_RESOURCE_LIMIT");
    const ids = new Set();
    const stores = value.stores.map((store) => {
      object(store, "STORE");
      exactKeys(store, ["storeId", "label", "marketplace", "providerAccountId", "providerIdentityState", "credentialRevision", "metadataRevision", "credentials"]);
      const storeId = string(store.storeId, "STORE_ID", 128);
      if (ids.has(storeId)) fail("BACKUP_DUPLICATE_STORE_ID");
      ids.add(storeId);
      const label = string(store.label, "STORE_LABEL", LIMITS.maxLabel);
      if (!["ozon", "wildberries"].includes(store.marketplace)) fail("BACKUP_MARKETPLACE_INVALID");
      if (!["CONFIRMED", "UNCONFIRMED"].includes(store.providerIdentityState)) fail("BACKUP_PROVIDER_IDENTITY_INVALID");
      if (store.providerIdentityState === "CONFIRMED") string(store.providerAccountId, "PROVIDER_ACCOUNT_ID", 128);
      else if (store.providerAccountId !== null) fail("BACKUP_PROVIDER_IDENTITY_INVALID");
      const revision = validRevision(store.credentialRevision);
      if (!Number.isSafeInteger(store.metadataRevision) || store.metadataRevision < 0) fail("BACKUP_METADATA_REVISION_INVALID");
      return { storeId, label, marketplace: store.marketplace, providerAccountId: store.providerIdentityState === "CONFIRMED" ? store.providerAccountId : null, providerIdentityState: store.providerIdentityState, credentialRevision: revision, metadataRevision: store.metadataRevision, credentials: validateCredentials(store.marketplace, store.credentials) };
    });
    return { payloadVersion: PAYLOAD_VERSION, accountBinding: { accountId }, createdAt: value.createdAt, stores };
  }
  function metadataOnly(store) {
    const credentials = store.credentials;
    return credentials == null || typeof credentials === "object" && !Array.isArray(credentials) && Object.keys(credentials).length === 0;
  }
  function payloadFromStores(accountId, stores) {
    return validatePayload({ payloadVersion: PAYLOAD_VERSION, accountBinding: { accountId }, createdAt: new Date().toISOString(), stores: stores.filter((store) => (store.lifecycleState || "ACTIVE") === "ACTIVE" && !metadataOnly(store)).map((store) => ({
      storeId: store.id, label: store.name, marketplace: store.marketplace, providerAccountId: store.providerIdentityState === "CONFIRMED" ? store.providerAccountId : null, providerIdentityState: store.providerIdentityState === "CONFIRMED" ? "CONFIRMED" : "UNCONFIRMED", credentialRevision: store.credentialRevision, metadataRevision: Number.isSafeInteger(store.metadataRevision) ? store.metadataRevision : 0,
      credentials: store.marketplace === "ozon" ? { type: "ozon", version: 1, seller: { clientId: store.credentials?.seller?.clientId || "", apiKey: store.credentials?.seller?.apiKey || "" }, performance: store.credentials?.performance?.clientId && store.credentials?.performance?.clientSecret ? { clientId: store.credentials.performance.clientId, clientSecret: store.credentials.performance.clientSecret } : null } : { type: "wildberries", version: 1, token: store.credentials?.token || "", tokenType: "personal" },
    })) }, accountId);
  }
  function headerFromFields(value) {
    return { magic: MAGIC, envelopeVersion: ENVELOPE_VERSION, kdf: { name: KDF_NAME, hash: "SHA-256", iterations: value.kdf.iterations, salt: value.kdf.salt }, encryption: { name: ENCRYPTION_NAME, keyLength: 256, iv: value.encryption.iv, tagLength: 128 } };
  }
  function validateEnvelope(value) {
    object(value, "ENVELOPE"); depth(value);
    exactKeys(value, ["magic", "envelopeVersion", "kdf", "encryption", "ciphertext"]);
    if (value.magic !== MAGIC || value.envelopeVersion !== ENVELOPE_VERSION) fail("BACKUP_VERSION_UNSUPPORTED");
    exactKeys(value.kdf, ["name", "hash", "iterations", "salt"]); exactKeys(value.encryption, ["name", "keyLength", "iv", "tagLength"]);
    if (value.kdf.name !== KDF_NAME || value.kdf.hash !== "SHA-256" || !Number.isSafeInteger(value.kdf.iterations) || value.kdf.iterations < LIMITS.minIterations || value.kdf.iterations > LIMITS.maxIterations) fail("BACKUP_KDF_INVALID");
    const salt = unb64(value.kdf.salt, 64), iv = unb64(value.encryption.iv, 32), ciphertext = unb64(value.ciphertext);
    if (salt.length < 16 || salt.length > 64 || iv.length !== 12 || value.encryption.name !== ENCRYPTION_NAME || value.encryption.keyLength !== 256 || value.encryption.tagLength !== 128 || ciphertext.length < 16) fail("BACKUP_ENVELOPE_INVALID");
    const header = headerFromFields(value);
    return { value, header, salt, iv, ciphertext, aad: encoder.encode(canonical(header)) };
  }
  async function key(password, salt, iterations, usage) {
    if (typeof password !== "string" || password.length < 8 || password.length > 256) fail("BACKUP_PASSWORD_INVALID");
    const material = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, material, { name: "AES-GCM", length: 256 }, false, usage);
  }
  async function encrypt(payload, password) {
    const normalized = validatePayload(payload, payload.accountBinding.accountId);
    const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
    const value = { kdf: { iterations: KDF_ITERATIONS, salt: b64(salt) }, encryption: { iv: b64(iv) } };
    const header = headerFromFields(value), aes = await key(password, salt, KDF_ITERATIONS, ["encrypt"]);
    const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: encoder.encode(canonical(header)), tagLength: 128 }, aes, encoder.encode(canonical(normalized)));
    const envelope = { magic: MAGIC, envelopeVersion: ENVELOPE_VERSION, kdf: header.kdf, encryption: header.encryption, ciphertext: b64(ciphertext) };
    if (bytes(JSON.stringify(envelope)).byteLength > LIMITS.maxFileBytes) fail("BACKUP_RESOURCE_LIMIT");
    return JSON.stringify(envelope);
  }
  function checksum(value) {
    return crypto.subtle.digest("SHA-256", encoder.encode(canonical(value))).then((digest) => [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join(""));
  }
  async function legacyPayload(value, accountId) {
    object(value, "LEGACY"); depth(value);
    const make = async (marketplace, credentials, suffix) => {
      const identity = await checksum({
        accountId,
        marketplace,
        format: value.format,
        backup_version: value.backup_version,
        exported_at: value.exported_at,
        extension_version: value.extension_version,
        extension_id: value.extension_id,
      });
      return { payloadVersion: PAYLOAD_VERSION, accountBinding: { accountId }, createdAt: String(value.exported_at || new Date().toISOString()), stores: [{ storeId: `legacy-${marketplace}-${identity.slice(0, 32)}`, label: `Imported ${suffix}`, marketplace, providerAccountId: null, providerIdentityState: "UNCONFIRMED", credentialRevision: `legacy-${identity}`, metadataRevision: 0, credentials }] };
    };
    const incoming = value.credentials;
    if (value.format === "ozon-bridge-seller-credentials-backup" && value.backup_version === 1) {
      exactKeys(value, ["format", "backup_version", "exported_at", "extension_version", "extension_id", "contains_secrets", "credentials_sha256", "credentials"]);
      exactKeys(incoming, ["seller_client_id", "seller_api_key"]); if (value.contains_secrets !== true) fail("BACKUP_LEGACY_INVALID");
      if (await checksum(incoming) !== String(value.credentials_sha256 || "").toLowerCase()) fail("BACKUP_CHECKSUM_MISMATCH");
      return validatePayload(await make("ozon", { type: "ozon", version: 1, seller: { clientId: string(incoming.seller_client_id, "SELLER_CLIENT_ID"), apiKey: string(incoming.seller_api_key, "SELLER_API_KEY") }, performance: null }, "Ozon"), accountId);
    }
    if (value.format === "ozon-bridge-credentials-backup" && value.backup_version === 2) {
      exactKeys(value, ["format", "backup_version", "exported_at", "extension_version", "extension_id", "contains_secrets", "credentials_sha256", "credentials"]);
      exactKeys(incoming, ["seller_client_id", "seller_api_key", "performance_client_id", "performance_client_secret"]); if (value.contains_secrets !== true) fail("BACKUP_LEGACY_INVALID");
      if (await checksum(incoming) !== String(value.credentials_sha256 || "").toLowerCase()) fail("BACKUP_CHECKSUM_MISMATCH");
      const seller = string(incoming.seller_client_id, "SELLER_CLIENT_ID"), apiKey = string(incoming.seller_api_key, "SELLER_API_KEY");
      const performance = incoming.performance_client_id && incoming.performance_client_secret ? { clientId: string(incoming.performance_client_id, "PERFORMANCE_CLIENT_ID"), clientSecret: string(incoming.performance_client_secret, "PERFORMANCE_CLIENT_SECRET") } : null;
      return validatePayload(await make("ozon", { type: "ozon", version: 1, seller: { clientId: seller, apiKey }, performance }, "Ozon"), accountId);
    }
    if (value.format === "wildberries-bridge-seller-credentials-backup" && [1, 2].includes(value.backup_version)) {
      exactKeys(value, ["format", "backup_version", "exported_at", "extension_version", "extension_id", "contains_secrets", "credentials_sha256", "credentials"]);
      exactKeys(incoming, ["seller_token", "seller_token_type"]); if (value.contains_secrets !== true || incoming.seller_token_type !== "personal") fail("BACKUP_LEGACY_INVALID");
      if (await checksum(incoming) !== String(value.credentials_sha256 || "").toLowerCase()) fail("BACKUP_CHECKSUM_MISMATCH");
      return validatePayload(await make("wildberries", { type: "wildberries", version: 1, token: string(incoming.seller_token, "WB_TOKEN"), tokenType: "personal" }, "Wildberries"), accountId);
    }
    fail("BACKUP_VERSION_UNSUPPORTED");
  }
  async function decrypt(input, password, accountId) {
    if (typeof accountId !== "string" || !accountId) fail("AUTH_REQUIRED");
    if (input instanceof Uint8Array && input.byteLength > LIMITS.maxFileBytes) fail("BACKUP_FILE_TOO_LARGE");
    let text; try { text = input instanceof Uint8Array ? decoder.decode(input) : String(input ?? ""); } catch (_) { fail("BACKUP_ENCODING_INVALID"); }
    if (!text || bytes(text).byteLength > LIMITS.maxFileBytes) fail("BACKUP_FILE_TOO_LARGE");
    let parsed; try { parsed = JSON.parse(text); } catch (_) { fail("BACKUP_JSON_INVALID"); }
    if (parsed?.magic !== MAGIC) return { payload: await legacyPayload(parsed, accountId), legacy: true };
    const checked = validateEnvelope(parsed), aes = await key(password, checked.salt, checked.value.kdf.iterations, ["decrypt"]);
    let plain; try { plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: checked.iv, additionalData: checked.aad, tagLength: 128 }, aes, checked.ciphertext); } catch (_) { fail("BACKUP_AUTHENTICATION_FAILED"); }
    let value; try { value = JSON.parse(decoder.decode(plain)); } catch (_) { fail("BACKUP_PAYLOAD_INVALID"); }
    return { payload: validatePayload(value, accountId), legacy: false };
  }
  function summary(payload, classifications = []) {
    return { storeCount: payload.stores.length, marketplaces: [...new Set(payload.stores.map((store) => store.marketplace))], conflictCount: classifications.filter((row) => !["IMPORT_NEW", "SAME_CURRENT"].includes(row.kind)).length, safeImportCount: classifications.filter((row) => row.kind === "IMPORT_NEW").length, rejectedCount: classifications.filter((row) => !["IMPORT_NEW", "SAME_CURRENT"].includes(row.kind)).length };
  }
  globalThis.SellerAgentsStoreBackup = Object.freeze({ MAGIC, ENVELOPE_VERSION, PAYLOAD_VERSION, KDF_NAME, ENCRYPTION_NAME, KDF_ITERATIONS, LIMITS, payloadFromStores, validatePayload, encrypt, decrypt, summary });
})();

;
/* Independent packaged-local capability authority.
 * Presence here means the adapter is packaged. It is never a Work grant and
 * has no implicit relationship to signed feature/entitlement keys. */
(() => {
  "use strict";

  const ID = /^[a-z0-9][a-z0-9._-]{2,95}$/;
  const entries = [
    {
      id: "marketplace.ozon.adapter",
      kind: "marketplace_adapter",
      marketplace: "ozon",
      packaged: true,
      executionAuthority: false,
    },
    {
      id: "marketplace.wildberries.adapter",
      kind: "marketplace_adapter",
      marketplace: "wildberries",
      packaged: true,
      executionAuthority: false,
    },
    {
      id: "ai.chatgpt.web.adapter",
      kind: "ai_adapter",
      family: "chatgpt",
      surface: "web",
      packaged: true,
      executionAuthority: false,
    },
    {
      id: "ai.alice.web.adapter",
      kind: "ai_adapter",
      family: "alice",
      surface: "web",
      packaged: true,
      executionAuthority: false,
    },
    {
      id: "ai.qwen.web.adapter",
      kind: "ai_adapter",
      family: "qwen",
      surface: "web",
      packaged: true,
      executionAuthority: false,
    },
    {
      id: "ai.kimi.web.adapter",
      kind: "ai_adapter",
      family: "kimi",
      surface: "web",
      packaged: true,
      executionAuthority: false,
    },
    {
      id: "ai.grok.web.adapter",
      kind: "ai_adapter",
      family: "grok",
      surface: "web",
      packaged: true,
      executionAuthority: false,
    },
    {
      id: "ai.gemini.web.adapter",
      kind: "ai_adapter",
      family: "gemini",
      surface: "web",
      packaged: true,
      executionAuthority: false,
    },
    {
      id: "ai.claude.web.adapter",
      kind: "ai_adapter",
      family: "claude",
      surface: "web",
      packaged: true,
      executionAuthority: false,
    },
    {
      id: "ai.deepseek.web.adapter",
      kind: "ai_adapter",
      family: "deepseek",
      surface: "web",
      packaged: true,
      executionAuthority: false,
    },
  ];

  function deepFreeze(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
    for (const nested of Object.values(value)) deepFreeze(nested);
    return Object.freeze(value);
  }

  const manifest = deepFreeze({
    schemaVersion: "packaged_capability_manifest_v1",
    authority: "PACKAGED_LOCAL_ONLY",
    executionAuthority: false,
    signedPermissionBindings: [],
    capabilities: entries,
  });
  const byId = new Map(entries.map(entry => [entry.id, entry]));

  function validId(id) {
    return typeof id === "string" && ID.test(id);
  }

  function has(id) {
    return validId(id) && byId.has(id);
  }

  function describe(id) {
    return validId(id) ? byId.get(id) || null : null;
  }

  function snapshot() {
    return manifest;
  }

  const api = Object.freeze({
    schemaVersion: manifest.schemaVersion,
    has,
    describe,
    snapshot,
  });
  Object.defineProperty(globalThis, "SellerAgentsPackagedCapabilities", {
    value: api,
    writable: false,
    configurable: false,
    enumerable: true,
  });
})();

;
/* Per-principal bootstrap scheduling. This queue never executes business commands. */
(() => {
  "use strict";
  const WAIT_MS = 65000, ACTIVE_MS = 60000;
  const fenceFields = ["principalEpoch", "accessEpoch", "grantEpoch", "environmentKey", "scopeKey"];
  const failure = (code, details = {}) => Object.assign(new Error(code), { code, ...details });
  function captureFence(value) {
    if (!value || typeof value !== "object") throw failure("BOOTSTRAP_FENCE_REQUIRED");
    for (const name of ["principalEpoch", "accessEpoch", "grantEpoch"]) {
      if (!Number.isSafeInteger(value[name]) || value[name] < 0) throw failure("BOOTSTRAP_FENCE_INVALID");
    }
    for (const name of ["environmentKey", "scopeKey"]) {
      if (typeof value[name] !== "string" || !value[name]) throw failure("BOOTSTRAP_FENCE_INVALID");
    }
    return Object.freeze(Object.fromEntries(fenceFields.map(name => [name, value[name]])));
  }
  async function createScopeIdentity(input, { canonicalJson, sha256 } = {}) {
    if (typeof canonicalJson !== "function" || typeof sha256 !== "function") throw failure("SCOPE_HASH_PORT_REQUIRED");
    const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const principal = {};
    for (const field of ["controlApiOrigin", "portalOrigin"]) {
      let parsed;
      try { parsed = new URL(input[field]); } catch (_) { throw failure("SCOPE_ORIGIN_INVALID"); }
      const loopbackDevelopment = input.development === true && parsed.protocol === "http:" &&
        ["127.0.0.1", "localhost", "[::1]"].includes(parsed.hostname);
      if (input[field] !== parsed.origin || !(parsed.protocol === "https:" || loopbackDevelopment) ||
          !Array.isArray(input.allowedOrigins) || !input.allowedOrigins.includes(parsed.origin)) throw failure("SCOPE_ORIGIN_INVALID");
      principal[field] = parsed.origin;
    }
    for (const field of ["accountId", "deviceId", "sessionId"]) {
      if (!uuid.test(input[field] || "")) throw failure("SCOPE_PRINCIPAL_INVALID");
      principal[field] = input[field].toLowerCase();
    }
    if (!Number.isSafeInteger(input.principalEpoch) || input.principalEpoch < 0) throw failure("SCOPE_PRINCIPAL_INVALID");
    principal.principalEpoch = input.principalEpoch;
    const ai = input.ai;
    if (!ai || !["chatgpt", "alice", "qwen", "kimi", "grok", "gemini", "claude", "deepseek"].includes(ai.family) || ai.surface !== "web" || ai.variant !== null)
      throw failure("SCOPE_AI_UNSUPPORTED");
    if (!["control_plane_v2", "control_plane_v3"].includes(input.contractVersion) ||
        typeof input.extensionVersion !== "string" || !/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(input.extensionVersion) ||
        !input.browser || !["chrome", "opera", "yandex_chromium", "firefox", "safari"].includes(input.browser.family) ||
        typeof input.browser.version !== "string" || !/^\d+(?:\.\d+){0,3}$/.test(input.browser.version) ||
        !/^[0-9a-f]{64}$/.test(input.trustBundleSha256 || "") ||
        !["identified", "privacy-neutral"].includes(input.privacyProjection)) throw failure("SCOPE_ENVIRONMENT_INVALID");
    const principalKey = canonicalJson(principal);
    const environmentKey = await sha256(canonicalJson({ contractVersion: input.contractVersion,
      extensionVersion: input.extensionVersion, browser: { family: input.browser.family, version: input.browser.version },
      trustBundleSha256: input.trustBundleSha256, privacyProjection: input.privacyProjection }));
    const scope = Object.freeze({ family: ai.family, surface: ai.surface, variant: null });
    const scopeKey = await sha256(canonicalJson({ keyVersion: 1, principalKey, environmentKey, ai: scope }));
    return Object.freeze({ principalKey, environmentKey, scopeKey, ai: scope });
  }
  const sameFence = (a, b) => fenceFields.every(name => a[name] === b[name]);
  function createBootstrapScheduler({
    isFenceCurrent, observeLateOutcome, quarantine,
    now = () => performance.now(),
    setTimer = (fn, ms) => setTimeout(fn, ms),
    clearTimer = id => clearTimeout(id),
    makeId = () => crypto.randomUUID(),
    workerInstanceId = makeId(),
    waitTimeoutMs = WAIT_MS,
    activeTimeoutMs = ACTIVE_MS,
    maxScopes = 2,
  }) {
    for (const fn of [isFenceCurrent, observeLateOutcome, quarantine]) {
      if (typeof fn !== "function") throw failure("BOOTSTRAP_SECURITY_OBSERVER_REQUIRED");
    }
    if (!Number.isFinite(waitTimeoutMs) || waitTimeoutMs <= 0 || waitTimeoutMs > WAIT_MS ||
        !Number.isFinite(activeTimeoutMs) || activeTimeoutMs <= 0 || activeTimeoutMs > ACTIVE_MS ||
        maxScopes !== 2) throw failure("BOOTSTRAP_LIMIT_INVALID");
    const scopes = new Map(), sequence = new Map(), deadlines = new WeakMap(), queue = [];
    let active = null, closed = false, pumping = false, quarantined = false;
    function quarantineAll(error) {
      closed = true;
      if (!quarantined) {
        quarantined = true;
        try { Promise.resolve(quarantine(error)).catch(() => {}); } catch (_) { /* Closed. */ }
      }
      for (const pending of [...scopes.values()]) retire(pending, "BOOTSTRAP_SECURITY_QUARANTINE");
    }
    function fenceCurrent(fence) {
      try { return isFenceCurrent(fence) === true; }
      catch (error) { quarantineAll(error); return false; }
    }
    function nextSeq(key) {
      const next = (sequence.get(key) || 0) + 1;
      if (!Number.isSafeInteger(next)) throw failure("BOOTSTRAP_SEQUENCE_EXHAUSTED");
      sequence.set(key, next);
      return next;
    }
    function current(job) {
      return !closed && job.ticket.workerInstanceId === workerInstanceId &&
        sequence.get(job.key) === job.ticket.scopeSeq && fenceCurrent(job.committedFence || job.ticket.fence);
    }
    function releaseWaiter(job, waiter, outcome, value) {
      if (waiter.done) return;
      waiter.done = true;
      clearTimer(waiter.timer);
      waiter.signal?.removeEventListener("abort", waiter.onAbort);
      job.waiters.delete(waiter);
      waiter[outcome](value);
    }
    function remove(job) {
      if (scopes.get(job.key) === job) scopes.delete(job.key);
      const index = queue.indexOf(job);
      if (index !== -1) queue.splice(index, 1);
      if (active === job) active = null;
      clearTimer(job.activeTimer);
    }
    function retire(job, code, details = {}) {
      if (job.state === "retired" || job.state === "settled") return;
      if (job.commitStarted && !quarantined) {
        quarantineAll(failure("BOOTSTRAP_SECURITY_COMMIT_UNKNOWN"));
        return;
      }
      const acquisition = job.dispatched ? "OUTCOME_UNKNOWN" : "NOT_STARTED";
      job.state = "retired";
      if (sequence.get(job.key) === job.ticket.scopeSeq) nextSeq(job.key);
      remove(job);
      const error = failure(code, { acquisition, retryRequiresExplicitAction: true, ...details });
      for (const waiter of [...job.waiters]) releaseWaiter(job, waiter, "reject", error);
      // Logical slot release is bounded; abort does not promise physical cancellation.
      job.controller.abort(error);
      pump();
    }
    function late(job, outcome) {
      Promise.resolve().then(() => observeLateOutcome(Object.freeze({
        ticket: job.ticket, ...outcome,
      }))).catch(error => {
        // An unknown security commit must never be bypassed by a concurrent writer.
        quarantineAll(error);
      });
    }
    function settle(job, ok, value) {
      if (job.state !== "active") {
        late(job, ok ? { value } : { error: value });
        return;
      }
      if (job.commitStarted) {
        quarantineAll(failure("BOOTSTRAP_SECURITY_COMMIT_UNKNOWN"));
        late(job, ok ? { value } : { error: value });
        return;
      }
      if (job.revocationCommitted && ok) {
        quarantineAll(failure("BOOTSTRAP_ALLOW_AFTER_REVOCATION"));
        return;
      }
      if (now() >= job.activeDeadline || !job.revocationCommitted && !current(job)) {
        retire(job, now() >= job.activeDeadline ? "BOOTSTRAP_ACTIVE_EXPIRED" : "BOOTSTRAP_CONTEXT_CHANGED");
        late(job, ok ? { value } : { error: value });
        return;
      }
      job.state = "settled";
      remove(job);
      for (const waiter of [...job.waiters]) {
        releaseWaiter(job, waiter, ok ? "resolve" : "reject",
          ok ? Object.freeze({ value, ticket: job.ticket }) : value);
      }
      pump();
    }
    function pump() {
      if (pumping || closed || active) return;
      pumping = true;
      try {
        while (!closed && !active && queue.length) {
          const job = queue[0];
          // Recheck deadlines before effects, including after a suspended worker wakes.
          for (const waiter of [...job.waiters]) {
            if (now() >= waiter.deadline) {
              releaseWaiter(job, waiter, "reject", failure("BOOTSTRAP_QUEUE_WAIT_EXPIRED", {
                acquisition: "NOT_STARTED", retryRequiresExplicitAction: true,
              }));
            }
          }
          if (!job.waiters.size) {
            retire(job, "BOOTSTRAP_QUEUE_WAIT_EXPIRED");
            continue;
          }
          if (!current(job)) {
            retire(job, "BOOTSTRAP_CONTEXT_CHANGED");
            continue;
          }
          queue.shift();
          active = job;
          job.state = "active";
          job.activeDeadline = now() + activeTimeoutMs;
          deadlines.set(job.ticket, job.activeDeadline);
          for (const waiter of job.waiters) clearTimer(waiter.timer);
          job.activeTimer = setTimer(() => retire(job, "BOOTSTRAP_ACTIVE_EXPIRED"), activeTimeoutMs);
          const request = Object.freeze({
            ...job.ticket, signal: job.controller.signal,
            deadline: job.activeDeadline,
            beginSecurityCommit() {
              this.assertCurrent();
              job.commitStarted = true;
            },
            finishRevocationCommit() {
              // A confirmed common denial intentionally invalidates the captured fence.
              // Preserve its original rejection; it can never complete as an allow.
              if (!job.commitStarted || job.state !== "active" || closed || now() >= job.activeDeadline ||
                  sequence.get(job.key) !== job.ticket.scopeSeq)
                throw failure("BOOTSTRAP_REVOCATION_COMMIT_INVALID");
              job.commitStarted = false;
              job.revocationCommitted = true;
            },
            finishSecurityCommit(committedFence = null) {
              if (committedFence !== null) {
                const next = captureFence(committedFence), before = job.committedFence || job.ticket.fence;
                // Only the current writer may acknowledge its own committed epoch change.
                // The immutable acquisition ticket and every command fence stay unchanged.
                if (!job.commitStarted || job.state !== "active" || closed || now() >= job.activeDeadline ||
                    sequence.get(job.key) !== job.ticket.scopeSeq || next.scopeKey !== before.scopeKey ||
                    next.environmentKey !== before.environmentKey || next.principalEpoch !== before.principalEpoch ||
                    next.accessEpoch < before.accessEpoch || !fenceCurrent(next))
                  throw failure("BOOTSTRAP_COMMIT_FENCE_INVALID");
                job.committedFence = next;
              }
              this.assertCurrent();
              job.commitStarted = false;
            },
            assertCurrent() {
              if (job.state !== "active" || now() >= job.activeDeadline || !current(job)) {
                throw failure("BOOTSTRAP_ATTEMPT_OBSOLETE");
              }
            },
          });
          // No retry or re-enqueue occurs here, even when the run rejects.
          Promise.resolve().then(() => {
            request.assertCurrent();
            job.dispatched = true;
            return job.run(request);
          }).then(value => settle(job, true, value), error => settle(job, false, error));
        }
      } finally { pumping = false; }
    }
    function request({ fence: suppliedFence, requestKey = "", run, signal, waitMs = waitTimeoutMs }) {
      if (closed) return Promise.reject(failure("BOOTSTRAP_SECURITY_QUARANTINE"));
      if (typeof requestKey !== "string" || typeof run !== "function" || !Number.isFinite(waitMs) || waitMs <= 0 || waitMs > WAIT_MS) {
        return Promise.reject(failure("BOOTSTRAP_REQUEST_INVALID"));
      }
      let fence;
      try { fence = captureFence(suppliedFence); }
      catch (error) { return Promise.reject(error); }
      if (!fenceCurrent(fence)) return Promise.reject(failure("BOOTSTRAP_CONTEXT_CHANGED"));
      if (signal?.aborted) return Promise.reject(failure("BOOTSTRAP_WAITER_CANCELLED", {
        acquisition: "NOT_STARTED", retryRequiresExplicitAction: true,
      }));
      const key = fence.scopeKey;
      let job = scopes.get(key);
      if (job && !sameFence(job.ticket.fence, fence)) {
        retire(job, "BOOTSTRAP_CONTEXT_CHANGED");
        if (closed) return Promise.reject(failure("BOOTSTRAP_SECURITY_QUARANTINE"));
        job = null;
      }
      if (job && job.requestKey !== requestKey) return Promise.reject(failure("BOOTSTRAP_REQUEST_CONFLICT", {
        acquisition: "NOT_STARTED", retryRequiresExplicitAction: true,
      }));
      if (!job) {
        if (scopes.size >= maxScopes) return Promise.reject(failure("BOOTSTRAP_SCOPE_CAPACITY", {
          acquisition: "NOT_STARTED", retryRequiresExplicitAction: true,
        }));
        const ticket = Object.freeze({
          workerInstanceId, acquisitionId: makeId(), scopeSeq: nextSeq(key), fence,
        });
        job = { key, ticket, requestKey, run, waiters: new Set(), state: "queued",
          controller: new AbortController(), activeTimer: null, activeDeadline: null,
          dispatched: false, commitStarted: false };
        scopes.set(key, job);
        queue.push(job);
      }
      const pending = job;
      const promise = new Promise((resolve, reject) => {
        const waiter = { resolve, reject, signal, done: false, timer: null,
          deadline: now() + waitMs, onAbort: null };
        waiter.onAbort = () => {
          releaseWaiter(pending, waiter, "reject", failure("BOOTSTRAP_WAITER_CANCELLED", {
            acquisition: pending.state === "queued" ? "NOT_STARTED" : "OUTCOME_UNKNOWN",
            retryRequiresExplicitAction: true,
          }));
          if (!pending.waiters.size) retire(pending, "BOOTSTRAP_WAITER_CANCELLED");
        };
        pending.waiters.add(waiter);
        signal?.addEventListener("abort", waiter.onAbort, { once: true });
        if (pending.state === "queued") {
          waiter.timer = setTimer(() => {
            if (pending.state !== "queued" || waiter.done) return;
            releaseWaiter(pending, waiter, "reject", failure("BOOTSTRAP_QUEUE_WAIT_EXPIRED", {
              acquisition: "NOT_STARTED", retryRequiresExplicitAction: true,
            }));
            if (!pending.waiters.size) retire(pending, "BOOTSTRAP_QUEUE_WAIT_EXPIRED");
          }, waitMs);
        }
      });
      pump();
      return promise;
    }
    return Object.freeze({
      request,
      isCurrent(ticket) {
        return Boolean(ticket && ticket.workerInstanceId === workerInstanceId &&
          !closed && sequence.get(ticket.fence.scopeKey) === ticket.scopeSeq &&
          now() < (deadlines.get(ticket) ?? -Infinity) &&
          fenceCurrent(scopes.get(ticket.fence.scopeKey)?.committedFence || ticket.fence));
      },
      invalidate(scopeKey, code = "BOOTSTRAP_CONTEXT_CHANGED") {
        const job = scopes.get(scopeKey);
        if (job) retire(job, code); else nextSeq(scopeKey);
      },
      dispose(code = "BOOTSTRAP_WORKER_RETIRED") {
        closed = true;
        for (const job of [...scopes.values()]) retire(job, code);
      },
      inspect() {
        return Object.freeze({
          workerInstanceId, closed, activeScope: active?.key || null,
          queuedScopes: Object.freeze(queue.map(job => job.key)),
          scopeSequences: Object.freeze(Object.fromEntries(sequence)),
        });
      },
    });
  }
  globalThis.SellerAgentsParallelAuthority = Object.freeze({
    BOOTSTRAP_WAIT_MS: WAIT_MS, BOOTSTRAP_ACTIVE_MS: ACTIVE_MS,
    captureFence, createScopeIdentity, createBootstrapScheduler,
  });
})();

;
/* Privileged browser control-plane client. Tokens and deviceCode never leave this scope. */
(() => {
  "use strict";
  const config = globalThis.SellerAgentsControlConfig;
  const verifier = globalThis.SellerAgentsBootstrapVerifier;
  const browserIdentity = globalThis.SellerAgentsBrowserIdentity;
  const localAuthority = globalThis.SellerAgentsLocalClientAuthority;
  const parallelAuthority = globalThis.SellerAgentsParallelAuthority;
  const STORAGE_KEY = "seller_agents_control_auth_v2";
  const METADATA_CLEAR_KEY = "seller_agents_pending_metadata_clear_v1";
  const METADATA_CLEAR_RECEIPT_KEY = "seller_agents_metadata_clear_receipt_v1";
  const consentApi = globalThis.SellerAgentsTechnicalDataConsent;
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const MACHINE = /^[a-z0-9][a-z0-9._-]*$/;
  const TOKEN = /^[A-Za-z0-9._~-]{16,4096}$/;
  const OPAQUE_TOKEN = /^[A-Za-z0-9_-]{43}$/;
  const EXCHANGE_PENDING = "DEVICE_AUTH_PENDING";
  const RETRYABLE_EXCHANGE_STATUS = new Set([429, 500, 502, 503, 504]);
  const CONTROL_REQUEST_DEADLINE_MS = 30000;
  const SUBSCRIPTION_REFRESH_INTERVAL_MS = 24 * 60 * 60 * 1000;
  const SUBSCRIPTION_REFRESH_JITTER_MAX_MS = 30 * 60 * 1000;
  const TERMINAL_EXCHANGE_ERRORS = new Set(["DEVICE_AUTH_CLOSED", "DEVICE_AUTH_INVALID", "DEVICE_LIMIT_REACHED", "SUBSCRIPTION_REQUIRED"]);
  const LOCAL_AI = Object.freeze({ chatgpt: Object.freeze({ family: "chatgpt", surface: "web" }), alice: Object.freeze({ family: "alice", surface: "web" }), qwen: Object.freeze({ family: "qwen", surface: "web" }), kimi: Object.freeze({ family: "kimi", surface: "web" }), grok: Object.freeze({ family: "grok", surface: "web" }), gemini: Object.freeze({ family: "gemini", surface: "web" }), claude: Object.freeze({ family: "claude", surface: "web" }), deepseek: Object.freeze({ family: "deepseek", surface: "web" }) });
  const MAX_DATE_MS = 8640000000000000;
  let state = { generation: 0, principalEpoch: 0, accessEpoch: 0, grants: {}, credentials: null, pending: null, rotation: null, authority: null, cacheClock: null, lastError: null };
  let initialized = false, initFlight = null, mutationQueue = Promise.resolve();
  let activationFlight = null, refreshFlight = null, subscriptionRefreshFlight = null, pollingFlight = null, authorityChanged = null;
  let runtimeClockOwner = null, runtimeAnchor = null, runtimeEffectiveHighWatermark = null, runtimeFloorNeedsPersistence = false, runtimeLastCheckpointAllowed = null;
  let bootstrapAttemptSequence = 0;
  let bootstrapScheduler = null;
  const bootstrapAcquisitionScopes = new Map();
  const bootstrapAttempts = new Map();
  let authStorageUnconfirmed = false;
  const verifiedGrantIdentities = new Set();
  const transferVault = globalThis.SellerAgentsCredentialTransferVault;
  const transferRecipientFlights = new Map();
  let metadataForgetFlight = null;
  let metadataForgetEpoch = 0, metadataForgetLastAttempt = null;
  async function clearTransferRecipientVault() {
    if (!transferVault) throw error("TRANSFER_VAULT_UNAVAILABLE");
    try { await transferVault.clear(); } catch (failure) { throw error("TRANSFER_VAULT_CLEAR_FAILED", safeError(failure)); }
  }
  function transferSingleFlight(requestId, fn) {
    const id = String(requestId || "");
    if (transferRecipientFlights.has(id)) return transferRecipientFlights.get(id);
    const run = Promise.resolve().then(fn).finally(() => { if (transferRecipientFlights.get(id) === run) transferRecipientFlights.delete(id); });
    transferRecipientFlights.set(id, run);
    return run;
  }
  const transportProvenance = new WeakMap();
  const httpErrorProvenance = new WeakMap();
  function error(code, detail) { const value = Object.assign(new Error(code), { code }); if (detail !== undefined) value.detail = detail; return value; }
  function now() { return Date.now(); }
  function validMillis(value) { return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && value <= MAX_DATE_MS; }
  function parsedMillis(value) { const result = Date.parse(value); return validMillis(result) ? result : null; }
  function monotonicNow() { const value = globalThis.performance && typeof globalThis.performance.now === "function" ? globalThis.performance.now() : NaN; if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || !Number.isSafeInteger(Math.ceil(value))) throw error("CACHE_MONOTONIC_INVALID"); return value; }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function key() { return crypto.randomUUID(); }
  function origin(value) { try { return typeof value === "string" && value === new URL(value).origin; } catch (_) { return false; } }
  function url(path, base) { const root = base || config.controlApiOrigin; if (!origin(root) || ![config.controlApiOrigin, config.portalOrigin].includes(root)) throw error("PACKAGED_ORIGIN_INVALID"); return new URL(path, `${root}/`).toString(); }
  const BOOTSTRAP_DIAGNOSTIC_STAGES = new Set(["REQUEST_FAMILY", "REQUEST_IDENTITY", "SIGNED_AUTHORITY"]);
  const BOOTSTRAP_DIAGNOSTIC_CHECKS = new Set(["REQUESTED_AI_KNOWN", "REQUEST_SURFACE", "REQUEST_VARIANT", "PAYLOAD_PRESENT", "ACCESS_BASIS_ALLOWED", "ACCOUNT_ACTIVE", "DEVICE_ACTIVE", "EXTENSION_STATUS_ALLOWED", "BROWSER_SUPPORTED", "EXTENSION_MINIMUM", "AI_UNCONFIGURED_SCOPE", "AI_UNAVAILABLE_LOCAL", "AI_RESOLVED", "PROFILE_SHAPE", "PROFILE_BROWSER_FAMILY", "PROFILE_EXTENSION_MINIMUM", "PROFILE_BROWSER_MINIMUM", "AI_PROFILE_SCOPE", "PROFILE_FINGERPRINT", "PAYLOAD_VARIANT", "LOCAL_MATERIALIZATION", "VALIDATOR_COMPLETED"]);
  function bootstrapCheck(checks, check, passed) { if (checks) checks.push({ check, passed: Boolean(passed) }); return passed; }
  function safeBootstrapDiagnostic(value) {
    if (value?.diagnosticVersion !== "bootstrap_rejection_v1" || !BOOTSTRAP_DIAGNOSTIC_STAGES.has(value.stage) || typeof value.recordedAt !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value.recordedAt) || !Number.isFinite(Date.parse(value.recordedAt)) || !Array.isArray(value.checks) || value.checks.length < 1 || value.checks.length > 24 || !value.checks.every(row => BOOTSTRAP_DIAGNOSTIC_CHECKS.has(row?.check) && typeof row.passed === "boolean")) return null;
    return { diagnosticVersion: "bootstrap_rejection_v1", stage: value.stage, recordedAt: value.recordedAt, checks: value.checks.map(row => ({ check: row.check, passed: row.passed })) };
  }
  function bootstrapProfileFailure(stage, checks) {
    const failure = error("BOOTSTRAP_PROFILE_INCOMPATIBLE");
    failure.bootstrapDiagnostic = { diagnosticVersion: "bootstrap_rejection_v1", stage, recordedAt: new Date(now()).toISOString(), checks };
    return failure;
  }
  function safeError(value) { const code = typeof value?.code === "string" ? value.code : "CONTROL_REQUEST_FAILED"; const result = { code: code.slice(0, 80) }; const diagnostic = result.code === "BOOTSTRAP_PROFILE_INCOMPATIBLE" ? safeBootstrapDiagnostic(value?.bootstrapDiagnostic) : null; if (diagnostic) result.bootstrapDiagnostic = diagnostic; return result; }
  function queueMutation(fn) { const run = mutationQueue.then(fn); mutationQueue = run.catch(() => {}); return run; }
  async function persist(next) {
    if (authStorageUnconfirmed) throw error("AUTH_STATE_COMMIT_UNCONFIRMED");
    const expected = { ...clone(next), authStateSchema: 2 };
    try {
      await chrome.storage.local.set({ [STORAGE_KEY]: expected });
      const observed = await chrome.storage.local.get(STORAGE_KEY);
      if (!observed?.[STORAGE_KEY] || verifier.canonicalJson(observed[STORAGE_KEY]) !== verifier.canonicalJson(expected))
        throw error("AUTH_STATE_READBACK_MISMATCH");
    } catch (failure) {
      authStorageUnconfirmed = true;
      state = { ...state, generation: state.generation + 1, accessEpoch: epoch("accessEpoch") + 1,
        grants: {}, authority: null, lastError: { code: "AUTH_STATE_COMMIT_UNCONFIRMED" } };
      queueMicrotask(() => { void notifyAuthorityChange(null, "AUTH_STATE_COMMIT_UNCONFIRMED", state.generation); });
      throw Object.assign(error("AUTH_STATE_COMMIT_UNCONFIRMED"), { cause: safeError(failure) });
    }
  }
  function sameAuthorityIdentity(left, right) { return Boolean(left && right && left.deviceId === right.deviceId && left.sessionId === right.sessionId && left.generation === right.generation && left.requestedAi === right.requestedAi && left.payload?.account?.id === right.payload?.account?.id); }
  function authorityProfileIdentity(authority) {
    const ai = authority?.payload?.ai;
    if (ai?.status !== "RESOLVED" || !ai.profile) return null;
    return verifier.canonicalJson({
      requestedAi: authority?.requestedAi ?? null,
      detected: ai.detected || null,
      profile: {
        profileKey: ai.profile.profileKey || null,
        revision: ai.profile.revision ?? null,
        scopeVariant: ai.profile.scopeVariant ?? null,
        contentSha256: ai.profile.contentSha256 || null
      }
    });
  }
  function authorityNeedsInvalidation(previous, next, reason) { if (!previous || !next) return Boolean(previous || next); if (!sameAuthorityIdentity(previous, next)) return true; if (["refresh_invalid", "bootstrap_unauthorized", "authority_invalid", "local_reset"].includes(reason)) return true; if (previous.workAllowed && !next.workAllowed) return true; return staticCanWork(previous.payload) && !staticCanWork(next.payload); }
  async function commit(next, previous = state.authority, reason = "state_changed", scopeNotice = null) {
    const changed = authorityNeedsInvalidation(previous, next.authority, reason);
    const profileChanged = authorityProfileIdentity(previous) !== authorityProfileIdentity(next.authority);
    await persist(next);
    state = next;
    if ((changed || profileChanged) && typeof authorityChanged === "function") {
      const notificationReason = changed ? reason : "profile_changed";
      try { await authorityChanged(clone(state.authority), notificationReason, state.generation, scopeNotice); } catch (_) { /* guards remain authoritative */ }
    }
    return true;
  }
  function isCurrent(context) {
    if (!context || state.generation !== context.generation) return false;
    if (context.attemptId && state.pending?.attemptId !== context.attemptId) return false;
    if (context.deviceId && state.credentials?.deviceId !== context.deviceId) return false;
    if (context.sessionId && state.credentials?.sessionId !== context.sessionId) return false;
    if (context.rotationKey && state.rotation?.idempotencyKey !== context.rotationKey) return false;
    return true;
  }
  function validContext(context) {
    if (!context || typeof context !== "object" || !Number.isSafeInteger(context.generation) || context.generation < 0) return false;
    return ["attemptId", "deviceId", "sessionId", "rotationKey"].every(key => context[key] === undefined || context[key] === null || typeof context[key] === "string");
  }
  function contextForState(extra = {}) { return { generation: state.generation, attemptId: state.pending?.attemptId || null, deviceId: state.credentials?.deviceId || null, sessionId: state.credentials?.sessionId || null, ...extra }; }
  function commitIfCurrent(context, updater, reason = "state_changed") { return queueMutation(async () => { if (!isCurrent(context)) return false; const next = await updater(clone(state)); if (!next || !isCurrent(context)) return false; await commit(next, state.authority, reason); return true; }); }
  function validCredentials(value) { return value && UUID.test(value.deviceId) && UUID.test(value.sessionId) && value.tokenType === "Bearer" && TOKEN.test(value.accessToken) && OPAQUE_TOKEN.test(value.refreshToken) && Number.isFinite(Date.parse(value.accessTokenExpiresAt)) && Number.isFinite(Date.parse(value.refreshTokenExpiresAt)); }
  function validAuthContext(value) { return exactKeys(value, ["contextVersion", "controlApiOrigin", "portalOrigin", "contractVersion"]) && value.contextVersion === "control_auth_context_v1" && origin(value.controlApiOrigin) && origin(value.portalOrigin) && typeof value.contractVersion === "string" && value.controlApiOrigin === config.controlApiOrigin && value.portalOrigin === config.portalOrigin && value.contractVersion === config.contractVersion; }
  function validStarting(value) { return exactKeys(value, ["phase", "attemptId", "startIdempotencyKey", "authContext"], ["metadataMode"]) && (!Object.hasOwn(value, "metadataMode") || ["identified", "privacy_neutral"].includes(value.metadataMode)) && value.phase === "starting" && typeof value.attemptId === "string" && value.attemptId.length > 0 && TOKEN.test(value.startIdempotencyKey) && validAuthContext(value.authContext); }
  function validPending(value) { return exactKeys(value, ["phase", "attemptId", "authorizationId", "deviceCode", "userCode", "expiresAt", "startIdempotencyKey", "exchangeIdempotencyKey", "authContext"], ["metadataMode"]) && (!Object.hasOwn(value, "metadataMode") || ["identified", "privacy_neutral"].includes(value.metadataMode)) && value.phase === "pending" && typeof value.attemptId === "string" && value.attemptId.length > 0 && UUID.test(value.authorizationId) && OPAQUE_TOKEN.test(value.deviceCode) && /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{4}-[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{4}$/.test(value.userCode) && Number.isFinite(Date.parse(value.expiresAt)) && TOKEN.test(value.startIdempotencyKey) && TOKEN.test(value.exchangeIdempotencyKey) && validAuthContext(value.authContext); }
  function validRestoredPending(value) { return validStarting(value) || validPending(value) && parsedMillis(value.expiresAt) > now(); }
  function pendingLive(value) { return value?.phase !== "starting" && validPending(value) && Date.parse(value.expiresAt) > now(); }
  function publicPending(value) { if (!value) return null; return { authorizationId: value.authorizationId, userCode: value.userCode, expiresAt: value.expiresAt, verificationUri: url(`/activate?authorizationId=${encodeURIComponent(value.authorizationId)}`, config.portalOrigin) }; }
  function publicStatus(decision = null) { const authority = state.grants?.[decision?.scopeKey]?.authority || state.authority, accountId = authority?.payload?.account?.id || null, snapshot = authority?.payload || null, matching = isCurrentScopedDecision(decision) && sameAuthorityRuntimeIdentity(decision.identity, authorityDecisionIdentity(authority)); const compatibility = snapshot?.compatibility ? { extension: { status: snapshot.compatibility.extension.status, minimumVersion: snapshot.compatibility.extension.minimumVersion }, browser: { status: snapshot.compatibility.browser.status } } : null; return Object.freeze({ authenticated: Boolean(state.credentials && authority && accountId), bootstrapRetryAvailable: Boolean(state.credentials && !state.authority), accountId, account: accountId ? { kind: "control_account", label: `Аккаунт · ${accountId.slice(0, 8)}` } : null, pending: pendingLive(state.pending) ? publicPending(state.pending) : null, lastError: state.lastError ? safeError(state.lastError) : null, generation: state.generation, workAllowed: Boolean(accountId && matching && decision.allowed === true), authority: authority ? { configVersion: snapshot.configVersion, expiresAt: snapshot.expiresAt, aiStatus: snapshot.ai.status } : null, compatibility }); }
  function authorityStaticValid(snapshot, checks = null) {
    const extension = snapshot?.compatibility?.extension;
    const accessAllowed = snapshot?.contractVersion !== "control_plane_v3" || snapshot?.accessBasis !== "NONE";
    return Boolean(bootstrapCheck(checks, "PAYLOAD_PRESENT", snapshot) && bootstrapCheck(checks, "ACCESS_BASIS_ALLOWED", accessAllowed) && bootstrapCheck(checks, "ACCOUNT_ACTIVE", snapshot.account?.status === "ACTIVE") && bootstrapCheck(checks, "DEVICE_ACTIVE", snapshot.devicePolicy?.status === "ACTIVE") && bootstrapCheck(checks, "EXTENSION_STATUS_ALLOWED", ["SUPPORTED", "UPDATE_RECOMMENDED"].includes(extension?.status)) && bootstrapCheck(checks, "BROWSER_SUPPORTED", snapshot.compatibility?.browser?.status === "SUPPORTED") && bootstrapCheck(checks, "EXTENSION_MINIMUM", extension.minimumVersion === null || (parseSemver(extension.minimumVersion) && versionAtLeast(config.extensionVersion, extension.minimumVersion))));
  }
  function cacheAuthorityDeadline(snapshot) {
    const expiresAt = parsedMillis(snapshot?.expiresAt);
    if (expiresAt === null) return null;
    if (snapshot?.contractVersion !== "control_plane_v3") return parsedMillis(snapshot?.offlineGraceUntil);
    if (snapshot.accessBasis === "COMMERCIAL") {
      const access = snapshot.subscriptionAccess;
      if (access === null) return expiresAt;
      const paidThrough = parsedMillis(access?.paidThrough), offlineHardUntil = parsedMillis(access?.offlineHardUntil);
      return paidThrough !== null && offlineHardUntil !== null && offlineHardUntil - paidThrough === 72 * 60 * 60 * 1000 ? offlineHardUntil : null;
    }
    return snapshot.accessBasis === "BETA" ? parsedMillis(snapshot.offlineGraceUntil) : expiresAt;
  }
  function authorityBaseValid(snapshot, effectiveTimeMs) {
    const expiresAt = parsedMillis(snapshot?.expiresAt), deadline = cacheAuthorityDeadline(snapshot);
    const legacyGraceRequired = snapshot?.contractVersion !== "control_plane_v3" || snapshot?.accessBasis === "BETA";
    return Boolean(authorityStaticValid(snapshot) && validMillis(effectiveTimeMs) && expiresAt !== null && deadline !== null && (!legacyGraceRequired || deadline > expiresAt) && effectiveTimeMs < deadline);
  }
  function staticCanWork(snapshot) { return Boolean(authorityStaticValid(snapshot) && snapshot.ai?.status === "RESOLVED" && ["chatgpt", "alice", "qwen", "kimi", "grok", "gemini", "claude", "deepseek"].includes(snapshot.ai.detected?.family)); }
  function canWork(snapshot, effectiveTimeMs) { return Boolean(authorityBaseValid(snapshot, effectiveTimeMs) && snapshot.ai?.status === "RESOLVED" && ["chatgpt", "alice", "qwen", "kimi", "grok", "gemini", "claude", "deepseek"].includes(snapshot.ai.detected?.family)); }
  function currentBrowserIdentity() { const detected = browserIdentity?.current?.(); if (!detected?.family || !detected?.version || !browserIdentity.families.includes(detected.family)) throw error("UNSUPPORTED_BROWSER"); return detected; }
  function browserFamily() { return currentBrowserIdentity().family; }
  function browserVersion() { return currentBrowserIdentity().version; }
  function clockOwner(credentials) { return { controlApiOrigin: config.controlApiOrigin, portalOrigin: config.portalOrigin, contractVersion: config.contractVersion, deviceId: credentials.deviceId, sessionId: credentials.sessionId }; }
  function authorityIdentity(authority = state.authority, generation = state.generation) { return authority ? { generation, deviceId: authority.deviceId, sessionId: authority.sessionId, accountId: authority.payload?.account?.id || null, requestedAi: authority.requestedAi ?? null } : null; }
  function authorityDecisionIdentity(authority = state.authority, generation = state.generation) { return authority ? verifier.canonicalJson({ generation, deviceId: authority.deviceId, sessionId: authority.sessionId, requestedAi: authority.requestedAi ?? null, accountId: authority.payload?.account?.id || null, envelope: authority.envelope, cacheBinding: authority.cacheBinding }) : null; }
  function sameAuthorityRuntimeIdentity(left, right) { return Boolean(left && right && verifier.canonicalJson(left) === verifier.canonicalJson(right)); }
  function validCacheBinding(value) {
    if (!exactKeys(value, ["cacheVersion", "controlApiOrigin", "portalOrigin", "contractVersion", "extensionVersion", "browser", "detectedAi", "trustBundleSha256"]) || value.cacheVersion !== "control_cache_binding_v1" || !origin(value.controlApiOrigin) || !origin(value.portalOrigin) || typeof value.contractVersion !== "string" || typeof value.extensionVersion !== "string" || !exactKeys(value.browser, ["family", "version"]) || !browserIdentity?.families?.includes(value.browser.family) || !parseBrowser(value.browser.version) || !(value.detectedAi === null || exactKeys(value.detectedAi, ["family", "surface", "variant"]) && LOCAL_AI[value.detectedAi.family] && value.detectedAi.surface === LOCAL_AI[value.detectedAi.family].surface && value.detectedAi.variant === null) || !/^[0-9a-f]{64}$/.test(value.trustBundleSha256)) return false;
    return true;
  }
  function validCacheClockShape(value, payload = null) {
    if (!exactKeys(value, ["cacheVersion", "owner", "trustedServerTimeMs", "effectiveTimeMs"]) || value.cacheVersion !== "control_cache_clock_v1" || !exactKeys(value.owner, ["controlApiOrigin", "portalOrigin", "contractVersion", "deviceId", "sessionId"]) || !origin(value.owner.controlApiOrigin) || !origin(value.owner.portalOrigin) || typeof value.owner.contractVersion !== "string" || value.owner.contractVersion.length < 1 || !UUID.test(value.owner.deviceId) || !UUID.test(value.owner.sessionId) || !validMillis(value.trustedServerTimeMs) || !validMillis(value.effectiveTimeMs) || value.effectiveTimeMs < value.trustedServerTimeMs) return false;
    if (payload) { const serverTimeMs = parsedMillis(payload.serverTime); if (serverTimeMs === null || value.trustedServerTimeMs < serverTimeMs || payload.contractVersion === "control_plane_v3" && value.trustedServerTimeMs !== serverTimeMs) return false; }
    return true;
  }
  function validCacheClock(value, credentials, payload = null) { if (!validCacheClockShape(value, payload) || !credentials) return false; const owner = value.owner; return owner.controlApiOrigin === config.controlApiOrigin && owner.portalOrigin === config.portalOrigin && owner.deviceId === credentials.deviceId && owner.sessionId === credentials.sessionId; }
  function expectedCacheContract(payload = null) { return payload?.contractVersion === "control_plane_v3" ? "control_plane_v3" : config.contractVersion; }
  async function trustBundleDigest() { return [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier.canonicalJson(config.trustBundle))))].map(value => value.toString(16).padStart(2, "0")).join(""); }
  async function expectedCacheBinding(payload, requestedAi = null) { const detectedAi = payload?.ai?.status === "RESOLVED" ? { family: payload.ai.detected.family, surface: payload.ai.detected.surface, variant: payload.ai.detected.variant } : null; return { cacheVersion: "control_cache_binding_v1", controlApiOrigin: config.controlApiOrigin, portalOrigin: config.portalOrigin, contractVersion: expectedCacheContract(payload), extensionVersion: config.extensionVersion, browser: { family: browserFamily(), version: browserVersion() }, detectedAi, trustBundleSha256: await trustBundleDigest() }; }
  async function verifyCachedEnvelope(envelope) {
    if (envelope?.envelopeVersion === "bootstrap_envelope_v3" && typeof verifier.verifyV3 === "function") return verifier.verifyV3(envelope, config.trustBundle);
    if (envelope?.envelopeVersion === "bootstrap_envelope_v2") return verifier.verifyV2(envelope, config.trustBundle);
    return { ok: false, error: "INVALID_ENVELOPE" };
  }
  function validRuntimeOwner(owner) { return typeof owner === "string" && owner.length > 0; }
  function effectiveTime(clock, payload = state.authority?.payload || null) {
    if (!validCacheClock(clock, state.credentials, payload)) throw error("CACHE_CLOCK_INVALID");
    const wall = Date.now();
    if (!validMillis(wall)) throw error("CACHE_WALL_CLOCK_INVALID");
    const monotonic = monotonicNow();
    const owner = verifier.canonicalJson({ controlApiOrigin: clock.owner.controlApiOrigin, portalOrigin: clock.owner.portalOrigin, deviceId: clock.owner.deviceId, sessionId: clock.owner.sessionId });
    if (runtimeClockOwner !== owner) {
      runtimeClockOwner = owner;
      const initial = Math.max(wall, clock.trustedServerTimeMs, clock.effectiveTimeMs);
      if (!validMillis(initial)) throw error("CACHE_EFFECTIVE_TIME_INVALID");
      runtimeAnchor = { effectiveNowMs: initial, monotonicNowMs: monotonic };
      runtimeEffectiveHighWatermark = runtimeAnchor.effectiveNowMs;
    } else {
      if (!runtimeAnchor || monotonic < runtimeAnchor.monotonicNowMs) throw error("CACHE_MONOTONIC_DECREASING");
      runtimeEffectiveHighWatermark = Math.max(runtimeEffectiveHighWatermark, clock.effectiveTimeMs);
    }
    const elapsed = monotonic - runtimeAnchor.monotonicNowMs;
    const anchoredRaw = runtimeAnchor.effectiveNowMs + elapsed;
    if (!Number.isFinite(anchoredRaw) || anchoredRaw < 0 || anchoredRaw > MAX_DATE_MS) throw error("CACHE_EFFECTIVE_TIME_INVALID");
    const anchored = Math.ceil(anchoredRaw);
    const result = Math.max(wall, clock.trustedServerTimeMs, clock.effectiveTimeMs, runtimeEffectiveHighWatermark, anchored);
    if (!validMillis(result)) throw error("CACHE_EFFECTIVE_TIME_INVALID");
    if (result < runtimeAnchor.effectiveNowMs) throw error("CACHE_EFFECTIVE_TIME_REGRESSION");
    runtimeAnchor = { effectiveNowMs: result, monotonicNowMs: monotonic };
    runtimeEffectiveHighWatermark = Math.max(runtimeEffectiveHighWatermark, result);
    return result;
  }
  function epoch(name) {
    const value = state[name] === undefined ? state.generation : state[name];
    if (!Number.isSafeInteger(value) || value < 0) throw error("AUTH_EPOCH_INVALID");
    return value;
  }
  function requestedFamily(identity) {
    const family = typeof identity === "string" ? identity : identity?.ai_id || identity?.family;
    return LOCAL_AI[family] ? family : null;
  }
  function grantFor(identity) {
    const family = requestedFamily(identity);
    if (!family || !state.credentials || !state.authority || !state.grants || typeof state.grants !== "object" || Array.isArray(state.grants)) return null;
    const matches = Object.values(state.grants).filter(record => record?.authority?.requestedAi === family &&
      record.principalEpoch === epoch("principalEpoch") && record.accessEpoch === epoch("accessEpoch") &&
      record.authority.generation === state.generation && record.authority.deviceId === state.credentials.deviceId &&
      record.authority.sessionId === state.credentials.sessionId && record.authority.payload?.account?.id === state.authority.payload?.account?.id);
    if (matches.length > 1) throw error("AUTH_GRANT_AMBIGUOUS");
    return matches[0] || null;
  }
  function grantIdentity(record) {
    return record ? verifier.canonicalJson({ scopeKey: record.scopeKey, environmentKey: record.environmentKey,
      principalEpoch: record.principalEpoch, accessEpoch: record.accessEpoch, grantEpoch: record.grantEpoch,
      authority: authorityDecisionIdentity(record.authority) }) : null;
  }
  async function scopeIdentityFor(authority) {
    if (!parallelAuthority?.createScopeIdentity || !state.credentials) throw error("AUTH_SCOPE_UNAVAILABLE");
    return parallelAuthority.createScopeIdentity({ controlApiOrigin: config.controlApiOrigin, portalOrigin: config.portalOrigin,
      allowedOrigins: [config.controlApiOrigin, config.portalOrigin], development: false,
      accountId: authority.payload?.account?.id, deviceId: state.credentials.deviceId, sessionId: state.credentials.sessionId,
      principalEpoch: epoch("principalEpoch"), contractVersion: expectedCacheContract(authority.payload),
      extensionVersion: config.extensionVersion, browser: currentBrowserIdentity(), trustBundleSha256: await trustBundleDigest(),
      privacyProjection: authority.privacyNeutral === true ? "privacy-neutral" : "identified",
      ai: { family: authority.requestedAi, surface: LOCAL_AI[authority.requestedAi]?.surface, variant: null } },
    { canonicalJson: verifier.canonicalJson,
      sha256: async value => [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)))].map(x => x.toString(16).padStart(2, "0")).join("") });
  }
  function grantRights(authority) {
    const payload = clone(authority.payload);
    for (const field of ["serverTime", "expiresAt", "offlineGraceUntil", "configVersion"]) delete payload[field];
    // Signed profile content and compatibility are execution rights, including its revision.
    return verifier.canonicalJson(payload);
  }
  async function makeGrant(authority, cacheClock) {
    const scope = await scopeIdentityFor(authority), previous = grantFor(authority.requestedAi);
    const changed = !previous || previous.authority.workAllowed !== true || grantRights(previous.authority) !== grantRights(authority);
    const grantEpoch = (previous?.grantEpoch || 0) + (changed ? 1 : 0);
    if (!Number.isSafeInteger(grantEpoch)) throw error("AUTH_GRANT_EPOCH_EXHAUSTED");
    const record = { schemaVersion: 1, ...scope, principalEpoch: epoch("principalEpoch"), accessEpoch: epoch("accessEpoch"), grantEpoch,
      authority: { ...authority, scopeKey: scope.scopeKey, principalEpoch: epoch("principalEpoch"), accessEpoch: epoch("accessEpoch"), grantEpoch },
      cacheClock: clone(cacheClock) };
    verifiedGrantIdentities.add(grantIdentity(record));
    return record;
  }
  async function verifyStoredGrant(record) {
    const identity = grantIdentity(record);
    if (verifiedGrantIdentities.has(identity)) return true;
    const authority = record?.authority;
    if (record?.schemaVersion !== 1 || !Number.isSafeInteger(record.grantEpoch) || record.grantEpoch < 1 ||
        !state.credentials || authority?.deviceId !== state.credentials.deviceId || authority?.sessionId !== state.credentials.sessionId ||
        authority?.generation !== state.generation || authority?.payload?.account?.id !== state.authority?.payload?.account?.id)
      throw error("STORED_GRANT_CONTEXT_MISMATCH");
    const verified = await verifyCachedEnvelope(authority.envelope);
    if (!verified.ok) throw error("STORED_GRANT_" + verified.error);
    const payload = verified.payload.localClientAuthority ? await materializeLocalAuthority(verified.payload, authority.requestedAi) : verified.payload;
    if (verifier.canonicalJson(payload) !== verifier.canonicalJson(authority.payload)) throw error("STORED_GRANT_PAYLOAD_MISMATCH");
    const policy = await validateAccountProfile(payload, authority.requestedAi, true);
    if (!policy || !validCacheClock(record.cacheClock, state.credentials, verified.payload)) throw error("STORED_GRANT_POLICY_MISMATCH");
    const expected = await expectedCacheBinding(payload, authority.requestedAi), scope = await scopeIdentityFor(authority);
    if (verifier.canonicalJson(expected) !== verifier.canonicalJson(authority.cacheBinding) || scope.scopeKey !== record.scopeKey || scope.environmentKey !== record.environmentKey)
      throw error("STORED_GRANT_SCOPE_MISMATCH");
    if (identity !== grantIdentity(grantFor(authority.requestedAi))) throw error("AUTH_GENERATION_CHANGED");
    verifiedGrantIdentities.add(identity); return true;
  }
  async function materializeLegacyScopedGrant(family) {
    if (authStorageUnconfirmed) throw error("AUTH_STATE_COMMIT_UNCONFIRMED");
    let record = grantFor(family);
    // Migrate only the already verified legacy authority, retaining its clock and TTL.
    if (!record && family && state.authority?.requestedAi === family && state.authority.workAllowed === true) {
      const oldIdentity = authorityDecisionIdentity();
      const migrated = await makeGrant(state.authority, state.cacheClock);
      await queueMutation(async () => {
        if (oldIdentity !== authorityDecisionIdentity()) throw error("AUTH_GENERATION_CHANGED");
        const next = { ...state, grants: { ...(state.grants || {}), [migrated.scopeKey]: migrated } };
        await persist(next); state = next;
      });
      record = grantFor(family);
    }
    return record;
  }
  async function scopedCacheCheckpoint(identity, acquisitionLease = null) {
    try { return await scopedCacheCheckpointActive(identity, acquisitionLease); }
    catch (failure) {
      if (authStorageUnconfirmed && failure?.code === "AUTH_STATE_COMMIT_UNCONFIRMED") {
        // The failed/held write has settled before this catch. Serialize the
        // existing fail-closed AUTH removal and verify restart protection.
        await queueMutation(async () => {
          try {
            await chrome.storage.local.remove(STORAGE_KEY);
            const observed = await chrome.storage.local.get(STORAGE_KEY);
            if (observed?.[STORAGE_KEY] !== undefined) throw error("AUTH_DENIAL_REMOVE_READBACK_FAILED");
            state = { ...state, credentials: null, authority: null, grants: {}, cacheClock: null };
          } catch (_) {
            state = { ...state, lastError: { code: "AUTH_DENIAL_PERSISTENCE_FAILED" } };
          }
        });
      }
      // Work-facing reads keep the existing boolean fail-closed contract.
      // Acquisitions must still propagate the exact failure to their lease.
      if (acquisitionLease) throw failure;
      return { allowed: false, persistenceFailure: authStorageUnconfirmed, checkpointFailed: true };
    }
  }
  async function scopedCacheCheckpointActive(identity, acquisitionLease = null) {
    if (authStorageUnconfirmed) return { allowed: false, persistenceFailure: true };
    const family = requestedFamily(identity);
    const record = await materializeLegacyScopedGrant(family);
    if (!record) return { allowed: false, missing: true };
    try { await verifyStoredGrant(record); }
    catch (failure) { await invalidateKnown(contextForState(), failure, false); return { allowed: false, invalid: true }; }
    const captured = grantIdentity(record);
    const outcome = await queueMutation(async () => {
      const current = grantFor(family);
      if (!current || captured !== grantIdentity(current)) return { allowed: false, stale: true };
      acquisitionLease?.assertCurrent();
      let effective = effectiveTime(current.cacheClock, current.authority.payload);
      let allowed = current.authority.workAllowed === true && canWork(current.authority.payload, effective);
      let denied = current.authority.workAllowed === true && !allowed;
      const updatedRecord = () => {
        const grantEpoch = current.grantEpoch + (denied ? 1 : 0);
        if (!Number.isSafeInteger(grantEpoch)) throw error("AUTH_GRANT_EPOCH_EXHAUSTED");
        return { ...current, grantEpoch, cacheClock: { ...current.cacheClock, effectiveTimeMs: Math.max(current.cacheClock.effectiveTimeMs, effective) },
          authority: { ...current.authority, workAllowed: allowed, grantEpoch } };
      };
      const updatedState = updated => ({ ...state, grants: { ...state.grants, [current.scopeKey]: updated },
        cacheClock: state.cacheClock ? { ...state.cacheClock, effectiveTimeMs: Math.max(state.cacheClock.effectiveTimeMs, effective) } : state.cacheClock,
        authority: state.authority?.scopeKey === current.scopeKey ? updated.authority : state.authority });
      let updated = updatedRecord(), next = updatedState(updated);
      acquisitionLease?.beginSecurityCommit();
      if (denied) state = next; // Denial precedes every storage await.
      await persist(next);
      if (authStorageUnconfirmed) throw error("AUTH_STATE_COMMIT_UNCONFIRMED");
      state = next;
      // A held storage write cannot return an allow after the signed deadline.
      const completion = effectiveTime(updated.cacheClock, updated.authority.payload);
      if (allowed && !canWork(updated.authority.payload, completion)) {
        effective = completion; allowed = false; denied = true;
        updated = updatedRecord(); next = updatedState(updated); state = next;
        await persist(next);
        if (authStorageUnconfirmed) throw error("AUTH_STATE_COMMIT_UNCONFIRMED");
      }
      if (denied) acquisitionLease?.finishRevocationCommit();
      else acquisitionLease?.finishSecurityCommit();
      verifiedGrantIdentities.add(grantIdentity(updated));
      return { allowed, effectiveTimeMs: Math.max(effective, completion), identity: authorityDecisionIdentity(updated.authority), grantIdentity: grantIdentity(updated), scopeKey: updated.scopeKey,
        grant: clone(updated), changed: denied };
    });
    if (outcome.changed) queueMicrotask(() => { void notifyAuthorityChange(outcome.grant.authority, "cache_time_expired", state.generation,
      { scopeKey: outcome.scopeKey, requestedAi: family }); });
    return outcome;
  }
  function isCurrentScopedDecision(decision) {
    const current = decision?.scopeKey ? state.grants?.[decision.scopeKey] : null;
    return Boolean(!authStorageUnconfirmed && state.credentials && current && decision.allowed === true
      && decision.grantIdentity === grantIdentity(current));
  }
  async function workDecisionFor(identity = null) {
    if (authStorageUnconfirmed) return { allowed: false, persistenceFailure: true };
    const family = requestedFamily(identity);
    if (identity !== null && !family) return { allowed: false, unsupported: true };
    if (family) return scopedCacheCheckpoint(family);
    const families = [...new Set(Object.values(state.grants || {}).map(g => g?.authority?.requestedAi).filter(f => LOCAL_AI[f]))];
    if (!families.length && LOCAL_AI[state.authority?.requestedAi]) families.push(state.authority.requestedAi);
    for (const candidate of families) {
      const decision = await scopedCacheCheckpoint(candidate);
      if (decision.allowed === true) return decision;
    }
    return { allowed: false };
  }
  async function authorityFor(identity = null) {
    await init();
    if (authStorageUnconfirmed) return null;
    if (identity === null) {
      const decision = await cacheAuthorizationCheckpoint(), authority = clone(state.authority);
      if (authority && !(decision.identity === authorityDecisionIdentity() && decision.allowed === true)) authority.workAllowed = false;
      return authority;
    }
    const decision = await workDecisionFor(identity), record = grantFor(identity);
    if (!record) return null;
    const authority = clone(record.authority);
    if (!isCurrentScopedDecision(decision) || decision.identity !== authorityDecisionIdentity(record.authority)) authority.workAllowed = false;
    return authority;
  }
  function currentWorkDecision(effectiveTimeMs) { const authority = state.authority; return { allowed: Boolean(authority && canWork(authority.payload, effectiveTimeMs)), effectiveTimeMs }; }
  async function notifyAuthorityChange(authority, reason, generation, scopeNotice = null) { if (typeof authorityChanged === "function") { try { await authorityChanged(clone(authority), reason, generation, scopeNotice); } catch (_) {} } }
  async function cacheAuthorizationCheckpoint() {
    if (authStorageUnconfirmed) return { allowed: false, persistenceFailure: true };
    if (state.authority?.requestedAi && grantFor(state.authority.requestedAi))
      return scopedCacheCheckpoint(state.authority.requestedAi);
    const entryIdentity = authorityDecisionIdentity();
    let outcome;
    try {
      outcome = await queueMutation(async () => {
        if (!entryIdentity || entryIdentity !== authorityDecisionIdentity()) return { allowed: false, stale: true, identity: entryIdentity };
        const clock = state.cacheClock, previous = state.authority;
        let effective;
        try { effective = effectiveTime(clock); }
        catch (failure) {
          return { allowed: false, clockInvalid: true, identity: entryIdentity, generation: state.generation, changed: previous?.workAllowed === true };
        }
        if (entryIdentity !== authorityDecisionIdentity()) return { allowed: false, stale: true, identity: entryIdentity };
        const decision = currentWorkDecision(effective), floor = Math.max(clock.effectiveTimeMs, effective);
        if (!validMillis(floor)) return { allowed: false, clockInvalid: true, identity: entryIdentity, generation: state.generation, changed: previous?.workAllowed === true };
        const changed = runtimeFloorNeedsPersistence || floor !== clock.effectiveTimeMs || Boolean(previous?.workAllowed && !decision.allowed);
        const next = changed ? { ...state, cacheClock: { ...clock, effectiveTimeMs: floor }, authority: previous && !decision.allowed ? { ...previous, workAllowed: false } : previous } : state;
        if (changed) state = next;
        if (changed) {
          try { await persist(next); runtimeFloorNeedsPersistence = false; }
          catch (failure) {
            runtimeFloorNeedsPersistence = true;
            try { await chrome.storage.local.remove(STORAGE_KEY); }
            catch (removeFailure) { state = { ...state, lastError: safeError(Object.assign(error("AUTH_DENIAL_PERSISTENCE_FAILED"), { detail: safeError(removeFailure) })) }; return { allowed: false, persistenceFailure: true, identity: entryIdentity, generation: state.generation, changed: previous?.workAllowed === true && !decision.allowed }; }
            return { allowed: false, persistenceFailure: true, identity: entryIdentity, generation: state.generation, changed: previous?.workAllowed === true && !decision.allowed };
          }
        }
        if (entryIdentity !== authorityDecisionIdentity()) return { allowed: false, stale: true, identity: entryIdentity };
        let completion;
        try { completion = effectiveTime(state.cacheClock); }
        catch (failure) {
          return { allowed: false, clockInvalid: true, identity: entryIdentity, generation: state.generation, changed: previous?.workAllowed === true };
        }
        if (entryIdentity !== authorityDecisionIdentity()) return { allowed: false, stale: true, identity: entryIdentity };
        const completionDecision = currentWorkDecision(completion);
        if (completionDecision.allowed && decision.allowed) return { allowed: true, effectiveTimeMs: completion, identity: entryIdentity, generation: state.generation, changed: false };
        const denialFloor = Math.max(state.cacheClock.effectiveTimeMs, completion);
        const denial = { ...state, cacheClock: { ...state.cacheClock, effectiveTimeMs: denialFloor }, authority: state.authority ? { ...state.authority, workAllowed: false } : null };
        state = denial;
        try { await persist(denial); runtimeFloorNeedsPersistence = false; }
        catch (failure) {
          runtimeFloorNeedsPersistence = true;
          try { await chrome.storage.local.remove(STORAGE_KEY); }
          catch (removeFailure) { state = { ...state, lastError: safeError(Object.assign(error("AUTH_DENIAL_PERSISTENCE_FAILED"), { detail: safeError(removeFailure) })) }; }
          return { allowed: false, persistenceFailure: true, identity: entryIdentity, generation: state.generation, changed: previous?.workAllowed === true };
        }
        return { allowed: false, effectiveTimeMs: completion, identity: entryIdentity, generation: state.generation, changed: previous?.workAllowed === true };
      });
    } catch (_) { runtimeLastCheckpointAllowed = false; return { allowed: false, persistenceFailure: true }; }
    const matching = outcome?.identity && outcome.identity === authorityDecisionIdentity();
    runtimeLastCheckpointAllowed = matching && outcome?.allowed === true;
    if (matching && outcome?.changed) { const notificationIdentity = outcome.identity, notificationGeneration = outcome.generation, notificationAuthority = clone(state.authority); queueMicrotask(() => { if (notificationIdentity === authorityDecisionIdentity() && notificationGeneration === state.generation) void notifyAuthorityChange(notificationAuthority, "cache_time_expired", notificationGeneration); }); }
    if (!matching) return { allowed: false, stale: true, identity: outcome?.identity || entryIdentity };
    return outcome || { allowed: false };
  }
  function parseRetryAfter(response) { const value = response.headers?.get("Retry-After"); if (!value) return 1000; const seconds = Number(value); if (Number.isFinite(seconds)) return Math.max(250, Math.min(60000, seconds * 1000)); const date = Date.parse(value); return Number.isFinite(date) ? Math.max(250, Math.min(60000, date - now())) : 1000; }
  async function readLimitedBody(response, limit = 1024 * 1024) {
    if (!response.body?.getReader) {
      const text = await response.text();
      if (text.length > limit) throw error("CONTROL_RESPONSE_TOO_LARGE");
      return text;
    }
    const reader = response.body.getReader(), chunks = [], decoder = new TextDecoder();
    let total = 0;
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      total += part.value.byteLength;
      if (total > limit) { try { await reader.cancel(); } catch (_) {} throw error("CONTROL_RESPONSE_TOO_LARGE"); }
      chunks.push(part.value);
    }
    const bytes = new Uint8Array(total); let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
    return decoder.decode(bytes);
  }
  async function request(path, options = {}) {
    const endpoint = url(path), headers = new Headers(options.headers || {}), requestOptions = { ...options };
    headers.set("Accept", "application/json");
    const captureProjection = requestOptions.captureProjection, observeSettlement = requestOptions.observeSettlement;
    delete requestOptions.captureProjection;
    delete requestOptions.observeSettlement;
    const requestPath = new URL(endpoint).pathname;
    const treeRequest = requestPath === "/v1/ai-prompt-tree";
    if (treeRequest || requestPath === "/v1/bootstrap" || requestPath === "/v1/health-authority") {
      requestOptions.cache = "no-store";
      headers.set("Cache-Control", "no-store");
    }
    const projectionKind = requestPath === "/v1/device-authorizations" ? "device_authorization" : requestPath === "/v1/bootstrap" || treeRequest ? "bootstrap" : requestPath === "/v1/health-authority" ? "health_authority" : null;
    if (projectionKind && requestOptions.body && typeof requestOptions.body === "object" && consentApi?.projectControlRequest) {
      const projection = await consentApi.projectControlRequest(projectionKind, treeRequest ? requestOptions.body.bootstrap : requestOptions.body);
      requestOptions.body = treeRequest ? { ...requestOptions.body, bootstrap: projection.body } : projection.body;
      if (typeof captureProjection === "function") captureProjection(projection);
      if (projection.consent.applicable && projection.consent.granted) {
        // A later identified send invalidates the prior clear acknowledgement.
        metadataForgetEpoch += 1;
        metadataForgetLastAttempt = null;
        await chrome.storage.local.remove(METADATA_CLEAR_RECEIPT_KEY);
      }
      if (projection.consent.applicable && !projection.consent.granted) {
        void scheduleMetadataForget();
        if (treeRequest) throw error("AI_TREE_TECHNICAL_PERMISSION_REQUIRED");
        if (projectionKind === "health_authority") throw error("HEALTH_TECHNICAL_PERMISSION_REQUIRED");
      }
    }
    if (requestPath === "/v1/device-authorizations/token" && consentApi?.consent) {
      const permission = await consentApi.consent();
      if (permission.applicable && !permission.granted && (state.pending?.metadataMode || "identified") === "identified") throw error("DEVICE_AUTH_WITHDRAWN");
    }
    if (requestOptions.body !== undefined) { headers.set("Content-Type", "application/json"); requestOptions.body = JSON.stringify(requestOptions.body); }
    const callerSignal = requestOptions.signal, controller = new AbortController();
    let timer = null, rejectInterrupted, resolveInterrupted;
    const interrupted = callerSignal ? new Promise((resolve, reject) => { resolveInterrupted = resolve; rejectInterrupted = reject; }) : null;
    const abortFromCaller = () => {
      rejectInterrupted(error("CONTROL_REQUEST_ABORTED"));
      controller.abort();
    };
    if (callerSignal) {
      if (callerSignal.aborted) abortFromCaller();
      else callerSignal.addEventListener("abort", abortFromCaller, { once: true });
    }
    requestOptions.signal = controller.signal;
    requestOptions.headers = headers;
    let requestReturned = false;
    const operation = (async () => {
      let response;
      try { response = await fetch(endpoint, requestOptions); }
      catch (_) { const failure = error("CONTROL_TRANSPORT_UNAVAILABLE"); transportProvenance.set(failure, endpoint); throw failure; }
      let body = null, bodyFailure = false;
      try {
        const text = await readLimitedBody(response); body = text ? JSON.parse(text) : null;
      } catch (failure) {
        bodyFailure = true;
        if (failure?.code === "CONTROL_RESPONSE_TOO_LARGE") { failure.status = response.status; failure.responseOk = response.ok; failure.retryAfterMs = parseRetryAfter(response); failure.body = null; }
        if (failure?.code === "CONTROL_RESPONSE_TOO_LARGE") throw failure;
      }
      if (!response.ok) { const failure = error(body?.error?.code || `CONTROL_HTTP_${response.status}`); failure.status = response.status; failure.retryAfterMs = parseRetryAfter(response); failure.body = body; if (!bodyFailure) httpErrorProvenance.set(failure, endpoint); throw failure; }
      return { body, response };
    })();
    if (typeof observeSettlement === "function") {
      const observe = outcome => Promise.resolve(observeSettlement({ ...outcome, late: requestReturned })).catch(quarantineBootstrap);
      void operation.then(value => observe({ value }), error => observe({ error }));
    }
    try {
      const deadline = new Promise((_, reject) => {
        timer = setTimeout(() => {
          const failure = error("CONTROL_REQUEST_TIMEOUT");
          transportProvenance.set(failure, endpoint);
          reject(failure);
          controller.abort();
        }, CONTROL_REQUEST_DEADLINE_MS);
      });
      return await Promise.race(interrupted ? [operation, deadline, interrupted] : [operation, deadline]);
    } finally {
      requestReturned = true;
      if (timer !== null) clearTimeout(timer);
      if (callerSignal) callerSignal.removeEventListener("abort", abortFromCaller);
      resolveInterrupted?.();
    }
  }
  async function scheduleMetadataForget() {
    if (metadataForgetFlight) return metadataForgetFlight;
    const credentials = clone(state.credentials);
    if (!credentials?.accessToken || !credentials.deviceId) return false;
    const context = contextForState({ deviceId: credentials.deviceId, sessionId: credentials.sessionId });
    const epoch = metadataForgetEpoch;
    metadataForgetFlight = (async () => {
      try {
        const stored = await chrome.storage.local.get(METADATA_CLEAR_RECEIPT_KEY);
        if (!isCurrent(context) || epoch !== metadataForgetEpoch) return false;
        const receipt = stored?.[METADATA_CLEAR_RECEIPT_KEY];
        if (receipt?.version === "client_metadata_cleared_v1" && receipt.deviceId === credentials.deviceId) return true;
        const attemptAt = now();
        if (metadataForgetLastAttempt?.deviceId === credentials.deviceId &&
            attemptAt >= metadataForgetLastAttempt.at && attemptAt - metadataForgetLastAttempt.at < 60000) return false;
        metadataForgetLastAttempt = { deviceId: credentials.deviceId, at: attemptAt };
        const marker = { version: "pending_client_metadata_clear_v1", deviceId: credentials.deviceId };
        await chrome.storage.local.set({ [METADATA_CLEAR_KEY]: marker });
        if (!isCurrent(context) || epoch !== metadataForgetEpoch) return false;
        const result = await authenticatedRequest("/v1/devices/current/client-metadata/forget", { method: "POST" }, context);
        if (result.body?.status !== "cleared" || result.body.deviceId !== credentials.deviceId ||
            !isCurrent(context) || epoch !== metadataForgetEpoch) return false;
        await chrome.storage.local.set({ [METADATA_CLEAR_RECEIPT_KEY]: { version: "client_metadata_cleared_v1", deviceId: credentials.deviceId } });
        if (!isCurrent(context) || epoch !== metadataForgetEpoch) {
          await chrome.storage.local.remove(METADATA_CLEAR_RECEIPT_KEY);
          return false;
        }
        const pending = await chrome.storage.local.get(METADATA_CLEAR_KEY);
        if (pending?.[METADATA_CLEAR_KEY]?.deviceId === credentials.deviceId) await chrome.storage.local.remove(METADATA_CLEAR_KEY);
        return true;
      } catch (_) { return false; }
    })().finally(() => { metadataForgetFlight = null; });
    return metadataForgetFlight;
  }
  async function handleTechnicalPermissionWithdrawal() {
    await init();
    const pending = state.pending;
    if (!state.credentials && pendingLive(pending) && (pending.metadataMode || "identified") === "identified") {
      pollingFlight?.exchangeController?.abort();
      await queueMutation(async () => {
        if (state.pending?.authorizationId === pending.authorizationId) await commit({ ...state, generation: state.generation + 1, pending: null, lastError: null }, state.authority, "activation_consent_withdrawn");
      });
      if (!state.credentials) await startActivation();
      return;
    }
    await scheduleMetadataForget();
  }
  function assertStart(body) { if (!body || body.status !== "pending" || !UUID.test(body.authorizationId) || !OPAQUE_TOKEN.test(body.deviceCode) || !/^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{4}-[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{4}$/.test(body.userCode) || !Number.isFinite(Date.parse(body.expiresAt))) throw error("INVALID_DEVICE_AUTH_RESPONSE"); return body; }
  function assertTokens(body) { if (!body || body.status !== "activated" || !validCredentials(body)) throw error("INVALID_TOKEN_RESPONSE"); return { deviceId: body.deviceId, sessionId: body.sessionId, tokenType: body.tokenType, accessToken: body.accessToken, accessTokenExpiresAt: body.accessTokenExpiresAt, refreshToken: body.refreshToken, refreshTokenExpiresAt: body.refreshTokenExpiresAt }; }
  function assertRefreshTokens(body, previous) { if (!body || body.tokenType !== "Bearer" || typeof body.accessToken !== "string" || !body.accessToken || !OPAQUE_TOKEN.test(body.refreshToken || "") || !Number.isFinite(Date.parse(body.accessTokenExpiresAt)) || !Number.isFinite(Date.parse(body.refreshTokenExpiresAt))) throw error("INVALID_REFRESH_RESPONSE"); return { deviceId: previous.deviceId, sessionId: previous.sessionId, tokenType: body.tokenType, accessToken: body.accessToken, accessTokenExpiresAt: body.accessTokenExpiresAt, refreshToken: body.refreshToken, refreshTokenExpiresAt: body.refreshTokenExpiresAt }; }
  function accessFresh() { return state.credentials && Date.parse(state.credentials.accessTokenExpiresAt) > now() + 30000; }
  async function openPortal(authorizationId) { const portalUrl = url(`/activate?authorizationId=${encodeURIComponent(authorizationId)}`, config.portalOrigin); if (chrome.tabs?.create) await chrome.tabs.create({ url: portalUrl }); return portalUrl; }
  function retryableExchange(failure) { return failure.code === EXCHANGE_PENDING || !failure.status || RETRYABLE_EXCHANGE_STATUS.has(failure.status); }
  function ownerCurrent(owner) { return Boolean(owner && (owner.context === null || isCurrent(owner.context))); }
  function detachObsoleteOwners() {
    if (pollingFlight && !ownerCurrent(pollingFlight)) pollingFlight = null;
    if (activationFlight && !ownerCurrent(activationFlight)) activationFlight = null;
    if (refreshFlight && !ownerCurrent(refreshFlight)) refreshFlight = null;
    if (subscriptionRefreshFlight && !ownerCurrent(subscriptionRefreshFlight)) subscriptionRefreshFlight = null;
  }
  function resetRuntimeClock() { runtimeClockOwner = null; runtimeAnchor = null; runtimeEffectiveHighWatermark = null; runtimeFloorNeedsPersistence = false; runtimeLastCheckpointAllowed = null; }
  function validAuthOwnership() { return Boolean(validCredentials(state.credentials) && validCacheClock(state.cacheClock, state.credentials, state.authority?.payload || null)); }
  async function ensureAuthOwnership() {
    if (validAuthOwnership()) return true;
    const failure = error("AUTH_CONTEXT_INVALID");
    await invalidateKnown(contextForState(), failure, true);
    throw error("AUTH_REQUIRED");
  }
  async function ensureFreshAccess(context, options = {}) {
    if (!state.credentials) throw error("AUTH_REQUIRED");
    if (!isCurrent(context)) throw error("AUTH_GENERATION_CHANGED");
    const forced = options.force === true;
    if (!forced && accessFresh()) return clone(state.credentials);
    try {
      await refresh({ context, ...(forced ? { force: true, rejectedAccessToken: options.rejectedAccessToken } : {}) });
    } catch (failure) {
      if (isCurrent(context) && (failure?.status === 401 || failure?.status === 403 || terminalAuthFailure(failure))) await invalidateKnown(context, failure, true);
      throw failure;
    }
    if (!isCurrent(context) || !state.credentials) throw error("AUTH_GENERATION_CHANGED");
    return clone(state.credentials);
  }
  function terminalServiceAuthFailure(failure) {
    return ["DEVICE_MISMATCH", "ACCOUNT_IDENTITY_MISMATCH", "TRANSFER_DEVICE_REVOKED"].includes(failure?.code);
  }
  async function authenticatedRequest(path, options = {}, requestContext = null) {
    await init();
    if (!state.credentials) throw error("AUTH_REQUIRED");
    await ensureAuthOwnership();
    const context = requestContext ? clone(requestContext) : contextForState();
    if (!isCurrent(context)) throw error("AUTH_GENERATION_CHANGED");
    await ensureFreshAccess(context);
    let retried = false;
    while (true) {
      if (!isCurrent(context) || !state.credentials) throw error("AUTH_GENERATION_CHANGED");
      const rejectedAccessToken = state.credentials.accessToken;
      const headers = new Headers(options.headers || {});
      headers.set("Authorization", `Bearer ${rejectedAccessToken}`);
      try {
        return await request(path, { ...options, headers });
      } catch (failure) {
        if (!isCurrent(context)) throw failure;
        if (failure?.status !== 401) {
          if (terminalServiceAuthFailure(failure)) await invalidateKnown(context, failure, true);
          throw failure;
        }
        if (retried) {
          await invalidateKnown(context, failure, true);
          throw failure;
        }
        retried = true;
        try {
          await ensureFreshAccess(context, { force: true, rejectedAccessToken });
        } catch (refreshFailure) {
          if (refreshFailure?.status === 401 || refreshFailure?.status === 403 || terminalAuthFailure(refreshFailure)) throw refreshFailure;
          throw failure;
        }
      }
    }
  }
  async function ensurePolling() {
    await init();
    if (!pendingLive(state.pending)) return;
    if (!validAuthContext(state.pending.authContext)) { await queueMutation(async () => { if (state.pending && !validAuthContext(state.pending.authContext)) await commit({ ...state, generation: state.generation + 1, pending: null, lastError: safeError(error("ACTIVATION_CONTEXT_MISMATCH")) }, state.authority, "activation_context_invalid"); }); return; }
    if (ownerCurrent(pollingFlight)) return pollingFlight.promise;
    if (pollingFlight) pollingFlight = null;
    const owner = { context: contextForState(), promise: null };
    owner.promise = (async () => {
      try {
        while (isCurrent(owner.context) && pendingLive(state.pending)) {
          const pending = state.pending;
          try {
            const permission = consentApi?.consent ? await consentApi.consent() : { applicable: false, granted: true };
            if (permission.applicable && !permission.granted && (pending.metadataMode || "identified") === "identified") {
              await queueMutation(async () => {
                if (state.pending?.authorizationId === pending.authorizationId) await commit({ ...state, generation: state.generation + 1, pending: null, lastError: null }, state.authority, "activation_consent_withdrawn");
              });
              if (!state.credentials) await startActivation();
              return;
            }
            const exchangeController = new AbortController();
            owner.exchangeController = exchangeController;
            let result;
            try { result = await request("/v1/device-authorizations/token", { method: "POST", headers: { "Idempotency-Key": pending.exchangeIdempotencyKey }, body: { deviceCode: pending.deviceCode }, signal: exchangeController.signal }); }
            finally { if (owner.exchangeController === exchangeController) owner.exchangeController = null; }
            const credentials = assertTokens(result.body);
            if (!isCurrent(owner.context) || state.pending?.authorizationId !== pending.authorizationId) return;
            const effective = now(); if (!validMillis(effective)) throw error("CACHE_WALL_CLOCK_INVALID");
            const cacheClock = { cacheVersion: "control_cache_clock_v1", owner: clockOwner(credentials), trustedServerTimeMs: 0, effectiveTimeMs: effective };
            if (!await commitIfCurrent(owner.context, current => ({ ...current, credentials, cacheClock, pending: null, rotation: null, authority: null, grants: {},
              principalEpoch: epoch("principalEpoch") + 1, accessEpoch: epoch("accessEpoch") + 1,
              lastError: null, generation: current.generation + 1 }), "activated")) return;
            const bootstrapContext = contextForState({ generation: owner.context.generation + 1, deviceId: credentials.deviceId, sessionId: credentials.sessionId });
            try { await bootstrap({ context: bootstrapContext }); } catch (failure) {
              await queueMutation(async () => { if (isCurrent(bootstrapContext) && state.credentials) await commit({ ...state, lastError: safeError(failure) }, state.authority, "bootstrap_failed"); });
            }
            return;
          } catch (failure) {
            if (!isCurrent(owner.context) || state.pending?.authorizationId !== pending.authorizationId) return;
            if (failure.code === "DEVICE_AUTH_WITHDRAWN") {
              await queueMutation(async () => {
                if (state.pending?.authorizationId === pending.authorizationId) await commit({ ...state, generation: state.generation + 1, pending: null, lastError: null }, state.authority, "activation_consent_withdrawn");
              });
              if (!state.credentials) await startActivation();
              return;
            }
            if (retryableExchange(failure) && Date.parse(pending.expiresAt) > now()) {
              const wait = failure.code === EXCHANGE_PENDING ? failure.retryAfterMs || 1000 : Math.min(5000, Math.max(1000, failure.retryAfterMs || 1000));
              await new Promise(resolve => setTimeout(resolve, Math.min(wait, Math.max(250, Date.parse(pending.expiresAt) - now()))));
              continue;
            }
            await commitIfCurrent(owner.context, current => ({ ...current, pending: null, lastError: safeError(failure), generation: current.generation + 1 }), "activation_failed");
            return;
          }
        }
      } finally { if (pollingFlight === owner) pollingFlight = null; }
    })();
    pollingFlight = owner;
    return owner.promise;
  }
  async function startActivation() {
    await init();
    if (state.credentials) { try { await ensureAuthOwnership(); } catch (_) {} }
    if (state.credentials && state.authority) return { ...publicStatus(), portalUrl: null };
    if (state.credentials && !state.authority) { const context = contextForState(); try { await bootstrap({ context }); } catch (failure) { await commitIfCurrent(context, current => ({ ...current, lastError: safeError(failure) }), "bootstrap_failed"); } return { ...publicStatus(), portalUrl: null }; }
    if (pendingLive(state.pending)) { if (!validAuthContext(state.pending.authContext)) { await queueMutation(async () => { await commit({ ...state, generation: state.generation + 1, pending: null, lastError: safeError(error("ACTIVATION_CONTEXT_MISMATCH")) }, state.authority, "activation_context_invalid"); }); } else { const context = contextForState(); const portalUrl = await openPortal(state.pending.authorizationId); if (isCurrent(context)) void ensurePolling(); return { ...publicStatus(), portalUrl: isCurrent(context) ? portalUrl : null }; } }
    if (ownerCurrent(activationFlight)) return activationFlight.promise;
    activationFlight = null;
    const permission = consentApi?.consent ? await consentApi.consent() : { applicable: false, granted: true };
    const requestedMetadataMode = permission.applicable && !permission.granted ? "privacy_neutral" : "identified";
    let metadataMode = requestedMetadataMode;
    const owner = { context: null, promise: null };
    owner.promise = (async () => {
      const started = await queueMutation(async () => { if (state.credentials || pendingLive(state.pending)) return null; const reusableStarting = state.pending?.phase === "starting" && (state.pending.metadataMode || "identified") === requestedMetadataMode && TOKEN.test(state.pending.startIdempotencyKey) && validAuthContext(state.pending.authContext); const startIdempotencyKey = reusableStarting ? state.pending.startIdempotencyKey : key(); const attemptId = reusableStarting && state.pending.attemptId && validAuthContext(state.pending.authContext) ? state.pending.attemptId : key(); const authContext = { contextVersion: "control_auth_context_v1", controlApiOrigin: config.controlApiOrigin, portalOrigin: config.portalOrigin, contractVersion: config.contractVersion }; const next = { ...state, generation: state.generation + 1, pending: { phase: "starting", attemptId, startIdempotencyKey, authContext, metadataMode: requestedMetadataMode }, lastError: null }; await commit(next, state.authority, "activation_starting"); return { context: { generation: next.generation, attemptId }, startIdempotencyKey }; });
      if (!started) return publicStatus();
      owner.context = started.context;
      const result = await request("/v1/device-authorizations", { method: "POST", headers: { "Idempotency-Key": started.startIdempotencyKey }, body: { clientType: "browser_extension", browserFamily: browserFamily(), browserVersion: browserVersion(), extensionVersion: config.extensionVersion }, captureProjection: projection => { metadataMode = projection.consent.applicable && !projection.consent.granted ? "privacy_neutral" : "identified"; } });
      const response = assertStart(result.body); const pending = { phase: "pending", attemptId: started.context.attemptId, authorizationId: response.authorizationId, deviceCode: response.deviceCode, userCode: response.userCode, expiresAt: response.expiresAt, startIdempotencyKey: started.startIdempotencyKey, exchangeIdempotencyKey: key(), authContext: { contextVersion: "control_auth_context_v1", controlApiOrigin: config.controlApiOrigin, portalOrigin: config.portalOrigin, contractVersion: config.contractVersion }, metadataMode };
      if (!await commitIfCurrent(started.context, current => ({ ...current, pending, lastError: null }), "activation_started") || !isCurrent(started.context)) return publicStatus();
      const portalUrl = await openPortal(response.authorizationId); if (!isCurrent(started.context)) return publicStatus(); void ensurePolling(); return { ...publicStatus(), portalUrl };
    })().catch(async failure => { if (owner.context) await commitIfCurrent(owner.context, current => ({ ...current, pending: current.pending?.phase === "starting" ? { ...current.pending, metadataMode } : current.pending, lastError: safeError(failure) }), "activation_failed"); throw failure; }).finally(() => { if (activationFlight === owner) activationFlight = null; });
    activationFlight = owner; return owner.promise;
  }
  async function refresh(options = {}) {
    if (!options || typeof options !== "object" || Array.isArray(options) || options.context !== undefined && !validContext(options.context)) throw error("AUTH_CONTEXT_INVALID");
    await init();
    const entryContext = options.context ? clone(options.context) : contextForState();
    if (!isCurrent(entryContext)) throw error("AUTH_GENERATION_CHANGED");
    const forced = options.force === true, rejectedAccessToken = options.rejectedAccessToken;
    if (!state.credentials) throw error("AUTH_REQUIRED");
    await ensureAuthOwnership();
    if (forced && rejectedAccessToken && state.credentials.accessToken !== rejectedAccessToken) { if (!isCurrent(entryContext)) throw error("AUTH_GENERATION_CHANGED"); return clone(state.credentials); }
    if (!forced && accessFresh() && !state.rotation) { if (!isCurrent(entryContext)) throw error("AUTH_GENERATION_CHANGED"); return clone(state.credentials); }
    if (ownerCurrent(refreshFlight) && refreshFlight.context && isCurrent(refreshFlight.context) && refreshFlight.context.generation === entryContext.generation && refreshFlight.context.deviceId === entryContext.deviceId && refreshFlight.context.sessionId === entryContext.sessionId) return refreshFlight.promise;
    refreshFlight = null;
    const owner = { context: entryContext, promise: null };
    owner.promise = (async () => {
      const prepared = await queueMutation(async () => { if (!isCurrent(entryContext)) throw error("AUTH_GENERATION_CHANGED"); if (!state.credentials) throw error("AUTH_REQUIRED"); const context = contextForState(); let rotation = state.rotation; if (!rotation || rotation.generation !== context.generation || rotation.refreshToken !== state.credentials.refreshToken) { rotation = { generation: context.generation, refreshToken: state.credentials.refreshToken, idempotencyKey: key() }; await commit({ ...state, rotation }, state.authority, "refresh_prepared"); } const preparedContext = { ...context, rotationKey: rotation.idempotencyKey }; owner.context = preparedContext; return { context: preparedContext, rotation, credentials: clone(state.credentials) }; });
      if (!isCurrent(prepared.context)) throw error("AUTH_GENERATION_CHANGED");
      owner.context = prepared.context;
      let result;
      try { result = await request("/v1/auth/refresh", { method: "POST", headers: { "Idempotency-Key": prepared.rotation.idempotencyKey }, body: { refreshToken: prepared.rotation.refreshToken } }); }
      catch (failure) { if (failure?.status || !isCurrent(prepared.context)) throw failure; result = await request("/v1/auth/refresh", { method: "POST", headers: { "Idempotency-Key": prepared.rotation.idempotencyKey }, body: { refreshToken: prepared.rotation.refreshToken } }); }
      const credentials = assertRefreshTokens(result.body, prepared.credentials); if (!await commitIfCurrent(prepared.context, current => ({ ...current, credentials, rotation: null, lastError: null }), "refresh_rotated")) throw error("AUTH_GENERATION_CHANGED"); void retryPendingMetadataForget(); return clone(credentials);
    })().catch(async failure => { if (failure.code === "AUTH_REFRESH_INVALID" && owner.context) await invalidateKnown(owner.context, failure, true); throw failure; }).finally(() => { if (refreshFlight === owner) refreshFlight = null; });
    refreshFlight = owner; return owner.promise;
  }
  function bootstrapContractVersion() { if (!["control_plane_v2", "control_plane_v3"].includes(config.contractVersion)) throw error("PACKAGED_CONTRACT_UNSUPPORTED"); return config.contractVersion; }
  function bootstrapRequest(detectedAi, credentials, authority) { const body = { contractVersion: bootstrapContractVersion(), extensionVersion: config.extensionVersion, browser: { family: browserFamily(), version: browserVersion() }, deviceId: credentials.deviceId, lastConfigVersion: authority?.payload?.configVersion || null }; if (detectedAi) body.detectedAi = detectedAi; return body; }
  const SEMVER = /^(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)(?:-(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
  function decimalCompare(left, right) { const a = left.replace(/^0+(?=\d)/, ""), b = right.replace(/^0+(?=\d)/, ""); return a.length === b.length ? (a === b ? 0 : a < b ? -1 : 1) : a.length < b.length ? -1 : 1; }
  function parseSemver(value) {
    if (typeof value !== "string" || value.length < 1 || value.length > 64 || !SEMVER.test(value)) return null;
    const withoutBuild = value.split("+", 1)[0], hyphen = withoutBuild.indexOf("-");
    const core = hyphen < 0 ? withoutBuild : withoutBuild.slice(0, hyphen);
    return { core: core.split("."), prerelease: hyphen < 0 ? [] : withoutBuild.slice(hyphen + 1).split(".") };
  }
  function compareSemver(left, right) {
    const a = parseSemver(left), b = parseSemver(right); if (!a || !b) return undefined;
    for (let i = 0; i < 3; i++) { const compared = decimalCompare(a.core[i], b.core[i]); if (compared) return compared; }
    if (!a.prerelease.length || !b.prerelease.length) return a.prerelease.length === b.prerelease.length ? 0 : a.prerelease.length ? -1 : 1;
    for (let i = 0; i < Math.min(a.prerelease.length, b.prerelease.length); i++) {
      const x = a.prerelease[i], y = b.prerelease[i]; if (x === y) continue;
      const xn = /^\d+$/.test(x), yn = /^\d+$/.test(y); if (xn && yn) return decimalCompare(x, y); if (xn !== yn) return xn ? -1 : 1; return x < y ? -1 : 1;
    }
    return a.prerelease.length === b.prerelease.length ? 0 : a.prerelease.length < b.prerelease.length ? -1 : 1;
  }
  function parseBrowser(value) {
    if (typeof value !== "string") return null; const parts = value.split(".");
    if (parts.length < 1 || parts.length > 4 || parts.some(part => !/^(?:0|[1-9]\d*)$/.test(part))) return null;
    if (parts.some(part => decimalCompare(part, "2147483647") > 0)) return null;
    return [...parts, ...Array(4 - parts.length).fill("0")];
  }
  function compareBrowser(left, right) { const a = parseBrowser(left), b = parseBrowser(right); if (!a || !b) return undefined; for (let i = 0; i < 4; i++) { const compared = decimalCompare(a[i], b[i]); if (compared) return compared; } return 0; }
  function versionAtLeast(actual, minimum, browser = false) { const compared = browser ? compareBrowser(actual, minimum) : compareSemver(actual, minimum); return compared !== undefined && compared >= 0; }
  function exactKeys(value, required, optional = []) { if (!value || typeof value !== "object" || Array.isArray(value)) return false; const allowed = new Set([...required, ...optional]); return Object.keys(value).every(k => allowed.has(k)) && required.every(k => Object.hasOwn(value, k)); }
  function validSelector(value, strategy) {
    if (!exactKeys(value, ["strategy", "primary", "fallbacks", "timeoutMs", "observationMode"]) || value.strategy !== strategy || !Array.isArray(value.fallbacks) || value.fallbacks.length > 3 || !Number.isSafeInteger(value.timeoutMs) || value.timeoutMs < 250 || value.timeoutMs > 30000 || !["polling", "mutation_observer"].includes(value.observationMode)) return false;
    const validPrimitive = primitive => exactKeys(primitive, ["kind", "reference"], ["role"]) && ["page-root", "conversation-root", "composer-root", "send-control", "assistant-response", "busy-control", "copy-control"].includes(primitive.reference) && (primitive.kind === "packaged_selector_reference" ? !Object.hasOwn(primitive, "role") : primitive.kind === "accessibility_role_name" && ["main", "article", "textbox", "button", "status"].includes(primitive.role));
    return validPrimitive(value.primary) && value.fallbacks.every(validPrimitive) && !(value.observationMode === "polling" && value.timeoutMs < 500);
  }
  function validProfileShape(profile, enforceEnvironment = true, expectedContractVersion = "control_plane_v1", checks = null) {
    const content = profile?.content, compatibility = profile?.compatibility;
    if (!MACHINE.test(profile?.profileKey || "") || String(profile?.profileKey || "").length > 64 || !Number.isSafeInteger(profile?.revision) || profile.revision <= 0 || profile?.schemaVersion !== "adapter_profile_v1" || profile?.scopeVariant !== null) return false;
    if (!exactKeys(content, ["schemaVersion", "page", "selectors", "observation", "contours"]) || content.schemaVersion !== "adapter_profile_v1" || !exactKeys(content.page, ["identityStrategy", "conversationStrategy", "composerStrategy"]) || content.page.identityStrategy !== "page_identity" || content.page.conversationStrategy !== "conversation_root" || content.page.composerStrategy !== "composer_root") return false;
    if (!exactKeys(content.selectors, ["conversation", "composer", "send", "assistantResponse"]) || !validSelector(content.selectors.conversation, "conversation_root") || !validSelector(content.selectors.composer, "composer_root") || !validSelector(content.selectors.send, "send_control") || !validSelector(content.selectors.assistantResponse, "assistant_response")) return false;
    if (!exactKeys(content.observation, ["mode", "intervalMs"]) || !["polling", "mutation_observer"].includes(content.observation.mode) || !Number.isSafeInteger(content.observation.intervalMs) || content.observation.intervalMs < 100 || content.observation.intervalMs > 5000 || (content.observation.mode === "mutation_observer" && content.observation.intervalMs !== 100)) return false;
    const contourKeys = new Set(["page_identity", "conversation_root", "composer_root", "send_control", "busy_state", "assistant_response", "copy_control"]);
    if (!Array.isArray(content.contours) || content.contours.length < 4 || content.contours.length > 7 || new Set(content.contours.map(x => x.key)).size !== content.contours.length || !content.contours.every(x => exactKeys(x, ["key", "required", "expectedState", "strategy"]) && contourKeys.has(x.key) && typeof x.required === "boolean" && ["PRESENT", "INTERACTIVE", "COMPLETES"].includes(x.expectedState) && contourKeys.has(x.strategy))) return false;
    if (!exactKeys(compatibility, ["schemaVersion", "contractVersion", "browserFamilies", "minimumBrowserVersions", "minimumExtensionVersion"]) || compatibility.schemaVersion !== "profile_compatibility_v1" || compatibility.contractVersion !== expectedContractVersion || !["control_plane_v1", "control_plane_v2"].includes(compatibility.contractVersion) || !Array.isArray(compatibility.browserFamilies) || compatibility.browserFamilies.length < 1 || compatibility.browserFamilies.length > browserIdentity.families.length || new Set(compatibility.browserFamilies).size !== compatibility.browserFamilies.length || !compatibility.browserFamilies.every(x => browserIdentity.families.includes(x)) || !Array.isArray(compatibility.minimumBrowserVersions) || compatibility.minimumBrowserVersions.length > browserIdentity.families.length || new Set(compatibility.minimumBrowserVersions.map(x => x.browserFamily)).size !== compatibility.minimumBrowserVersions.length || !compatibility.minimumBrowserVersions.every(x => exactKeys(x, ["browserFamily", "minimumVersion"]) && compatibility.browserFamilies.includes(x.browserFamily) && parseBrowser(x.minimumVersion)) || !(compatibility.minimumExtensionVersion === null || parseSemver(compatibility.minimumExtensionVersion))) return false;
    bootstrapCheck(checks, "PROFILE_SHAPE", true);
    if (!enforceEnvironment) return true;
    if (!bootstrapCheck(checks, "PROFILE_BROWSER_FAMILY", compatibility.browserFamilies.includes(browserFamily())) || !bootstrapCheck(checks, "PROFILE_EXTENSION_MINIMUM", !compatibility.minimumExtensionVersion || versionAtLeast(config.extensionVersion, compatibility.minimumExtensionVersion))) return false;
    const browserMin = compatibility.minimumBrowserVersions.find(x => x.browserFamily === browserFamily()); return bootstrapCheck(checks, "PROFILE_BROWSER_MINIMUM", !browserMin || versionAtLeast(browserVersion(), browserMin.minimumVersion, true));
  }
  async function profileFingerprint(profile) { const bytes = new TextEncoder().encode(verifier.canonicalJson({ content: profile.content, compatibility: profile.compatibility })); return [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map(x => x.toString(16).padStart(2, "0")).join(""); }
  async function materializeLocalAuthority(payload, requestedAi = null) {
    const identity = currentBrowserIdentity();
    return localAuthority?.materialize(payload, {
      browserFamily: identity.family,
      browserVersion: identity.version,
      extensionVersion: config.extensionVersion,
      requestedAi,
      localAi: LOCAL_AI,
      compareSemver,
      compareBrowser,
      versionAtLeast,
      profileValid: (profile, family, version, extension) => validProfileShape(profile, true, "control_plane_v2") && browserFamily() === family && browserVersion() === version && config.extensionVersion === extension,
      profileFingerprint,
    }) || null;
  }
  async function validateAccountProfile(payload, requestedAi = null, enforceEnvironment = true, checks = null) {
    if (!authorityStaticValid(payload, checks) || !bootstrapCheck(checks, "REQUESTED_AI_KNOWN", !requestedAi || Boolean(LOCAL_AI[requestedAi]))) return null;
    if (payload.ai.status === "UNCONFIGURED") return bootstrapCheck(checks, "AI_UNCONFIGURED_SCOPE", requestedAi === null) ? { workAllowed: false, requestedAi: null } : null;
    if (payload.ai.status === "UNAVAILABLE") return bootstrapCheck(checks, "AI_UNAVAILABLE_LOCAL", payload.localClientAuthority) ? { workAllowed: false, requestedAi: requestedAi || null } : null;
    // Adapter profile bytes remain v1/v2 material even when a dormant v3 bootstrap carries them.
    const profileContractVersion = payload.ai.profile?.compatibility?.contractVersion === "control_plane_v1" ? "control_plane_v1" : "control_plane_v2";
    if (!bootstrapCheck(checks, "AI_RESOLVED", payload.ai.status === "RESOLVED")) return null;
    const checksBeforeProfile = checks?.length || 0;
    if (!validProfileShape(payload.ai.profile, enforceEnvironment, profileContractVersion, checks)) { if (checks && checks.length === checksBeforeProfile) bootstrapCheck(checks, "PROFILE_SHAPE", false); return null; }
    const expected = requestedAi ? LOCAL_AI[requestedAi] : LOCAL_AI[payload.ai.detected?.family], detected = payload.ai.detected;
    if (!bootstrapCheck(checks, "AI_PROFILE_SCOPE", expected && detected.family === (requestedAi || detected.family) && detected.surface === expected.surface && detected.variant === null && payload.ai.profile.scopeVariant === null)) return null;
    if (!bootstrapCheck(checks, "PROFILE_FINGERPRINT", (await profileFingerprint(payload.ai.profile)) === payload.ai.profile.contentSha256)) return null;
    return { workAllowed: true, requestedAi: requestedAi || payload.ai.detected.family };
  }
  async function validateOperationalAuthority(payload, requestedAi = null) { return Boolean(await validateAccountProfile(payload, requestedAi, true)); }
  async function validateBootstrapAuthority(payload, requestedAi = null, privacyNeutral = false, checks = null) {
    if (privacyNeutral) {
      if (!bootstrapCheck(checks, "PAYLOAD_VARIANT", payload?.localClientAuthority && !Object.hasOwn(payload, "compatibility") && !Object.hasOwn(payload, "features") && !Object.hasOwn(payload, "ai"))) return null;
      payload = await materializeLocalAuthority(payload, requestedAi);
      if (!bootstrapCheck(checks, "LOCAL_MATERIALIZATION", payload)) return null;
    } else if (!bootstrapCheck(checks, "PAYLOAD_VARIANT", !payload?.localClientAuthority)) return null;
    return validateAccountProfile(payload, requestedAi, true, checks);
  }
  async function requestBootstrap(credentials, authority, detectedAi, attempt) {
    return request("/v1/bootstrap", { method: "POST", headers: { Authorization: `Bearer ${credentials.accessToken}` },
      body: bootstrapRequest(detectedAi, credentials, authority), signal: attempt.lease?.signal,
      captureProjection: projection => { attempt.privacyNeutral = projection.consent.applicable && !projection.consent.granted; },
      observeSettlement: async outcome => { attempt.lastHttpOutcome = outcome; await observeBootstrapLate(attempt, outcome); } });
  }
  function decodeBase64Url(value) { if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value)) return null; try { const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4); const bytes = Uint8Array.from(atob(padded), c => c.charCodeAt(0)); return verifier.base64urlEncode(bytes) === value ? bytes : null; } catch (_) { return null; } }
  async function snapshotDigest(envelope) { const bytes = decodeBase64Url(envelope?.payload); if (!bytes) return null; return [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map(value => value.toString(16).padStart(2, "0")).join(""); }
  function healthRequest(detectedAi, credentials, authority) { return { healthTransportVersion: "health_transport_v1", bootstrap: bootstrapRequest(detectedAi, credentials, authority), bootstrapEnvelope: authority.envelope }; }
  async function healthContextFromBootstrap(payload, authority, credentials) { if (payload?.contractVersion !== "control_plane_v2" || payload?.ai?.status !== "RESOLVED" || !authority?.deviceId || !authority?.sessionId || !credentials?.deviceId || !credentials?.sessionId || authority.deviceId !== credentials.deviceId || authority.sessionId !== credentials.sessionId) return null; const bootstrapSnapshotSha256 = await snapshotDigest(authority.envelope); if (!bootstrapSnapshotSha256) return null; return { accountId: payload.account.id, deviceId: authority.deviceId, sessionId: authority.sessionId, contractVersion: payload.contractVersion, configVersion: payload.configVersion, bootstrapSnapshotSha256, ai: { family: payload.ai.detected.family, surface: payload.ai.detected.surface, variant: payload.ai.detected.variant, profileKey: payload.ai.profile.profileKey, revision: payload.ai.profile.revision, scopeVariant: payload.ai.profile.scopeVariant, contentSha256: payload.ai.profile.contentSha256 } }; }
  async function acquireSignedHealthAuthority(options = {}) {
    if (!options || typeof options !== "object" || Array.isArray(options) || options.context !== undefined && !validContext(options.context)) throw error("AUTH_CONTEXT_INVALID");
    await init(); if (!state.credentials) throw error("AUTH_REQUIRED"); await ensureAuthOwnership();
    const context = options.context ? clone(options.context) : contextForState(); if (!isCurrent(context)) throw error("AUTH_GENERATION_CHANGED");
    const requestedAi = options.detectedAi?.family || null;
    if (!requestedAi || !LOCAL_AI[requestedAi] || options.detectedAi.surface !== LOCAL_AI[requestedAi].surface || options.detectedAi.variant !== null) throw error("HEALTH_CONTEXT_INVALID");
    const permission = consentApi?.consent ? await consentApi.consent() : { applicable: false, granted: true };
    if (permission.applicable && !permission.granted) { void scheduleMetadataForget(); return null; }
    const authority = clone(state.authority), authorityIdentityBefore = authorityDecisionIdentity(authority, context.generation); if (!authority?.envelope) throw error("HEALTH_CONTEXT_INVALID"); if (authority.payload?.contractVersion !== "control_plane_v2") return null; let result; try { result = await authenticatedRequest("/v1/health-authority", { method: "POST", body: healthRequest(options.detectedAi, state.credentials, authority) }, context); } catch (failure) { if (failure.code === "HEALTH_TECHNICAL_PERMISSION_REQUIRED") return null; throw failure; }
    if (!isCurrent(context) || authorityIdentityBefore !== authorityDecisionIdentity()) throw error("AUTH_GENERATION_CHANGED");
    const verified = await verifier.verifyHealthV1(result.body, config.trustBundle); if (!verified.ok) throw error(`HEALTH_${verified.error}`);
    if (verified.payload.status === "PASS") { const expected = await healthContextFromBootstrap(authority?.payload, authority, state.credentials); if (!expected || verifier.canonicalJson(expected) !== verifier.canonicalJson(verified.payload.context)) throw error("HEALTH_CONTEXT_MISMATCH"); }
    return { payload: clone(verified.payload), envelope: clone(verified.envelope) };
  }
  async function getHealthAuthorityContext() { await init(); if (!state.credentials || !state.authority) throw error("HEALTH_CONTEXT_INVALID"); await getVerifiedAuthorityTime(); return clone(state.authority); }
  async function getVerifiedAuthorityTime(identity = null) {
    await init();
    if (authStorageUnconfirmed) throw error("AUTH_STATE_COMMIT_UNCONFIRMED");
    const record = identity === null ? null : grantFor(identity);
    const authority = identity === null ? state.authority : record?.authority;
    const clock = identity === null ? state.cacheClock : record?.cacheClock;
    if (!state.credentials || !clock || !authority || record && !verifiedGrantIdentities.has(grantIdentity(record))) throw error("HEALTH_CONTEXT_INVALID");
    return effectiveTime(clock, authority.payload);
  }
  /* C3A reads this cache snapshot only. It deliberately does not checkpoint,
   * persist a denial, refresh Bootstrap, or acquire Health. */
  function canContinueCached(identity) {
    if (!initialized || authStorageUnconfirmed) return false;
    try {
      const record = grantFor(identity);
      return Boolean(record && verifiedGrantIdentities.has(grantIdentity(record)) && record.authority.workAllowed === true &&
        canWork(record.authority.payload, effectiveTime(record.cacheClock, record.authority.payload)));
    } catch (_) { return false; }
  }
  async function getCachedContinuationState(identity = null) {
    await init();
    const record = identity === null ? null : grantFor(identity);
    const trusted = !authStorageUnconfirmed && (identity === null || record && verifiedGrantIdentities.has(grantIdentity(record)));
    const authority = trusted ? (identity === null ? state.authority : record?.authority) : null;
    return clone({
      generation: state.generation,
      principalEpoch: epoch("principalEpoch"), accessEpoch: epoch("accessEpoch"), grantEpoch: record?.grantEpoch || null,
      authority,
      cacheClock: identity === null ? state.cacheClock : record?.cacheClock || null,
      localInvalidation: {
        revoked: !state.credentials || !authority,
        loggedOut: !state.credentials,
        authReset: !state.credentials,
        obsolete: false,
        storeDeleted: false,
      },
    });
  }
  function terminalAuthFailure(failure) { return failure?.code === "AUTH_REFRESH_INVALID" || failure?.status === 401 || ["AUTH_INVALID", "DEVICE_REVOKED"].includes(failure?.code); }
  async function invalidateKnown(context, failure, terminal = terminalAuthFailure(failure)) {
    return queueMutation(async () => {
      if (!isCurrent(context)) return false;
      const denyingAcquisitions = [...bootstrapAttempts.values()].filter(attempt => attempt.lease && bootstrapAttemptCurrent(attempt));
      for (const attempt of denyingAcquisitions) attempt.lease.beginSecurityCommit();
      const previous = state.authority;
      const next = { ...state, generation: state.generation + 1, principalEpoch: epoch("principalEpoch") + (terminal ? 1 : 0), accessEpoch: epoch("accessEpoch") + 1, grants: {}, credentials: terminal ? null : state.credentials, pending: null, rotation: null, authority: null, cacheClock: terminal ? null : state.cacheClock, lastError: safeError(failure) };
      /* The denial is authoritative before any storage or cleanup await. */
      state = next;
      let transferCleanupFailure = null;
      if (terminal) {
        resetRuntimeClock();
        try { await clearTransferRecipientVault(); } catch (cleanupFailure) { transferCleanupFailure = cleanupFailure; }
      }
      detachObsoleteOwners();
      let persistenceFailure = null;
      try { await persist(next); }
      catch (_) {
        let removed = false;
        try { await chrome.storage.local.remove(STORAGE_KEY); removed = true; }
        catch (removeFailure) { persistenceFailure = error("AUTH_DENIAL_PERSISTENCE_FAILED"); persistenceFailure.detail = safeError(removeFailure); /* memory remains denied; disk could still contain the old record */ }
        if (removed) state = { ...state, credentials: null, cacheClock: null };
        if (persistenceFailure) state = { ...state, lastError: safeError(persistenceFailure) };
      }
      if (previous && typeof authorityChanged === "function") {
        try { await authorityChanged(null, failure?.code || "authority_invalid", state.generation); } catch (_) { /* cleanup is advisory */ }
      }
      if (!authStorageUnconfirmed && !persistenceFailure)
        for (const attempt of denyingAcquisitions) attempt.lease.finishRevocationCommit();
      return persistenceFailure || transferCleanupFailure ? { denied: true, ...(persistenceFailure ? { persistenceFailure: persistenceFailure.code } : {}), ...(transferCleanupFailure ? { transferCleanupFailure: transferCleanupFailure.code } : {}) } : true;
    });
  }
  async function invalidateUnauthorized(context, failure) { return invalidateKnown(context, failure, true); }
  function bootstrapAttemptCurrent(attempt) {
    if (!attempt || authStorageUnconfirmed || bootstrapAttemptSequence !== attempt.sequence || !isCurrent(attempt.context)) return false;
    if (attempt.lease) { try { attempt.lease.assertCurrent(); } catch (_) { return false; } }
    return true;
  }
  function bootstrapFence(scopeKey) {
    const scope = bootstrapAcquisitionScopes.get(scopeKey);
    if (!scope) throw error("BOOTSTRAP_ACQUISITION_SCOPE_MISSING");
    return { scopeKey, environmentKey: scope.environmentKey, principalEpoch: epoch("principalEpoch"),
      accessEpoch: epoch("accessEpoch"), grantEpoch: grantFor(scope.family)?.grantEpoch || 0 };
  }
  function bootstrapFenceCurrent(fence) {
    const scope = bootstrapAcquisitionScopes.get(fence.scopeKey), credentials = state.credentials;
    if (authStorageUnconfirmed || !scope || !credentials || scope.deviceId !== credentials.deviceId ||
        scope.sessionId !== credentials.sessionId || scope.principalEpoch !== epoch("principalEpoch")) return false;
    return verifier.canonicalJson(bootstrapFence(fence.scopeKey)) === verifier.canonicalJson(fence);
  }
  function quarantineBootstrap(failure) {
    if (authStorageUnconfirmed) return;
    authStorageUnconfirmed = true;
    state = { ...state, generation: state.generation + 1, accessEpoch: epoch("accessEpoch") + 1,
      authority: null, grants: {}, lastError: safeError(failure) };
    queueMicrotask(() => { void notifyAuthorityChange(null, "BOOTSTRAP_SECURITY_QUARANTINE", state.generation); });
  }
  async function observeBootstrapLate(attempt, outcome) {
    // A late allow never enters the state writer. A denial retains its common scope.
    if (!attempt?.principal || outcome.late !== true && bootstrapAttemptCurrent(attempt)) return;
    const principalCurrent = () => !authStorageUnconfirmed && state.credentials &&
      epoch("principalEpoch") === attempt.principal.principalEpoch &&
      state.credentials.deviceId === attempt.principal.deviceId && state.credentials.sessionId === attempt.principal.sessionId;
    if (!principalCurrent()) return;
    const failed = outcome.error;
    if (failed) {
      if ((failed.status === 401 || failed.status === 403) && httpErrorProvenance.get(failed) === endpointFor("/v1/bootstrap"))
        await invalidateKnown(contextForState(), failed, failed.status === 401);
      else if (failed.code === "CONTROL_RESPONSE_TOO_LARGE" && failed.responseOk === true)
        await invalidateKnown(contextForState(), failed, false);
      return;
    }
    const verified = await verifyCachedEnvelope(outcome.value?.body);
    if (!principalCurrent()) return;
    if (!verified?.ok) { await invalidateKnown(contextForState(), error("BOOTSTRAP_LATE_VERIFICATION_FAILED"), false); return; }
    const payload = attempt.privacyNeutral ? await materializeLocalAuthority(verified.payload, attempt.requestedAi) : verified.payload;
    if (!principalCurrent()) return;
    const validation = await validateBootstrapAuthority(verified.payload, attempt.requestedAi, attempt.privacyNeutral);
    if (!principalCurrent()) return;
    if (!validation || validation.workAllowed !== true || !staticCanWork(payload))
      await invalidateKnown(contextForState(), error("BOOTSTRAP_LATE_COMMON_DENY"), false);
  }
  async function scheduleBootstrap(options, mode, execute) {
    // The coalescing key and dispatched options share one private snapshot.
    // Wait duration and cancellation remain properties of each caller.
    const captured = {};
    for (const key of ["detectedAi", "context", "expectedAccountId", "minimumServerTimeExclusive"]) {
      if (options[key] !== undefined) captured[key] = clone(options[key]);
    }
    const requestKey = verifier.canonicalJson({ mode, options: captured });
    const signal = options.signal, waitMs = options.waitMs;
    await init();
    if (authStorageUnconfirmed) throw error("AUTH_STATE_COMMIT_UNCONFIRMED");
    if (!state.credentials) throw error("AUTH_REQUIRED");
    if (!parallelAuthority?.createBootstrapScheduler) throw error("BOOTSTRAP_SCHEDULER_UNAVAILABLE");
    const family = captured.detectedAi?.family || null;
    if (family !== null && !LOCAL_AI[family]) throw bootstrapProfileFailure("REQUEST_FAMILY", [{ check: "REQUESTED_AI_KNOWN", passed: false }]);
    // Capture the acquisition fence only after legacy cache materialization.
    // Offline fallback must not invalidate its own ticket by creating the first grant.
    await materializeLegacyScopedGrant(family);
    if (authStorageUnconfirmed) throw error("AUTH_STATE_COMMIT_UNCONFIRMED");
    if (!state.credentials) throw error("AUTH_REQUIRED");
    const principal = { principalEpoch: epoch("principalEpoch"), deviceId: state.credentials.deviceId, sessionId: state.credentials.sessionId };
    const environmentKey = verifier.canonicalJson({ purpose: "bootstrap_acquisition_environment_v1",
      controlApiOrigin: config.controlApiOrigin, portalOrigin: config.portalOrigin, contractVersion: bootstrapContractVersion(),
      extensionVersion: config.extensionVersion, browser: currentBrowserIdentity(), trustBundleSha256: await trustBundleDigest() });
    // This acquisition key is not a signed grant scopeKey. The first response alone
    // can establish the control account ID; no fabricated account ID is persisted.
    const scopeKey = verifier.canonicalJson({ purpose: "bootstrap_acquisition_v1", principal, environmentKey, family });
    if (principal.principalEpoch !== epoch("principalEpoch") || principal.deviceId !== state.credentials?.deviceId ||
        principal.sessionId !== state.credentials?.sessionId) throw error("AUTH_GENERATION_CHANGED");
    bootstrapAcquisitionScopes.set(scopeKey, { ...principal, family, environmentKey });
    if (!bootstrapScheduler) bootstrapScheduler = parallelAuthority.createBootstrapScheduler({
      isFenceCurrent: bootstrapFenceCurrent,
      observeLateOutcome: async ({ ticket }) => {
        const attempt = bootstrapAttempts.get(ticket.acquisitionId);
        try { if (attempt?.lastHttpOutcome) await observeBootstrapLate(attempt, { ...attempt.lastHttpOutcome, late: true }); }
        finally { bootstrapAttempts.delete(ticket.acquisitionId); }
      },
      quarantine: quarantineBootstrap,
    });
    const result = await bootstrapScheduler.request({ fence: bootstrapFence(scopeKey), requestKey,
      ...(signal ? { signal } : {}),
      ...(waitMs === undefined ? {} : { waitMs }),
      run: lease => execute(captured, lease, principal) });
    bootstrapAttempts.delete(result.ticket.acquisitionId);
    return result.value;
  }
  function endpointFor(path) { return url(path); }
  function registeredTransport(failure, path) { return transportProvenance.get(failure) === endpointFor(path); }
  async function invalidateBootstrapFailure(attempt, failure, terminal = false) {
    if (!bootstrapAttemptCurrent(attempt)) return false;
    return invalidateKnown(attempt.context, failure, terminal);
  }
  async function bootstrapOnline(options, attempt) {
    await init();
    if (!state.credentials) throw error("AUTH_REQUIRED");
    await ensureAuthOwnership();
    if (!bootstrapAttemptCurrent(attempt)) throw error("AUTH_GENERATION_CHANGED");
    const requestedAi = options.detectedAi?.family || null;
    if (options.detectedAi && (!LOCAL_AI[requestedAi] || options.detectedAi.surface !== LOCAL_AI[requestedAi].surface || options.detectedAi.variant !== null)) {
      const failure = bootstrapProfileFailure("REQUEST_IDENTITY", [{ check: "REQUESTED_AI_KNOWN", passed: Boolean(LOCAL_AI[requestedAi]) }, { check: "REQUEST_SURFACE", passed: options.detectedAi.surface === LOCAL_AI[requestedAi]?.surface }, { check: "REQUEST_VARIANT", passed: options.detectedAi.variant === null }]); await invalidateBootstrapFailure(attempt, failure); throw failure;
    }
    if (!accessFresh()) {
      attempt.preflightRefresh = true;
      try { await refresh({ context: attempt.context }); }
      catch (failure) {
        attempt.preflightRefreshTransport = registeredTransport(failure, "/v1/auth/refresh");
        attempt.preflightRefresh = false;
        if (failure.status === 401 || failure.status === 403 || terminalAuthFailure(failure)) await invalidateBootstrapFailure(attempt, failure, true);
        throw failure;
      }
      attempt.preflightRefresh = false;
      if (!bootstrapAttemptCurrent(attempt)) throw error("AUTH_GENERATION_CHANGED");
    }
    let credentials = clone(state.credentials), authority = clone(state.authority), retried = false;
    while (true) {
      if (!bootstrapAttemptCurrent(attempt)) throw error("AUTH_GENERATION_CHANGED");
      let result;
      try { result = await requestBootstrap(credentials, authority, options.detectedAi, attempt); }
      catch (failure) {
        if (failure.status === 401 && !retried && bootstrapAttemptCurrent(attempt)) {
          retried = true; attempt.observedBootstrap401 = true;
          try { await refresh({ force: true, rejectedAccessToken: credentials.accessToken, context: attempt.context }); }
          catch (refreshFailure) {
            if (failure.status === 401 && bootstrapAttemptCurrent(attempt)) await invalidateBootstrapFailure(attempt, failure, true);
            throw failure;
          }
          if (!bootstrapAttemptCurrent(attempt)) throw error("AUTH_GENERATION_CHANGED");
          credentials = clone(state.credentials); authority = clone(state.authority); continue;
        }
        if (failure.status === 401) await invalidateBootstrapFailure(attempt, failure, true);
        else if (failure.status === 403 || (failure.code === "CONTROL_RESPONSE_TOO_LARGE" && failure.responseOk === true)) await invalidateBootstrapFailure(attempt, failure, false);
        throw failure;
      }
      if (!bootstrapAttemptCurrent(attempt)) throw error("AUTH_GENERATION_CHANGED");
      let verified;
      try {
        const verify = bootstrapContractVersion() === "control_plane_v3" ? verifier.verifyV3 : verifier.verifyV2;
        if (typeof verify !== "function") throw error("BOOTSTRAP_VERIFIER_UNAVAILABLE");
        verified = await verify(result.body, config.trustBundle);
      }
      catch (verificationFailure) { const failure = error(`BOOTSTRAP_${verificationFailure?.code || "VERIFICATION_FAILED"}`); await invalidateBootstrapFailure(attempt, failure, false); throw failure; }
      if (!bootstrapAttemptCurrent(attempt)) throw error("AUTH_GENERATION_CHANGED");
      if (!verified.ok) { const failure = error(`BOOTSTRAP_${verified.error}`); await invalidateBootstrapFailure(attempt, failure, false); throw failure; }
      const verifiedServerTimeMs = parsedMillis(verified.payload?.serverTime);
      if (options.minimumServerTimeExclusive !== undefined && (verifiedServerTimeMs === null || verifiedServerTimeMs <= options.minimumServerTimeExclusive))
        throw error("BOOTSTRAP_SERVER_TIME_NOT_ADVANCED");
      const currentDeny = verified.payload?.contractVersion === "control_plane_v3" && verified.payload?.accessBasis === "NONE";
      const privacyVariantMatches = attempt.privacyNeutral === true ? Boolean(verified.payload?.localClientAuthority) : !verified.payload?.localClientAuthority;
      const acceptedPayload = currentDeny ? verified.payload : attempt.privacyNeutral === true ? await materializeLocalAuthority(verified.payload, requestedAi).catch(() => null) : verified.payload;
      if (options.expectedAccountId && acceptedPayload?.account?.id !== options.expectedAccountId) {
        const failure = error("BOOTSTRAP_ACCOUNT_MISMATCH"); await invalidateBootstrapFailure(attempt, failure, false); throw failure;
      }
      const validationChecks = [];
      const validation = acceptedPayload ? currentDeny && privacyVariantMatches ? { workAllowed: false, requestedAi } : await validateBootstrapAuthority(verified.payload, requestedAi, attempt.privacyNeutral === true, validationChecks).catch(() => { bootstrapCheck(validationChecks, "VALIDATOR_COMPLETED", false); return null; }) : (bootstrapCheck(validationChecks, "LOCAL_MATERIALIZATION", false), null);
      if (!bootstrapAttemptCurrent(attempt)) throw error("AUTH_GENERATION_CHANGED");
      if (!validation) { const failure = bootstrapProfileFailure("SIGNED_AUTHORITY", validationChecks); await invalidateBootstrapFailure(attempt, failure, false); throw failure; }
      const cacheBinding = await expectedCacheBinding(acceptedPayload, validation.requestedAi);
      if (!bootstrapAttemptCurrent(attempt)) throw error("AUTH_GENERATION_CHANGED");
      const nextAuthority = { verified: true, privacyNeutral: attempt.privacyNeutral === true, workAllowed: validation.workAllowed, payload: acceptedPayload, envelope: verified.envelope, deviceId: credentials.deviceId, sessionId: credentials.sessionId, generation: attempt.context.generation, requestedAi: validation.requestedAi, cacheBinding };
      let committed;
      try {
        committed = await queueMutation(async () => {
          if (!bootstrapAttemptCurrent(attempt)) return false;
          const current = clone(state), signedServerTimeMs = verifiedServerTimeMs, previousClock = current.cacheClock;
          if (signedServerTimeMs === null) throw error("BOOTSTRAP_SERVER_TIME_INVALID");
          if (previousClock && signedServerTimeMs < previousClock.trustedServerTimeMs) throw error("BOOTSTRAP_SERVER_TIME_REGRESSION");
          const owner = clockOwner(credentials), baseTrusted = Math.max(previousClock?.trustedServerTimeMs || 0, signedServerTimeMs), baseEffective = Math.max(previousClock?.effectiveTimeMs || 0, baseTrusted);
          const candidateClock = { cacheVersion: "control_cache_clock_v1", owner, trustedServerTimeMs: baseTrusted, effectiveTimeMs: baseEffective };
          const effective = effectiveTime(candidateClock, verified.payload);
          if (currentDeny) {
            const denyExpiresAt = parsedMillis(acceptedPayload.expiresAt);
            if (denyExpiresAt === null || effective >= denyExpiresAt) throw error("BOOTSTRAP_EXPIRED_OR_INCOMPATIBLE");
          } else if (!authorityBaseValid(acceptedPayload, effective)) throw error("BOOTSTRAP_EXPIRED_OR_INCOMPATIBLE");
          // Preserve the current common denial for identified/neutral UNAVAILABLE.
          // Merely resolving a different AI no longer changes the common generation.
          const commonDeny = currentDeny || nextAuthority.workAllowed !== true;
          const generation = commonDeny ? current.generation + 1 : current.generation;
          const clock = { ...candidateClock, effectiveTimeMs: Math.max(candidateClock.effectiveTimeMs, effective) };
          const previousGrant = grantFor(nextAuthority.requestedAi);
          const grant = commonDeny ? null : await makeGrant({ ...nextAuthority, generation }, clock);
          if (!bootstrapAttemptCurrent(attempt)) return false;
          const grants = commonDeny ? {} : Object.fromEntries(Object.entries(current.grants || {})
            .filter(([, item]) => item.authority?.requestedAi !== nextAuthority.requestedAi));
          if (grant) grants[grant.scopeKey] = grant;
          const next = { ...current, generation, principalEpoch: epoch("principalEpoch"),
            accessEpoch: epoch("accessEpoch") + (commonDeny ? 1 : 0), grants, cacheClock: clock,
            authority: grant?.authority || { ...nextAuthority, generation }, lastError: null };
          attempt.lease?.beginSecurityCommit();
          if (commonDeny) state = next;
          await commit(next, commonDeny ? current.authority : previousGrant?.authority || null, "bootstrap_verified",
            grant ? { scopeKey: grant.scopeKey, requestedAi: nextAuthority.requestedAi } : null);
          attempt.lease?.finishSecurityCommit(bootstrapFence(attempt.lease.fence.scopeKey));
          attempt.context = { ...attempt.context, generation };
          attempt.committedAuthorityIdentity = cacheIdentity(next.authority, generation);
          return bootstrapAttemptCurrent(attempt);
        });
      } catch (failure) { await invalidateBootstrapFailure(attempt, failure, false); throw failure; }
      if (!committed) throw error("AUTH_GENERATION_CHANGED");
      if (attempt.policy !== true) runtimeLastCheckpointAllowed = nextAuthority.workAllowed === true;
      return clone(acceptedPayload);
    }
  }
  function cacheIdentity(authority, generation) { return authority ? verifier.canonicalJson({ generation, deviceId: authority.deviceId, sessionId: authority.sessionId, requestedAi: authority.requestedAi ?? null, accountId: authority.payload?.account?.id || null, envelope: authority.envelope, cacheBinding: authority.cacheBinding }) : null; }
  function policyCurrent(capture) { return bootstrapAttemptSequence === capture.sequence && isCurrent(capture.context) && validCredentials(state.credentials) && cacheIdentity(state.authority, state.generation) === capture.authorityIdentity; }
  function cacheFailure(code) { return error(code); }
  async function persistCacheDenial(next, capture) {
    if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
    state = next;
    try { await persist(next); }
    catch (_) {
      runtimeFloorNeedsPersistence = true;
      state = { ...state, authority: state.authority ? { ...state.authority, workAllowed: false } : null };
      runtimeLastCheckpointAllowed = false;
      try { await chrome.storage.local.remove(STORAGE_KEY); }
      catch (removeFailure) { const failure = error("AUTH_DENIAL_PERSISTENCE_FAILED"); failure.detail = safeError(removeFailure); state = { ...state, lastError: safeError(failure) }; throw failure; }
      throw error("AUTH_DENIAL_PERSISTENCE_FAILED");
    }
    runtimeFloorNeedsPersistence = false;
    if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
  }
  async function cachedBootstrapCheckpoint(capture, payload) {
    return queueMutation(async () => {
      if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
      const authority = state.authority, clock = state.cacheClock;
      if (!authority || !validCacheClock(clock, state.credentials, payload) || clock.owner.contractVersion !== expectedCacheContract(payload)) throw cacheFailure("CACHE_CLOCK_INVALID");
      const expiresAt = parsedMillis(payload.expiresAt), deadline = cacheAuthorityDeadline(payload);
      const legacyGraceRequired = payload?.contractVersion !== "control_plane_v3" || payload?.accessBasis === "BETA";
      if (expiresAt === null || deadline === null || legacyGraceRequired && deadline <= expiresAt) throw cacheFailure("CACHE_EXPIRY_INVALID");
      let effective;
      try { effective = effectiveTime(clock); } catch (_) { throw cacheFailure("CACHE_EFFECTIVE_TIME_INVALID"); }
      if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
      const floor = Math.max(clock.effectiveTimeMs, effective);
      if (!validMillis(floor)) throw cacheFailure("CACHE_EFFECTIVE_TIME_INVALID");
      const freshness = effective < deadline ? (effective < expiresAt ? "FRESH" : "STALE_BUT_OFFLINE_GRACE_ELIGIBLE") : null;
      const next = floor === clock.effectiveTimeMs && !runtimeFloorNeedsPersistence ? state : { ...state, cacheClock: { ...clock, effectiveTimeMs: floor } };
      if (next !== state) {
        state = next;
        try { await persist(next); }
        catch (_) {
          runtimeFloorNeedsPersistence = true; state = { ...state, authority: state.authority ? { ...state.authority, workAllowed: false } : null }; runtimeLastCheckpointAllowed = false;
          try { await chrome.storage.local.remove(STORAGE_KEY); }
          catch (removeFailure) { const denial = error("AUTH_DENIAL_PERSISTENCE_FAILED"); denial.detail = safeError(removeFailure); state = { ...state, lastError: safeError(denial) }; throw denial; }
          throw error("AUTH_DENIAL_PERSISTENCE_FAILED");
        }
        runtimeFloorNeedsPersistence = false;
        if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
      }
      if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
      if (!freshness) { await persistCacheDenial({ ...state, cacheClock: { ...state.cacheClock, effectiveTimeMs: floor }, authority: { ...authority, workAllowed: false } }, capture); throw cacheFailure("CACHE_EXPIRED"); }
      let completion;
      try { completion = effectiveTime(state.cacheClock); } catch (_) { throw cacheFailure("CACHE_EFFECTIVE_TIME_INVALID"); }
      if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
      if (completion >= deadline) {
        const denialFloor = Math.max(state.cacheClock.effectiveTimeMs, completion);
        await persistCacheDenial({ ...state, cacheClock: { ...state.cacheClock, effectiveTimeMs: denialFloor }, authority: { ...authority, workAllowed: false } }, capture);
        throw cacheFailure("CACHE_EXPIRED");
      }
      const resultFreshness = completion < expiresAt ? "FRESH" : "STALE_BUT_OFFLINE_GRACE_ELIGIBLE";
      if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
      runtimeLastCheckpointAllowed = false;
      return { source: "CACHE", freshness: resultFreshness, payload: clone(payload) };
    });
  }
  function subscriptionRefreshJitter(deviceId) {
    let hash = 2166136261;
    for (const char of String(deviceId || "")) {
      hash ^= char.charCodeAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0) % (SUBSCRIPTION_REFRESH_JITTER_MAX_MS + 1);
  }
  async function getSubscriptionRefreshPlan() {
    await init();
    if (bootstrapContractVersion() !== "control_plane_v3")
      return Object.freeze({ active: false, reason: "NEGOTIATION_DORMANT" });
    const authority = state.authority, payload = authority?.payload, credentials = state.credentials, clock = state.cacheClock;
    if (!authority || !credentials || !clock || payload?.contractVersion !== "control_plane_v3")
      return Object.freeze({ active: false, reason: "V3_AUTHORITY_MISSING" });
    if (payload.accessBasis === "NONE" || authority.workAllowed !== true)
      return Object.freeze({ active: false, reason: "V3_AUTHORITY_DENIED" });
    let effectiveTimeMs;
    try { effectiveTimeMs = effectiveTime(clock, payload); }
    catch (_) { return Object.freeze({ active: false, reason: "V3_AUTHORITY_INVALID" }); }
    const serverTimeMs = parsedMillis(payload.serverTime), expiresAt = parsedMillis(payload.expiresAt);
    if (serverTimeMs === null || expiresAt === null)
      return Object.freeze({ active: false, reason: "V3_AUTHORITY_INVALID" });
    const cadenceDue = serverTimeMs + SUBSCRIPTION_REFRESH_INTERVAL_MS - subscriptionRefreshJitter(credentials.deviceId);
    let effectiveDueAt = cadenceDue, reason = "CADENCE";
    if (payload.accessBasis === "COMMERCIAL") {
      const paidThrough = parsedMillis(payload.subscriptionAccess?.paidThrough);
      if (paidThrough !== null && paidThrough > serverTimeMs && paidThrough <= effectiveDueAt) {
        effectiveDueAt = paidThrough;
        reason = "PAID_THROUGH";
      } else if (payload.subscriptionAccess === null && expiresAt <= effectiveDueAt) {
        effectiveDueAt = expiresAt;
        reason = "TRIAL_EXPIRY";
      }
    } else if (payload.accessBasis === "BETA") {
      const legacyGrace = parsedMillis(payload.offlineGraceUntil);
      if (legacyGrace !== null && legacyGrace <= effectiveDueAt) {
        effectiveDueAt = legacyGrace;
        reason = "BETA_GRACE";
      }
    }
    if (!validMillis(effectiveDueAt))
      return Object.freeze({ active: false, reason: "V3_AUTHORITY_INVALID" });
    const dueAt = now() + Math.max(0, effectiveDueAt - effectiveTimeMs);
    if (!validMillis(dueAt))
      return Object.freeze({ active: false, reason: "V3_REFRESH_DUE_INVALID" });
    const identity = Object.freeze({
      accountId: payload.account.id,
      deviceId: credentials.deviceId,
      sessionId: credentials.sessionId,
      generation: state.generation,
      contractVersion: payload.contractVersion,
      configVersion: payload.configVersion,
      serverTime: payload.serverTime,
      paidThrough: payload.subscriptionAccess?.paidThrough || null,
    });
    return Object.freeze({ active: true, reason, dueAt, effectiveDueAt, identity });
  }
  async function runSubscriptionRefreshTask(expectedIdentity) {
    await init();
    const plan = await getSubscriptionRefreshPlan();
    if (!plan.active) return { status: "INACTIVE", reason: plan.reason };
    if (!expectedIdentity || verifier.canonicalJson(expectedIdentity) !== verifier.canonicalJson(plan.identity))
      return { status: "STALE" };
    const authority = state.authority, entryContext = contextForState();
    if (subscriptionRefreshFlight && ownerCurrent(subscriptionRefreshFlight) && subscriptionRefreshFlight.context && isCurrent(subscriptionRefreshFlight.context) && subscriptionRefreshFlight.identity === verifier.canonicalJson(plan.identity))
      return subscriptionRefreshFlight.promise;
    const requestedAi = authority.requestedAi;
    const detectedAi = requestedAi && LOCAL_AI[requestedAi] ? { family: requestedAi, surface: LOCAL_AI[requestedAi].surface, variant: null } : null;
    const owner = { context: entryContext, identity: verifier.canonicalJson(plan.identity), promise: null };
    owner.promise = (async () => {
      const previousServerTimeMs = parsedMillis(authority.payload.serverTime);
      if (previousServerTimeMs === null) throw error("SUBSCRIPTION_AUTHORITY_TIME_INVALID");
      const payload = await bootstrap({
        context: entryContext,
        expectedAccountId: authority.payload.account.id,
        minimumServerTimeExclusive: previousServerTimeMs,
        ...(detectedAi ? { detectedAi } : {}),
      });
      const denied = payload?.contractVersion === "control_plane_v3" && payload?.accessBasis === "NONE";
      return {
        status: denied ? "DENY" : "REFRESHED",
        contractVersion: payload?.contractVersion || null,
        configVersion: payload?.configVersion || null,
        serverTime: payload?.serverTime || null,
      };
    })().finally(() => { if (subscriptionRefreshFlight === owner) subscriptionRefreshFlight = null; });
    subscriptionRefreshFlight = owner;
    return owner.promise;
  }

  async function bootstrapWithPolicyActive(options = {}, lease = null, principal = null) {
    if (!options || typeof options !== "object" || Array.isArray(options) || options.context !== undefined && !validContext(options.context)) throw error("AUTH_CONTEXT_INVALID");
    const sequence = ++bootstrapAttemptSequence, attempt = { sequence, context: null, observedBootstrap401: false, preflightRefresh: false, policy: true, lease, principal };
    if (lease) bootstrapAttempts.set(lease.acquisitionId, attempt);
    try {
      await init(); if (!state.credentials) throw error("AUTH_REQUIRED"); await ensureAuthOwnership();
      attempt.context = options.context ? clone(options.context) : contextForState();
      if (!isCurrent(attempt.context)) throw error("AUTH_GENERATION_CHANGED");
      const requestedAi = options.detectedAi?.family || null;
      const capturedAuthority = clone(state.authority), capturedClock = clone(state.cacheClock);
      Object.assign(attempt, { requestedAi, authority: capturedAuthority, clock: capturedClock, authorityIdentity: cacheIdentity(capturedAuthority, attempt.context.generation) });
      const payload = await bootstrapOnline(options, attempt);
      if (!bootstrapAttemptCurrent(attempt) || !attempt.committedAuthorityIdentity || cacheIdentity(state.authority, state.generation) !== attempt.committedAuthorityIdentity) throw error("AUTH_GENERATION_CHANGED");
      return { source: "ONLINE", freshness: "FRESH", payload: clone(payload) };
    } catch (onlineFailure) {
      const capture = typeof attempt.authorityIdentity === "string" || attempt.authorityIdentity === null ? attempt : null;
      const eligible = capture && !attempt.observedBootstrap401 && (registeredTransport(onlineFailure, "/v1/bootstrap") || (attempt.preflightRefreshTransport === true && registeredTransport(onlineFailure, "/v1/auth/refresh")) || (httpErrorProvenance.get(onlineFailure) === endpointFor("/v1/bootstrap") && onlineFailure.status === 503 && onlineFailure.code === "BOOTSTRAP_UNAVAILABLE"));
      if (eligible && capture.requestedAi && bootstrapAttemptCurrent(attempt)) {
        const cached = await scopedCacheCheckpoint(capture.requestedAi, attempt.lease);
        // A confirmed expiry rejects the acquisition under its revocation receipt;
        // it must never acknowledge a newer fence as an allowed result.
        if (cached.changed) throw cacheFailure("CACHE_EXPIRED");
        if (cached.invalid) throw cacheFailure("CACHE_VERIFICATION_FAILED");
        if (!bootstrapAttemptCurrent(attempt)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
        if (cached.grant) {
          const payload = cached.grant.authority.payload;
          const effective = effectiveTime(cached.grant.cacheClock, payload);
          const expiresAt = parsedMillis(payload.expiresAt), deadline = cacheAuthorityDeadline(payload);
          if (expiresAt === null || deadline === null || effective >= deadline) throw cacheFailure("CACHE_EXPIRED");
          if (!cached.allowed) throw onlineFailure;
          return { source: "CACHE", freshness: effective < expiresAt ? "FRESH" : "STALE_BUT_OFFLINE_GRACE_ELIGIBLE", payload: clone(payload) };
        }
        // An already expired legacy authority has no operational grant. Preserve
        // the existing verified legacy-cache diagnostics below, never invent a grant.
      }
      if (!eligible || !policyCurrent(capture)) throw onlineFailure;
      const authority = capture.authority, requestedAi = capture.requestedAi;
      if (!authority || authority.requestedAi !== requestedAi || !capture.clock || !validCacheBinding(authority.cacheBinding)) throw onlineFailure;
      let verified;
      try {
        verified = await verifyCachedEnvelope(authority.envelope);
        if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
        if (!verified.ok) throw cacheFailure("CACHE_VERIFICATION_FAILED");
        const verifiedPayload = verified.payload.localClientAuthority ? await materializeLocalAuthority(verified.payload, requestedAi) : verified.payload;
        if (!verifiedPayload || verifier.canonicalJson(verifiedPayload) !== verifier.canonicalJson(authority.payload)) throw cacheFailure("CACHE_VERIFICATION_FAILED");
        const validation = await validateAccountProfile(verifiedPayload, requestedAi, true);
        if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
        if (!validation || validation.requestedAi !== requestedAi) throw cacheFailure("CACHE_CONTEXT_MISMATCH");
        const expected = await expectedCacheBinding(verifiedPayload, validation.requestedAi);
        if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
        if (verifier.canonicalJson(authority.cacheBinding) !== verifier.canonicalJson(expected) || !validCacheClock(capture.clock, state.credentials, verified.payload) || capture.clock.owner.contractVersion !== expectedCacheContract(verified.payload)) throw cacheFailure("CACHE_CONTEXT_MISMATCH");
        const currentAuthority = state.authority;
        if (!currentAuthority || cacheIdentity(currentAuthority, state.generation) !== capture.authorityIdentity) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
        const result = await cachedBootstrapCheckpoint(capture, verifiedPayload);
        if (!policyCurrent(capture)) throw cacheFailure("CACHE_ACQUISITION_OBSOLETED");
        return result;
      } catch (cacheError) {
        if (cacheError?.code === "AUTH_DENIAL_PERSISTENCE_FAILED" || cacheError?.code === "CACHE_ACQUISITION_OBSOLETED" || cacheError?.code === "CACHE_CLOCK_INVALID" || cacheError?.code === "CACHE_EFFECTIVE_TIME_INVALID" || cacheError?.code === "CACHE_CONTEXT_MISMATCH" || cacheError?.code === "CACHE_VERIFICATION_FAILED" || cacheError?.code === "CACHE_EXPIRY_INVALID" || cacheError?.code === "CACHE_EXPIRED") throw cacheError;
        throw onlineFailure;
      }
    }
  }
  async function bootstrapActive(options = {}, lease = null, principal = null) {
    if (!options || typeof options !== "object" || Array.isArray(options) || options.context !== undefined && !validContext(options.context) || options.expectedAccountId !== undefined && !UUID.test(options.expectedAccountId) || options.minimumServerTimeExclusive !== undefined && !validMillis(options.minimumServerTimeExclusive)) throw error("AUTH_CONTEXT_INVALID");
    const sequence = ++bootstrapAttemptSequence, attempt = { sequence, context: options.context ? clone(options.context) : null, observedBootstrap401: false, preflightRefresh: false, lease, principal, requestedAi: options.detectedAi?.family || null };
    if (lease) bootstrapAttempts.set(lease.acquisitionId, attempt);
    await init(); if (!state.credentials) throw error("AUTH_REQUIRED"); await ensureAuthOwnership(); if (!attempt.context) attempt.context = contextForState(); if (!bootstrapAttemptCurrent(attempt)) throw error("AUTH_GENERATION_CHANGED");
    return bootstrapOnline(options, attempt);
  }
  async function bootstrapWithPolicy(options = {}) {
    if (!options || typeof options !== "object" || Array.isArray(options)) throw error("AUTH_CONTEXT_INVALID");
    return scheduleBootstrap(options, "POLICY", (captured, lease, principal) => bootstrapWithPolicyActive(captured, lease, principal));
  }
  async function bootstrap(options = {}) {
    if (!options || typeof options !== "object" || Array.isArray(options)) throw error("AUTH_CONTEXT_INVALID");
    const payload = await scheduleBootstrap(options, "RAW", (captured, lease, principal) => bootstrapActive(captured, lease, principal));
    // Reuse initiated configuration synchronization; no tab polling, timer or
    // marketplace hook. The per-AI cache coalesces pulls and checks infrequently.
    if (payload?.ai?.status === "RESOLVED" && LOCAL_AI[payload.ai.detected?.family])
      void getPromptTree(payload.ai.detected.family);
    return payload;
  }
  // Privileged release diagnostics: retain the installed client's own storage and
  // refresh transaction. This never activates a device or grants Work authority.
  async function acquireBootstrapPreflight(input) {
    let body = input?.request;
    if (!exactKeys(input, ["expectedAccountId", "request"]) || !UUID.test(input.expectedAccountId) ||
        !exactKeys(body, ["contractVersion", "extensionVersion", "browser", "deviceId", "lastConfigVersion"]) ||
        !exactKeys(body.browser, ["family", "version"]) || !UUID.test(body.deviceId) || body.lastConfigVersion !== null ||
        body.contractVersion !== "control_plane_v2" || body.contractVersion !== config.contractVersion ||
        body.extensionVersion !== config.extensionVersion || body.browser.family !== browserFamily() ||
        body.browser.version !== browserVersion()) throw error("PREFLIGHT_CONTEXT_MISMATCH");
    body = clone(body);
    const expectedAccountId = input.expectedAccountId;
    // restore() resumes a pending activation. A release probe must never do that.
    const saved = initialized ? state : (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
    if (!saved?.credentials || saved.pending) throw error("PREFLIGHT_EXISTING_SESSION_REQUIRED");
    if (saved.credentials.deviceId !== body.deviceId) throw error("PREFLIGHT_CONTEXT_MISMATCH");
    await init();
    if (!state.credentials || state.pending || state.credentials.deviceId !== body.deviceId) throw error("PREFLIGHT_EXISTING_SESSION_REQUIRED");
    const context = contextForState();
    const result = await authenticatedRequest("/v1/bootstrap", { method: "POST", body: clone(body) }, context);
    if (!isCurrent(context)) throw error("AUTH_GENERATION_CHANGED");
    const verified = await verifier.verifyV2(result.body, config.trustBundle);
    if (!isCurrent(context)) throw error("AUTH_GENERATION_CHANGED");
    if (!verified?.ok) throw error("PREFLIGHT_SIGNATURE_INVALID");
    const payload = verified.payload;
    if (payload?.contractVersion !== body.contractVersion || payload?.snapshotVersion !== "bootstrap_snapshot_v2" ||
        payload?.account?.id !== expectedAccountId || payload.account.status !== "ACTIVE" ||
        payload?.ai?.status !== "UNCONFIGURED") throw error("PREFLIGHT_SIGNED_CONTEXT_MISMATCH");
    const serverTime = parsedMillis(payload.serverTime), expiresAt = parsedMillis(payload.expiresAt);
    if (serverTime === null || expiresAt === null || Math.max(now(), serverTime) >= expiresAt) throw error("PREFLIGHT_SIGNATURE_EXPIRED");
    return { envelope: clone(verified.envelope), authenticatedContext: {
      accountId: payload.account.id, deviceId: context.deviceId,
      browserFamily: browserFamily(), browserVersion: browserVersion(), controlApiOrigin: config.controlApiOrigin,
    } };
  }
  async function ensureForIdentity(identity) {
    await init(); if (authStorageUnconfirmed) throw error("AUTH_STATE_COMMIT_UNCONFIRMED");
    if (!state.credentials) throw error("AUTH_REQUIRED");
    const requested = requestedFamily(identity); if (!requested) throw error("WORK_UNSUPPORTED_AI");
    const decision = await scopedCacheCheckpoint(requested), current = grantFor(requested)?.authority;
    if (decision.allowed && decision.identity === authorityDecisionIdentity(current) && current?.generation === state.generation)
      return clone(current.payload);
    return bootstrap({ detectedAi: { family: requested, surface: LOCAL_AI[requested].surface, variant: null } });
  }
  async function discardRestoredAuthority(failure) {
    const context = contextForState();
    let changed = false, generation = state.generation;
    await queueMutation(async () => {
      if (!isCurrent(context)) return;
      const previous = state.authority;
      const next = { ...state, generation: state.generation + 1, accessEpoch: epoch("accessEpoch") + 1,
        grants: {}, authority: null, lastError: safeError(failure) };
      state = next;
      try { await persist(next); } catch (_) { try { await chrome.storage.local.remove(STORAGE_KEY); } catch (removeFailure) { state = { ...state, lastError: safeError(Object.assign(error("AUTH_DENIAL_PERSISTENCE_FAILED"), { detail: safeError(removeFailure) })) }; } }
      changed = Boolean(previous); generation = state.generation;
    });
    if (changed) void notifyAuthorityChange(null, "authority_invalid", generation);
  }
  async function discardOrphanCredentialState() {
    const next = { ...state, rotation: null, authority: null, grants: {}, cacheClock: null };
    state = next;
    try { await persist(next); } catch (_) { /* signed-out memory remains safe; pending state is not discarded */ }
  }
  function storedAuthShapeError(saved) {
    if (!saved || typeof saved !== "object" || Array.isArray(saved)) return "AUTH_STATE_SCHEMA_INVALID";
    if (saved.authStateSchema !== undefined && saved.authStateSchema !== 2) return "AUTH_STATE_SCHEMA_UNSUPPORTED";
    for (const name of ["generation", "principalEpoch", "accessEpoch"]) {
      if (saved[name] === undefined && name !== "generation" && saved.authStateSchema === undefined) continue;
      if (!Number.isSafeInteger(saved[name]) || saved[name] < 0) return "AUTH_EPOCH_INVALID";
    }
    if (saved.grants === undefined && saved.authStateSchema === 2) return "AUTH_GRANT_HISTORY_INVALID";
    if (saved.grants !== undefined) {
      if (!saved.grants || typeof saved.grants !== "object" || Array.isArray(saved.grants)) return "AUTH_GRANT_HISTORY_INVALID";
      for (const [scopeKey, grant] of Object.entries(saved.grants)) {
        if (!grant || typeof grant !== "object" || grant.schemaVersion !== 1 || grant.scopeKey !== scopeKey ||
          !Number.isSafeInteger(grant.grantEpoch) || grant.grantEpoch < 1 ||
          !grant.authority || grant.authority.generation !== saved.generation ||
          grant.authority.deviceId !== saved.credentials?.deviceId || grant.authority.sessionId !== saved.credentials?.sessionId ||
          grant.authority.payload?.account?.id !== saved.authority?.payload?.account?.id ||
          grant.principalEpoch !== (saved.principalEpoch ?? saved.generation) || grant.accessEpoch !== (saved.accessEpoch ?? 0))
          return "AUTH_GRANT_HISTORY_INVALID";
      }
    }
    if (saved.authMigration !== undefined) {
      const migration = saved.authMigration;
      if (!migration || migration.sourceSchema !== 1 || migration.targetSchema !== 2 || migration.phase !== "COMMITTED" ||
        !/^[a-f0-9]{64}$/.test(migration.sourceDigest || "") || migration.migrationId !== "auth-v2:" + migration.sourceDigest)
        return "AUTH_MIGRATION_REVALIDATION_REQUIRED";
    }
    return null;
  }
  async function legacyAuthMigration(saved) {
    const bytes = new TextEncoder().encode(verifier.canonicalJson(saved));
    const sourceDigest = [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map(x => x.toString(16).padStart(2, "0")).join("");
    return { sourceSchema: 1, targetSchema: 2, migrationId: "auth-v2:" + sourceDigest, sourceDigest, phase: "COMMITTED" };
  }
  async function restoreOnce() {
    await chrome.storage.local.setAccessLevel?.({ accessLevel: "TRUSTED_CONTEXTS" });
    const result = await chrome.storage.local.get(STORAGE_KEY), saved = result[STORAGE_KEY];
    if (saved !== undefined && saved !== null) {
      const schemaFailure = storedAuthShapeError(saved);
      if (schemaFailure) {
        // Preserve the unrecognized record for compatible recovery. No fallback
        // to its old authority or rewrite of generations/history is permitted.
        authStorageUnconfirmed = true;
        state = { ...state, lastError: { code: schemaFailure } };
        initialized = true;
        return publicStatus({ allowed: false, persistenceFailure: true });
      }
      state = { ...state, ...clone(saved), principalEpoch: saved.principalEpoch ?? saved.generation,
        accessEpoch: saved.accessEpoch ?? 0, grants: saved.grants ?? {} };
      if (saved.authStateSchema === undefined) state.authMigration = await legacyAuthMigration(saved);
    }
    if (state.credentials !== null && state.credentials !== undefined && !validCredentials(state.credentials)) await invalidateKnown(contextForState(), error("STORED_CREDENTIALS_INVALID"), true);
    else if ((state.credentials === null || state.credentials === undefined) && saved && (state.rotation || state.authority || state.cacheClock)) await discardOrphanCredentialState();
    if (state.credentials && !validCacheClock(state.cacheClock, state.credentials)) await invalidateKnown(contextForState(), error("STORED_CACHE_CLOCK_INVALID"), true);
    if (state.credentials && state.authority) {
      const savedAuthority = state.authority, binding = savedAuthority.cacheBinding, clock = state.cacheClock;
      let authorityFailure = null;
      if (!validCacheBinding(binding)) authorityFailure = error("STORED_CACHE_BINDING_INVALID");
      else if (savedAuthority.deviceId !== state.credentials.deviceId || savedAuthority.sessionId !== state.credentials.sessionId) await invalidateKnown(contextForState(), error("AUTHORITY_CREDENTIAL_MISMATCH"), true);
      else if (savedAuthority.generation !== state.generation) await invalidateKnown(contextForState(), error("STORED_AUTHORITY_GENERATION_MISMATCH"), true);
      else if (binding.controlApiOrigin !== config.controlApiOrigin || binding.portalOrigin !== config.portalOrigin) authorityFailure = error("STORED_CACHE_CONTEXT_MISMATCH");
      else {
        try {
          const verified = await verifyCachedEnvelope(savedAuthority.envelope); if (!verified.ok) throw error(`STORED_AUTHORITY_${verified.error}`);
          const storedDeny = verified.payload?.contractVersion === "control_plane_v3" && verified.payload?.accessBasis === "NONE";
          const verifiedPayload = storedDeny ? verified.payload : verified.payload.localClientAuthority ? await materializeLocalAuthority(verified.payload, savedAuthority.requestedAi) : verified.payload;
          if (!verifiedPayload || verifier.canonicalJson(verifiedPayload) !== verifier.canonicalJson(savedAuthority.payload)) throw error("STORED_AUTHORITY_PAYLOAD_MISMATCH");
          const allowed = storedDeny ? { workAllowed: false, requestedAi: savedAuthority.requestedAi ?? null } : await validateAccountProfile(verifiedPayload, savedAuthority.requestedAi, false).catch(() => null); if (!allowed) throw error("STORED_AUTHORITY_POLICY_MISMATCH");
          if (!validCacheClock(clock, state.credentials, verified.payload) || verified.payload.contractVersion === "control_plane_v3" && clock.owner.contractVersion !== "control_plane_v3") throw error("STORED_CACHE_CLOCK_INCONSISTENT");
          const expected = await expectedCacheBinding(verifiedPayload, allowed.requestedAi);
          if (verifier.canonicalJson(binding) !== verifier.canonicalJson(expected)) throw error("STORED_CACHE_CONTEXT_MISMATCH");
          if (!storedDeny && !await validateAccountProfile(verifiedPayload, savedAuthority.requestedAi, true).catch(() => null)) throw error("STORED_AUTHORITY_ENVIRONMENT_MISMATCH");
          state.authority = { ...savedAuthority, privacyNeutral: Boolean(verified.payload.localClientAuthority), payload: verifiedPayload, requestedAi: allowed.requestedAi, workAllowed: savedAuthority.workAllowed === true && allowed.workAllowed === true };
        } catch (failure) { authorityFailure = failure; }
      }
      if (authorityFailure) {
        if (authorityFailure.code === "STORED_CACHE_CLOCK_INCONSISTENT") await invalidateKnown(contextForState(), authorityFailure, true);
        else if (state.credentials) await discardRestoredAuthority(authorityFailure);
      }
    }
    if (state.pending && !validRestoredPending(state.pending)) await invalidateKnown(contextForState(), error("ACTIVATION_CONTEXT_MISMATCH"), true);
    try { await transferVault?.prune(now()); } catch (_) { /* transfer actions fail closed on vault access; auth restore remains independent */ }
    const restoredDecision = state.authority && state.credentials ? await cacheAuthorizationCheckpoint() : { allowed: false };
    // The auth migration is one existing storage-key replacement, followed by
    // exact readback; there is no cross-key staging window or renewed TTL.
    if (saved && saved.authStateSchema === undefined && !authStorageUnconfirmed) await persist(state);
    initialized = true; if (pendingLive(state.pending)) void ensurePolling(); return publicStatus(restoredDecision);
  }
  function init() { if (initialized) { void retryPendingMetadataForget(); return Promise.resolve(publicStatus()); } if (!initFlight) initFlight = restoreOnce().finally(() => { initFlight = null; }); return initFlight.then(status => { void retryPendingMetadataForget(); return status; }); }
  async function retryPendingMetadataForget() { try { const stored = await chrome.storage.local.get(METADATA_CLEAR_KEY); const marker = stored?.[METADATA_CLEAR_KEY]; if (marker?.version === "pending_client_metadata_clear_v1" && marker.deviceId === state.credentials?.deviceId) void scheduleMetadataForget(); } catch (_) {} }
  async function localReset() { await init(); await queueMutation(async () => {
    activationFlight = null; pollingFlight = null; refreshFlight = null; subscriptionRefreshFlight = null;
    const previous = state.authority, next = { generation: state.generation + 1, principalEpoch: epoch("principalEpoch") + 1, accessEpoch: epoch("accessEpoch") + 1, grants: {}, credentials: null, pending: null, rotation: null, authority: null, cacheClock: null, lastError: null };
    state = next; resetRuntimeClock();
    // Retire every old-principal waiter before another principal can acquire.
    // Disposing preserves quarantine if a security write was not confirmed.
    bootstrapScheduler?.dispose("AUTH_GENERATION_CHANGED");
    bootstrapScheduler = null;
    let cleanupFailure = null;
    try { await clearTransferRecipientVault(); } catch (failure) { cleanupFailure = failure; }
    await commit({ ...next, lastError: cleanupFailure ? safeError(cleanupFailure) : null }, previous, "local_reset");
    if (cleanupFailure) throw cleanupFailure;
  }); return publicStatus(); }
  async function cancelActivation() { await init(); await queueMutation(async () => { activationFlight = null; pollingFlight = null; await commit({ ...state, generation: state.generation + 1, pending: null, lastError: null }, state.authority, "activation_cancelled"); }); return publicStatus(); }
  function validSyncReadEntityId(value) {
    if (typeof value !== "string") return false;
    if (/^conversation:[a-f0-9]{64}$/.test(value)) return true;
    if (!/^store:.{1,122}$/s.test(value)) return false;
    return [...value.slice("store:".length)].every(character => {
      const code = character.charCodeAt(0);
      return code > 0x1f && code !== 0x7f;
    });
  }
  async function synchronizeMetadata(body) {
    await init(); if (!state.credentials) throw error("AUTH_REQUIRED"); await ensureAuthOwnership();
    const entries = body?.entries, readEntityIds = body?.readEntityIds ?? [];
    if (!body || body.syncVersion !== "seller_agents_sync_v1" || !Array.isArray(entries) || entries.length > 32 ||
      !Array.isArray(readEntityIds) || readEntityIds.length > 32 || entries.length + readEntityIds.length < 1 ||
      entries.length + readEntityIds.length > 32 || new Set(readEntityIds).size !== readEntityIds.length ||
      readEntityIds.some(value => !validSyncReadEntityId(value))) throw error("SYNC_REQUEST_INVALID");
    return (await authenticatedRequest("/v1/sync", { method: "POST", body: { ...body, installationId: state.credentials.deviceId } })).body;
  }
  async function transferAuth() {
    await init();
    if (!state.credentials || !state.authority?.payload?.account?.id) throw error("AUTH_REQUIRED");
    await ensureAuthOwnership();
    const context = contextForState();
    return { credentials: clone(state.credentials), accountId: state.authority.payload.account.id, sessionId: state.credentials.sessionId, context };
  }
  // A transfer may cross crypto/storage awaits. Its original account and auth
  // generation remain authoritative even after reset and re-login to that account.
  function assertCredentialTransferContext(context) {
    if (!validContext(context) || !context.accountId || !context.deviceId || !context.sessionId ||
        !isCurrent(context) || state.authority?.payload?.account?.id !== context.accountId ||
        !validAuthOwnership()) throw error("AUTH_GENERATION_CHANGED");
    return true;
  }
  // Backup authority is pinned once before crypto and remains synchronous at
  // the catalog write barrier, including logout/re-login to the same account.
  function assertBackupContext(context) {
    return assertCredentialTransferContext(context);
  }
  async function captureBackupContext() {
    await init();
    const accountId = state.authority?.payload?.account?.id;
    if (!state.credentials || !accountId) throw error("AUTH_REQUIRED");
    const context = Object.freeze(contextForState({ accountId }));
    assertBackupContext(context);
    return context;
  }
  function transferRecordMatches(record, auth) {
    return Boolean(record && record.accountId === auth.accountId && record.recipientDeviceId === auth.credentials.deviceId && record.sessionId === auth.sessionId);
  }
  function transferBodyFromRecord(record) {
    return { requestId: record.requestId, recipientDeviceId: record.recipientDeviceId, recipientPublicKeySpki: record.publicKeySpki, sourceDeviceId: record.sourceDeviceId || null, selectedStores: record.selectedStoreIds.map(storeId => ({ storeId })), consent: true, expiresInSeconds: record.expiresInSeconds };
  }
  function assertTransferRequestMatches(record, result) {
    const stores = Array.isArray(result?.selectedStores) ? result.selectedStores.map(item => item?.storeId) : [];
    if (!result || result.requestId !== record.requestId || result.accountId !== record.accountId || result.recipientDeviceId !== record.recipientDeviceId || result.recipientPublicKeySpki !== record.publicKeySpki || (record.sourceDeviceId && result.sourceDeviceId !== record.sourceDeviceId) || verifier.canonicalJson(stores) !== verifier.canonicalJson(record.selectedStoreIds) || !Number.isFinite(Date.parse(result.expiresAt))) throw error("TRANSFER_REQUEST_MISMATCH");
    return result;
  }
  function safeTransferResult(input) {
    if (!input || input.importState !== "IMPORTED" || typeof input.requestId !== "string" || !Array.isArray(input.results)) throw error("TRANSFER_RESULT_INVALID");
    return { requestId: input.requestId, importState: "IMPORTED", results: input.results.map(item => ({ storeId: typeof item?.storeId === "string" ? item.storeId : null, kind: typeof item?.kind === "string" ? item.kind : null, code: typeof item?.code === "string" ? item.code : null, store: item?.store ? { id: String(item.store.id || ""), marketplace: String(item.store.marketplace || ""), credentialRevision: String(item.store.credentialRevision || "") } : null })) };
  }
  function publicTransferRecord(record) {
    return clone({ requestId: record.requestId, sourceDeviceId: record.sourceDeviceId || null, phase: record.phase, expiresAt: record.expiresAt, packetId: record.packetId || null, result: record.result || null });
  }
  async function requireTransferRecord(requestId, auth = null) {
    const identity = auth || await transferAuth(), record = await transferVault.get(requestId);
    if (!record) throw error("TRANSFER_KEY_MISSING");
    if (!transferRecordMatches(record, identity)) throw error("TRANSFER_ACCOUNT_MISMATCH");
    return { auth: identity, record };
  }
  async function reconcilePreparedCredentialTransfer(record, auth) {
    if (record.phase !== "PREPARED") return record;
    const body = transferBodyFromRecord(record), options = { method: "POST", body };
    let response;
    try { response = await authenticatedRequest("/v1/credential-transfers", options, auth.context); }
    catch (failure) {
      if (failure?.status) throw failure;
      response = await authenticatedRequest("/v1/credential-transfers", options, auth.context);
    }
    const result = assertTransferRequestMatches(record, response.body);
    const currentAuth = await transferAuth();
    if (!transferRecordMatches(record, currentAuth)) throw error("TRANSFER_ACCOUNT_MISMATCH");
    const active = await transferVault.update(record.requestId, current => ({ ...current, phase: "ACTIVE", sourceDeviceId: result.sourceDeviceId || current.sourceDeviceId || null, expiresAt: result.expiresAt }));
    return { record: active, request: clone(result) };
  }
  async function createCredentialTransfer(input = {}) {
    const auth = await transferAuth();
    if (input.consent !== true) throw error("TRANSFER_CONSENT_REQUIRED");
    if (!transferVault) throw error("TRANSFER_VAULT_UNAVAILABLE");
    const keys = await SellerAgentsCredentialTransferCrypto.generateRecipientKeyPair(), requestId = input.requestId || crypto.randomUUID();
    const selectedStoreIds = (input.selectedStoreIds || []).map(value => String(value).trim());
    const requestedExpiry = input.expiresInSeconds === undefined ? 300 : Number(input.expiresInSeconds);
    if (selectedStoreIds.length > 16 || selectedStoreIds.some(value => !value || value.length > 128) || !Number.isInteger(requestedExpiry)) throw error("TRANSFER_REQUEST_INVALID");
    const expiresInSeconds = Math.min(900, Math.max(60, requestedExpiry));
    const prepared = { vaultVersion: transferVault.VERSION, requestId, accountId: auth.accountId, recipientDeviceId: auth.credentials.deviceId, sessionId: auth.sessionId, sourceDeviceId: input.sourceDeviceId || null, selectedStoreIds, publicKeySpki: keys.publicKeySpki, privateKey: keys.privateKey, expiresInSeconds, expiresAt: new Date(now() + expiresInSeconds * 1000).toISOString(), phase: "PREPARED", packetId: null, result: null };
    try { await transferVault.put(prepared); } catch (failure) { throw error("TRANSFER_VAULT_PERSIST_FAILED", safeError(failure)); }
    const reconciled = await reconcilePreparedCredentialTransfer(prepared, auth);
    return clone(reconciled.request);
  }
  async function listCredentialTransferRecipients() {
    const auth = await transferAuth();
    if (!transferVault) throw error("TRANSFER_VAULT_UNAVAILABLE");
    const rows = [];
    for (const stored of await transferVault.list()) {
      if (!transferRecordMatches(stored, auth)) { await transferVault.remove(stored.requestId).catch(() => null); continue; }
      let record = stored;
      if (record.phase === "PREPARED") {
        try { record = (await reconcilePreparedCredentialTransfer(record, auth)).record; }
        catch (failure) { if (failure?.code === "TRANSFER_EXPIRED" || failure?.code === "TRANSFER_REPLAY" || failure?.code === "TRANSFER_ACCOUNT_MISMATCH") await transferVault.remove(record.requestId).catch(() => null); else rows.push(publicTransferRecord(record)); continue; }
      }
      rows.push(publicTransferRecord(record));
    }
    return rows;
  }
  async function listCredentialTransfers() { const auth = await transferAuth(); return clone((await authenticatedRequest("/v1/credential-transfers/pending/source", {}, auth.context)).body); }
  async function readCredentialTransfer(requestId) { const auth = await transferAuth(); return clone((await authenticatedRequest(`/v1/credential-transfers/${encodeURIComponent(requestId)}`, {}, auth.context)).body); }
  async function markCredentialTransferSourceSeen(requestId) { const auth = await transferAuth(); return clone((await authenticatedRequest(`/v1/credential-transfers/${encodeURIComponent(requestId)}/source-seen`, { method: "POST" }, auth.context)).body); }
  async function submitCredentialTransferPacket(input) { const auth = await transferAuth(); return clone((await authenticatedRequest(`/v1/credential-transfers/${encodeURIComponent(input.requestId)}/packet`, { method: "POST", body: { requestId: input.requestId, packetId: input.packetId, envelope: input.envelope } }, auth.context)).body); }
  async function receiveCredentialTransfer(requestId, sourceDeviceId) {
    return transferSingleFlight(requestId, async () => {
      const { auth, record } = await requireTransferRecord(requestId);
      const importContext = { ...auth.context, accountId: auth.accountId };
      assertCredentialTransferContext(importContext);
      if (record.phase === "ACKED_RESULT") return { ackedResult: true, result: clone(record.result), importContext };
      if (record.phase === "IMPORTED_PENDING_ACK") return { pendingAck: true, packet: { packetId: record.packetId }, result: clone(record.result), importContext };
      if (!record.privateKey) throw error("TRANSFER_KEY_MISSING");
      const packet = (await authenticatedRequest(`/v1/credential-transfers/${encodeURIComponent(requestId)}/packet`, {}, auth.context)).body;
      if (!packet?.packetId || packet.requestId !== requestId) throw error("TRANSFER_PACKET_INVALID");
      const current = await transferVault.update(requestId, value => ({ ...value, phase: "RECEIVING", sourceDeviceId: sourceDeviceId || value.sourceDeviceId || null, packetId: packet.packetId }));
      if (!transferRecordMatches(current, await transferAuth())) throw error("TRANSFER_ACCOUNT_MISMATCH");
      const payload = await SellerAgentsCredentialTransferCrypto.decrypt({ envelope: packet.envelope, privateKey: current.privateKey, accountId: auth.accountId, requestId, sourceDeviceId, recipientDeviceId: auth.credentials.deviceId, packetId: packet.packetId });
      assertCredentialTransferContext(importContext);
      return { packet, payload, importContext };
    });
  }
  async function recordCredentialTransferImported(input) {
    const { record } = await requireTransferRecord(input?.requestId);
    if (input.importContext) assertCredentialTransferContext(input.importContext);
    if (!input?.packetId || record.packetId !== input.packetId) throw error("TRANSFER_PACKET_CHANGED");
    if (record.phase === "ACKED_RESULT" && record.result) return clone(record.result);
    if (record.phase === "IMPORTED_PENDING_ACK" && record.result) return clone(record.result);
    if (record.phase !== "RECEIVING") throw error("TRANSFER_IMPORT_PHASE_INVALID");
    const result = safeTransferResult({ requestId: input.requestId, importState: "IMPORTED", results: input.results || [] });
    await transferVault.update(input.requestId, current => {
      if (input.importContext) assertCredentialTransferContext(input.importContext);
      if (current.packetId !== input.packetId) throw error("TRANSFER_PACKET_CHANGED");
      if (current.phase === "ACKED_RESULT" && current.result) return current;
      if (current.phase === "IMPORTED_PENDING_ACK" && current.result) return current;
      if (current.phase !== "RECEIVING") throw error("TRANSFER_IMPORT_PHASE_INVALID");
      return { ...current, phase: "IMPORTED_PENDING_ACK", packetId: input.packetId, result };
    });
    return clone(result);
  }
  async function acknowledgeCredentialTransfer(input) {
    return transferSingleFlight(input?.requestId, async () => {
      const { auth, record } = await requireTransferRecord(input?.requestId);
      if (record.phase === "ACKED_RESULT") return { request: null, result: clone(record.result), reconciled: true };
      if (record.phase !== "IMPORTED_PENDING_ACK" || !record.result || record.packetId !== input.packetId) throw error("TRANSFER_IMPORT_NOT_DURABLE");
      let serverResult, directResponse, reconciled = false;
      try { directResponse = clone((await authenticatedRequest(`/v1/credential-transfers/${encodeURIComponent(input.requestId)}/ack`, { method: "POST", body: input }, auth.context)).body); }
      catch (failure) {
        let observed = null, readFailure = null;
        try {
          const body = clone((await authenticatedRequest(`/v1/credential-transfers/${encodeURIComponent(input.requestId)}`, {}, auth.context)).body);
          observed = assertTransferRequestMatches(record, body);
        } catch (readError) { readFailure = readError; }
        if (readFailure?.code === "TRANSFER_ACCOUNT_MISMATCH") {
          // A GET 404/mismatch after any failed ACK (including transport
          // timeout, not only REPLAY) supplies no identity-bound terminal
          // result. Keep the imported vault record, never invent ACK, and
          // only show the sanitized pending state if local authority still
          // matches its original account/device/session/store binding.
          const latestAuth = await transferAuth();
          if (!transferRecordMatches(record, latestAuth)) throw error("TRANSFER_ACCOUNT_MISMATCH");
          throw error("TRANSFER_ACK_UNCONFIRMED", { serverState: null });
        }
        if (readFailure && ["TRANSFER_REQUEST_MISMATCH", "TRANSFER_ACCOUNT_MISMATCH",
                            "AUTH_REQUIRED", "TRANSFER_EXPIRED"].includes(readFailure.code)) throw readFailure;
        if (["CANCELLED", "EXPIRED"].includes(observed?.state)) {
          const latestAuth = await transferAuth();
          if (!transferRecordMatches(record, latestAuth)) throw error("TRANSFER_ACCOUNT_MISMATCH");
          // The authenticated readback matched this exact recipient request.
          // A terminal server state is distinct from a recoverable lost relay.
          throw error("TRANSFER_ACK_TERMINAL", { state: observed.state });
        }
        if (observed?.state !== "COMPLETED") {
          // Losing the process-memory relay before ACK can yield REPLAY while
          // PostgreSQL still has a nonterminal delivered request. Do not
          // erase the already durable recipient import or invent an ACK.
          if (failure?.code === "TRANSFER_REPLAY" &&
              (!observed || !["CANCELLED", "EXPIRED"].includes(observed.state))) {
            const latestAuth = await transferAuth();
            if (!transferRecordMatches(record, latestAuth)) throw error("TRANSFER_ACCOUNT_MISMATCH");
            throw error("TRANSFER_ACK_UNCONFIRMED", { serverState: observed?.state || null });
          }
          throw failure;
        }
        serverResult = observed; reconciled = true;
      }
      if (!reconciled) {
        // A successful HTTP status alone cannot certify the exact imported
        // recipient request. Reject a foreign/malformed ACK body before the
        // durable vault is marked ACKED_RESULT; a later matching authenticated
        // readback can still recover a lost or malformed response.
        serverResult = assertTransferRequestMatches(record, directResponse);
        if (serverResult.state !== "COMPLETED")
          throw error("TRANSFER_ACK_UNCONFIRMED", { serverState: serverResult.state || null });
      }
      const latestAuth = await transferAuth();
      if (!transferRecordMatches(record, latestAuth)) throw error("TRANSFER_ACCOUNT_MISMATCH");
      const acked = await transferVault.update(input.requestId, current => ({ ...current, phase: "ACKED_RESULT", privateKey: null, result: current.result }));
      return { request: serverResult, result: clone(acked.result), reconciled };
    });
  }
  async function discardCredentialTransfer(requestId) {
    const auth = await transferAuth(), record = await transferVault.get(requestId);
    if (!record) return false;
    if (!transferRecordMatches(record, auth)) throw error("TRANSFER_ACCOUNT_MISMATCH");
    await transferVault.remove(requestId); return true;
  }
  async function consumeCredentialTransferResult(requestId) {
    const { record } = await requireTransferRecord(requestId);
    if (record.phase !== "ACKED_RESULT" || !record.result) throw error("TRANSFER_RESULT_NOT_READY");
    const result = clone(record.result);
    await transferVault.remove(requestId);
    return result;
  }
  let promptTreeCache = null;
  async function promptTreeContext(detected) {
    await init();
    await ensureAuthOwnership();
    const authority = await authorityFor(detected.family), payload = authority?.payload;
    if (!authority?.workAllowed || authStorageUnconfirmed || !state.credentials ||
        payload?.ai?.status !== "RESOLVED" ||
        verifier.canonicalJson(payload.ai.detected) !== verifier.canonicalJson(detected))
      throw error("AI_TREE_ACCESS_REQUIRED");
    return { origin: config.controlApiOrigin, accountId: payload.account.id,
      deviceId: state.credentials.deviceId, sessionId: state.credentials.sessionId,
      principalEpoch: epoch("principalEpoch"), accessEpoch: epoch("accessEpoch"),
      grantEpoch: authority.grantEpoch, scopeKey: authority.scopeKey,
      profileKey: payload.ai.profile.profileKey, profileRevision: payload.ai.profile.revision,
      profileHash: payload.ai.profile.contentSha256 };
  }
  function treeCache() {
    if (!globalThis.OctoportPromptTrees?.createCache || !verifier?.verifyPromptTreeV1)
      throw error("AI_TREE_CLIENT_UNAVAILABLE");
    if (!promptTreeCache) promptTreeCache = OctoportPromptTrees.createCache({
      storage: chrome.storage.local, verifier, trustBundle: config.trustBundle,
      authorize: promptTreeContext,
      fetchManifest: async ({ detected, context, requestNonce, known }) => {
        if (verifier.canonicalJson(await promptTreeContext(detected)) !== verifier.canonicalJson(context))
          throw error("AI_TREE_CONTEXT_CHANGED");
        const authority = grantFor(detected.family)?.authority;
        const requestContext = contextForState();
        const principal = { principalEpoch: epoch("principalEpoch"), deviceId: state.credentials?.deviceId, sessionId: state.credentials?.sessionId };
        let denialApplied = false;
        const observeDenial = async (failure, late = false) => {
          // A current endpoint denial invalidates all grants, including a denial
          // arriving after timeout. Tree data and transport failures cannot grant work.
          if (denialApplied || !failure || !(failure.status === 403 || late && failure.status === 401) ||
            httpErrorProvenance.get(failure) !== endpointFor("/v1/ai-prompt-tree") || authStorageUnconfirmed ||
            epoch("principalEpoch") !== principal.principalEpoch || state.credentials?.deviceId !== principal.deviceId ||
            state.credentials?.sessionId !== principal.sessionId) return;
          denialApplied = true;
          await invalidateKnown(contextForState(), failure, failure.status === 401);
        };
        try {
          const result = await authenticatedRequest("/v1/ai-prompt-tree", { method: "POST",
            body: { bootstrap: bootstrapRequest(detected, state.credentials, authority), requestNonce, known },
            observeSettlement: outcome => outcome.late ? observeDenial(outcome.error, true) : undefined }, requestContext);
          return result.body;
        } catch (failure) {
          await observeDenial(failure);
          throw failure;
        }
      },
    });
    return promptTreeCache;
  }
  async function promptTreeDetected(identity) {
    const family = requestedFamily(identity);
    if (!family) throw error("AI_TREE_SCOPE_UNSUPPORTED");
    const authority = await authorityFor(family);
    if (!authority?.workAllowed || authority.payload?.ai?.status !== "RESOLVED") throw error("AI_TREE_ACCESS_REQUIRED");
    return clone(authority.payload.ai.detected);
  }
  async function getPromptTree(identity, options = {}) {
    let detected;
    try {
      detected = await promptTreeDetected(identity);
      const pin = await treeCache().get(detected, { offline: options.cacheOnly === true, refresh: options.refresh === true });
      return { available: true, pin, warning: null };
    } catch (failure) {
      // A failed update preserves a previously verified copy. Reauthorization
      // inside the cache prevents this fallback from reviving a known denial.
      if (detected && !options.cacheOnly) {
        try { return { available: true, pin: await treeCache().get(detected, { offline: true }), warning: safeError(failure) }; }
        catch (_) { /* No foreign AI or unverified fallback. */ }
      }
      return { available: false, pin: null, warning: safeError(failure) };
    }
  }
  async function validatePromptTreePin(identity, pin) {
    const detected = await promptTreeDetected(identity);
    return treeCache().validatePinned(detected, pin);
  }
  const api = { getPromptTree, validatePromptTreePin, restore: init, status: async (identity = null) => { await init(); const decision = await workDecisionFor(identity); return publicStatus(decision); }, currentAccount: async () => { await init(); return state.authority?.payload?.account?.id || null; }, generation: async () => { await init(); return state.generation; }, hasAuthority: async () => { await init(); return Boolean(state.authority && state.credentials); }, canWork: async (identity = null) => { await init(); const decision = await workDecisionFor(identity); return isCurrentScopedDecision(decision); }, getAuthority: authorityFor, canContinueCached, getCachedContinuationState, getHealthAuthorityContext, getVerifiedAuthorityTime, getSubscriptionRefreshPlan, runSubscriptionRefreshTask, acquireSignedHealthAuthority, synchronizeMetadata, captureBackupContext, assertBackupContext, createCredentialTransfer, assertCredentialTransferContext, listCredentialTransferRecipients, listCredentialTransfers, readCredentialTransfer, markCredentialTransferSourceSeen, submitCredentialTransferPacket, receiveCredentialTransfer, recordCredentialTransferImported, acknowledgeCredentialTransfer, discardCredentialTransfer, consumeCredentialTransferResult, startActivation, cancelActivation, refresh, bootstrap, acquireBootstrapPreflight, bootstrapWithPolicy, ensureForIdentity, localReset, openPortal: async () => { await init(); const pending = state.pending; if (!pendingLive(state.pending) || !validAuthContext(pending.authContext)) throw error("NO_ACTIVATION_ATTEMPT"); return openPortal(pending.authorizationId); }, onAuthorityChanged: handler => { authorityChanged = handler; } };
  consentApi?.onWithdrawal?.(handleTechnicalPermissionWithdrawal);
  globalThis.SellerAgentsControlClient = Object.freeze(api);
})();

;
/* Read-only projection of an already acquired, signed Health envelope. */
(() => {
  "use strict";
  const client = globalThis.SellerAgentsControlClient;
  const verifier = globalThis.SellerAgentsBootstrapVerifier;
  const config = globalThis.SellerAgentsControlConfig;
  if (
    !client ||
    typeof client.acquireSignedHealthAuthority !== "function" ||
    typeof client.getHealthAuthorityContext !== "function" ||
    typeof client.getVerifiedAuthorityTime !== "function" ||
    !verifier?.verifyHealthV1
  )
    throw new Error("SIGNED_HEALTH_CLIENT_MISSING");
  function fail(code = "HEALTH_METADATA_INVALID") {
    return Object.assign(new Error(code), { code });
  }
  function freezeCopy(value) {
    const copy = JSON.parse(JSON.stringify(value));
    const freeze = (current) => {
      if (!current || typeof current !== "object" || Object.isFrozen(current))
        return current;
      for (const nested of Object.values(current)) freeze(nested);
      return Object.freeze(current);
    };
    return freeze(copy);
  }
  async function context(payload, authority) {
    if (
      payload?.contractVersion !== "control_plane_v2" ||
      payload?.ai?.status !== "RESOLVED" ||
      !payload.account?.id
    )
      return null;
    const bytes = (() => {
      try {
        const value = authority?.envelope?.payload;
        if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value)) return null;
        const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
        const decoded = Uint8Array.from(atob(padded), c => c.charCodeAt(0));
        return btoa(String.fromCharCode(...decoded)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "") === value ? decoded : null;
      } catch (_) { return null; }
    })();
    if (!bytes) return null;
    const digest = bytes ? [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map(value => value.toString(16).padStart(2, "0")).join("") : null;
    if (!digest || !authority.deviceId || !authority.sessionId) return null;
    return {
      accountId: payload.account.id,
      deviceId: authority.deviceId,
      sessionId: authority.sessionId,
      contractVersion: payload.contractVersion,
      configVersion: payload.configVersion,
      bootstrapSnapshotSha256: digest,
      ai: {
        family: payload.ai.detected.family,
        surface: payload.ai.detected.surface,
        variant: payload.ai.detected.variant,
        profileKey: payload.ai.profile.profileKey,
        revision: payload.ai.profile.revision,
        scopeVariant: payload.ai.profile.scopeVariant,
        contentSha256: payload.ai.profile.contentSha256,
      },
    };
  }
  async function project(envelope, authority) {
    const verified = await verifier.verifyHealthV1(
      envelope,
      config.trustBundle,
    );
    if (!verified.ok) throw fail(`HEALTH_${verified.error}`);
    const payload = authority?.payload,
      expected = await context(payload, authority);
    if (
      verified.payload.status === "PASS" &&
      (!expected ||
        verifier.canonicalJson(expected) !==
          verifier.canonicalJson(verified.payload.context))
    )
      throw fail("HEALTH_CONTEXT_MISMATCH");
    const now = await client.getVerifiedAuthorityTime();
    const claimObserved = Date.parse(verified.payload.observedAt);
    const bootstrapExpires = Date.parse(payload?.expiresAt);
    const claimExpires =
      verified.payload.status === "PASS"
        ? Date.parse(verified.payload.expiresAt)
        : null;
    const current =
      verified.payload.status === "PASS" &&
      Number.isFinite(claimExpires) &&
      claimObserved <= now &&
      now < Math.min(claimExpires, bootstrapExpires);
    const result = {
      metadataVersion: "signed_health_metadata_v1",
      verified: true,
      current,
      status: verified.payload.status,
      target: verified.payload.target,
      observedAt: verified.payload.observedAt,
      executionAuthority: false,
    };
    if (verified.payload.status === "PASS") {
      result.expiresAt = verified.payload.expiresAt;
      result.context = verified.payload.context;
    } else result.reason = verified.payload.reason;
    return freezeCopy(result);
  }
  async function getVerifiedHealthMetadata(options = {}) {
    const acquired = await client.acquireSignedHealthAuthority(options);
    return project(acquired.envelope, await client.getHealthAuthorityContext());
  }
  async function readVerifiedHealthMetadata(envelope) {
    return project(envelope, await client.getHealthAuthorityContext());
  }
  globalThis.SellerAgentsControlClient = Object.freeze({
    ...client,
    getVerifiedHealthMetadata,
    readVerifiedHealthMetadata,
  });
})();

;
/* Read-only projection of already verified bootstrap metadata.
 * This layer deliberately grants no Work, dispatch, replay, or scheduler authority. */
(() => {
  "use strict";

  const client = globalThis.SellerAgentsControlClient;
  if (!client || typeof client.bootstrapWithPolicy !== "function")
    throw new Error("SIGNED_METADATA_CONTROL_CLIENT_MISSING");

  const SOURCES = new Set(["ONLINE", "CACHE"]);
  const FRESHNESS = new Set(["FRESH", "STALE_BUT_OFFLINE_GRACE_ELIGIBLE"]);

  function fail() {
    return Object.assign(new Error("BOOTSTRAP_METADATA_INVALID"), {
      code: "BOOTSTRAP_METADATA_INVALID",
    });
  }

  function plainObject(value) {
    return Boolean(value && typeof value === "object" && !Array.isArray(value));
  }

  function freezeCopy(value) {
    const copy = value == null ? value : JSON.parse(JSON.stringify(value));
    const freeze = current => {
      if (!current || typeof current !== "object" || Object.isFrozen(current)) return current;
      for (const nested of Object.values(current)) freeze(nested);
      return Object.freeze(current);
    };
    return freeze(copy);
  }

  function projectVerifiedMetadata(result) {
    const payload = result?.payload;
    if (
      !plainObject(result) ||
      !SOURCES.has(result.source) ||
      !FRESHNESS.has(result.freshness) ||
      !plainObject(payload) ||
      !Number.isSafeInteger(payload.configVersion) ||
      payload.configVersion <= 0 ||
      !["BETA", "COMMERCIAL", "NONE"].includes(payload.accessBasis) ||
      !plainObject(payload.entitlements) ||
      !plainObject(payload.features)
    ) throw fail();

    let ai;
    if (payload.ai?.status === "RESOLVED") {
      if (!plainObject(payload.ai.detected) || !plainObject(payload.ai.profile)) throw fail();
      ai = {
        status: "RESOLVED",
        detected: payload.ai.detected,
        profile: payload.ai.profile,
      };
    } else if (payload.ai?.status === "UNCONFIGURED") {
      ai = { status: "UNCONFIGURED" };
    } else {
      throw fail();
    }

    return freezeCopy({
      metadataVersion: "signed_bootstrap_metadata_v1",
      source: result.source,
      freshness: result.freshness,
      executionAuthority: false,
      configVersion: payload.configVersion,
      accessBasis: payload.accessBasis,
      signedEntitlements: payload.entitlements,
      signedFeatures: payload.features,
      ai,
    });
  }

  async function getVerifiedBootstrapMetadata(options = {}) {
    return projectVerifiedMetadata(await client.bootstrapWithPolicy(options));
  }

  globalThis.SellerAgentsControlClient = Object.freeze({
    ...client,
    getVerifiedBootstrapMetadata,
  });
})();

;
/* Read-only intersection of reviewed packaged-local capabilities and explicit
 * signed server entitlement permissions. This layer never grants Work,
 * dispatch, replay, provider, scheduler, or offline execution authority. */
(() => {
  "use strict";

  const client = globalThis.SellerAgentsControlClient;
  const packaged = globalThis.SellerAgentsPackagedCapabilities;
  if (!client || typeof client.getVerifiedBootstrapMetadata !== "function")
    throw new Error("CAPABILITY_INTERSECTION_SIGNED_METADATA_MISSING");
  if (
    !packaged ||
    typeof packaged.has !== "function" ||
    typeof packaged.describe !== "function"
  )
    throw new Error("CAPABILITY_INTERSECTION_PACKAGED_AUTHORITY_MISSING");

  const SOURCES = new Set(["ONLINE", "CACHE"]);
  const FRESHNESS = new Set(["FRESH", "STALE_BUT_OFFLINE_GRACE_ELIGIBLE"]);
  const ACCESS_BASES = new Set(["BETA", "COMMERCIAL", "NONE"]);

  const bindings = [
    {
      capabilityId: "marketplace.ozon.adapter",
      entitlementKey: "source.ozon",
    },
    {
      capabilityId: "marketplace.wildberries.adapter",
      entitlementKey: "source.wildberries",
    },
    {
      capabilityId: "ai.chatgpt.web.adapter",
      entitlementKey: "ai.chatgpt",
    },
    {
      capabilityId: "ai.alice.web.adapter",
      entitlementKey: "ai.alice",
    },
    {
      capabilityId: "ai.qwen.web.adapter",
      entitlementKey: "ai.qwen",
    },
    {
      capabilityId: "ai.kimi.web.adapter",
      entitlementKey: "ai.kimi",
    },
    {
      capabilityId: "ai.grok.web.adapter",
      entitlementKey: "ai.grok",
    },
    {
      capabilityId: "ai.gemini.web.adapter",
      entitlementKey: "ai.gemini",
    },
    {
      capabilityId: "ai.claude.web.adapter",
      entitlementKey: "ai.claude",
    },
    {
      capabilityId: "ai.deepseek.web.adapter",
      entitlementKey: "ai.deepseek",
    },
  ];

  function deepFreeze(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value))
      return value;
    for (const nested of Object.values(value)) deepFreeze(nested);
    return Object.freeze(value);
  }

  const manifest = deepFreeze({
    schemaVersion: "seller_agents_capability_intersection_v1",
    authority: "PACKAGED_AND_SIGNED_ENTITLEMENT_READ_ONLY",
    executionAuthority: false,
    bindings,
  });
  const byCapabilityId = new Map(
    manifest.bindings.map(binding => [binding.capabilityId, binding]),
  );

  function fail() {
    return Object.assign(new Error("CAPABILITY_PERMISSION_METADATA_INVALID"), {
      code: "CAPABILITY_PERMISSION_METADATA_INVALID",
    });
  }

  function plainObject(value) {
    return Boolean(value && typeof value === "object" && !Array.isArray(value));
  }

  function validateMetadata(metadata) {
    if (
      !plainObject(metadata) ||
      metadata.metadataVersion !== "signed_bootstrap_metadata_v1" ||
      !SOURCES.has(metadata.source) ||
      !FRESHNESS.has(metadata.freshness) ||
      metadata.executionAuthority !== false ||
      !Number.isSafeInteger(metadata.configVersion) ||
      metadata.configVersion <= 0 ||
      !ACCESS_BASES.has(metadata.accessBasis) ||
      !plainObject(metadata.signedEntitlements)
    )
      throw fail();
  }

  function evaluate(metadata) {
    validateMetadata(metadata);
    const capabilities = manifest.bindings.map(binding => {
      const local = packaged.describe(binding.capabilityId);
      const packagedPresent =
        packaged.has(binding.capabilityId) === true &&
        local?.packaged === true &&
        local.executionAuthority === false;
      const signedPermissionPresent = Object.prototype.hasOwnProperty.call(
        metadata.signedEntitlements,
        binding.entitlementKey,
      );
      const signedValue = signedPermissionPresent
        ? metadata.signedEntitlements[binding.entitlementKey]
        : undefined;
      if (signedPermissionPresent && typeof signedValue !== "boolean")
        throw fail();
      const signedPermissionAllowed = signedValue === true;

      return {
        capabilityId: binding.capabilityId,
        entitlementKey: binding.entitlementKey,
        packaged: packagedPresent,
        signedPermissionPresent,
        signedPermissionAllowed,
        permissionSatisfied: packagedPresent && signedPermissionAllowed,
        executionAuthority: false,
      };
    });

    return deepFreeze({
      schemaVersion: "verified_capability_intersection_v1",
      source: metadata.source,
      freshness: metadata.freshness,
      configVersion: metadata.configVersion,
      accessBasis: metadata.accessBasis,
      executionAuthority: false,
      capabilities,
    });
  }

  function snapshot() {
    return manifest;
  }

  function hasBinding(capabilityId) {
    return typeof capabilityId === "string" && byCapabilityId.has(capabilityId);
  }

  function describeBinding(capabilityId) {
    return hasBinding(capabilityId) ? byCapabilityId.get(capabilityId) : null;
  }

  async function getVerified(options = {}) {
    return evaluate(await client.getVerifiedBootstrapMetadata(options));
  }

  function evaluateVerifiedMetadata(metadata) {
    return evaluate(metadata);
  }

  const api = Object.freeze({
    schemaVersion: manifest.schemaVersion,
    snapshot,
    hasBinding,
    describeBinding,
    getVerified,
    evaluateVerifiedMetadata,
  });
  Object.defineProperty(globalThis, "SellerAgentsCapabilityIntersection", {
    value: api,
    writable: false,
    configurable: false,
    enumerable: true,
  });
})();

;
/* One pure installation-local Work authority evaluator. */
(() => {
  "use strict";
  const config = globalThis.SellerAgentsControlConfig;
  const verifier = globalThis.SellerAgentsBootstrapVerifier;
  const browserIdentity = globalThis.SellerAgentsBrowserIdentity;
  const packaged = globalThis.SellerAgentsPackagedCapabilities;
  const intersection = globalThis.SellerAgentsCapabilityIntersection;
  const sourcePermission = Object.freeze({ ozon: "source.ozon", wildberries: "source.wildberries" });
  const aiPermission = Object.freeze({ chatgpt: "ai.chatgpt", alice: "ai.alice", qwen: "ai.qwen", kimi: "ai.kimi", grok: "ai.grok", gemini: "ai.gemini", claude: "ai.claude", deepseek: "ai.deepseek" });
  const capabilityId = Object.freeze({ "source.ozon": "marketplace.ozon.adapter", "source.wildberries": "marketplace.wildberries.adapter", "ai.chatgpt": "ai.chatgpt.web.adapter", "ai.alice": "ai.alice.web.adapter", "ai.qwen": "ai.qwen.web.adapter", "ai.kimi": "ai.kimi.web.adapter", "ai.grok": "ai.grok.web.adapter", "ai.gemini": "ai.gemini.web.adapter", "ai.claude": "ai.claude.web.adapter", "ai.deepseek": "ai.deepseek.web.adapter" });
  const aiFamilies = new Set(["chatgpt", "alice", "qwen", "kimi", "grok", "gemini", "claude", "deepseek"]);
  const maxDate = 8640000000000000;
  const plain = value => Boolean(value && typeof value === "object" && !Array.isArray(value));
  const text = value => typeof value === "string" && value.length > 0;
  const same = (left, right) => text(left) && left === right;
  const parsed = value => { const result = Date.parse(value); return Number.isSafeInteger(result) && result >= 0 && result <= maxDate ? result : null; };
  function freeze(value) { if (!value || typeof value !== "object" || Object.isFrozen(value)) return value; for (const child of Object.values(value)) freeze(child); return Object.freeze(value); }
  function deny(denied, code) { if (!denied.includes(code)) denied.push(code); }
  function browserFamily() { return browserIdentity?.current?.().family || null; }
  function browserVersion() { return browserIdentity?.current?.().version || null; }
  function bytes(value) { if (!text(value) || !/^[A-Za-z0-9_-]+$/.test(value)) return null; try { const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4); const result = Uint8Array.from(atob(padded), char => char.charCodeAt(0)); return verifier.base64urlEncode(result) === value ? result : null; } catch (_) { return null; } }
  async function digest(value) { return [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier.canonicalJson(value))))].map(item => item.toString(16).padStart(2, "0")).join(""); }
  function atLeast(actual, minimum) { const a = typeof actual === "string" && actual.split(".").map(Number), b = typeof minimum === "string" && minimum.split(".").map(Number); if (!a || !b || a.length < 3 || b.length < 3 || a.some(Number.isNaN) || b.some(Number.isNaN)) return false; for (let i = 0; i < 3; i += 1) if (a[i] !== b[i]) return a[i] > b[i]; return true; }
  function invalidation(current) { if (current.revoked === true || current.knownRevoke === true || current.knownRevoked === true || current.loggedOut === true || current.authReset === true || current.obsolete === true) return "DENY_AUTH_INVALIDATED"; if (current.storeDeleted === true) return "DENY_STORE_CONTEXT"; return null; }
  function freshness(payload, clock, requestedTime, source) {
    const expires = parsed(payload?.expiresAt), legacyGrace = parsed(payload?.offlineGraceUntil), server = parsed(payload?.serverTime);
    const values = [clock?.effectiveTimeMs, clock?.trustedServerTimeMs, server, requestedTime].filter(Number.isSafeInteger);
    if (expires === null || server === null || values.length < 3 || values.some(value => value < 0 || value > maxDate)) return { state: null, effectiveTimeMs: null };
    let deadline = legacyGrace, offlineEligible = true;
    if (payload?.contractVersion === "control_plane_v3") {
      if (source === "ONLINE") { deadline = expires; offlineEligible = false; }
      else if (payload.accessBasis === "COMMERCIAL") {
        const access = payload.subscriptionAccess;
        if (access === null) { deadline = expires; offlineEligible = false; }
        else {
          const paidThrough = parsed(access?.paidThrough), hard = parsed(access?.offlineHardUntil);
          if (paidThrough === null || hard === null || hard - paidThrough !== 72 * 60 * 60 * 1000) return { state: null, effectiveTimeMs: null };
          deadline = hard;
        }
      } else if (payload.accessBasis === "BETA") deadline = legacyGrace;
      else { deadline = expires; offlineEligible = false; }
    }
    const requiresLegacyGrace = payload?.contractVersion !== "control_plane_v3" || payload?.accessBasis === "BETA";
    if (deadline === null || requiresLegacyGrace && (legacyGrace === null || legacyGrace <= expires)) return { state: null, effectiveTimeMs: null };
    const effectiveTimeMs = Math.max(...values);
    const state = effectiveTimeMs >= deadline ? "CACHE_EXPIRED" : effectiveTimeMs < expires ? "FRESH" : offlineEligible ? "STALE_BUT_OFFLINE_GRACE_ELIGIBLE" : "CACHE_EXPIRED";
    return { state, effectiveTimeMs };
  }
  function capability(payload, state, source, marketplace, family) { const sourceKey = sourcePermission[marketplace], aiKey = aiPermission[family]; if (!sourceKey || !aiKey) return { source: null, ai: null, result: null }; try { const result = intersection.evaluateVerifiedMetadata({ metadataVersion: "signed_bootstrap_metadata_v1", source: source === "ONLINE" ? "ONLINE" : "CACHE", freshness: state, executionAuthority: false, configVersion: payload.configVersion, accessBasis: payload.accessBasis, signedEntitlements: payload.entitlements, signedFeatures: payload.features, ai: payload.ai }); const sourceRow = result.capabilities.find(row => row.entitlementKey === sourceKey && row.capabilityId === capabilityId[sourceKey]); const aiRow = result.capabilities.find(row => row.entitlementKey === aiKey && row.capabilityId === capabilityId[aiKey]); return { source: sourceRow || null, ai: aiRow || null, result }; } catch (_) { return { source: null, ai: null, result: null }; } }
  function signedPayloadProjection(payload) {
    if (!plain(payload?.localClientAuthority)) return payload;
    const { compatibility, features, ai, ...signedPayload } = payload;
    return signedPayload;
  }
  function context(value, current, authority, payload, operation) {
    const identity = plain(value.identity) ? value.identity : plain(value.dialogue?.identity) ? value.dialogue.identity : {};
    const family = current.aiFamily || current.aiProvider || identity.ai_id || identity.provider || payload.ai?.detected?.family;
    const origin = current.origin || identity.origin;
    const conversationId = current.conversationId ?? identity.conversationId ?? identity.conversation_id ?? null;
    const conversationKey = current.conversationKey ?? identity.key ?? null;
    const store = plain(value.store) ? value.store : {};
    const binding = plain(value.binding) ? value.binding : plain(value.dialogue?.binding) ? value.dialogue.binding : null;
    const boundStore = binding?.store_context || binding || {};
    const profile = payload.ai?.profile, actualProfile = current.aiProfile || {};
    const gates = {
      account: text(payload.account?.id) && current.accountId === payload.account.id && (current.expectedAccountId === undefined || current.expectedAccountId === payload.account.id),
      device: same(authority.deviceId, current.deviceId) && (current.expectedDeviceId === undefined || current.expectedDeviceId === authority.deviceId),
      session: same(authority.sessionId, current.sessionId) && (current.expectedSessionId === undefined || current.expectedSessionId === authority.sessionId),
      generation: Number.isSafeInteger(authority.generation) && authority.generation === current.generation && (current.expectedGeneration === undefined || current.expectedGeneration === current.generation),
      pageIdentity: (family === "chatgpt" && ["https://chatgpt.com", "https://chat.openai.com"].includes(origin) || family === "alice" && origin === "https://alice.yandex.ru" || family === "qwen" && origin === "https://chat.qwen.ai" || family === "kimi" && origin === "https://www.kimi.ai" || family === "grok" && origin === "https://grok.com" || family === "gemini" && origin === "https://gemini.google.com" || family === "claude" && origin === "https://claude.ai" || family === "deepseek" && origin === "https://chat.deepseek.com") && (conversationId === null || conversationKey === `${origin}|${conversationId}`),
      aiProfile: payload.ai?.status === "RESOLVED" && aiFamilies.has(family) && payload.ai.detected?.family === family && authority.requestedAi === family && payload.ai.detected?.surface === current.aiSurface && payload.ai.detected?.variant === current.aiVariant && profile?.scopeVariant === null && actualProfile.profileKey === profile.profileKey && actualProfile.revision === profile.revision && actualProfile.scopeVariant === profile.scopeVariant && actualProfile.contentSha256 === profile.contentSha256,
      dialogue: conversationId === null || conversationKey === `${origin}|${conversationId}`,
      store: text(store.accountId) && store.accountId === payload.account?.id && text(store.id || store.storeId) && (current.storeId === undefined || (store.id || store.storeId) === current.storeId) && ["ozon", "wildberries"].includes(store.marketplace) && store.marketplace === current.marketplace && text(store.credentialRevision) && store.credentialRevision === current.credentialRevision && (store.selectedStoreId == null || store.selectedStoreId === store.id || store.selectedStoreId === store.storeId) && (store.expectedStoreId == null || store.expectedStoreId === store.id || store.expectedStoreId === store.storeId),
      binding: !binding ? operation === "START" || operation === "REBIND" : text(binding.binding_id || binding.bindingId) && Number(binding.revision) > 0 && (binding.conversation_key || binding.conversationKey) === conversationKey && (binding.conversation_id || binding.conversationId) === conversationId && binding.origin === origin && (binding.ai_id || binding.provider) === family,
      bindingStore: !binding || boundStore.accountId === payload.account?.id && (boundStore.storeId || boundStore.id) === (store.id || store.storeId) && boundStore.marketplace === store.marketplace && boundStore.credentialRevision === store.credentialRevision,
      credentialRevision: current.expectedCredentialRevision == null || current.expectedCredentialRevision === current.credentialRevision,
      bindingRevision: !binding || current.bindingId == null || (binding.binding_id || binding.bindingId) === current.bindingId && Number(binding.revision) === Number(current.bindingRevision),
      workIntent: current.workStartIntentId === undefined || current.expectedWorkStartIntentId === undefined || current.workStartIntentId === current.expectedWorkStartIntentId,
    };
    if (plain(value.work) && value.work.start_intent_id !== undefined && current.workStartIntentId !== undefined) gates.workIntent = gates.workIntent && value.work.start_intent_id === current.workStartIntentId;
    return { gates, family, origin, conversationId, conversationKey, store, binding };
  }
  async function evaluate(input, options = {}) {
    const value = plain(input) ? input : {}, current = plain(value.current) ? value.current : {}, authority = plain(value.cachedAuthority) ? value.cachedAuthority : plain(value.authority) ? value.authority : null, payload = authority?.payload;
    const rawOperation = value.operation || value.work?.operation;
    const operation = typeof rawOperation === "string" ? rawOperation.toUpperCase() : null, denied = [], gates = {};
    const invalid = invalidation(current); if (invalid) deny(denied, invalid);
    if (!authority || !plain(payload)) { deny(denied, "DENY_AUTH_INVALIDATED"); return freeze({ schemaVersion: "autonomous_work_authority_decision_v1", allowed: false, executionAuthority: false, operation, authorityState: "DENY_AUTH_INVALIDATED", freshness: null, effectiveTimeMs: null, deniedGates: denied, gates, provenanceUsed: false, healthRequired: options.requireHealth === true }); }
    let signed = false; try { const verified = authority.envelope?.envelopeVersion === "bootstrap_envelope_v3" && typeof verifier.verifyV3 === "function" ? await verifier.verifyV3(authority.envelope, config.trustBundle) : await verifier.verifyV2(authority.envelope, config.trustBundle); const expectedSignedPayload = signedPayloadProjection(payload); signed = authority.verified === true && verified.ok === true && verifier.canonicalJson(verified.payload) === verifier.canonicalJson(expectedSignedPayload); } catch (_) {}
    gates.signedBootstrap = signed; if (!signed) deny(denied, "DENY_AUTH_INVALIDATED");
    const time = freshness(payload, value.cacheClock, value.effectiveTimeMs, value.source); gates.freshness = time.state !== null;
    if (time.state === "CACHE_EXPIRED") deny(denied, "DENY_CACHE_EXPIRED"); else if (!gates.freshness) deny(denied, "DENY_AUTH_INVALIDATED");
    const clockOwner = value.cacheClock?.owner || {};
    const payloadServerTime = parsed(payload.serverTime);
    gates.cacheOwnership = value.cacheClock?.cacheVersion === "control_cache_clock_v1" && clockOwner.controlApiOrigin === config.controlApiOrigin && clockOwner.portalOrigin === config.portalOrigin && clockOwner.contractVersion === payload.contractVersion && clockOwner.deviceId === authority.deviceId && clockOwner.sessionId === authority.sessionId && payloadServerTime !== null && Number(value.cacheClock?.trustedServerTimeMs) >= payloadServerTime && (payload.contractVersion !== "control_plane_v3" || Number(value.cacheClock?.trustedServerTimeMs) === payloadServerTime);
    if (!gates.cacheOwnership) deny(denied, "DENY_AUTH_INVALIDATED");
    const wireCompatible = payload.snapshotVersion === "bootstrap_snapshot_v2" && payload.contractVersion === config.contractVersion || payload.snapshotVersion === "bootstrap_snapshot_v3" && payload.contractVersion === "control_plane_v3";
    gates.bootstrapCompatibility = wireCompatible && Number.isSafeInteger(payload.configVersion) && payload.configVersion > 0 && payload.account?.status === "ACTIVE" && payload.devicePolicy?.status === "ACTIVE" && ["SUPPORTED", "UPDATE_RECOMMENDED"].includes(payload.compatibility?.extension?.status) && (payload.compatibility?.extension?.minimumVersion === null || atLeast(config.extensionVersion, payload.compatibility.extension.minimumVersion)) && payload.compatibility?.browser?.status === "SUPPORTED";
    if (!gates.bootstrapCompatibility) deny(denied, "DENY_AUTH_INVALIDATED");
    gates.accessBasis = payload.contractVersion !== "control_plane_v3" || payload.accessBasis !== "NONE";
    if (!gates.accessBasis) deny(denied, "DENY_AUTH_INVALIDATED");
    const trustBundleSha256 = await digest(config.trustBundle), expectedAi = payload.ai?.status === "RESOLVED" ? { family: payload.ai.detected.family, surface: payload.ai.detected.surface, variant: payload.ai.detected.variant } : null;
    gates.cacheBinding = plain(authority.cacheBinding) && authority.cacheBinding.cacheVersion === "control_cache_binding_v1" && authority.cacheBinding.controlApiOrigin === config.controlApiOrigin && authority.cacheBinding.portalOrigin === config.portalOrigin && authority.cacheBinding.contractVersion === payload.contractVersion && authority.cacheBinding.extensionVersion === config.extensionVersion && authority.cacheBinding.browser?.family === browserFamily() && authority.cacheBinding.browser?.version === browserVersion() && authority.cacheBinding.trustBundleSha256 === trustBundleSha256 && verifier.canonicalJson(authority.cacheBinding.detectedAi) === verifier.canonicalJson(expectedAi);
    if (!gates.cacheBinding) deny(denied, "DENY_AUTH_INVALIDATED");
    const details = context(value, current, authority, payload, operation); Object.assign(gates, details.gates);
    if (!details.gates.account) deny(denied, "DENY_ACCOUNT_MISMATCH");
    if (!details.gates.device || !details.gates.session || !details.gates.generation) deny(denied, "DENY_DEVICE_SESSION_MISMATCH");
    if (!details.gates.aiProfile) deny(denied, "DENY_AI_PROFILE_MISMATCH");
    if (!details.gates.pageIdentity || !details.gates.dialogue) deny(denied, "DENY_BINDING_CONTEXT");
    if (!details.gates.store || !details.gates.bindingStore) deny(denied, "DENY_STORE_CONTEXT");
    if (!details.gates.credentialRevision) deny(denied, "DENY_CREDENTIAL_REVISION");
    if (!details.gates.binding || !details.gates.bindingRevision || !details.gates.workIntent) deny(denied, "DENY_BINDING_CONTEXT");
    const profileDigest = payload.ai?.profile?.contentSha256 ? await digest({ content: payload.ai.profile.content, compatibility: payload.ai.profile.compatibility }) : null;
    gates.aiProfileContent = profileDigest !== null && profileDigest === payload.ai?.profile?.contentSha256;
    if (!gates.aiProfileContent) deny(denied, "DENY_AI_PROFILE_MISMATCH");
    const capabilities = capability(payload, time.state, value.source, details.store.marketplace, details.family); gates.sourceCapability = capabilities.source?.permissionSatisfied === true && capabilities.source?.packaged === true; gates.aiCapability = capabilities.ai?.permissionSatisfied === true && capabilities.ai?.packaged === true;
    if (!gates.sourceCapability || !gates.aiCapability) deny(denied, "DENY_CAPABILITY");
    if (options.requireHealth === true && !(value.health?.status === "PASS" && value.health.current === true && value.health.verified === true)) deny(denied, "DENY_HEALTH_OBSERVATION");
    const state = time.state === "FRESH" ? "ALLOW_FRESH" : time.state === "STALE_BUT_OFFLINE_GRACE_ELIGIBLE" ? "ALLOW_OFFLINE_GRACE" : "DENY_CACHE_EXPIRED";
    const authorityState = denied.length ? (denied.includes("DENY_CACHE_EXPIRED") ? "DENY_CACHE_EXPIRED" : "DENY_CONTEXT") : state;
    return freeze({ schemaVersion: "autonomous_work_authority_decision_v1", allowed: denied.length === 0, executionAuthority: false, operation, authorityState, freshness: time.state, effectiveTimeMs: time.effectiveTimeMs, deniedGates: [...denied], gates, provenanceUsed: false, healthRequired: options.requireHealth === true, capabilityEvidence: capabilities.result ? { source: capabilities.result.source, freshness: capabilities.result.freshness, executionAuthority: false } : null });
  }
  function createProvenance(seed, finalFields = {}) { const value = plain(seed) ? { ...seed, ...finalFields, executionAuthority: false, bearer: false } : null; return value ? freeze(value) : null; }
  Object.defineProperty(globalThis, "SellerAgentsAutonomousWorkAuthority", { value: Object.freeze({ evaluate, createProvenance }), writable: false, configurable: false, enumerable: true });
})();

;
/* Compatibility surface backed by the single autonomous evaluator. */
(() => {
  "use strict";
  const core = globalThis.SellerAgentsAutonomousWorkAuthority;
  if (!core) throw new Error("AUTONOMOUS_WORK_AUTHORITY_MISSING");
  Object.defineProperty(globalThis, "SellerAgentsOnlineWorkAuthority", {
    value: Object.freeze({ evaluate: input => core.evaluate(input, { requireHealth: input?.health !== undefined }) }),
    writable: false,
    configurable: false,
    enumerable: true,
  });
})();

;
/* Passive verified-Health adapter for the pure online Work authority. It
 * consumes an already acquired envelope and never acquires Health itself. */
(() => {
  "use strict";

  const client = globalThis.SellerAgentsControlClient;
  const core = globalThis.SellerAgentsAutonomousWorkAuthority;
  if (!client || typeof client.readVerifiedHealthMetadata !== "function" || !core || typeof core.evaluate !== "function")
    throw new Error("VERIFIED_ONLINE_WORK_AUTHORITY_MISSING");

  function plainObject(value) {
    return Boolean(value && typeof value === "object" && !Array.isArray(value));
  }

  function deniedHealth() {
    return { status: "UNAVAILABLE", current: false, verified: false };
  }

  function trustedHealth(metadata) {
    return Boolean(
      metadata &&
      metadata.verified === true &&
      metadata.current === true &&
      metadata.status === "PASS" &&
      metadata.target === "WORK" &&
      metadata.executionAuthority === false,
    );
  }

  function sameHealthContext(value, context) {
    const account = value.account;
    const session = value.session;
    const compatibility = value.compatibility;
    const bootstrap = value.bootstrap;
    const ai = value.ai;
    const profile = ai?.profile;
    const expected = context?.ai;
    return plainObject(context) &&
      plainObject(account) && plainObject(session) && plainObject(compatibility) && plainObject(bootstrap) &&
      plainObject(ai) && plainObject(profile) && plainObject(expected) &&
      account.accountId === context.accountId &&
      session.generation === value.currentAuthorityGeneration &&
      session.deviceId === context.deviceId &&
      session.sessionId === context.sessionId &&
      compatibility.contractVersion === context.contractVersion &&
      bootstrap.accountId === context.accountId &&
      bootstrap.generation === session.generation &&
      bootstrap.deviceId === context.deviceId &&
      bootstrap.sessionId === context.sessionId &&
      bootstrap.contractVersion === context.contractVersion &&
      bootstrap.configVersion === context.configVersion &&
      bootstrap.bootstrapSnapshotSha256 === context.bootstrapSnapshotSha256 &&
      bootstrap.aiProvider === expected.family &&
      ai.provider === expected.family &&
      profile.provider === expected.family &&
      ai.surface === expected.surface &&
      ai.variant === expected.variant &&
      profile.profileKey === expected.profileKey &&
      profile.revision === expected.revision &&
      profile.scopeVariant === expected.scopeVariant &&
      profile.contentSha256 === expected.contentSha256 &&
      value.capabilityIntersection?.configVersion === context.configVersion;
  }

  async function evaluate(input, healthEnvelope) {
    const value = plainObject(input) ? input : {};
    let health = deniedHealth();
    if (plainObject(healthEnvelope)) {
      try {
        const metadata = await client.readVerifiedHealthMetadata(healthEnvelope);
        const currentAuthorityGeneration = typeof client.generation === "function" ? await client.generation() : null;
        if (trustedHealth(metadata) && sameHealthContext({ ...value, currentAuthorityGeneration }, metadata.context)) health = { status: "PASS", current: true, verified: true };
      } catch (_) {
        // Verification, context, freshness, and time failures are denials.
      }
    }
    return core.evaluate({ ...value, health }, { requireHealth: true });
  }

  const api = Object.freeze({ evaluate });
  Object.defineProperty(globalThis, "SellerAgentsVerifiedOnlineWorkAuthority", {
    value: api,
    writable: false,
    configurable: false,
    enumerable: true,
  });
})();

;
/* Compatibility surface backed by the single autonomous evaluator. */
(() => {
  "use strict";
  const core = globalThis.SellerAgentsAutonomousWorkAuthority;
  if (!core) throw new Error("AUTONOMOUS_WORK_AUTHORITY_MISSING");
  Object.defineProperty(globalThis, "SellerAgentsOfflineWorkAuthority", {
    value: core,
    writable: false,
    configurable: false,
    enumerable: true,
  });
})();

;
(() => {
  "use strict";

  // Extracted from the accepted worker; one local flight owns a given key.
  // Errors clear the flight but do not execute a replacement operation.
  function singleFlight(map, key, fn) {
    if (map.has(key)) return map.get(key);
    const request = Promise.resolve()
      .then(fn)
      .finally(() => {
        if (map.get(key) === request) map.delete(key);
      });
    map.set(key, request);
    return request;
  }

  function createWriteQueue() {
    let tail = Promise.resolve();
    return Object.freeze({
      run(fn) {
        const next = tail.then(fn, fn);
        tail = next.catch(() => null);
        return next;
      },
    });
  }

  // A queue belongs to the whole storage map, not an individual dialogue.
  // Otherwise concurrent read/modify/write operations can erase each other.
  const recordWriters = new Set();
  function canonicalRecord(value) {
    if (value === null || typeof value !== "object") return value;
    if (Array.isArray(value)) return value.map(canonicalRecord);
    return Object.fromEntries(Object.keys(value).sort().filter(key => value[key] !== undefined)
      .map(key => [key, canonicalRecord(value[key])]));
  }
  function recordBytes(value) { return JSON.stringify(canonicalRecord(value)); }
  function createRecordStore({
    read,
    write,
    namespace,
    now = () => new Date().toISOString(),
    onCommitFailure = () => {},
    writerKey = null,
  }) {
    if (
      typeof read !== "function" ||
      typeof write !== "function" ||
      !namespace
    ) {
      throw new TypeError(
        "Local record storage ports and namespace are required",
      );
    }
    if (writerKey !== null) {
      if (typeof writerKey !== "string" || !writerKey) throw new TypeError("Invalid writer identity");
      if (recordWriters.has(writerKey)) throw Object.assign(new Error("RECORD_STORE_WRITER_ALREADY_REGISTERED"), { code: "RECORD_STORE_WRITER_ALREADY_REGISTERED" });
      recordWriters.add(writerKey);
    }
    const queue = createWriteQueue();
    let unavailable = null;
    function assertAvailable() { if (unavailable) throw unavailable; }
    function failStorage(stage) {
      unavailable = Object.assign(new Error("RECORD_STORE_COMMIT_UNCONFIRMED"), {
        code: "RECORD_STORE_COMMIT_UNCONFIRMED", stage,
      });
      // The in-memory barrier is immediate. Do not await cleanup under this writer.
      Promise.resolve().then(() => onCommitFailure(unavailable)).catch(() => null);
      return unavailable;
    }
    async function snapshot() {
      assertAvailable();
      try {
        const data = await read(namespace);
        if (!data || typeof data !== "object" || Array.isArray(data) ||
            (data[namespace] !== undefined && (!data[namespace] || typeof data[namespace] !== "object" || Array.isArray(data[namespace]))))
          throw new Error("Invalid record map");
        return data;
      } catch (_) { throw failStorage("read"); }
    }
    async function get(key) {
      const data = await snapshot();
      return (data[namespace] || {})[key] || null;
    }
    function mutate(key, mutator) {
      return queue.run(async () => {
        const data = await snapshot();
        const records = { ...(data[namespace] || {}) };
        const next = await mutator(records[key] || null);
        assertAvailable();
        if (next) records[key] = { ...next, updated_at: now() };
        else delete records[key];
        const expected = recordBytes(records);
        try { await write({ [namespace]: records }); }
        catch (_) { throw failStorage("write"); }
        let observed;
        try { observed = await read(namespace); }
        catch (_) { throw failStorage("readback"); }
        if (!observed || typeof observed !== "object" || Array.isArray(observed) ||
            !observed[namespace] || typeof observed[namespace] !== "object" || Array.isArray(observed[namespace]) ||
            recordBytes(observed[namespace]) !== expected) throw failStorage("readback");
        // Observed exact persistence, not a promise of fsync/power-loss durability.
        return records[key] || null;
      });
    }
    return Object.freeze({ get, mutate, withWrite: fn => queue.run(() => { assertAvailable(); return fn(); }) });
  }

  globalThis.SellerAgentsLocalOperations = Object.freeze({
    singleFlight,
    createWriteQueue,
    createRecordStore,
  });
})();

;
/* Hash-only Work receipts. Uses the existing MANUAL_OPERATIONS writer. */
(() => {
  "use strict";
  const RETRY_WARNING = "Предыдущий запрос мог выполниться. Новый запуск может повторить действие и расход квоты";
  const MAX_MARKERS = 2000, BUFFER_TTL_MS = 3600000;
  const err = code => Object.assign(new Error(code), { code });
  const clone = value => JSON.parse(JSON.stringify(value));
  const object = value => Boolean(value && typeof value === "object" && !Array.isArray(value));
  const nonempty = value => typeof value === "string" && value.length > 0;
  function createCommandLedger({ store, canonicalJson, sha256, makeId = () => crypto.randomUUID(),
    now = () => Date.now(), assertContext, classifyReadOnly, readBuffer }) {
    if (!store?.mutate || !store?.get || [canonicalJson, sha256, assertContext, classifyReadOnly, readBuffer].some(fn => typeof fn !== "function"))
      throw err("COMMAND_LEDGER_PORTS_REQUIRED");
    const unknown = receipt => receipt.items.some(item => ["PROVIDER_INTENT", "UNKNOWN"].includes(item.state));
    async function check(context) {
      // This port may read context, never mutate authority or perform provider/DOM effects.
      if (!object(context) || await assertContext(context) !== true) throw err("EXECUTION_CONTEXT_CHANGED");
    }
    function ledger(current) {
      if (current?.r3_commands === undefined) return { schema: 2, origins: {}, receipts: {}, approvals: {}, deliveries: {} };
      const value = current.r3_commands;
      if (!object(value) || value.schema !== 2 || !["origins", "receipts", "approvals", "deliveries"].every(k => object(value[k])))
        throw err("COMMAND_HISTORY_UNKNOWN");
      return clone(value);
    }
    function capacity(data) {
      if (Object.keys(data.receipts).length + Object.keys(data.deliveries).length + Object.keys(data.approvals).length >= MAX_MARKERS)
        throw err("WORK_MARKER_CAPACITY_START_REQUIRED");
    }
    function compactCompletedWork(data, context) {
      // Only a new Work may retire completed history. Uncertain effects and their
      // ancestry remain durable fences, even when their payloads have expired.
      if (!nonempty(context.accountId) || !nonempty(context.workSessionId)) return;
      const removable = new Set(Object.entries(data.receipts).filter(([, receipt]) =>
        receipt.context?.accountId === context.accountId &&
        nonempty(receipt.context.workSessionId) && receipt.context.workSessionId !== context.workSessionId &&
        Array.isArray(receipt.items) && receipt.items.length > 0 && receipt.items.every(item => item.state === "RESULT")
      ).map(([id]) => id));
      const sameContext = (left, right) => object(left) && object(right) && canonicalJson(left) === canonicalJson(right);
      function confirmedDelivery(id, delivery) {
        const receipt = data.receipts[delivery?.executionId];
        return Boolean(receipt && delivery.state === "CONFIRMED" && delivery.deliveryId === id &&
          sameContext(delivery.context, receipt.context) && delivery.expiresAt === receipt.payloadExpiresAt &&
          nonempty(delivery.bufferDigest) && (receipt.deliveryBufferDigest === delivery.bufferDigest ||
            receipt.items.some(item => item.state === "RESULT" && item.bufferDigest === delivery.bufferDigest)));
      }
      function completedCopy(id, approval) {
        const delivery = data.deliveries[approval.consumedBy];
        const receipt = data.receipts[approval.executionId];
        return Boolean(approval.kind === "COPY" && approval.confirmationId === id && delivery && receipt &&
          confirmedDelivery(approval.consumedBy, delivery) && delivery.executionId === approval.executionId &&
          delivery.confirmationId === id && sameContext(approval.context, receipt.context) &&
          approval.bufferDigest === delivery.bufferDigest && approval.expiresAt === delivery.expiresAt &&
          Number.isSafeInteger(approval.deliveryRevision) && delivery.deliveryRevision === approval.deliveryRevision + 1);
      }
      for (const [id, delivery] of Object.entries(data.deliveries)) {
        const approval = data.approvals[delivery.confirmationId];
        if (!confirmedDelivery(id, delivery) || (delivery.original !== true &&
            (!approval || !completedCopy(delivery.confirmationId, approval)))) removable.delete(delivery.executionId);
      }
      // Resolve all receipt/approval dependencies together to a fixed point.
      // A retained uncertain effect protects every linked execution, regardless
      // of insertion order or the number of explicit retry generations.
      let changed;
      do {
        changed = false;
        for (const [id, receipt] of Object.entries(data.receipts)) {
          if (!removable.has(id) && removable.delete(receipt.predecessor)) changed = true;
        }
        for (const [id, approval] of Object.entries(data.approvals)) {
          if (approval.kind === "COPY") {
            // COPY consumes a deliveryId, while RETRY consumes an executionId.
            // A missing, uncertain or mismatched delivery remains a durable fence.
            if (!removable.has(approval.executionId) || (approval.consumedBy && !completedCopy(id, approval)))
              if (removable.delete(approval.executionId)) changed = true;
          } else if (approval.kind === "RETRY") {
            if (!removable.has(approval.predecessor) || (approval.consumedBy && !removable.has(approval.consumedBy))) {
              if (removable.delete(approval.predecessor)) changed = true;
              if (removable.delete(approval.consumedBy)) changed = true;
            }
          } else {
            for (const target of [approval.executionId, approval.predecessor, approval.consumedBy])
              if (removable.delete(target)) changed = true;
          }
        }
      } while (changed);
      for (const [id, approval] of Object.entries(data.approvals)) {
        if (approval.kind === "COPY" && removable.has(approval.executionId) &&
            (!approval.consumedBy || completedCopy(id, approval))) delete data.approvals[id];
        else if (approval.kind === "RETRY" && removable.has(approval.predecessor) &&
            (!approval.consumedBy || removable.has(approval.consumedBy))) delete data.approvals[id];
      }
      for (const [id, delivery] of Object.entries(data.deliveries)) {
        if (delivery.state === "CONFIRMED" && removable.has(delivery.executionId)) delete data.deliveries[id];
      }
      for (const id of removable) delete data.receipts[id];
      const origins = new Set([...Object.values(data.receipts), ...Object.values(data.approvals)]
        .map(record => record.blockOriginKey));
      for (const id of Object.keys(data.origins)) if (!origins.has(id)) delete data.origins[id];
    }
    async function mutate(conversationKey, context, fn) {
      await check(context);
      let result;
      await store.mutate(conversationKey, async current => {
        await check(context);
        const data = ledger(current);
        compactCompletedWork(data, context);
        result = fn(data);
        if (result?.then) throw err("COMMAND_WRITER_ASYNC_EFFECT_FORBIDDEN");
        return { ...(current || {}), r3_commands: data };
      });
      await check(context);
      return clone(result);
    }
    function receiptFor(data, id, context) {
      const receipt = data.receipts[id];
      if (!receipt || canonicalJson(receipt.context) !== canonicalJson(context)) throw err("COMMAND_CONTEXT_MISMATCH");
      return receipt;
    }
    function predecessorFor(data, id, context) {
      const receipt = data.receipts[id];
      // A new explicit approval uses current authority. It cannot change the original Work or binding.
      const stable = ["accountId", "principalEpoch", "conversationKey", "bindingId", "bindingRevision",
        "workSessionId", "workGeneration", "storeId", "marketplace", "aiFamily"];
      if (!receipt || stable.some(key => receipt.context[key] !== context[key])) throw err("COMMAND_CONTEXT_MISMATCH");
      return receipt;
    }
    function normalizeSelection(items) {
      if (!Array.isArray(items) || !items.length) throw err("RETRY_SELECTION_REQUIRED");
      const seen = new Set();
      return items.map(item => {
        if (!Number.isSafeInteger(item?.ordinal) || item.ordinal < 0 || seen.has(item.ordinal) || !nonempty(item.inputHash))
          throw err("RETRY_SELECTION_INVALID");
        seen.add(item.ordinal);
        if (classifyReadOnly(item) !== true) throw err("RETRY_READ_ONLY_REQUIRED");
        return { ordinal: item.ordinal, inputHash: item.inputHash };
      }).sort((a, b) => a.ordinal - b.ordinal);
    }
    async function blockKeys(input) {
      const { accountId, conversationBindingId, workSessionId, messageIdentity, blockOrdinal, blockText } = input || {};
      if (![accountId, conversationBindingId, workSessionId].every(nonempty) || !object(messageIdentity) ||
          !["provider-message", "document-local"].includes(messageIdentity.kind) || !nonempty(messageIdentity.id) ||
          (messageIdentity.kind === "document-local" && !nonempty(messageIdentity.documentKey)) ||
          !Number.isSafeInteger(blockOrdinal) || blockOrdinal < 0 || typeof blockText !== "string")
        throw err("BLOCK_IDENTITY_REQUIRED");
      const identity = { kind: messageIdentity.kind, id: messageIdentity.id };
      if (identity.kind === "document-local") identity.documentKey = messageIdentity.documentKey;
      const blockOriginKey = await sha256(canonicalJson({ version: 1, accountId, conversationBindingId, workSessionId,
        messageIdentity: identity, blockOrdinal }));
      return { blockOriginKey, blockVersion: await sha256(blockText),
        messageAnchorKey: await sha256(canonicalJson({ version: 1, accountId, conversationBindingId, workSessionId, messageIdentity: identity })) };

    }
    async function reserveCommand({ conversationKey, context, blockOriginKey, blockVersion, items, source = null }) {
      if (![conversationKey, blockOriginKey, blockVersion].every(nonempty) || !Array.isArray(items) || !items.length)
        throw err("COMMAND_INPUT_INVALID");
      const ordinals = new Set();
      const captured = items.map(item => {
        if (!Number.isSafeInteger(item.ordinal) || item.ordinal < 0 || ordinals.has(item.ordinal) || !nonempty(item.inputHash))
          throw err("COMMAND_INPUT_INVALID");
        ordinals.add(item.ordinal);
        return { ordinal: item.ordinal, inputHash: item.inputHash, state: "RESERVED", providerAttemptId: null };
      });
      const commandKey = await sha256(canonicalJson({ blockOriginKey, blockVersion, approvalRevision: 0 }));
      return mutate(conversationKey, context, data => {
        const existing = Object.values(data.receipts).find(r => r.commandKey === commandKey);
        if (existing) return { executionId: existing.executionId, dispatch: false, duplicate: true, unknown: unknown(existing), payloadExpiresAt: existing.payloadExpiresAt };
        const origin = data.origins[blockOriginKey];
        if (source) {
          if (!object(source) || !nonempty(source.messageAnchorKey) || !nonempty(source.documentKey) ||
              !["provider-message", "document-local"].includes(source.messageKind)) throw err("BLOCK_IDENTITY_REQUIRED");
          const sameWork = Object.values(data.receipts).filter(r => r.context?.workSessionId === context.workSessionId);
          if (sameWork.some(r => r.source?.messageKind === "document-local" &&
              (r.source.documentKey !== source.documentKey || unknown(r))))
            throw err("COMMAND_LOCAL_IDENTITY_UNCERTAIN_START_REQUIRED");
          if (sameWork.some(r => r.source?.messageAnchorKey === source.messageAnchorKey && unknown(r)))
            throw err("COMMAND_OUTCOME_UNKNOWN_EXPLICIT_RETRY_REQUIRED");
        }
        if (origin && Object.values(data.receipts).some(r => r.blockOriginKey === blockOriginKey && unknown(r)))
          throw err("COMMAND_OUTCOME_UNKNOWN_EXPLICIT_RETRY_REQUIRED");
        capacity(data);
        const executionId = makeId();
        data.origins[blockOriginKey] = origin || { approvalRevision: 0 };
        data.receipts[executionId] = { executionId, commandKey, blockOriginKey, blockVersion, approvalRevision: 0,
          context: clone(context), items: captured.map(item => ({ ...item, itemId: commandKey + ":" + item.ordinal })),
          createdAt: now(), payloadExpiresAt: now() + BUFFER_TTL_MS, predecessor: null,
          ...(source ? { source: clone(source) } : {}) };
        return { executionId, dispatch: false, duplicate: false, payloadExpiresAt: data.receipts[executionId].payloadExpiresAt };
      });
    }
    async function beginProviderAttempt({ conversationKey, context, executionId, ordinal }) {
      return mutate(conversationKey, context, data => {
        const receipt = receiptFor(data, executionId, context), item = receipt.items.find(i => i.ordinal === ordinal);
        if (!item) throw err("COMMAND_ITEM_MISSING");
        if (item.state !== "RESERVED") return { dispatch: false, state: item.state, providerAttemptId: item.providerAttemptId };
        if (now() >= receipt.payloadExpiresAt) throw err("COMMAND_EXPIRED");
        item.state = "PROVIDER_INTENT"; item.providerAttemptId = makeId(); item.intentAt = now();
        return { dispatch: true, providerAttemptId: item.providerAttemptId, itemId: item.itemId };
      });
    }
    async function recordProviderOutcome({ conversationKey, context, executionId, ordinal, providerAttemptId, outcome, bufferDigest = null }) {
      return mutate(conversationKey, context, data => {
        const receipt = receiptFor(data, executionId, context), item = receipt.items.find(i => i.ordinal === ordinal);
        if (!item || item.providerAttemptId !== providerAttemptId || item.state !== "PROVIDER_INTENT")
          throw err("PROVIDER_OUTCOME_OBSOLETE");
        if (!["RESULT", "UNKNOWN", "PROVEN_NOT_DISPATCHED"].includes(outcome)) throw err("PROVIDER_OUTCOME_INVALID");
        if (outcome === "RESULT" && !nonempty(bufferDigest)) throw err("RESULT_DIGEST_REQUIRED");
        // A transport timeout cannot be recorded as proof of absence by this API.
        if (outcome === "PROVEN_NOT_DISPATCHED") throw err("PROVIDER_ABSENCE_REQUIRES_SEPARATE_PROOF");
        item.state = outcome; item.bufferDigest = bufferDigest;
        return { recorded: true, state: outcome };
      });
    }
    async function previewRetry({ conversationKey, context, executionId, blockVersion, selection, parserContract, credentialRevision }) {
      const selected = normalizeSelection(selection);
      if (![blockVersion, parserContract].every(nonempty) || !nonempty(credentialRevision)) throw err("RETRY_PREVIEW_INVALID");
      return mutate(conversationKey, context, data => {
        const old = predecessorFor(data, executionId, context);
        if (!unknown(old)) throw err("RETRY_UNKNOWN_REQUIRED");
        for (const item of selected) {
          const original = old.items.find(i => i.ordinal === item.ordinal);
          if (!original || (blockVersion === old.blockVersion && original.inputHash !== item.inputHash))
            throw err("RETRY_SELECTION_CHANGED");
        }
        capacity(data);
        const confirmationId = makeId(), approvalRevision = data.origins[old.blockOriginKey].approvalRevision;
        data.approvals[confirmationId] = { kind: "RETRY", confirmationId, predecessor: executionId,
          blockOriginKey: old.blockOriginKey, blockVersion, approvalRevision, selection: selected,
          parserContract, credentialRevision, context: clone(context), expiresAt: now() + BUFFER_TTL_MS,
          consumedBy: null };
        return { confirmationId, warning: RETRY_WARNING, approvalRevision, selection: selected, requiresSeparateConfirmation: true };
      });
    }
    async function confirmRetry({ conversationKey, context, confirmationId, confirmed, selection, blockVersion, parserContract, credentialRevision }) {
      if (confirmed !== true) throw err("RETRY_EXPLICIT_CONFIRMATION_REQUIRED");
      const selected = normalizeSelection(selection);
      // The command hash is computed before entering the single writer, then checked against its immutable preview.
      const current = await store.get(conversationKey), preview = ledger(current).approvals[confirmationId];
      if (!preview || preview.kind !== "RETRY") throw err("RETRY_PREVIEW_MISSING");
      const commandKey = await sha256(canonicalJson({ blockOriginKey: preview.blockOriginKey,
        blockVersion: preview.blockVersion, approvalRevision: preview.approvalRevision + 1 }));
      return mutate(conversationKey, context, data => {
        const approval = data.approvals[confirmationId];
        if (!approval || approval.kind !== "RETRY" || canonicalJson(approval.context) !== canonicalJson(context)) throw err("RETRY_PREVIEW_MISSING");
        if (canonicalJson(selected) !== canonicalJson(approval.selection) || blockVersion !== approval.blockVersion ||
            parserContract !== approval.parserContract || credentialRevision !== approval.credentialRevision) throw err("RETRY_PREVIEW_CHANGED");
        if (approval.consumedBy) return { executionId: approval.consumedBy, duplicate: true, dispatch: false };
        if (now() >= approval.expiresAt) throw err("RETRY_CONFIRMATION_EXPIRED");
        const origin = data.origins[approval.blockOriginKey];
        if (origin.approvalRevision !== approval.approvalRevision) throw err("RETRY_APPROVAL_STALE");
        predecessorFor(data, approval.predecessor, context);
        capacity(data);
        const executionId = makeId();
        origin.approvalRevision++;
        approval.consumedBy = executionId;
        data.receipts[executionId] = { executionId, commandKey, blockOriginKey: approval.blockOriginKey,
          blockVersion: approval.blockVersion, approvalRevision: origin.approvalRevision, predecessor: approval.predecessor,
          context: clone(context), createdAt: now(), payloadExpiresAt: now() + BUFFER_TTL_MS,
          ...(data.receipts[approval.predecessor]?.source ? { source: clone(data.receipts[approval.predecessor].source) } : {}),
          items: selected.map(item => ({ ...item, itemId: commandKey + ":" + item.ordinal, state: "RESERVED", providerAttemptId: null })) };
        return { executionId, commandKey, payloadExpiresAt: data.receipts[executionId].payloadExpiresAt, duplicate: false, dispatch: false, predecessor: approval.predecessor, approvalRevision: origin.approvalRevision };
      });
    }
    async function recordDeliveryBuffer({ conversationKey, context, executionId, bufferDigest, expiresAt, previousDelivery = null }) {
      if (!nonempty(bufferDigest)) throw err("RESULT_DIGEST_REQUIRED");
      const buffer = await verifiedBuffer(executionId, context);
      if (buffer.digest !== bufferDigest || buffer.expiresAt !== expiresAt) throw err("COPY_BUFFER_MISMATCH");
      return mutate(conversationKey, context, data => {
        const receipt = receiptFor(data, executionId, context);
        if (expiresAt !== receipt.payloadExpiresAt || now() >= expiresAt)
          throw err("COPY_BUFFER_MISMATCH");
        if (previousDelivery) {
          if (!nonempty(previousDelivery.deliveryId) || !["CONFIRMED", "UNKNOWN"].includes(previousDelivery.state))
            throw err("COPY_PREVIOUS_DELIVERY_REQUIRED");
          if (!data.deliveries[previousDelivery.deliveryId]) {
            capacity(data);
            data.deliveries[previousDelivery.deliveryId] = { ...clone(previousDelivery), executionId,
              bufferDigest, expiresAt, context: clone(context), original: true };
          }
        }
        receipt.deliveryBufferDigest = bufferDigest;
        return { recorded: true };
      });
    }
    async function verifiedBuffer(executionId, context) {
      await check(context);
      const buffer = await readBuffer(executionId, context);
      if (!buffer || !nonempty(buffer.digest) || typeof buffer.payload !== "string" ||
          !Number.isFinite(buffer.expiresAt) || now() >= buffer.expiresAt ||
          canonicalJson(buffer.context) !== canonicalJson(context) || await sha256(buffer.payload) !== buffer.digest)
        throw err("COPY_BUFFER_UNAVAILABLE");
      await check(context);
      return buffer;
    }
    async function previewCopy({ conversationKey, context, executionId }) {
      const buffer = await verifiedBuffer(executionId, context);
      return mutate(conversationKey, context, data => {
        const receipt = receiptFor(data, executionId, context);
        if (buffer.expiresAt !== receipt.payloadExpiresAt || !(receipt.deliveryBufferDigest === buffer.digest || receipt.items.some(i => i.state === "RESULT" && i.bufferDigest === buffer.digest)))
          throw err("COPY_BUFFER_MISMATCH");
        capacity(data);
        const confirmationId = makeId(), deliveryRevision = receipt.deliveryRevision || 0;
        data.approvals[confirmationId] = { kind: "COPY", confirmationId, executionId, deliveryRevision,
          bufferDigest: buffer.digest, expiresAt: buffer.expiresAt, context: clone(context), consumedBy: null };
        return { confirmationId, deliveryRevision, bufferDigest: buffer.digest, expiresAt: buffer.expiresAt,
          requiresSeparateConfirmation: true };
      });
    }
    async function confirmCopy({ conversationKey, context, confirmationId, confirmed }) {
      if (confirmed !== true) throw err("COPY_EXPLICIT_CONFIRMATION_REQUIRED");
      const preview = ledger(await store.get(conversationKey)).approvals[confirmationId];
      if (!preview || preview.kind !== "COPY") throw err("COPY_PREVIEW_MISSING");
      const buffer = await verifiedBuffer(preview.executionId, context);
      return mutate(conversationKey, context, data => {
        const approval = data.approvals[confirmationId];
        if (!approval || approval.kind !== "COPY" || canonicalJson(approval.context) !== canonicalJson(context)) throw err("COPY_PREVIEW_MISSING");
        const receipt = receiptFor(data, approval.executionId, context);
        if (now() >= approval.expiresAt || buffer.digest !== approval.bufferDigest || buffer.expiresAt !== approval.expiresAt)
          throw err("COPY_BUFFER_UNAVAILABLE");
        if (approval.consumedBy) return { deliveryId: approval.consumedBy, duplicate: true, send: false };
        if ((receipt.deliveryRevision || 0) !== approval.deliveryRevision) throw err("COPY_CONFIRMATION_STALE");
        capacity(data);
        const deliveryId = makeId();
        receipt.deliveryRevision = approval.deliveryRevision + 1; approval.consumedBy = deliveryId;
        data.deliveries[deliveryId] = { deliveryId, executionId: receipt.executionId, state: "COPY_RESERVED",
          confirmationId, bufferDigest: buffer.digest, expiresAt: buffer.expiresAt,
          context: clone(context), deliveryRevision: receipt.deliveryRevision };
        return { deliveryId, duplicate: false, send: false };
      });
    }
    async function beginCopyDelivery({ conversationKey, context, deliveryId }) {
      const pending = ledger(await store.get(conversationKey)).deliveries[deliveryId];
      if (!pending) throw err("COPY_DELIVERY_MISSING");
      const buffer = await verifiedBuffer(pending.executionId, context);
      return mutate(conversationKey, context, data => {
        const delivery = data.deliveries[deliveryId];
        if (!delivery || canonicalJson(delivery.context) !== canonicalJson(context)) throw err("COPY_DELIVERY_MISSING");
        if (now() >= delivery.expiresAt || buffer.digest !== delivery.bufferDigest || buffer.expiresAt !== delivery.expiresAt)
          throw err("COPY_BUFFER_UNAVAILABLE");
        if (delivery.state !== "COPY_RESERVED") return { send: false, state: delivery.state };
        delivery.state = "DELIVERY_INTENT"; delivery.intentAt = now();
        return { send: true, deliveryId, bufferDigest: delivery.bufferDigest, expiresAt: delivery.expiresAt };
      });
    }
    async function recordCopyOutcome({ conversationKey, context, deliveryId, outcome }) {
      if (!["CONFIRMED", "UNKNOWN"].includes(outcome)) throw err("COPY_OUTCOME_INVALID");
      return mutate(conversationKey, context, data => {
        const delivery = data.deliveries[deliveryId];
        if (!delivery || canonicalJson(delivery.context) !== canonicalJson(context) || delivery.state !== "DELIVERY_INTENT")
          throw err("COPY_OUTCOME_OBSOLETE");
        delivery.state = outcome;
        return { recorded: true, state: outcome };
      });
    }
    return Object.freeze({ blockKeys, reserveCommand, beginProviderAttempt, recordProviderOutcome, recordDeliveryBuffer,
      previewRetry, confirmRetry, previewCopy, confirmCopy, beginCopyDelivery, recordCopyOutcome });
  }
  globalThis.SellerAgentsCommandLedger = Object.freeze({ createCommandLedger, RETRY_WARNING, MAX_MARKERS });
})();

;
(() => {
  "use strict";
  const fields = Object.freeze([
    "accountId",
    "storeId",
    "marketplace",
    "credentialRevision",
    "conversationKey",
    "bindingId",
    "bindingRevision",
    "workSessionId",
    "policyRevision",
    "commandHash",
    "requestId",
  ]);
  const authorityFields = Object.freeze(["scopeKey", "principalEpoch", "accessEpoch", "grantEpoch", "workGeneration", "aiFamily"]);
  function error(code = "EXECUTION_CONTEXT_CHANGED") {
    return Object.assign(
      new Error(
        "Контекст запущенного пакета изменился. Остаток остановлен; выберите магазин и явно запустите новую команду.",
      ),
      { code, execution_context_error: true, external_request_executed: false },
    );
  }
  function snapshot(input) {
    const output = {};
    for (const field of fields) {
      const value = input?.[field];
      if (
        !["string", "number"].includes(typeof value) ||
        !String(value).length ||
        (typeof value === "number" && !Number.isFinite(value))
      )
        throw error("EXECUTION_CONTEXT_MISSING");
      output[field] = value;
    }
    if (input?.authGeneration !== undefined) {
      if (!Number.isSafeInteger(input.authGeneration) || input.authGeneration < 0)
        throw error("EXECUTION_CONTEXT_MISSING");
      output.authGeneration = input.authGeneration;
    }
    if (authorityFields.some(field => input?.[field] !== undefined)) {
      for (const field of authorityFields) {
        const value = input[field];
        if (["scopeKey", "aiFamily"].includes(field) ? typeof value !== "string" || !value : !Number.isSafeInteger(value) || value < 0)
          throw error("EXECUTION_CONTEXT_MISSING");
        output[field] = value;
      }
    }
    return Object.freeze(output);
  }
  function assertSame(expected, live) {
    if (live?.active !== true || fields.some((field) => expected[field] !== live[field]) ||
        (expected.authGeneration !== undefined && expected.authGeneration !== live.authGeneration) ||
        authorityFields.some(field => expected[field] !== undefined && expected[field] !== live[field]))
      throw error();
  }
  function createGuard(expected, readCurrent) {
    const pinned = snapshot(expected);
    if (typeof readCurrent !== "function")
      throw error("EXECUTION_CONTEXT_READER_MISSING");
    async function assertCurrent() {
      const current = await readCurrent();
      assertSame(pinned, current);
      return current;
    }
    return Object.freeze({ snapshot: pinned, assertCurrent });
  }
  globalThis.SellerAgentsExecutionContext = Object.freeze({
    snapshot,
    assertSame,
    createGuard,
    error,
    fields,
    authorityFields,
  });
})();

;
(() => {
  "use strict";

  const fail = (code, message = code) => {
    throw Object.assign(new Error(message), { code });
  };
  const plain = (value) =>
    value !== null && typeof value === "object" && !Array.isArray(value);
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const forbidden = new Set(["__proto__", "constructor", "prototype"]);

  function safeMetadataTree(value, depth = 0) {
    if (depth > 64) fail("METADATA_DEPTH");
    if (Array.isArray(value)) {
      for (const child of value) safeMetadataTree(child, depth + 1);
      return;
    }
    if (!plain(value)) return;
    for (const key of Object.keys(value)) {
      if (forbidden.has(key)) fail("UNSAFE_METADATA_KEY");
      safeMetadataTree(value[key], depth + 1);
    }
  }

  function safeResponseTree(value, depth = 0, budget = { keys: 0 }) {
    if (depth > 64) fail("RESPONSE_DEPTH_EXCEEDED");
    if (typeof value === "number" && !Number.isFinite(value))
      fail("RESPONSE_NUMBER_NOT_FINITE");
    if (!value || typeof value !== "object") return;
    for (const [key, child] of Object.entries(value)) {
      if (++budget.keys > 300000) fail("RESPONSE_KEY_LIMIT");
      if (forbidden.has(key)) fail("UNSAFE_RESPONSE_KEY");
      safeResponseTree(child, depth + 1, budget);
    }
  }

  function canonical(value) {
    if (value === undefined) fail("UNDEFINED_CANONICAL_VALUE");
    if (Array.isArray(value))
      return "[" + value.map(canonical).join(",") + "]";
    if (plain(value))
      return (
        "{" +
        Object.keys(value)
          .sort()
          .map((key) => JSON.stringify(key) + ":" + canonical(value[key]))
          .join(",") +
        "}"
      );
    return JSON.stringify(value);
  }

  function dateValue(value) {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value))
      fail("INVALID_DATE");
    const milliseconds = Date.parse(value + "T00:00:00Z");
    if (
      !Number.isFinite(milliseconds) ||
      new Date(milliseconds).toISOString().slice(0, 10) !== value
    )
      fail("INVALID_DATE");
    return milliseconds;
  }

  function dateTime(value) {
    const match =
      typeof value === "string" &&
      value.match(
        /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,9})?(Z|([+-])(\d{2}):(\d{2}))$/,
      );
    if (!match) fail("INVALID_DATE_TIME");
    dateValue(match[1]);
    if (
      +match[2] > 23 ||
      +match[3] > 59 ||
      +match[4] > 59 ||
      (match[6] && (+match[7] > 23 || +match[8] > 59))
    )
      fail("INVALID_DATE_TIME");
    const milliseconds = Date.parse(value);
    if (!Number.isFinite(milliseconds)) fail("INVALID_DATE_TIME");
    return milliseconds;
  }

  const schemaKeys = new Set([
    "type",
    "required",
    "properties",
    "additionalProperties",
    "items",
    "enum",
    "minimum",
    "maximum",
    "minLength",
    "maxLength",
    "minItems",
    "maxItems",
    "format",
    "description",
    "title",
    "nullable",
  ]);

  function compileSchema(schema, depth = 0) {
    if (depth > 32 || !plain(schema)) fail("INVALID_SCHEMA");
    safeMetadataTree(schema);
    for (const key of Object.keys(schema))
      if (!schemaKeys.has(key)) fail("UNSUPPORTED_SCHEMA_KEYWORD");
    if (
      schema.type &&
      !["object", "array", "string", "number", "integer", "boolean", "null"].includes(
        schema.type,
      )
    )
      fail("INVALID_SCHEMA_TYPE");
    if (schema.properties !== undefined && !plain(schema.properties))
      fail("INVALID_SCHEMA");
    if (
      schema.additionalProperties !== undefined &&
      typeof schema.additionalProperties !== "boolean"
    )
      fail("UNSUPPORTED_SCHEMA_KEYWORD");
    if (schema.nullable !== undefined && typeof schema.nullable !== "boolean")
      fail("INVALID_SCHEMA");
    if (
      schema.enum !== undefined &&
      (!Array.isArray(schema.enum) || !schema.enum.length)
    )
      fail("INVALID_SCHEMA");
    for (const key of ["minLength", "maxLength", "minItems", "maxItems"])
      if (
        schema[key] !== undefined &&
        (!Number.isSafeInteger(schema[key]) || schema[key] < 0)
      )
        fail("INVALID_SCHEMA");
    for (const key of ["minimum", "maximum"])
      if (
        schema[key] !== undefined &&
        (typeof schema[key] !== "number" || !Number.isFinite(schema[key]))
      )
        fail("INVALID_SCHEMA");
    for (const [minimum, maximum] of [
      ["minimum", "maximum"],
      ["minLength", "maxLength"],
      ["minItems", "maxItems"],
    ])
      if (
        schema[minimum] !== undefined &&
        schema[maximum] !== undefined &&
        schema[minimum] > schema[maximum]
      )
        fail("INVALID_SCHEMA");

    if (schema.properties)
      for (const child of Object.values(schema.properties))
        compileSchema(child, depth + 1);
    if (schema.items) compileSchema(schema.items, depth + 1);
    if (
      schema.required &&
      (!Array.isArray(schema.required) ||
        schema.required.some((key) => typeof key !== "string"))
    )
      fail("INVALID_SCHEMA");
    if (schema.format && !["date", "date-time"].includes(schema.format))
      fail("UNSUPPORTED_SCHEMA_FORMAT");
    return Object.freeze(clone(schema));
  }

  function validateSchema(value, schema, path = "$", depth = 0) {
    if (depth > 64) fail("RESPONSE_DEPTH");
    if (value === null && schema.nullable) return true;
    const type = schema.type;
    if (
      (type === "object" && !plain(value)) ||
      (type === "array" && !Array.isArray(value)) ||
      (type === "string" && typeof value !== "string") ||
      (type === "number" &&
        (typeof value !== "number" || !Number.isFinite(value))) ||
      (type === "integer" && !Number.isSafeInteger(value)) ||
      (type === "boolean" && typeof value !== "boolean") ||
      (type === "null" && value !== null)
    )
      fail("SCHEMA_TYPE_MISMATCH", path);
    if (
      schema.enum &&
      !schema.enum.some((candidate) => canonical(candidate) === canonical(value))
    )
      fail("SCHEMA_ENUM", path);
    if (plain(value)) {
      for (const key of schema.required || [])
        if (!Object.hasOwn(value, key)) fail("SCHEMA_REQUIRED", path + "." + key);
      for (const [key, child] of Object.entries(value)) {
        if (forbidden.has(key)) fail("UNSAFE_RESPONSE_KEY");
        if (schema.properties?.[key])
          validateSchema(child, schema.properties[key], path + "." + key, depth + 1);
        else if (schema.additionalProperties === false)
          fail("SCHEMA_ADDITIONAL_PROPERTY", path + "." + key);
      }
    }
    if (Array.isArray(value)) {
      if (
        (schema.minItems !== undefined && value.length < schema.minItems) ||
        (schema.maxItems !== undefined && value.length > schema.maxItems)
      )
        fail("SCHEMA_ARRAY_LENGTH", path);
      if (schema.items)
        value.forEach((child, index) =>
          validateSchema(child, schema.items, path + "[" + index + "]", depth + 1),
        );
    }
    if (
      typeof value === "number" &&
      ((schema.minimum !== undefined && value < schema.minimum) ||
        (schema.maximum !== undefined && value > schema.maximum))
    )
      fail("SCHEMA_NUMBER_RANGE", path);
    if (typeof value === "string") {
      if (
        (schema.minLength !== undefined &&
          [...value].length < schema.minLength) ||
        (schema.maxLength !== undefined &&
          [...value].length > schema.maxLength)
      )
        fail("SCHEMA_STRING_LENGTH", path);
      if (schema.format === "date") dateValue(value);
      if (schema.format === "date-time") dateTime(value);
    }
    return true;
  }

  globalThis.SellerAgentsProviderResponsePolicy = Object.freeze({
    safeMetadataTree,
    safeResponseTree,
    canonical,
    dateValue,
    dateTime,
    compileSchema,
    validateSchema,
  });
})();

;
(() => {
  "use strict";

  const fail = (code) => {
    throw Object.assign(new Error(code), { code });
  };

  function responsePolicy() {
    const value = globalThis.SellerAgentsProviderResponsePolicy;
    if (
      !value ||
      typeof value.safeResponseTree !== "function" ||
      typeof value.compileSchema !== "function" ||
      typeof value.validateSchema !== "function"
    )
      fail("PROVIDER_RESPONSE_POLICY_REQUIRED");
    return value;
  }

  function safeTree(value, depth = 0, budget = { keys: 0 }) {
    return responsePolicy().safeResponseTree(value, depth, budget);
  }

  function policy(value) {
    if (value === null || value === undefined) return null;
    const dependency = responsePolicy();
    if (
      value.reviewed !== true ||
      typeof value.source_revision !== "string" ||
      !value.source_revision
    )
      fail("RESPONSE_POLICY_NOT_REVIEWED");
    if (
      value.semanticError !== undefined &&
      typeof value.semanticError !== "function"
    )
      fail("RESPONSE_POLICY_INVALID");
    return {
      ...value,
      ...(value.schema
        ? { schema: dependency.compileSchema(value.schema) }
        : {}),
    };
  }

  function verify(response, { binary = false, policy = null } = {}) {
    const details = {
      transport: "response_received",
      http: response.ok ? "success" : "error",
      parse: binary ? "binary" : "text",
      schema: "not_configured",
      semantic: "not_configured",
      source_revision: policy?.source_revision || null,
      fully_verified: false,
    };
    let value = response.parsed;
    try {
      const dependency = responsePolicy();
      const json = /(?:^|[+/])json(?:;|$)/i.test(
        String(response.responseMeta?.content_type || ""),
      );
      if (!binary && json) {
        if (
          !response.rawText.trim() &&
          [204, 205].includes(response.httpStatus)
        ) {
          value = null;
          details.parse = "empty";
        } else {
          try {
            value = JSON.parse(response.rawText);
            details.parse = "json";
          } catch (_) {
            details.parse = "invalid_json";
            fail("PROVIDER_JSON_INVALID");
          }
        }
      } else if (!binary && response.parsed !== null) {
        details.parse = "json";
      }
      if (!binary && details.parse === "json")
        dependency.safeResponseTree(value);
      if (response.ok && policy?.schema) {
        try {
          dependency.validateSchema(value, policy.schema);
          details.schema = "pass";
        } catch (error) {
          details.schema = "failed";
          throw error;
        }
      }
      if (response.ok && policy?.semanticError) {
        const error = policy.semanticError(value);
        details.semantic = error ? "error" : "pass";
        if (error)
          fail(
            /^[A-Z0-9_]{1,100}$/.test(error.code)
              ? error.code
              : "PROVIDER_SEMANTIC_ERROR",
          );
      }
      details.fully_verified =
        response.ok &&
        details.schema === "pass" &&
        details.semantic === "pass";
      return { ok: response.ok, value, details, error: null };
    } catch (error) {
      return {
        ok: false,
        value: null,
        details,
        error: {
          code: /^[A-Z0-9_]{1,100}$/.test(error.code)
            ? error.code
            : "RESPONSE_VERIFICATION_FAILED",
          stage: "response_verification",
          automatic_retry: false,
        },
      };
    }
  }

  globalThis.SellerAgentsProviderResponseVerifier = Object.freeze({
    policy,
    verify,
    safeTree,
  });
})();

;
(() => {
  "use strict";

  const fail = (code) => {
    throw Object.assign(new Error(code), { code });
  };

  function responseVerifier() {
    const value = globalThis.SellerAgentsProviderResponseVerifier;
    if (!value || typeof value.verify !== "function")
      fail("PROVIDER_RESPONSE_VERIFIER_REQUIRED");
    return value;
  }

  function verificationDetails(value) {
    if (
      !value ||
      typeof value !== "object" ||
      Array.isArray(value) ||
      typeof value.fully_verified !== "boolean" ||
      typeof value.parse !== "string"
    )
      fail("PROVIDER_RESPONSE_VERIFICATION_REQUIRED");
    return value;
  }

  function responseMeta(value) {
    if (
      !value ||
      typeof value !== "object" ||
      Array.isArray(value) ||
      typeof value.provider_http_ok !== "boolean" ||
      !Number.isInteger(value.provider_http_status) ||
      value.provider_http_status < 0 ||
      value.provider_http_status > 999
    )
      fail("PROVIDER_RESPONSE_METADATA_INVALID");
    return {
      provider_http_ok: value.provider_http_ok,
      provider_http_status: value.provider_http_status,
    };
  }

  function safeErrorCode(error) {
    return /^[A-Z0-9_]{1,100}$/.test(error?.code || "")
      ? error.code
      : "RESPONSE_PROCESSING_FAILED";
  }

  function success(details, metadata, { binary = false } = {}) {
    responseVerifier();
    const checked = verificationDetails(details);
    const http = responseMeta(metadata);
    if (typeof binary !== "boolean")
      fail("PROVIDER_RESPONSE_MODE_INVALID");
    const disposition = checked.fully_verified
      ? "VERIFIED_PROVIDER_SCHEMA_AND_SEMANTICS"
      : binary
        ? "BINARY_BYTES_CAPTURED"
        : checked.parse !== "json"
          ? "NON_JSON_BODY"
          : "STRUCTURAL_ONLY_PROVIDER_SCHEMA_PENDING";
    return Object.freeze({
      disposition,
      verification_details: checked,
      ...http,
    });
  }

  function processingFailure(error, details, metadata) {
    responseVerifier();
    const checked = verificationDetails(details);
    const http = responseMeta(metadata);
    const code = safeErrorCode(error);
    return Object.freeze({
      disposition:
        code === "PROVIDER_JSON_INVALID"
          ? "MALFORMED_DECLARED_JSON"
          : "RESPONSE_PROCESSING_FAILED",
      verification_details: checked,
      error: Object.freeze({
        code,
        stage: "response_processing",
        automatic_retry: false,
      }),
      ...http,
      body_omitted: true,
      raw_capture_policy: Object.freeze({ chat_access_blocked: true }),
    });
  }

  globalThis.SellerAgentsProviderResponseDisposition = Object.freeze({
    success,
    processingFailure,
  });
})();

;
(() => {
  "use strict";

  const fail = (code) => {
    throw Object.assign(new Error(code), { code });
  };

  function responseDisposition() {
    const value = globalThis.SellerAgentsProviderResponseDisposition;
    if (
      !value ||
      typeof value !== "object" ||
      typeof value.success !== "function" ||
      typeof value.processingFailure !== "function"
    )
      fail("PROVIDER_RESPONSE_DISPOSITION_REQUIRED");
    return value;
  }

  function verificationDetails(value) {
    if (
      !value ||
      typeof value !== "object" ||
      Array.isArray(value) ||
      typeof value.fully_verified !== "boolean" ||
      typeof value.parse !== "string" ||
      typeof value.schema !== "string" ||
      typeof value.semantic !== "string"
    )
      fail("PROVIDER_RESPONSE_DISPOSITION_INVALID");
    return value;
  }

  function responseMetadata(value) {
    if (
      typeof value.provider_http_ok !== "boolean" ||
      !Number.isInteger(value.provider_http_status) ||
      value.provider_http_status < 0 ||
      value.provider_http_status > 999
    )
      fail("PROVIDER_RESPONSE_DISPOSITION_INVALID");
    return value;
  }

  function descriptor(value) {
    if (!value || typeof value !== "object" || Array.isArray(value))
      fail("PROVIDER_RESPONSE_ARTIFACT_DESCRIPTOR_INVALID");
    const ref = value.ref;
    const sha256 = value.sha256;
    const byteLength = value.byte_length;
    if (
      typeof ref !== "string" ||
      !ref ||
      ref !== ref.trim() ||
      ref.length > 512 ||
      typeof sha256 !== "string" ||
      !/^[a-f0-9]{64}$/.test(sha256) ||
      !Number.isSafeInteger(byteLength) ||
      byteLength < 0
    )
      fail("PROVIDER_RESPONSE_ARTIFACT_DESCRIPTOR_INVALID");
    return Object.freeze({
      ref,
      sha256,
      byte_length: byteLength,
    });
  }

  function byteLength(value) {
    if (!Number.isSafeInteger(value) || value < 0)
      fail("PROVIDER_RESPONSE_BYTE_LENGTH_INVALID");
    return value;
  }

  function failureDisposition(value) {
    responseDisposition();
    if (!value || typeof value !== "object" || Array.isArray(value))
      fail("PROVIDER_RESPONSE_FAILURE_DISPOSITION_REQUIRED");
    try {
      verificationDetails(value.verification_details);
      responseMetadata(value);
    } catch (_) {
      fail("PROVIDER_RESPONSE_FAILURE_DISPOSITION_REQUIRED");
    }
    const error = value.error;
    const expectedDisposition =
      error?.code === "PROVIDER_JSON_INVALID"
        ? "MALFORMED_DECLARED_JSON"
        : "RESPONSE_PROCESSING_FAILED";
    if (
      !error ||
      typeof error !== "object" ||
      Array.isArray(error) ||
      !/^[A-Z0-9_]{1,100}$/.test(error.code || "") ||
      error.stage !== "response_processing" ||
      error.automatic_retry !== false ||
      value.disposition !== expectedDisposition ||
      value.body_omitted !== true ||
      value.raw_capture_policy?.chat_access_blocked !== true
    )
      fail("PROVIDER_RESPONSE_FAILURE_DISPOSITION_REQUIRED");
    return value;
  }

  function binaryDisposition(value) {
    responseDisposition();
    if (!value || typeof value !== "object" || Array.isArray(value))
      fail("PROVIDER_RESPONSE_BINARY_DISPOSITION_REQUIRED");
    let details;
    try {
      details = verificationDetails(value.verification_details);
      responseMetadata(value);
    } catch (_) {
      fail("PROVIDER_RESPONSE_BINARY_DISPOSITION_REQUIRED");
    }
    const verificationPass =
      details.schema === "pass" && details.semantic === "pass";
    if (details.fully_verified !== verificationPass)
      fail("PROVIDER_RESPONSE_BINARY_DISPOSITION_REQUIRED");
    const expectedDisposition = verificationPass
      ? "VERIFIED_PROVIDER_SCHEMA_AND_SEMANTICS"
      : "BINARY_BYTES_CAPTURED";
    if (
      value.disposition !== expectedDisposition ||
      details.parse !== "binary" ||
      value.provider_http_ok !== true
    )
      fail("PROVIDER_RESPONSE_BINARY_DISPOSITION_REQUIRED");
    return value;
  }

  function quarantineDefault(disposition) {
    failureDisposition(disposition);
    return Object.freeze({
      stored_locally: false,
      raw_retention_failed: true,
      chat_access_blocked: true,
    });
  }

  function quarantineStored(disposition, storedDescriptor) {
    failureDisposition(disposition);
    const stored = descriptor(storedDescriptor);
    return Object.freeze({
      stored_locally: true,
      ref: stored.ref,
      sha256: stored.sha256,
      byte_length: stored.byte_length,
      chat_access_blocked: true,
    });
  }

  function binaryStored(disposition, storedDescriptor, payloadByteLength) {
    binaryDisposition(disposition);
    const stored = descriptor(storedDescriptor);
    const length = byteLength(payloadByteLength);
    if (stored.byte_length !== length)
      fail("PROVIDER_RESPONSE_BYTE_LENGTH_INVALID");
    return Object.freeze({
      artifact_refs: Object.freeze([stored]),
      delivery_error: null,
      result_policy: Object.freeze({
        artifact: stored,
        byte_length: length,
        delivery_status: "PREPARED_NOT_ATTACHED",
      }),
    });
  }

  function binaryStorageFailed(disposition, payloadByteLength) {
    const checked = binaryDisposition(disposition);
    const length = byteLength(payloadByteLength);
    const deliveryError = Object.freeze({
      code: "ARTIFACT_STORAGE_FAILED",
      provider_http_status: checked.provider_http_status,
      provider_ok: true,
      automatic_retry: false,
    });
    return Object.freeze({
      artifact_refs: Object.freeze([]),
      delivery_error: deliveryError,
      result_policy: Object.freeze({
        byte_length: length,
        delivery_error: deliveryError,
        bytes_preserved_in_result: true,
      }),
    });
  }

  globalThis.SellerAgentsProviderResponseRetention = Object.freeze({
    quarantineDefault,
    quarantineStored,
    binaryStored,
    binaryStorageFailed,
  });
})();

;
(() => {
  "use strict";

  const STATES = Object.freeze({
    NOT_DISPATCHED: "NOT_DISPATCHED",
    DISPATCH_INTENT_COMMITTED: "DISPATCH_INTENT_COMMITTED",
    RESPONSE_RECEIVED: "RESPONSE_RECEIVED",
    RETRY_WAIT_KNOWN: "RETRY_WAIT_KNOWN",
    OUTCOME_UNKNOWN: "OUTCOME_UNKNOWN",
    COMPLETED_KNOWN: "COMPLETED_KNOWN",
    FAILED_KNOWN: "FAILED_KNOWN",
  });
  const MAX_HISTORY = 8;
  const UNKNOWN_RETENTION_MS = 60 * 60 * 1000;

  const fail = (code) => {
    throw Object.assign(new Error(code), { code });
  };

  function plainObject(value) {
    return !!value && typeof value === "object" && !Array.isArray(value);
  }

  function exactKeys(value, expected, code) {
    if (!plainObject(value)) fail(code);
    const actual = Object.keys(value).sort();
    const wanted = [...expected].sort();
    if (
      actual.length !== wanted.length ||
      actual.some((key, index) => key !== wanted[index])
    )
      fail(code);
    return value;
  }

  function safeByteLength(value, code = "PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID") {
    if (!Number.isSafeInteger(value) || value < 0) fail(code);
    return value;
  }

  function safeDescriptor(value) {
    exactKeys(
      value,
      ["ref", "sha256", "byte_length"],
      "PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID",
    );
    const ref = value.ref;
    const sha256 = value.sha256;
    if (
      typeof ref !== "string" ||
      !ref ||
      ref !== ref.trim() ||
      ref.length > 512 ||
      typeof sha256 !== "string" ||
      !/^[a-f0-9]{64}$/.test(sha256)
    )
      fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
    return Object.freeze({
      ref,
      sha256,
      byte_length: safeByteLength(value.byte_length),
    });
  }

  function text(value, max = 160) {
    const output = String(value ?? "").trim();
    return output ? output.slice(0, max) : null;
  }

  function safeIso(value, now = Date.now()) {
    const ms = Date.parse(String(value || ""));
    return Number.isFinite(ms) && ms <= Number(now)
      ? new Date(ms).toISOString()
      : new Date(Number(now)).toISOString();
  }

  function responseClassification(response) {
    const status = Number(response?.httpStatus || response?.http_status || 0);
    const retryAfter = text(
      response?.responseMeta?.retry_after ?? response?.response_meta?.retry_after,
    );
    if (status === 429) return "KNOWN_429";
    if (status === 401 || status === 403) return "KNOWN_AUTH_ERROR";
    if (status >= 200 && status < 300) return "KNOWN_SUCCESS";
    if (status >= 400) return "KNOWN_PROVIDER_ERROR";
    if (response?.external_request_executed === false) return "KNOWN_LOCAL_RESULT";
    return retryAfter ? "KNOWN_RESPONSE" : "KNOWN_RESPONSE";
  }

  function responseMetadata(response) {
    const meta = response?.responseMeta || response?.response_meta || {};
    return Object.freeze({
      http_status: Number(response?.httpStatus || response?.http_status || 0),
      ok: response?.ok === true,
      classification: responseClassification(response),
      retry_after: text(meta.retry_after),
      provider_request_id: text(meta.request_id || response?.provider_request_id),
    });
  }

  function safeVerificationDetails(value) {
    exactKeys(
      value,
      [
        "transport",
        "http",
        "parse",
        "schema",
        "semantic",
        "source_revision",
        "fully_verified",
      ],
      "PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID",
    );
    const allowedParse = new Set(["text", "json", "empty", "invalid_json", "binary"]);
    const allowedSchema = new Set(["not_configured", "pass", "failed"]);
    const allowedSemantic = new Set(["not_configured", "pass", "error"]);
    if (
      value.transport !== "response_received" ||
      !["success", "error"].includes(value.http) ||
      !allowedParse.has(value.parse) ||
      !allowedSchema.has(value.schema) ||
      !allowedSemantic.has(value.semantic) ||
      typeof value.fully_verified !== "boolean" ||
      !(
        value.source_revision === null ||
        (typeof value.source_revision === "string" &&
          value.source_revision.length > 0 &&
          value.source_revision.length <= 240)
      )
    )
      fail("PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID");
    const verified =
      value.http === "success" &&
      value.schema === "pass" &&
      value.semantic === "pass";
    if (value.fully_verified !== verified)
      fail("PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID");
    return Object.freeze({
      transport: value.transport,
      http: value.http,
      parse: value.parse,
      schema: value.schema,
      semantic: value.semantic,
      source_revision: value.source_revision,
      fully_verified: value.fully_verified,
    });
  }

  function safeProcessingError(value) {
    exactKeys(
      value,
      ["code", "stage", "automatic_retry"],
      "PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID",
    );
    if (
      !/^[A-Z0-9_]{1,100}$/.test(value.code || "") ||
      value.stage !== "response_processing" ||
      value.automatic_retry !== false
    )
      fail("PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID");
    return Object.freeze({
      code: value.code,
      stage: "response_processing",
      automatic_retry: false,
    });
  }

  function safeDisposition(value) {
    if (!plainObject(value))
      fail("PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID");
    const failure =
      value.disposition === "MALFORMED_DECLARED_JSON" ||
      value.disposition === "RESPONSE_PROCESSING_FAILED";
    exactKeys(
      value,
      failure
        ? [
            "disposition",
            "verification_details",
            "error",
            "provider_http_ok",
            "provider_http_status",
            "body_omitted",
            "raw_capture_policy",
          ]
        : [
            "disposition",
            "verification_details",
            "provider_http_ok",
            "provider_http_status",
          ],
      "PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID",
    );
    if (
      typeof value.provider_http_ok !== "boolean" ||
      !Number.isInteger(value.provider_http_status) ||
      value.provider_http_status < 0 ||
      value.provider_http_status > 999
    )
      fail("PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID");
    const details = safeVerificationDetails(value.verification_details);
    if (
      details.http !== (value.provider_http_ok ? "success" : "error")
    )
      fail("PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID");

    if (failure) {
      const error = safeProcessingError(value.error);
      const expected =
        error.code === "PROVIDER_JSON_INVALID"
          ? "MALFORMED_DECLARED_JSON"
          : "RESPONSE_PROCESSING_FAILED";
      exactKeys(
        value.raw_capture_policy,
        ["chat_access_blocked"],
        "PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID",
      );
      if (
        value.disposition !== expected ||
        value.body_omitted !== true ||
        value.raw_capture_policy.chat_access_blocked !== true ||
        details.fully_verified
      )
        fail("PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID");
      return Object.freeze({
        disposition: value.disposition,
        verification_details: details,
        error,
        provider_http_ok: value.provider_http_ok,
        provider_http_status: value.provider_http_status,
        body_omitted: true,
        raw_capture_policy: Object.freeze({ chat_access_blocked: true }),
      });
    }

    if (details.parse === "binary" && value.provider_http_ok !== true)
      fail("PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID");

    const expected = details.fully_verified
      ? "VERIFIED_PROVIDER_SCHEMA_AND_SEMANTICS"
      : details.parse === "binary"
        ? "BINARY_BYTES_CAPTURED"
        : details.parse !== "json"
          ? "NON_JSON_BODY"
          : "STRUCTURAL_ONLY_PROVIDER_SCHEMA_PENDING";
    if (value.disposition !== expected)
      fail("PROVIDER_RESPONSE_OUTCOME_DISPOSITION_INVALID");
    return Object.freeze({
      disposition: value.disposition,
      verification_details: details,
      provider_http_ok: value.provider_http_ok,
      provider_http_status: value.provider_http_status,
    });
  }

  function sameDescriptor(left, right) {
    return (
      left.ref === right.ref &&
      left.sha256 === right.sha256 &&
      left.byte_length === right.byte_length
    );
  }

  function safeQuarantineRetention(value) {
    if (!plainObject(value))
      fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
    if (value.stored_locally === false) {
      exactKeys(
        value,
        ["stored_locally", "raw_retention_failed", "chat_access_blocked"],
        "PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID",
      );
      if (
        value.raw_retention_failed !== true ||
        value.chat_access_blocked !== true
      )
        fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
      return Object.freeze({
        stored_locally: false,
        raw_retention_failed: true,
        chat_access_blocked: true,
      });
    }
    exactKeys(
      value,
      ["stored_locally", "ref", "sha256", "byte_length", "chat_access_blocked"],
      "PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID",
    );
    if (value.stored_locally !== true || value.chat_access_blocked !== true)
      fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
    const descriptor = safeDescriptor({
      ref: value.ref,
      sha256: value.sha256,
      byte_length: value.byte_length,
    });
    return Object.freeze({
      stored_locally: true,
      ref: descriptor.ref,
      sha256: descriptor.sha256,
      byte_length: descriptor.byte_length,
      chat_access_blocked: true,
    });
  }

  function safeStorageError(value, disposition) {
    exactKeys(
      value,
      ["code", "provider_http_status", "provider_ok", "automatic_retry"],
      "PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID",
    );
    if (
      value.code !== "ARTIFACT_STORAGE_FAILED" ||
      value.provider_http_status !== disposition.provider_http_status ||
      value.provider_ok !== true ||
      value.automatic_retry !== false
    )
      fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
    return Object.freeze({
      code: "ARTIFACT_STORAGE_FAILED",
      provider_http_status: value.provider_http_status,
      provider_ok: true,
      automatic_retry: false,
    });
  }

  function safeBinaryRetention(value, disposition) {
    exactKeys(
      value,
      ["artifact_refs", "delivery_error", "result_policy"],
      "PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID",
    );
    if (!Array.isArray(value.artifact_refs) || !plainObject(value.result_policy))
      fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");

    if (value.delivery_error === null) {
      if (value.artifact_refs.length !== 1)
        fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
      const artifact = safeDescriptor(value.artifact_refs[0]);
      exactKeys(
        value.result_policy,
        ["artifact", "byte_length", "delivery_status"],
        "PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID",
      );
      const policyArtifact = safeDescriptor(value.result_policy.artifact);
      const length = safeByteLength(value.result_policy.byte_length);
      if (
        !sameDescriptor(artifact, policyArtifact) ||
        artifact.byte_length !== length ||
        value.result_policy.delivery_status !== "PREPARED_NOT_ATTACHED"
      )
        fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
      return Object.freeze({
        artifact_refs: Object.freeze([artifact]),
        delivery_error: null,
        result_policy: Object.freeze({
          artifact,
          byte_length: length,
          delivery_status: "PREPARED_NOT_ATTACHED",
        }),
      });
    }

    if (value.artifact_refs.length !== 0)
      fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
    const deliveryError = safeStorageError(value.delivery_error, disposition);
    exactKeys(
      value.result_policy,
      ["byte_length", "delivery_error", "bytes_preserved_in_result"],
      "PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID",
    );
    const policyError = safeStorageError(
      value.result_policy.delivery_error,
      disposition,
    );
    const length = safeByteLength(value.result_policy.byte_length);
    if (
      value.result_policy.bytes_preserved_in_result !== true ||
      JSON.stringify(deliveryError) !== JSON.stringify(policyError)
    )
      fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
    return Object.freeze({
      artifact_refs: Object.freeze([]),
      delivery_error: deliveryError,
      result_policy: Object.freeze({
        byte_length: length,
        delivery_error: deliveryError,
        bytes_preserved_in_result: true,
      }),
    });
  }

  function attachResponseProcessing(record, disposition, retention) {
    if (
      !plainObject(record) ||
      record.state !== STATES.RESPONSE_RECEIVED ||
      !plainObject(record.response) ||
      record.response_processing !== undefined
    )
      fail("PROVIDER_RESPONSE_OUTCOME_STATE_INVALID");
    const checked = safeDisposition(disposition);
    if (
      checked.provider_http_status !== record.response.http_status ||
      checked.provider_http_ok !== record.response.ok
    )
      fail("PROVIDER_RESPONSE_OUTCOME_METADATA_MISMATCH");

    let checkedRetention;
    if (retention !== undefined && retention !== null) {
      const failure =
        checked.disposition === "MALFORMED_DECLARED_JSON" ||
        checked.disposition === "RESPONSE_PROCESSING_FAILED";
      if (failure) checkedRetention = safeQuarantineRetention(retention);
      else if (checked.verification_details.parse === "binary")
        checkedRetention = safeBinaryRetention(retention, checked);
      else fail("PROVIDER_RESPONSE_OUTCOME_RETENTION_INVALID");
    }

    const snapshot = Object.freeze({
      ...checked,
      ...(checkedRetention ? { retention: checkedRetention } : {}),
    });
    return Object.freeze({ ...record, response_processing: snapshot });
  }

  function identity(input = {}) {
    const output = {};
    for (const [key, value] of Object.entries({
      logical_execution_id: input.logical_execution_id,
      provider_attempt_id: input.provider_attempt_id,
      execution_id: input.execution_id,
      command_index: input.command_index,
      account: input.account,
      conversation: input.conversation,
      work_generation: input.work_generation,
      binding: input.binding,
      binding_revision: input.binding_revision,
      marketplace: input.marketplace,
      store: input.store,
      credential_revision: input.credential_revision,
      operation: input.operation,
      attempt_number: input.attempt_number,
    })) {
      if (value !== undefined && value !== null && String(value) !== "")
        output[key] = typeof value === "number" ? value : text(value, 240);
    }
    return output;
  }

  function createIntent(input, now = Date.now()) {
    const record = {
      schema_version: 1,
      state: STATES.DISPATCH_INTENT_COMMITTED,
      outcome: null,
      ...identity(input),
      created_at: safeIso(null, now),
      intent_committed_at: safeIso(null, now),
      response_received_at: null,
      finalized_at: null,
      response: null,
      delivery_state: "PENDING",
    };
    if (!record.provider_attempt_id || !record.logical_execution_id)
      throw Object.assign(new Error("Provider attempt identity is incomplete"), {
        code: "PROVIDER_ATTEMPT_IDENTITY_MISSING",
      });
    return Object.freeze(record);
  }

  function withState(record, state, patch = {}, now = Date.now()) {
    if (!record || typeof record !== "object")
      throw new TypeError("Provider attempt record is required");
    if (record.state === STATES.OUTCOME_UNKNOWN && state !== STATES.OUTCOME_UNKNOWN)
      throw Object.assign(new Error("UNKNOWN provider outcome cannot be replayed"), {
        code: "PROVIDER_UNKNOWN_REPLAY_FORBIDDEN",
      });
    return Object.freeze({
      ...record,
      ...patch,
      state,
      finalized_at: [
        STATES.RETRY_WAIT_KNOWN,
        STATES.OUTCOME_UNKNOWN,
        STATES.COMPLETED_KNOWN,
        STATES.FAILED_KNOWN,
      ].includes(state)
        ? safeIso(null, now)
        : record.finalized_at || null,
    });
  }

  function markResponseReceived(record, response, now = Date.now()) {
    if (record?.state === STATES.OUTCOME_UNKNOWN)
      return withState(record, STATES.OUTCOME_UNKNOWN, {}, now);
    return withState(
      record,
      STATES.RESPONSE_RECEIVED,
      {
        outcome: "KNOWN_RESPONSE",
        response: responseMetadata(response),
        response_received_at: safeIso(null, now),
      },
      now,
    );
  }

  function markKnown(record, ok, now = Date.now()) {
    if (record?.state === STATES.OUTCOME_UNKNOWN)
      return withState(record, STATES.OUTCOME_UNKNOWN, {}, now);
    const response = record.response || {};
    if (response.classification === "KNOWN_429" && response.retry_after)
      return withState(record, STATES.RETRY_WAIT_KNOWN, { outcome: "KNOWN_RESPONSE" }, now);
    return withState(
      record,
      ok === true ? STATES.COMPLETED_KNOWN : STATES.FAILED_KNOWN,
      { outcome: "KNOWN_RESPONSE" },
      now,
    );
  }

  function markUnknown(record, now = Date.now(), reason = "dispatch_started_without_durable_response") {
    return withState(
      record,
      STATES.OUTCOME_UNKNOWN,
      { outcome: "UNKNOWN_OUTCOME", unknown_reason: text(reason, 200) },
      now,
    );
  }

  function beginPermittedRetry(record, providerAttemptId, now = Date.now()) {
    if (record?.state !== STATES.RETRY_WAIT_KNOWN)
      throw Object.assign(new Error("Only a known retry wait can create a new attempt"), {
        code: "PROVIDER_RETRY_NOT_PERMITTED",
      });
    return createIntent({
      ...record,
      provider_attempt_id: providerAttemptId,
      attempt_number: Number(record.attempt_number || 1) + 1,
    }, now);
  }

  function compactHistory(history, now = Date.now(), max = MAX_HISTORY) {
    const rows = Array.isArray(history) ? history.filter((row) => row && typeof row === "object") : [];
    const retained = rows.filter((row) => {
      if ([STATES.DISPATCH_INTENT_COMMITTED, STATES.RESPONSE_RECEIVED, STATES.RETRY_WAIT_KNOWN].includes(row.state)) return true;
      const at = Date.parse(String(row.finalized_at || row.created_at || ""));
      return Number.isFinite(at) && Number(now) - at <= UNKNOWN_RETENTION_MS;
    });
    return retained.slice(-Math.max(1, Math.min(Number(max) || MAX_HISTORY, MAX_HISTORY)));
  }

  function canAutomaticallyDispatch(record) {
    return record?.state === STATES.NOT_DISPATCHED;
  }

  globalThis.SellerAgentsProviderOutcome = Object.freeze({
    STATES,
    MAX_HISTORY,
    UNKNOWN_RETENTION_MS,
    createIntent,
    markResponseReceived,
    markKnown,
    markUnknown,
    beginPermittedRetry,
    attachResponseProcessing,
    compactHistory,
    canAutomaticallyDispatch,
    responseClassification,
    responseMetadata,
  });
})();

;
(() => {
  "use strict";

  // Result recovery is deliberately a separate journal dimension from the
  // provider-attempt record.  It may contain a bounded business result, but it
  // never changes provider authority and it never creates a provider retry.
  const SCHEMA_VERSION = 1;
  const TECHNICAL_RETENTION_MS = 60 * 60 * 1000;
  const MAX_BUFFER_BYTES = 16 * 1024 * 1024;
  const RESULT_PHASES = Object.freeze({
    NONE: "NONE",
    BUFFERED: "BUFFERED",
    MATERIALIZED: "MATERIALIZED",
    EXPIRED: "EXPIRED",
    UNAVAILABLE: "UNAVAILABLE",
  });
  const DELIVERY_OUTCOMES = Object.freeze({
    NOT_ATTEMPTED: "NOT_ATTEMPTED",
    CLAIMED: "CLAIMED",
    COMMITTED: "COMMITTED",
    UNKNOWN: "DELIVERY_OUTCOME_UNKNOWN",
    CONFIRMED: "CONFIRMED",
    KNOWN_PRE_IRREVERSIBLE_FAILURE: "KNOWN_PRE_IRREVERSIBLE_FAILURE",
  });

  const text = (value, max = 320) => {
    const output = String(value ?? "").trim();
    return output ? output.slice(0, max) : null;
  };
  const number = (value, fallback = null) => {
    const output = Number(value);
    return Number.isFinite(output) ? output : fallback;
  };
  const clone = (value) => {
    if (value === undefined) return undefined;
    try {
      return structuredClone(value);
    } catch (_) {
      return JSON.parse(JSON.stringify(value));
    }
  };
  const bytes = (value) => new TextEncoder().encode(JSON.stringify(value)).byteLength;

  function contextOf(value = {}) {
    const source = value.context || value;
    return Object.freeze({
      accountId: text(source.accountId || source.account_id, 160),
      conversationKey: text(source.conversationKey || source.conversation_key, 320),
      marketplace: text(source.marketplace, 64),
      storeId: text(source.storeId || source.store_id, 240),
      bindingId: text(source.bindingId || source.binding_id, 240),
      bindingRevision: number(source.bindingRevision ?? source.binding_revision, null),
      workGeneration: text(source.workGeneration || source.work_generation || source.workSessionId || source.work_session_id, 240),
      aiSurface: text(source.aiSurface || source.ai_surface, 160),
      aiProfile: text(source.aiProfile || source.ai_profile, 240),
    });
  }

  function sameContext(left, right) {
    const a = contextOf(left);
    const b = contextOf(right);
    return [
      "accountId", "conversationKey", "marketplace", "storeId", "bindingId",
      "bindingRevision", "workGeneration", "aiSurface", "aiProfile",
    ].every((field) => a[field] === b[field]);
  }

  function sanitize(value, key = "", seen = new WeakSet()) {
    const lower = String(key).toLowerCase();
    if (["authorization", "access_token", "api_key", "apikey", "client_secret", "storage_state", "storagestate"].some((part) => lower.includes(part))) return undefined;
    if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
      return value;
    }
    if (value === undefined || typeof value === "function" || typeof value === "symbol") return undefined;
    if (typeof value === "object") {
      if (seen.has(value)) return undefined;
      seen.add(value);
      if (Array.isArray(value)) return value.map((item) => sanitize(item, key, seen)).filter((item) => item !== undefined);
      const output = {};
      for (const [childKey, childValue] of Object.entries(value)) {
        const next = sanitize(childValue, childKey, seen);
        if (next !== undefined) output[childKey] = next;
      }
      return output;
    }
    return undefined;
  }

  function bufferId(input = {}) {
    return text(input.result_buffer_id || input.buffer_id) ||
      `${text(input.logical_execution_id, 240) || "execution"}:${text(input.provider_attempt_id, 240) || "attempt"}`;
  }

  function createBuffer(input = {}, now = Date.now()) {
    const payload = sanitize({
      ok: input.ok === true,
      request_id: text(input.request_id, 240),
      operation: text(input.operation, 160),
      http_status: number(input.http_status, 0),
      external_request_executed: input.external_request_executed !== false,
      executed_command_fingerprint: text(input.executed_command_fingerprint, 160),
      report_text: text(input.report_text, 8 * 1024 * 1024),
      result: input.result,
    });
    const created = number(input.created_at_ms, now) || now;
    const expires = Math.min(
      created + TECHNICAL_RETENTION_MS,
      number(input.expires_at_ms, created + TECHNICAL_RETENTION_MS) || created + TECHNICAL_RETENTION_MS,
    );
    const base = {
      schema_version: SCHEMA_VERSION,
      phase: RESULT_PHASES.BUFFERED,
      result_buffer_id: bufferId(input),
      logical_execution_id: text(input.logical_execution_id, 240),
      provider_attempt_id: text(input.provider_attempt_id, 240),
      execution_id: text(input.execution_id, 240),
      command_index: number(input.command_index, null),
      projection_kind: text(input.projection_kind, 64) || "single",
      context: contextOf(input),
      created_at_ms: created,
      expires_at_ms: expires,
      payload: payload,
      delivery_outcome: input.delivery_outcome || DELIVERY_OUTCOMES.NOT_ATTEMPTED,
      provider_replay_forbidden: true,
    };
    if (bytes(base) > MAX_BUFFER_BYTES) {
      return Object.freeze({
        schema_version: SCHEMA_VERSION,
        phase: RESULT_PHASES.UNAVAILABLE,
        result_buffer_id: base.result_buffer_id,
        logical_execution_id: base.logical_execution_id,
        provider_attempt_id: base.provider_attempt_id,
        execution_id: base.execution_id,
        command_index: base.command_index,
        projection_kind: base.projection_kind,
        context: base.context,
        created_at_ms: created,
        expires_at_ms: expires,
        unavailable_code: "RESULT_BUFFER_TOO_LARGE",
        provider_replay_forbidden: true,
      });
    }
    return Object.freeze(base);
  }

  function expire(buffer, now = Date.now()) {
    if (!buffer || typeof buffer !== "object") return null;
    return Object.freeze({
      schema_version: SCHEMA_VERSION,
      phase: RESULT_PHASES.EXPIRED,
      result_buffer_id: text(buffer.result_buffer_id, 240),
      logical_execution_id: text(buffer.logical_execution_id, 240),
      provider_attempt_id: text(buffer.provider_attempt_id, 240),
      execution_id: text(buffer.execution_id, 240),
      command_index: number(buffer.command_index, null),
      projection_kind: text(buffer.projection_kind, 64) || "single",
      context: contextOf(buffer),
      created_at_ms: number(buffer.created_at_ms, now),
      expires_at_ms: number(buffer.expires_at_ms, now),
      expired_at_ms: now,
      provider_replay_forbidden: true,
      delivery_replay_forbidden: true,
    });
  }

  function normalize(buffer, now = Date.now()) {
    if (!buffer || typeof buffer !== "object") return null;
    if (buffer.phase === RESULT_PHASES.BUFFERED && number(buffer.expires_at_ms, 0) <= now) return expire(buffer, now);
    return buffer;
  }

  function recoveryDecision({ providerAttempt = null, resultBuffer = null, deliveryOutcome = DELIVERY_OUTCOMES.NOT_ATTEMPTED, currentContext = null, finish = false, now = Date.now() } = {}) {
    if (providerAttempt?.state === "OUTCOME_UNKNOWN") return { type: "blocked", code: "PROVIDER_OUTCOME_UNKNOWN_NO_RETRY" };
    if (finish === true) return { type: "blocked", code: "STALE_DELIVERY_CONTEXT" };
    const buffer = normalize(resultBuffer, now);
    if (!buffer || buffer.phase === RESULT_PHASES.NONE) return { type: "blocked", code: "RESULT_RECOVERY_UNAVAILABLE_NO_REPLAY" };
    if (buffer.phase === RESULT_PHASES.EXPIRED) return { type: "blocked", code: "RESULT_BUFFER_EXPIRED" };
    if (buffer.phase === RESULT_PHASES.UNAVAILABLE) return { type: "blocked", code: "RESULT_RECOVERY_UNAVAILABLE_NO_REPLAY" };
    if (currentContext && !sameContext(buffer.context, currentContext)) return { type: "blocked", code: "STALE_DELIVERY_CONTEXT" };
    if ([DELIVERY_OUTCOMES.COMMITTED, DELIVERY_OUTCOMES.UNKNOWN].includes(deliveryOutcome)) return { type: "blocked", code: "DELIVERY_OUTCOME_UNKNOWN_NO_RETRY" };
    if (deliveryOutcome === DELIVERY_OUTCOMES.CONFIRMED) return { type: "none", code: "DELIVERY_CONFIRMED" };
    return { type: "resume_local_result", code: "KNOWN_RESULT_RECOVERY_SAFE", provider_calls: 0 };
  }

  function compact(buffer, now = Date.now()) {
    if (!buffer) return null;
    return number(buffer.expires_at_ms, 0) <= now ? expire(buffer, now) : buffer;
  }

  globalThis.SellerAgentsResultRecovery = Object.freeze({
    SCHEMA_VERSION,
    TECHNICAL_RETENTION_MS,
    MAX_BUFFER_BYTES,
    RESULT_PHASES,
    DELIVERY_OUTCOMES,
    contextOf,
    sameContext,
    createBuffer,
    normalize,
    expire,
    compact,
    recoveryDecision,
  });
})();

;
(() => {
  "use strict";
  function create(ports) {
    const {
      normalizeKey,
      singleFlight,
      flights,
      preparePolicy,
      prepareCapability,
      prepareQueries,
      workerId,
      diagnostic,
      guidanceResult,
      policyErrorResult,
      planningErrorResult,
      findGroup,
      readCache,
      projectGroup,
      prepareQuota,
      groupError,
      persistQuotaWait,
      quotaMetadata,
      execute,
      groupPlanning,
      storeCache,
      cachedResult,
      acquisitionPlanning,
      executionError,
      projectSingle,
      reviewedAcquisitionProfile,
      providerId,
      coalescedOperation,
      bridgeErrorCode,
      beforeProviderDispatch,
    } = ports;
    const outcome = globalThis.SellerAgentsProviderOutcome;
    const resultRecovery = globalThis.SellerAgentsResultRecovery;
    const attemptId = () => `provider-attempt-${crypto.randomUUID()}`;
    const logicalId = (owner, index) => `${String(owner?.operation_id || owner?.run_id || ownerId)}:${index}`;
    function attemptInput(owner, entry, index, id, number = 1) {
      const context = owner?.execution_context || {};
      return {
        logical_execution_id: logicalId(owner, index),
        provider_attempt_id: id,
        execution_id: owner?.operation_id || owner?.run_id || ownerId,
        command_index: index,
        account: context.accountId,
        conversation: context.conversationKey,
        work_generation: context.workSessionId,
        binding: context.bindingId,
        binding_revision: context.bindingRevision,
        marketplace: context.marketplace || providerId,
        store: context.storeId,
        credential_revision: context.credentialRevision,
        operation: entry?.operation || entry?.command?.operation || coalescedOperation,
        attempt_number: number,
      };
    }
    function setAttempt(entry, attempt) {
      if (!attempt) return entry;
      const history = Array.isArray(entry?.provider_attempt_history)
        ? entry.provider_attempt_history
        : [];
      return {
        ...entry,
        provider_attempt: attempt,
        provider_attempt_history: outcome.compactHistory(
          history.map((row) => row.provider_attempt_id === attempt.provider_attempt_id ? attempt : row),
        ),
      };
    }
    async function commitAttemptIntent({ owner, indexes, entryForIndex, mutateOwner, ownerMatches, isCollecting, providerAttemptId }) {
      const now = Date.now();
      const attempts = new Map(indexes.map((index) => [index, outcome.createIntent(attemptInput(owner, entryForIndex(index), index, providerAttemptId), now)]));
      let stored = false;
      const next = await mutateOwner((current) => {
        if (!current || !ownerMatches(current) || !isCollecting(current) || !current.batch) return current;
        const currentEntries = [...(current.batch.entries || [])];
        for (const index of indexes) {
          const entry = currentEntries[index];
          if (!entry || entry.status !== "requesting") return current;
          const previous = Array.isArray(entry.provider_attempt_history) ? entry.provider_attempt_history : [];
          if (entry.provider_attempt?.state === outcome.STATES.DISPATCH_INTENT_COMMITTED) return current;
          currentEntries[index] = {
            ...entry,
            provider_attempt_id: providerAttemptId,
            provider_attempt: attempts.get(index),
            provider_attempt_history: outcome.compactHistory([...previous, attempts.get(index)], now),
          };
        }
        stored = true;
        return { ...current, batch: { ...current.batch, entries: currentEntries } };
      });
      return { stored, owner: next, attempts };
    }
    async function recordResponse({ indexes, mutateOwner, ownerMatches, isCollecting, providerAttemptId, response }) {
      let stored = false;
      const next = await mutateOwner((current) => {
        if (!current || !ownerMatches(current) || !isCollecting(current) || !current.batch) return current;
        const currentEntries = [...(current.batch.entries || [])];
        for (const index of indexes) {
          const entry = currentEntries[index];
          if (!entry || entry.provider_attempt_id !== providerAttemptId || !entry.provider_attempt) return current;
          currentEntries[index] = setAttempt(entry, outcome.markResponseReceived(entry.provider_attempt, response));
        }
        stored = true;
        return { ...current, batch: { ...current.batch, entries: currentEntries } };
      });
      if (!stored) throw Object.assign(new Error("Provider response receipt could not be committed"), { code: "PROVIDER_RESPONSE_RECEIPT_STORE_FAILED" });
      return next;
    }
    async function recordResultBuffer({ indexes, mutateOwner, ownerMatches, isCollecting, providerAttemptId, providerResult, projectionKind = "single" }) {
      if (!resultRecovery?.createBuffer || !providerResult) return;
      let stored = false;
      await mutateOwner((current) => {
        if (!current || !ownerMatches(current) || !isCollecting(current) || !current.batch) return current;
        const entries = [...(current.batch.entries || [])];
        for (const index of indexes) {
          const entry = entries[index];
          if (!entry || entry.provider_attempt_id !== providerAttemptId || !entry.provider_attempt) return current;
          let attempt = entry.provider_attempt;
          if (attempt.state === outcome.STATES.DISPATCH_INTENT_COMMITTED) {
            attempt = outcome.markResponseReceived(attempt, {
              ok: providerResult.ok === true,
              httpStatus: Number(providerResult.http_status || 0),
              external_request_executed: providerResult.external_request_executed !== false,
              response_meta: providerResult.response_meta,
            });
          }
          if (![outcome.STATES.RESPONSE_RECEIVED, outcome.STATES.COMPLETED_KNOWN, outcome.STATES.FAILED_KNOWN, outcome.STATES.RETRY_WAIT_KNOWN].includes(attempt.state)) return current;
          const buffer = resultRecovery.createBuffer({
            ...providerResult,
            logical_execution_id: attempt.logical_execution_id,
            provider_attempt_id: attempt.provider_attempt_id,
            execution_id: attempt.execution_id,
            command_index: attempt.command_index,
            context: {
              accountId: attempt.account,
              conversationKey: attempt.conversation,
              marketplace: attempt.marketplace,
              storeId: attempt.store,
              bindingId: attempt.binding,
              bindingRevision: attempt.binding_revision,
              workGeneration: attempt.work_generation,
            },
            expires_at_ms: current.payload_expires_at_ms,
            projection_kind: projectionKind,
          });
          entries[index] = { ...setAttempt(entry, attempt), result_buffer: buffer, result_phase: buffer.phase };
        }
        stored = true;
        return { ...current, batch: { ...current.batch, entries } };
      });
      if (!stored) throw Object.assign(new Error("Known provider result buffer could not be committed"), { code: "RESULT_BUFFER_STORE_FAILED" });
      const barrier = globalThis.__SELLER_AGENTS_TEST_HOOKS?.afterResultBufferCommit;
      if (typeof barrier === "function") await barrier({ provider_attempt_id: providerAttemptId, indexes: [...indexes] });
    }
    function bufferedProviderResult(entry) {
      const payload = entry?.result_buffer?.payload;
      if (!payload || typeof payload !== "object") return null;
      return { ...payload, result: payload.result, report_text: payload.report_text };
    }
    async function recoverBufferedSingle({ index, owner, entry, mutateOwner, ownerMatches, isCollecting }) {
      const buffer = entry?.result_buffer;
      const decision = resultRecovery?.recoveryDecision
        ? resultRecovery.recoveryDecision({ providerAttempt: entry.provider_attempt, resultBuffer: buffer, currentContext: owner.execution_context, now: Date.now() })
        : { type: "resume_local_result" };
      if (decision.type !== "resume_local_result") return decision;
      const result = bufferedProviderResult(entry);
      if (!result) return { type: "blocked", code: "RESULT_RECOVERY_UNAVAILABLE_NO_REPLAY" };
      let stored = false;
      await mutateOwner((current) => {
        if (!current || !ownerMatches(current) || !isCollecting(current) || !current.batch || Number(current.batch.next_index || 0) !== index) return current;
        const entries = [...(current.batch.entries || [])];
        const live = entries[index];
        if (!live || live.status !== "requesting" || live.provider_attempt_id !== entry.provider_attempt_id) return current;
        entries[index] = {
          ...live,
          ...setAttempt(live, outcome.markKnown(live.provider_attempt, result.ok === true)),
          status: "complete",
          request_id: result.request_id || live.request_id || null,
          http_status: Number(result.http_status || 0),
          external_request_executed: result.external_request_executed !== false,
          executed_command_fingerprint: result.executed_command_fingerprint || null,
          report_text: String(result.report_text || ""),
          request_completed_at: new Date().toISOString(),
          result_phase: resultRecovery?.RESULT_PHASES?.MATERIALIZED || "MATERIALIZED",
        };
        stored = true;
        return { ...current, batch: { ...current.batch, entries, next_index: index + 1, request_state: "idle", request_worker_session_id: null, quota_wait: null, request_quota: null } };
      });
      return stored ? { type: "recovered", code: "KNOWN_RESULT_RECOVERED", provider_calls: 0 } : { type: "blocked", code: "RESULT_RECOVERY_STORE_RACE" };
    }
    async function recoverBufferedGroup({ nextIndex, owner, group, mutateOwner, ownerMatches, isCollecting }) {
      const expectedIndexes = Array.isArray(group?.member_indexes)
        ? group.member_indexes.map((value) => Number(value))
        : [];
      if (!expectedIndexes.length || expectedIndexes[0] !== nextIndex)
        return { type: "blocked", code: "RESULT_RECOVERY_UNAVAILABLE_NO_REPLAY" };
      const members = expectedIndexes.map((index) => owner.batch.entries?.[index]);
      if (members.some((entry) => !entry || entry.status !== "requesting" || entry.result_buffer?.projection_kind !== "physical"))
        return { type: "blocked", code: "RESULT_RECOVERY_UNAVAILABLE_NO_REPLAY" };
      const decisions = members.map((entry) => resultRecovery?.recoveryDecision
        ? resultRecovery.recoveryDecision({
            providerAttempt: entry.provider_attempt,
            resultBuffer: entry.result_buffer,
            currentContext: owner.execution_context,
            now: Date.now(),
          })
        : { type: "resume_local_result" });
      const blocked = decisions.find((decision) => decision.type !== "resume_local_result");
      if (blocked) return blocked;
      const physicalResult = bufferedProviderResult(members[0]);
      if (!physicalResult) return { type: "blocked", code: "RESULT_RECOVERY_UNAVAILABLE_NO_REPLAY" };
      let logicalResults;
      try {
        logicalResults = members.map((member) => projectGroup(member, group, physicalResult));
      } catch (error) {
        logicalResults = members.map((member) => projectGroup(member, group, physicalResult, error));
      }
      let stored = false;
      await mutateOwner((current) => {
        if (!current || !ownerMatches(current) || !isCollecting(current) || !current.batch) return current;
        if (Number(current.batch.next_index || 0) !== nextIndex || current.batch.request_state !== "requesting") return current;
        const entries = [...(current.batch.entries || [])];
        for (let offset = 0; offset < expectedIndexes.length; offset += 1) {
          const index = expectedIndexes[offset];
          const entry = entries[index];
          if (!entry || entry.status !== "requesting" || String(entry.query_group_id || "") !== String(group.group_id) || !logicalResults[offset]) return current;
        }
        const completedAt = new Date().toISOString();
        for (let offset = 0; offset < expectedIndexes.length; offset += 1) {
          const index = expectedIndexes[offset];
          const entry = entries[index];
          const logicalResult = logicalResults[offset];
          entries[index] = {
            ...setAttempt(entry, finalAttempt(entry, physicalResult)),
            status: "complete",
            request_id: logicalResult.request_id || null,
            physical_request_id: logicalResult.physical_request_id || physicalResult.request_id || null,
            http_status: Number(logicalResult.http_status || 0),
            external_request_executed: logicalResult.external_request_executed === true,
            executed_command_fingerprint: logicalResult.executed_command_fingerprint || group.physical_command_fingerprint || null,
            report_text: String(logicalResult.report_text || ""),
            request_completed_at: completedAt,
            result_phase: resultRecovery?.RESULT_PHASES?.MATERIALIZED || "MATERIALIZED",
          };
        }
        stored = true;
        return {
          ...current,
          batch: {
            ...current.batch,
            entries,
            next_index: expectedIndexes[expectedIndexes.length - 1] + 1,
            request_state: "idle",
            request_worker_session_id: null,
            quota_wait: null,
            request_quota: null,
          },
        };
      });
      return stored ? { type: "recovered", code: "KNOWN_RESULT_RECOVERED", provider_calls: 0 } : { type: "blocked", code: "RESULT_RECOVERY_STORE_RACE" };
    }
    async function markRequestingUnknown({ indexes, mutateOwner, ownerMatches, isCollecting }) {
      await mutateOwner((current) => {
        if (!current || !ownerMatches(current) || !isCollecting(current) || !current.batch) return current;
        const currentEntries = [...(current.batch.entries || [])];
        let changed = false;
        for (const index of indexes) {
          const entry = currentEntries[index];
          if (!entry?.provider_attempt || entry.provider_attempt.state !== outcome.STATES.DISPATCH_INTENT_COMMITTED) continue;
          currentEntries[index] = setAttempt(entry, outcome.markUnknown(entry.provider_attempt));
          changed = true;
        }
        return changed ? { ...current, batch: { ...current.batch, entries: currentEntries } } : current;
      });
    }
    function finalAttempt(entry, result) {
      const record = entry?.provider_attempt;
      if (!record) return null;
      if (record.state === outcome.STATES.RESPONSE_RECEIVED)
        return outcome.markKnown(record, result?.ok === true);
      if (record.state === outcome.STATES.DISPATCH_INTENT_COMMITTED && result?.external_request_executed === false)
        return outcome.markKnown(
          outcome.markResponseReceived(record, {
            ok: false,
            httpStatus: Number(result?.http_status || 0),
            external_request_executed: false,
            response_meta: result?.response_meta,
          }),
          false,
        );
      if (record.state === outcome.STATES.DISPATCH_INTENT_COMMITTED)
        return outcome.markUnknown(record, Date.now(), "provider_call_or_response_not_durably_receipted");
      return record;
    }
    async function storePreDispatchDenial({ index, owner, entry, error, mutateOwner, ownerMatches, isCollecting }) {
      const result = executionError(entry.command, entry.command_fingerprint, error, 0, null);
      let stored = false;
      await mutateOwner((current) => {
        if (!current || !ownerMatches(current) || !isCollecting(current) || !current.batch) return current;
        if (Number(current.batch.next_index || 0) !== index || current.batch.request_state !== "requesting") return current;
        const entries = [...(current.batch.entries || [])];
        const currentEntry = entries[index];
        if (!currentEntry || currentEntry.status !== "requesting") return current;
        entries[index] = {
          ...currentEntry,
          status: "complete",
          request_id: result.request_id || null,
          http_status: Number(result.http_status || 0),
          external_request_executed: false,
          report_text: String(result.report_text || ""),
          request_completed_at: new Date().toISOString(),
        };
        stored = true;
        return { ...current, batch: { ...current.batch, entries, next_index: index + 1, request_state: "idle", request_worker_session_id: null, request_quota: null, quota_wait: null } };
      });
      return stored;
    }
    function process({
      conversationKey,
      ownerKind,
      ownerId,
      getOwner,
      mutateOwner,
      ownerMatches,
      isCollecting,
      failOwner,
      finalizeOwner,
    }) {
      const key = normalizeKey(conversationKey);
      const flightKey = `${String(ownerKind || "batch")}:${String(ownerId || "")}`;
      return singleFlight(flights, flightKey, async () => {
        const initialOwner = await getOwner();
        const initialEntries = Array.isArray(initialOwner?.batch?.entries)
          ? initialOwner.batch.entries
          : [];
        // Guidance and policy blocks are local results. Personal-data policy is
        // applied before any subscription probe, quota/cache scheduling or provider call.
        if (initialEntries.some((entry) => entry?.kind === "command")) {
          const policyPrepared = await preparePolicy({
            ownerKind,
            ownerId,
            getOwner,
            mutateOwner,
            ownerMatches,
            isCollecting,
            failOwner,
          });
          if (!policyPrepared?.ok)
            return policyPrepared || { ok: false, code: "BATCH_POLICY_FAILED" };
          const afterPolicy = await getOwner();
          const remainingCommands = Array.isArray(afterPolicy?.batch?.entries)
            ? afterPolicy.batch.entries.some(
                (entry) => entry?.kind === "command",
              )
            : false;
          if (remainingCommands) {
            const prepared = await prepareCapability({
              ownerKind,
              ownerId,
              getOwner,
              mutateOwner,
              ownerMatches,
              isCollecting,
              failOwner,
            });
            if (!prepared?.ok)
              return prepared || { ok: false, code: "BATCH_PLANNING_FAILED" };
            if (prepared.code === "CAPABILITY_PROBE_IN_PROGRESS")
              return { ok: true, code: "CAPABILITY_PROBE_IN_PROGRESS" };
            const queryPrepared = await prepareQueries({
              ownerKind,
              ownerId,
              getOwner,
              mutateOwner,
              ownerMatches,
              isCollecting,
              failOwner,
            });
            if (!queryPrepared?.ok)
              return (
                queryPrepared || {
                  ok: false,
                  code: "BATCH_QUERY_PLANNING_FAILED",
                }
              );
          }
        }
        while (true) {
          let owner = await getOwner();
          if (!owner || !ownerMatches(owner))
            return { ok: false, code: "BATCH_OWNER_NOT_ACTIVE" };
          if (!isCollecting(owner) || !owner.batch)
            return {
              ok: true,
              code: "BATCH_NOT_COLLECTING",
              status: owner.status || null,
            };

          const entries = Array.isArray(owner.batch.entries)
            ? owner.batch.entries
            : [];
          const nextIndex = Math.max(0, Number(owner.batch.next_index || 0));
          if (nextIndex >= entries.length)
            return await finalizeOwner(owner, entries);

          const entry = entries[nextIndex];
          if (!entry) {
            await failOwner(
              "BATCH_ENTRY_MISSING",
              `Batch entry ${nextIndex} отсутствует.`,
            );
            return { ok: false, code: "BATCH_ENTRY_MISSING" };
          }
          if (entry.status === "complete") {
            await mutateOwner((current) => {
              if (
                !current ||
                !ownerMatches(current) ||
                !isCollecting(current) ||
                !current.batch
              )
                return current;
              if (Number(current.batch.next_index || 0) !== nextIndex)
                return current;
              return {
                ...current,
                batch: { ...current.batch, next_index: nextIndex + 1 },
              };
            });
            continue;
          }
          if (entry.status === "requesting" && entry.result_buffer && !entry.query_group_id) {
            const recovered = await recoverBufferedSingle({ index: nextIndex, owner, entry, mutateOwner, ownerMatches, isCollecting });
            if (recovered.type === "recovered") {
              await diagnostic("KNOWN_RESULT_RECOVERED_NO_PROVIDER_REPLAY", { owner_kind: ownerKind, owner_id: ownerId, queue_index: nextIndex, provider_attempt_id: entry.provider_attempt_id, provider_calls: 0 });
              continue;
            }
            if (recovered.type === "blocked") {
              await failOwner(recovered.code, "Известный provider result нельзя безопасно восстановить; повторный provider request запрещён.");
              return { ok: false, code: recovered.code };
            }
          }
          if (entry.status === "requesting") {
            const worker = String(owner.batch.request_worker_session_id || "");
            if (worker && worker !== workerId) {
              await markRequestingUnknown({
                indexes: [nextIndex],
                mutateOwner,
                ownerMatches,
                isCollecting,
              });
              await failOwner(
                "REQUEST_OUTCOME_UNKNOWN_NO_RETRY",
                "Service worker перезапустился во время provider request. Исход запроса неизвестен; автоматический повтор запрещён.",
              );
              await diagnostic(
                "REQUEST_RECOVERY_BLOCKED_NO_RETRY",
                {
                  owner_kind: ownerKind,
                  owner_id: ownerId,
                  queue_index: nextIndex,
                  previous_worker_session_id: worker,
                  worker_session_id: workerId,
                },
                { level: "error" },
              );
              return { ok: false, code: "REQUEST_OUTCOME_UNKNOWN_NO_RETRY" };
            }
            return { ok: true, code: "REQUEST_IN_PROGRESS" };
          }

          if (
            entry.kind === "pre_execution_error" ||
            entry.kind === "guidance"
          ) {
            const guidance = guidanceResult(entry);
            if (entry.kind === "pre_execution_error")
              await diagnostic("GUIDANCE_ATTEMPT_CLASSIFIED", {
                owner_kind: ownerKind,
                owner_id: ownerId,
                code: entry.error?.code || "INVALID_COMMAND",
                status: guidance.status,
                cluster: guidance.cluster,
                external_request_executed: false,
              });
            else
              await diagnostic("GUIDANCE_CLUSTER_SELECTED", {
                owner_kind: ownerKind,
                owner_id: ownerId,
                status: guidance.status,
                cluster: guidance.cluster,
                external_request_executed: false,
              });
            const result = guidance;
            let stored = false;
            await mutateOwner((current) => {
              if (
                !current ||
                !ownerMatches(current) ||
                !isCollecting(current) ||
                !current.batch
              )
                return current;
              if (Number(current.batch.next_index || 0) !== nextIndex)
                return current;
              const currentEntries = [...(current.batch.entries || [])];
              const currentEntry = currentEntries[nextIndex];
              if (!currentEntry || currentEntry.status !== "pending")
                return current;
              currentEntries[nextIndex] = {
                ...currentEntry,
                status: "complete",
                request_id: result.request_id,
                http_status: 0,
                external_request_executed: false,
                report_text: result.report_text,
                request_completed_at: new Date().toISOString(),
              };
              stored = true;
              return {
                ...current,
                batch: {
                  ...current.batch,
                  entries: currentEntries,
                  next_index: nextIndex + 1,
                  request_state: "idle",
                  request_worker_session_id: null,
                },
              };
            });
            if (!stored) return { ok: false, code: "BATCH_ENTRY_STORE_RACE" };
            await diagnostic(
              "BATCH_PREEXEC_RESULT_STORED",
              {
                owner_kind: ownerKind,
                owner_id: ownerId,
                queue_index: nextIndex,
                code: entry.error?.code || entry.guidance?.status || "GUIDANCE",
                external_request_executed: false,
              },
              { level: "warning" },
            );
            continue;
          }

          if (entry.kind === "policy_error") {
            const result = policyErrorResult(
              entry.command,
              entry.command_fingerprint,
            );
            let stored = false;
            await mutateOwner((current) => {
              if (
                !current ||
                !ownerMatches(current) ||
                !isCollecting(current) ||
                !current.batch
              )
                return current;
              if (Number(current.batch.next_index || 0) !== nextIndex)
                return current;
              const currentEntries = [...(current.batch.entries || [])];
              const currentEntry = currentEntries[nextIndex];
              if (
                !currentEntry ||
                currentEntry.status !== "pending" ||
                currentEntry.kind !== "policy_error"
              )
                return current;
              currentEntries[nextIndex] = {
                ...currentEntry,
                status: "complete",
                request_id: result.request_id,
                http_status: 0,
                external_request_executed: false,
                report_text: result.report_text,
                request_completed_at: new Date().toISOString(),
              };
              stored = true;
              return {
                ...current,
                batch: {
                  ...current.batch,
                  entries: currentEntries,
                  next_index: nextIndex + 1,
                  request_state: "idle",
                  request_worker_session_id: null,
                },
              };
            });
            if (!stored)
              return { ok: false, code: "BATCH_POLICY_RESULT_STORE_RACE" };
            await diagnostic(
              "BATCH_PERSONAL_DATA_POLICY_RESULT_STORED",
              {
                owner_kind: ownerKind,
                owner_id: ownerId,
                queue_index: nextIndex,
                operation: entry.operation,
                code: "OPERATION_DISABLED_BY_USER",
                external_request_executed: false,
              },
              { level: "warning" },
            );
            continue;
          }

          if (entry.kind === "planning_error") {
            const plan = {
              error: entry.error || {},
              planning: entry.planning || null,
            };
            const result = planningErrorResult(
              entry.command,
              entry.command_fingerprint,
              plan,
            );
            let stored = false;
            await mutateOwner((current) => {
              if (
                !current ||
                !ownerMatches(current) ||
                !isCollecting(current) ||
                !current.batch
              )
                return current;
              if (Number(current.batch.next_index || 0) !== nextIndex)
                return current;
              const currentEntries = [...(current.batch.entries || [])];
              const currentEntry = currentEntries[nextIndex];
              if (
                !currentEntry ||
                currentEntry.status !== "pending" ||
                currentEntry.kind !== "planning_error"
              )
                return current;
              currentEntries[nextIndex] = {
                ...currentEntry,
                status: "complete",
                request_id: result.request_id,
                http_status: 0,
                external_request_executed: false,
                report_text: result.report_text,
                request_completed_at: new Date().toISOString(),
              };
              stored = true;
              return {
                ...current,
                batch: {
                  ...current.batch,
                  entries: currentEntries,
                  next_index: nextIndex + 1,
                  request_state: "idle",
                  request_worker_session_id: null,
                },
              };
            });
            if (!stored)
              return { ok: false, code: "BATCH_PLANNING_RESULT_STORE_RACE" };
            await diagnostic(
              "BATCH_CAPABILITY_RESULT_STORED",
              {
                owner_kind: ownerKind,
                owner_id: ownerId,
                queue_index: nextIndex,
                operation: entry.operation,
                code: entry.error?.code || "CAPABILITY_PLANNING_REJECTED",
                external_request_executed: false,
              },
              { level: "warning" },
            );
            continue;
          }

          if (entry.kind === "command" && entry.query_group_id) {
            const group = findGroup(owner.batch, entry.query_group_id);
            if (
              !group ||
              Number(group.leader_index) !== nextIndex ||
              !Array.isArray(group.member_indexes) ||
              group.member_indexes.length < 2
            ) {
              await failOwner(
                "BATCH_QUERY_PLAN_CORRUPT",
                "Durable query plan не совпадает с текущим queue index; provider request запрещён.",
              );
              return { ok: false, code: "BATCH_QUERY_PLAN_CORRUPT" };
            }
            const expectedIndexes = group.member_indexes.map((value) =>
              Number(value),
            );
            if (
              expectedIndexes.some(
                (value, offset) => value !== nextIndex + offset,
              )
            ) {
              await failOwner(
                "BATCH_QUERY_PLAN_NONCONTIGUOUS",
                "Step 2 coalescing допускает только contiguous logical commands; provider request запрещён.",
              );
              return { ok: false, code: "BATCH_QUERY_PLAN_NONCONTIGUOUS" };
            }

            if (entry.status === "requesting" && entry.result_buffer) {
              const recovered = await recoverBufferedGroup({
                nextIndex,
                owner,
                group,
                mutateOwner,
                ownerMatches,
                isCollecting,
              });
              if (recovered.type === "recovered") {
                await diagnostic("KNOWN_RESULT_RECOVERED_NO_PROVIDER_REPLAY", {
                  owner_kind: ownerKind,
                  owner_id: ownerId,
                  queue_index: nextIndex,
                  coalescing_group_id: group.group_id,
                  provider_calls: 0,
                });
                continue;
              }
              if (recovered.type === "blocked") {
                await failOwner(recovered.code, "Известный provider result нельзя безопасно восстановить; повторный provider request запрещён.");
                return { ok: false, code: recovered.code };
              }
            }

            const groupCacheHit = await readCache(group.physical_command);
            if (groupCacheHit.hit === true) {
              const members = expectedIndexes.map(
                (memberIndex) => owner.batch.entries[memberIndex],
              );
              const virtualPhysicalResult = {
                ok: true,
                request_id: null,
                physical_attempt_id: null,
                provider: providerId,
                executed_command_fingerprint:
                  group.physical_command_fingerprint,
                http_status: Number(groupCacheHit.http_status || 200),
                result: groupCacheHit.result,
                elapsed_ms: 0,
                rate_limit: null,
                external_request_executed: false,
                cache: groupCacheHit.cache,
              };
              const logicalResults = members.map((member) =>
                projectGroup(member, group, virtualPhysicalResult),
              );
              let cacheStored = false;
              owner = await mutateOwner((current) => {
                if (
                  !current ||
                  !ownerMatches(current) ||
                  !isCollecting(current) ||
                  !current.batch
                )
                  return current;
                if (Number(current.batch.next_index || 0) !== nextIndex)
                  return current;
                if (current.batch.request_state === "requesting")
                  return current;
                const currentEntries = [...(current.batch.entries || [])];
                for (
                  let offset = 0;
                  offset < expectedIndexes.length;
                  offset += 1
                ) {
                  const memberIndex = expectedIndexes[offset];
                  const currentEntry = currentEntries[memberIndex];
                  const logicalResult = logicalResults[offset];
                  if (
                    !currentEntry ||
                    currentEntry.status !== "pending" ||
                    !logicalResult
                  )
                    return current;
                  currentEntries[memberIndex] = {
                    ...currentEntry,
                    status: "complete",
                    request_id: logicalResult.request_id || null,
                    physical_request_id: null,
                    http_status: Number(logicalResult.http_status || 0),
                    external_request_executed: false,
                    executed_command_fingerprint:
                      group.physical_command_fingerprint || null,
                    cache_hit: true,
                    report_text: String(logicalResult.report_text || ""),
                    request_completed_at: new Date().toISOString(),
                  };
                }
                cacheStored = true;
                return {
                  ...current,
                  batch: {
                    ...current.batch,
                    entries: currentEntries,
                    next_index: expectedIndexes[expectedIndexes.length - 1] + 1,
                    request_state: "idle",
                    request_worker_session_id: null,
                    quota_wait: null,
                    request_quota: null,
                  },
                };
              });
              if (!cacheStored)
                return { ok: false, code: "PROVIDER_CACHE_RESULT_STORE_RACE" };
              await diagnostic("PROVIDER_CACHE_HIT", {
                owner_kind: ownerKind,
                owner_id: ownerId,
                queue_index: nextIndex,
                logical_count: logicalResults.length,
                coalescing_group_id: group.group_id,
                external_request_executed: false,
              });
              continue;
            }

            const quotaDecision = await prepareQuota(group.physical_command);
            if (quotaDecision.error) {
              const members = expectedIndexes.map(
                (memberIndex) => owner.batch.entries[memberIndex],
              );
              const logicalResults = members.map((member) =>
                groupError(member, group, quotaDecision.error, 0, null),
              );
              let stored = false;
              owner = await mutateOwner((current) => {
                if (
                  !current ||
                  !ownerMatches(current) ||
                  !isCollecting(current) ||
                  !current.batch
                )
                  return current;
                if (Number(current.batch.next_index || 0) !== nextIndex)
                  return current;
                const currentEntries = [...(current.batch.entries || [])];
                for (
                  let offset = 0;
                  offset < expectedIndexes.length;
                  offset += 1
                ) {
                  const memberIndex = expectedIndexes[offset];
                  const currentEntry = currentEntries[memberIndex];
                  const logicalResult = logicalResults[offset];
                  if (
                    !currentEntry ||
                    currentEntry.status !== "pending" ||
                    !logicalResult
                  )
                    return current;
                  currentEntries[memberIndex] = {
                    ...currentEntry,
                    status: "complete",
                    request_id: logicalResult.request_id || null,
                    physical_request_id: null,
                    http_status: 0,
                    external_request_executed: false,
                    executed_command_fingerprint:
                      group.physical_command_fingerprint || null,
                    report_text: String(logicalResult.report_text || ""),
                    request_completed_at: new Date().toISOString(),
                  };
                }
                stored = true;
                return {
                  ...current,
                  batch: {
                    ...current.batch,
                    entries: currentEntries,
                    next_index: expectedIndexes[expectedIndexes.length - 1] + 1,
                    request_state: "idle",
                    request_worker_session_id: null,
                    quota_wait: null,
                    request_quota: null,
                  },
                };
              });
              if (!stored)
                return { ok: false, code: "PROVIDER_QUOTA_ERROR_STORE_RACE" };
              await diagnostic(
                "PROVIDER_QUOTA_STATE_UNAVAILABLE",
                {
                  owner_kind: ownerKind,
                  owner_id: ownerId,
                  queue_index: nextIndex,
                  logical_count: logicalResults.length,
                  external_request_executed: false,
                },
                { level: "error" },
              );
              continue;
            }
            if (quotaDecision.required && !quotaDecision.allowed) {
              await persistQuotaWait({
                ownerKind,
                ownerId,
                nextIndex,
                quota: quotaDecision.quota,
                mutateOwner,
                ownerMatches,
                isCollecting,
                groupId: group.group_id,
              });
              return {
                ok: true,
                code: "PROVIDER_QUOTA_WAITING",
                next_allowed_at: Number(
                  quotaDecision.quota?.next_allowed_at || 0,
                ),
              };
            }

            let groupGranted = false;
            owner = await mutateOwner((current) => {
              if (
                !current ||
                !ownerMatches(current) ||
                !isCollecting(current) ||
                !current.batch
              )
                return current;
              if (Number(current.batch.next_index || 0) !== nextIndex)
                return current;
              if (
                current.batch.query_planning_state !== "complete" ||
                !["idle", "quota_waiting"].includes(
                  String(current.batch.request_state || "idle"),
                )
              )
                return current;
              const liveGroup = findGroup(current.batch, entry.query_group_id);
              if (!liveGroup || Number(liveGroup.leader_index) !== nextIndex)
                return current;
              const currentEntries = [...(current.batch.entries || [])];
              for (const memberIndex of expectedIndexes) {
                const member = currentEntries[memberIndex];
                if (
                  !member ||
                  member.kind !== "command" ||
                  member.status !== "pending" ||
                  String(member.query_group_id || "") !== String(group.group_id)
                )
                  return current;
              }
              const startedAt = new Date().toISOString();
              for (const memberIndex of expectedIndexes)
                currentEntries[memberIndex] = {
                  ...currentEntries[memberIndex],
                  status: "requesting",
                  request_started_at: startedAt,
                };
              groupGranted = true;
              return {
                ...current,
                last_operation: coalescedOperation,
                batch: {
                  ...current.batch,
                  entries: currentEntries,
                  request_state: "requesting",
                  request_worker_session_id: workerId,
                  quota_wait: null,
                  request_quota: quotaMetadata(quotaDecision.quota),
                },
              };
            });
            if (!groupGranted) continue;

            if (typeof beforeProviderDispatch === "function") await beforeProviderDispatch();
            const groupProviderAttemptId = attemptId();
            const groupIntent = await commitAttemptIntent({
              owner,
              indexes: expectedIndexes,
              entryForIndex: (index) => owner.batch.entries[index],
              mutateOwner,
              ownerMatches,
              isCollecting,
              providerAttemptId: groupProviderAttemptId,
            });
            if (!groupIntent.stored) {
              await failOwner("PROVIDER_ATTEMPT_INTENT_STORE_RACE", "Provider dispatch intent was not durably committed; provider request suppressed.");
              return { ok: false, code: "PROVIDER_ATTEMPT_INTENT_STORE_RACE" };
            }
            owner = groupIntent.owner;

            const liveEntries = owner.batch.entries;
            const liveMembers = expectedIndexes.map(
              (memberIndex) => liveEntries[memberIndex],
            );
            const liveLeader = liveMembers[0];
            await diagnostic("BATCH_COALESCED_REQUEST_STARTED", {
              owner_kind: ownerKind,
              owner_id: ownerId,
              queue_index: nextIndex,
              queue_total: liveEntries.length,
              coalescing_group_id: group.group_id,
              logical_count: liveMembers.length,
              physical_command_fingerprint: group.physical_command_fingerprint,
              physical_metrics: group.physical_metrics,
            });

            const requestStartedAt = Date.now();
            const physicalAttemptId = `physical-attempt-${crypto.randomUUID()}`;
            let physicalResult = null;
            let logicalResults;
            let providerResponse = null;
            try {
              physicalResult = {
                ...(await execute(liveLeader.command_text, {
                  executionCommand: group.physical_command,
                  planning: groupPlanning(
                    liveLeader,
                    group,
                    physicalAttemptId,
                    group.physical_command_fingerprint,
                  ),
                  quotaPermit: quotaDecision.quota,
                  providerAttemptId: groupProviderAttemptId,
                  logicalExecutionId: logicalId(owner, nextIndex),
                  onProviderResponse: (response) => {
                    providerResponse = response?.response || response;
                  },
                  onProviderResult: async (value) => {
                    await recordResultBuffer({
                      indexes: expectedIndexes,
                      mutateOwner,
                      ownerMatches,
                      isCollecting,
                      providerAttemptId: groupProviderAttemptId,
                      providerResult: value?.provider_result || value,
                      projectionKind: "physical",
                    });
                  },
                })),
                physical_attempt_id: physicalAttemptId,
              };
              if (providerResponse)
                owner = await recordResponse({
                  indexes: expectedIndexes,
                  mutateOwner,
                  ownerMatches,
                  isCollecting,
                  providerAttemptId: groupProviderAttemptId,
                  response: providerResponse,
                });
              if (physicalResult.ok === true) {
                await storeCache(group.physical_command, physicalResult, null);
                try {
                  logicalResults = liveMembers.map((member) =>
                    projectGroup(member, group, physicalResult),
                  );
                } catch (projectionError) {
                  logicalResults = liveMembers.map((member) =>
                    projectGroup(
                      member,
                      group,
                      physicalResult,
                      projectionError,
                    ),
                  );
                  await diagnostic(
                    "BATCH_COALESCED_PROJECTION_FAILED",
                    {
                      owner_kind: ownerKind,
                      owner_id: ownerId,
                      coalescing_group_id: group.group_id,
                      physical_request_id: physicalResult.request_id || null,
                      code: String(
                        projectionError?.code ||
                          "ANALYTICS_COALESCED_RESPONSE_UNPROJECTABLE",
                      ),
                    },
                    { level: "error" },
                  );
                }
              } else {
                logicalResults = liveMembers.map((member) =>
                  projectGroup(member, group, physicalResult),
                );
              }
            } catch (error) {
              logicalResults = liveMembers.map((member) =>
                groupError(
                  member,
                  group,
                  error,
                  Date.now() - requestStartedAt,
                  physicalAttemptId,
                ),
              );
            }

            let stored = false;
            owner = await mutateOwner((current) => {
              if (
                !current ||
                !ownerMatches(current) ||
                !isCollecting(current) ||
                !current.batch
              )
                return current;
              if (Number(current.batch.next_index || 0) !== nextIndex)
                return current;
              if (
                current.batch.request_state !== "requesting" ||
                current.batch.request_worker_session_id !== workerId
              )
                return current;
              const currentEntries = [...(current.batch.entries || [])];
              for (
                let offset = 0;
                offset < expectedIndexes.length;
                offset += 1
              ) {
                const memberIndex = expectedIndexes[offset];
                const currentEntry = currentEntries[memberIndex];
                const logicalResult = logicalResults[offset];
                if (
                  !currentEntry ||
                  currentEntry.status !== "requesting" ||
                  String(currentEntry.query_group_id || "") !==
                    String(group.group_id) ||
                  !logicalResult
                )
                  return current;
              }
              const completedAt = new Date().toISOString();
              for (
                let offset = 0;
                offset < expectedIndexes.length;
                offset += 1
              ) {
                const memberIndex = expectedIndexes[offset];
                const currentEntry = currentEntries[memberIndex];
                const logicalResult = logicalResults[offset];
                currentEntries[memberIndex] = {
                  ...setAttempt(currentEntry, finalAttempt(currentEntry, physicalResult)),
                  status: "complete",
                  request_id: logicalResult.request_id || null,
                  physical_request_id:
                    logicalResult.physical_request_id ||
                    physicalResult?.request_id ||
                    null,
                  http_status: Number(logicalResult.http_status || 0),
                  external_request_executed:
                    logicalResult.external_request_executed === true,
                  executed_command_fingerprint:
                    logicalResult.executed_command_fingerprint ||
                    group.physical_command_fingerprint ||
                    null,
                  report_text: String(logicalResult.report_text || ""),
                  request_completed_at: completedAt,
                };
              }
              const firstBridgeError = logicalResults.find(
                (result) => result?.bridge_error === true,
              );
              stored = true;
              return {
                ...current,
                batch: {
                  ...current.batch,
                  entries: currentEntries,
                  next_index: expectedIndexes[expectedIndexes.length - 1] + 1,
                  request_state: "idle",
                  request_worker_session_id: null,
                  quota_wait: null,
                  request_quota: null,
                },
                last_error: firstBridgeError
                  ? {
                      code: firstBridgeError.error?.code || bridgeErrorCode,
                      message:
                        firstBridgeError.error?.message ||
                        "Coalesced bridge execution error converted to logical results.",
                      at: new Date().toISOString(),
                      recoverable: true,
                    }
                  : null,
              };
            });
            if (!stored) {
              await failOwner(
                "BATCH_COALESCED_RESULT_STORE_RACE",
                "Coalesced provider result получен, но durable batch state изменился до atomic logical projection store. Автоматический повтор запрещён.",
              );
              return { ok: false, code: "BATCH_COALESCED_RESULT_STORE_RACE" };
            }
            await diagnostic(
              "BATCH_COALESCED_RESULTS_STORED",
              {
                owner_kind: ownerKind,
                owner_id: ownerId,
                queue_index: nextIndex,
                logical_count: logicalResults.length,
                physical_request_id: physicalResult?.request_id || null,
                physical_command_fingerprint:
                  physicalResult?.executed_command_fingerprint ||
                  group.physical_command_fingerprint ||
                  null,
                http_status: Number(
                  physicalResult?.http_status ||
                    logicalResults[0]?.http_status ||
                    0,
                ),
                external_request_executed: logicalResults.some(
                  (result) => result?.external_request_executed === true,
                ),
              },
              {
                level: logicalResults.some((result) => result?.ok === false)
                  ? "warning"
                  : "info",
              },
            );
            continue;
          }

          const requestedPhysicalCommand =
            entry.execution_command || entry.command;
          const singleCacheHit = await readCache(requestedPhysicalCommand);
          if (singleCacheHit.hit === true) {
            const result = cachedResult(entry, singleCacheHit);
            let cacheStored = false;
            owner = await mutateOwner((current) => {
              if (
                !current ||
                !ownerMatches(current) ||
                !isCollecting(current) ||
                !current.batch
              )
                return current;
              if (Number(current.batch.next_index || 0) !== nextIndex)
                return current;
              if (current.batch.request_state === "requesting") return current;
              const currentEntries = [...(current.batch.entries || [])];
              const currentEntry = currentEntries[nextIndex];
              if (
                !currentEntry ||
                currentEntry.status !== "pending" ||
                currentEntry.kind !== "command"
              )
                return current;
              currentEntries[nextIndex] = {
                ...currentEntry,
                status: "complete",
                request_id: result.request_id || null,
                http_status: Number(result.http_status || 0),
                external_request_executed: false,
                executed_command_fingerprint:
                  result.executed_command_fingerprint || null,
                cache_hit: true,
                report_text: String(result.report_text || ""),
                request_completed_at: new Date().toISOString(),
              };
              cacheStored = true;
              return {
                ...current,
                batch: {
                  ...current.batch,
                  entries: currentEntries,
                  next_index: nextIndex + 1,
                  request_state: "idle",
                  request_worker_session_id: null,
                  quota_wait: null,
                  request_quota: null,
                },
              };
            });
            if (!cacheStored)
              return { ok: false, code: "PROVIDER_CACHE_RESULT_STORE_RACE" };
            await diagnostic("PROVIDER_CACHE_HIT", {
              owner_kind: ownerKind,
              owner_id: ownerId,
              queue_index: nextIndex,
              logical_count: 1,
              operation: entry.operation,
              external_request_executed: false,
            });
            continue;
          }
          const acquisitionProfile = reviewedAcquisitionProfile(
            requestedPhysicalCommand,
          );
          const physicalCommandForQuota = acquisitionProfile?.applicable
            ? acquisitionProfile.command
            : requestedPhysicalCommand;
          const executionPlanning = acquisitionPlanning(
            entry.planning || null,
            acquisitionProfile,
          );
          const quotaDecision = await prepareQuota(physicalCommandForQuota);
          if (quotaDecision.error) {
            const result = executionError(
              entry.command,
              entry.command_fingerprint,
              quotaDecision.error,
              0,
              executionPlanning,
            );
            let stored = false;
            owner = await mutateOwner((current) => {
              if (
                !current ||
                !ownerMatches(current) ||
                !isCollecting(current) ||
                !current.batch
              )
                return current;
              if (Number(current.batch.next_index || 0) !== nextIndex)
                return current;
              const currentEntries = [...(current.batch.entries || [])];
              const currentEntry = currentEntries[nextIndex];
              if (!currentEntry || currentEntry.status !== "pending")
                return current;
              currentEntries[nextIndex] = {
                ...currentEntry,
                status: "complete",
                request_id: result.request_id || null,
                http_status: 0,
                external_request_executed: false,
                executed_command_fingerprint: null,
                report_text: String(result.report_text || ""),
                request_completed_at: new Date().toISOString(),
              };
              stored = true;
              return {
                ...current,
                batch: {
                  ...current.batch,
                  entries: currentEntries,
                  next_index: nextIndex + 1,
                  request_state: "idle",
                  request_worker_session_id: null,
                  quota_wait: null,
                  request_quota: null,
                },
              };
            });
            if (!stored)
              return { ok: false, code: "PROVIDER_QUOTA_ERROR_STORE_RACE" };
            await diagnostic(
              "PROVIDER_QUOTA_STATE_UNAVAILABLE",
              {
                owner_kind: ownerKind,
                owner_id: ownerId,
                queue_index: nextIndex,
                logical_count: 1,
                external_request_executed: false,
              },
              { level: "error" },
            );
            continue;
          }
          if (quotaDecision.required && !quotaDecision.allowed) {
            await persistQuotaWait({
              ownerKind,
              ownerId,
              nextIndex,
              quota: quotaDecision.quota,
              mutateOwner,
              ownerMatches,
              isCollecting,
            });
            return {
              ok: true,
              code: "PROVIDER_QUOTA_WAITING",
              next_allowed_at: Number(
                quotaDecision.quota?.next_allowed_at || 0,
              ),
            };
          }

          let requestGranted = false;
          owner = await mutateOwner((current) => {
            if (
              !current ||
              !ownerMatches(current) ||
              !isCollecting(current) ||
              !current.batch
            )
              return current;
            if (Number(current.batch.next_index || 0) !== nextIndex)
              return current;
            const currentEntries = [...(current.batch.entries || [])];
            const currentEntry = currentEntries[nextIndex];
            if (
              !currentEntry ||
              currentEntry.status !== "pending" ||
              currentEntry.kind !== "command"
            )
              return current;
            requestGranted = true;
            currentEntries[nextIndex] = {
              ...currentEntry,
              status: "requesting",
              request_started_at: new Date().toISOString(),
            };
            return {
              ...current,
              last_operation: currentEntry.operation || null,
              batch: {
                ...current.batch,
                entries: currentEntries,
                request_state: "requesting",
                request_worker_session_id: workerId,
                quota_wait: null,
                request_quota: quotaMetadata(quotaDecision.quota),
              },
            };
          });
          if (!requestGranted) continue;

          const pendingEntry = owner.batch.entries[nextIndex];
          if (typeof beforeProviderDispatch === "function") {
            try {
              await beforeProviderDispatch();
            } catch (error) {
              if (error?.external_request_executed === false) {
                if (await storePreDispatchDenial({ index: nextIndex, owner, entry: pendingEntry, error, mutateOwner, ownerMatches, isCollecting })) continue;
              }
              throw error;
            }
          }
          const providerAttemptId = attemptId();
          const intent = await commitAttemptIntent({
            owner,
            indexes: [nextIndex],
            entryForIndex: () => owner.batch.entries[nextIndex],
            mutateOwner,
            ownerMatches,
            isCollecting,
            providerAttemptId,
          });
          if (!intent.stored) {
            await failOwner("PROVIDER_ATTEMPT_INTENT_STORE_RACE", "Provider dispatch intent was not durably committed; provider request suppressed.");
            return { ok: false, code: "PROVIDER_ATTEMPT_INTENT_STORE_RACE" };
          }
          owner = intent.owner;

          const liveEntry = owner.batch.entries[nextIndex];
          await diagnostic("BATCH_REQUEST_STARTED", {
            owner_kind: ownerKind,
            owner_id: ownerId,
            queue_index: nextIndex,
            queue_total: owner.batch.entries.length,
            operation: liveEntry.operation,
            command_fingerprint: liveEntry.command_fingerprint,
          });
          let result;
          const requestStartedAt = Date.now();
          let providerResponse = null;
          try {
            result = await execute(liveEntry.command_text, {
              executionCommand: physicalCommandForQuota,
              planning: executionPlanning,
              quotaPermit: quotaDecision.quota,
              providerAttemptId,
              logicalExecutionId: logicalId(owner, nextIndex),
              onProviderResponse: (response) => {
                providerResponse = response?.response || response;
              },
              onProviderResult: async (value) => {
                await recordResultBuffer({
                  indexes: [nextIndex],
                  mutateOwner,
                  ownerMatches,
                  isCollecting,
                  providerAttemptId,
                  providerResult: value?.provider_result || value,
                  projectionKind: "single",
                });
              },
            });
            if (providerResponse)
              owner = await recordResponse({
                indexes: [nextIndex],
                mutateOwner,
                ownerMatches,
                isCollecting,
                providerAttemptId,
                response: providerResponse,
              });
            if (
              result?.ok === true &&
              physicalCommandForQuota.operation === coalescedOperation
            ) {
              await storeCache(
                physicalCommandForQuota,
                result,
                acquisitionProfile,
              );
              result = projectSingle(liveEntry, result, acquisitionProfile);
            }
          } catch (error) {
            try {
              result = executionError(
                liveEntry.command,
                liveEntry.command_fingerprint,
                error,
                Date.now() - requestStartedAt,
                executionPlanning,
              );
            } catch (reportError) {
              await failOwner(
                reportError.code || "BATCH_ERROR_REPORT_FAILED",
                reportError.message || String(reportError),
              );
              throw reportError;
            }
          }

          let stored = false;
          owner = await mutateOwner((current) => {
            if (
              !current ||
              !ownerMatches(current) ||
              !isCollecting(current) ||
              !current.batch
            )
              return current;
            if (Number(current.batch.next_index || 0) !== nextIndex)
              return current;
            if (
              current.batch.request_state !== "requesting" ||
              current.batch.request_worker_session_id !== workerId
            )
              return current;
            const currentEntries = [...(current.batch.entries || [])];
            const currentEntry = currentEntries[nextIndex];
            if (!currentEntry || currentEntry.status !== "requesting")
              return current;
            currentEntries[nextIndex] = {
              ...setAttempt(currentEntry, finalAttempt(currentEntry, result)),
              status: "complete",
              request_id: result.request_id || null,
              http_status: Number(result.http_status || 0),
              external_request_executed:
                result.external_request_executed !== false &&
                (result.external_request_executed === true ||
                  result.bridge_error !== true),
              executed_command_fingerprint:
                result.executed_command_fingerprint || null,
              report_text: String(result.report_text || ""),
              request_completed_at: new Date().toISOString(),
            };
            stored = true;
            return {
              ...current,
              batch: {
                ...current.batch,
                entries: currentEntries,
                next_index: nextIndex + 1,
                request_state: "idle",
                request_worker_session_id: null,
                quota_wait: null,
                request_quota: null,
              },
              last_error: result.bridge_error
                ? {
                    code: result.error?.code || bridgeErrorCode,
                    message:
                      result.error?.message ||
                      "Bridge execution error converted to batch result.",
                    at: new Date().toISOString(),
                    recoverable: true,
                  }
                : null,
            };
          });
          if (!stored) {
            await failOwner(
              "BATCH_RESULT_STORE_RACE",
              "provider result получен, но durable batch state изменился до сохранения. Автоматический повтор запрещён.",
            );
            return { ok: false, code: "BATCH_RESULT_STORE_RACE" };
          }
          await diagnostic("BATCH_RESULT_STORED", {
            owner_kind: ownerKind,
            owner_id: ownerId,
            queue_index: nextIndex,
            queue_total: owner.batch.entries.length,
            operation: liveEntry.operation,
            request_id: result.request_id || null,
            executed_command_fingerprint:
              result.executed_command_fingerprint || null,
            http_status: Number(result.http_status || 0),
            external_request_executed:
              result.external_request_executed !== false &&
              (result.external_request_executed === true ||
                result.bridge_error !== true),
          });
          if (result.stop_after_result) {
            await failOwner(result.stop_after_result, "Результат сохранён; продолжение пакета остановлено.");
            return { ok: false, code: result.stop_after_result };
          }
        }
      });
    }
    return Object.freeze({ process });
  }
  globalThis.SellerAgentsBatchQueue = Object.freeze({ create });
})();

;
(() => {
  "use strict";
  // The same async fences surround every marketplace's queue ports. The application
  // owns the durable record; the core never reads browser settings or credentials.
  async function run(options, { context, ports }) {
    const original = options;
    const check = async () => { if (context) await context.assertCurrent(); };
    const guarded = (fn) => async (...args) => {
      await check();
      const result = await fn(...args);
      await check();
      return result;
    };
    try {
      await check();
      const guardedPorts = { ...ports };
      for (const name of ["preparePolicy", "prepareCapability", "prepareQueries", "diagnostic",
        "readCache", "prepareQuota", "persistQuotaWait", "beforeProviderDispatch", "execute", "storeCache"])
        if (typeof ports[name] === "function") guardedPorts[name] = guarded(ports[name]);
      return await globalThis.SellerAgentsBatchQueue.create(guardedPorts).process({
        ...options,
        getOwner: guarded(options.getOwner),
        mutateOwner: (fn) => original.mutateOwner(async (current) => {
          await check();
          return fn(current);
        }),
        finalizeOwner: guarded(options.finalizeOwner),
      });
    } catch (error) {
      if (!error?.execution_context_error) throw error;
      const current = await original.getOwner();
      if (original.ownerMatches(current) && original.isCollecting(current))
        await original.failOwner(error.code, error.message);
      return { ok: false, code: error.code };
    }
  }
  globalThis.SellerAgentsGuardedBatchQueue = Object.freeze({ run });
})();

;
(() => {
  "use strict";
  // Only observed Retry-After deadlines. Provider-specific intervals are NOT inferred.
  function create({ read, write, namespace, now = () => Date.now() }) {
    if (typeof read !== "function" || typeof write !== "function" || !namespace)
      throw new TypeError("Quota storage ports and namespace are required");
    const queue = globalThis.SellerAgentsLocalOperations.createWriteQueue();
    function key(scope) {
      if (!/^[a-f0-9]{64}$/.test(scope)) throw new Error("INVALID_QUOTA_SCOPE");
      return `${namespace}:${scope}`;
    }
    async function get(scope) {
      const name = key(scope), record = (await read(name))[name];
      if (record != null && (!Number.isFinite(record.next_allowed_at) || record.next_allowed_at < 0))
        throw Object.assign(new Error("Quota state is invalid"), { code: "QUOTA_STATE_INVALID" });
      return record?.next_allowed_at || 0;
    }
    async function prepare(scope) {
      const deadline = await get(scope);
      return { required: deadline > now(), allowed: deadline <= now(),
        quota: { scope, next_allowed_at: deadline, source: "provider_retry_after" } };
    }
    async function observe(scope, value) {
      const text = String(value ?? "").trim();
      if (!text) return;
      const at = /^\d+(?:\.\d+)?$/.test(text) ? now() + Number(text) * 1000 : Date.parse(text);
      if (!Number.isFinite(at) || at < now() || !Number.isFinite(new Date(at).getTime())) return;
      return queue.run(async () => {
        const next_allowed_at = Math.max(await get(scope), at);
        await write({ [key(scope)]: { next_allowed_at } });
        if ((await get(scope)) < next_allowed_at)
          throw Object.assign(new Error("Quota write did not persist"), { code: "QUOTA_STORAGE_FAILED" });
      });
    }
    return Object.freeze({ prepare, observe });
  }
  globalThis.SellerAgentsObservedQuota = Object.freeze({ create });
})();

;
// Payload-free mirror, fed only after successful writes through the sole manual record store.
let manualContextOwners = new Map();
function manualContextOwnerSummary(owner) {
  return owner
    ? {
        operation_id: owner.operation_id,
        status: owner.status,
        execution_context: owner.execution_context,
      }
    : null;
}
function rememberManualContextOwners(records) {
  manualContextOwners = new Map(
    Object.entries(records || {}).map(([key, owner]) => [
      key,
      manualContextOwnerSummary(owner),
    ]),
  );
}
/* D2.2 standalone Ozon carrier. Service account/store catalog is connected in later D2/I1 steps. */
async function readBatchContextState(key, immutable, ownerIdentity = null) {
  if (await saEnabled()) return saReadContext(key, immutable, ownerIdentity);
  const data = await storageGet([
    KEYS.SELLER_CLIENT_ID,
    KEYS.SELLER_API_KEY,
    KEYS.PERFORMANCE_CLIENT_ID,
    KEYS.PERFORMANCE_CLIENT_SECRET,
    KEYS.PERSONAL_DATA_ENABLED,
    KEYS.CONVERSATION_BINDINGS,
    KEYS.WORK_SESSIONS,
  ]);
  const seller = OzonCredentials.normalizeSellerCredentials({
    clientId: data[KEYS.SELLER_CLIENT_ID] || "",
    apiKey: data[KEYS.SELLER_API_KEY] || "",
  });
  const performance = OzonCredentials.normalizePerformanceCredentials({
    clientId: data[KEYS.PERFORMANCE_CLIENT_ID] || "",
    clientSecret: data[KEYS.PERFORMANCE_CLIENT_SECRET] || "",
  });
  const binding = normalizeBindingRecord(
    data[KEYS.CONVERSATION_BINDINGS]?.[key],
    key,
  );
  const work = OzonWorkSessionModel.normalize(
    data[KEYS.WORK_SESSIONS]?.[key],
    key,
  );
  const currentOwner = manualContextOwners.get(key);
  const ownerActive =
    !ownerIdentity ||
    (currentOwner?.operation_id === ownerIdentity.operation_id &&
      manualOperationActive(currentOwner) &&
      SellerAgentsExecutionContext.fields.every(
        (field) =>
          currentOwner.execution_context?.[field] ===
          ownerIdentity.execution_context[field],
      ));
  return {
    ...immutable,
    accountId: "standalone-local-development",
    marketplace: "ozon",
    storeId: await sha256Hex(
      JSON.stringify([
        "standalone-ozon-store",
        seller.clientId,
        performance.clientId,
      ]),
    ),
    credentialRevision: await sha256Hex(
      JSON.stringify([
        "standalone-ozon-credentials",
        seller.clientId,
        seller.apiKey,
        performance.clientId,
        performance.clientSecret,
      ]),
    ),
    conversationKey: key,
    bindingId: binding?.binding_id || "unbound",
    bindingRevision: binding?.revision || 0,
    workSessionId: work.start_intent_id || "inactive",
    policyRevision:
      data[KEYS.PERSONAL_DATA_ENABLED] === true
        ? "personal-enabled"
        : "personal-disabled",
    active:
      ownerActive &&
      [
        OzonWorkSessionModel.STATES.ACTIVE_VISIBLE,
        OzonWorkSessionModel.STATES.ACTIVE_HIDDEN,
        OzonWorkSessionModel.STATES.RECOVERING,
      ].includes(work.state),
  };
}
async function captureBatchContext(key, text, requestId) {
  const immutable = { commandHash: await sha256Hex(String(text)), requestId };
  const state = await readBatchContextState(key, immutable);
  if (!state.active) return null; // A rejected pre-execution local error is never an API authorization.
  return SellerAgentsExecutionContext.snapshot(state);
}
async function createBatchExecutionGuard(owner) {
  if (await saEnabled()) return saGuard(owner);
  if (owner && !manualContextOwners.has(owner.conversation_key))
    manualContextOwners.set(
      owner.conversation_key,
      manualContextOwnerSummary(owner),
    );
  const pinned = owner?.execution_context;
  if (!pinned) {
    if ((owner?.batch?.entries || []).some((e) => e.kind === "command"))
      throw SellerAgentsExecutionContext.error("EXECUTION_CONTEXT_MISSING");
    return null;
  }
  const guard = SellerAgentsExecutionContext.createGuard(pinned, () =>
    readBatchContextState(
      owner.conversation_key,
      { commandHash: pinned.commandHash, requestId: pinned.requestId },
      owner,
    ),
  );
  await guard.assertCurrent();
  // Capture once, then verify against the pinned identity. Never retain credentials in the durable operation record.
  const settings = structuredClone(await getSettings());
  const settingsRevision = await sha256Hex(
    JSON.stringify([
      "standalone-ozon-credentials",
      settings.sellerCredentials.clientId,
      settings.sellerCredentials.apiKey,
      settings.performanceCredentials.clientId,
      settings.performanceCredentials.clientSecret,
    ]),
  );
  if (settingsRevision !== pinned.credentialRevision)
    throw SellerAgentsExecutionContext.error();
  await guard.assertCurrent();
  Object.freeze(settings.sellerCredentials);
  Object.freeze(settings.performanceCredentials);
  Object.freeze(settings);
  return Object.freeze({
    ...guard,
    async settings() {
      await guard.assertCurrent();
      return settings;
    },
  });
}
async function assertManualBatchContext(key, operationId) {
  const owner = await getManualOperation(key);
  if (!owner || owner.operation_id !== operationId)
    throw SellerAgentsExecutionContext.error();
  const guard = await createBatchExecutionGuard(owner);
  if (guard) await guard.assertCurrent();
  return guard;
}
async function runComposedBatchQueue(options) {
  const original = options;
  let context = null;
  try {
    if (options.ownerKind === "manual")
      context = await createBatchExecutionGuard(await options.getOwner());
    if (context?.snapshot.marketplace === "wildberries") return SellerAgentsGuardedBatchQueue.run(options, { context, ports: SellerAgentsWBBatch.createPorts(context, { quota: saQuota, diagnostic, workerId: WORKER_SESSION_ID, flights: batchCollectionRequests }) });
    const ports = {
      normalizeKey: normalizeConversationKey,
      singleFlight,
      flights: batchCollectionRequests,
      workerId: WORKER_SESSION_ID,
      preparePolicy: (o) =>
        ensureBatchLocalPolicy({ ...o, executionContext: context }),
      prepareCapability: (o) =>
        ensureBatchCapabilityAndPlanning({ ...o, executionContext: context }),
      prepareQueries: ensureBatchQueryPlanning,
      diagnostic,
      beforeProviderDispatch: async () => {
        if (typeof context?.assertDispatchAuthority === "function")
          await context.assertDispatchAuthority();
      },
      guidanceResult: localGuidanceResult,
      policyErrorResult: buildPersonalDataPolicyErrorResult,
      planningErrorResult: buildCapabilityPlanningErrorResult,
      findGroup: findBatchQueryGroup,
      readCache: (command) => readAnalyticsResultCacheForCurrentSettings(command, context),
      projectGroup: buildCoalescedLogicalResult,
      prepareQuota: (command) => prepareProviderQuotaForCommand(command, context),
      groupError: buildCoalescedExecutionErrorResult,
      persistQuotaWait: persistBatchQuotaWait,
      quotaMetadata: safeQuotaMetadata,
      execute: (text, opts) => executeOzonCore(text, { ...opts, executionContext: context }),
      groupPlanning: coalescedPlanningForEntry,
      storeCache: (command, result, profile) =>
        storeAnalyticsResultCacheForCurrentSettings(
          command,
          result,
          profile,
          context,
        ),
      cachedResult: buildCachedSingleResult,
      acquisitionPlanning,
      executionError: buildExecutionErrorResult,
      projectSingle: projectPrefetchedSingleResult,
      reviewedAcquisitionProfile: (command) =>
        OzonContract.reviewedAnalyticsAcquisitionProfile(command),
      providerId: "seller_api",
      coalescedOperation: "analytics_data",
      bridgeErrorCode: "OZON_BRIDGE_ERROR",
    };
    return await SellerAgentsGuardedBatchQueue.run(options, { context, ports });
  } catch (error) {
    if (!error?.execution_context_error) throw error;
    const current = await original.getOwner();
    if (original.ownerMatches(current) && original.isCollecting(current))
      await original.failOwner(error.code, error.message);
    return { ok: false, code: error.code };
  }
}

;
/* P3: one installation-local coordinator for durable technical wakes. */
(() => {
  "use strict";

  const STORAGE_KEY = "seller_agents_technical_wake_v1";
  const ALARM = "seller-agents-technical-wake-v1";
  const VERSION = 1;
  const MAX_TASKS = 32;
  const MAX_DUE_PER_WAKE = 16;
  const CLAIM_MS = 30_000;
  const RETRY_MS = 60_000;
  const PAYLOAD_TTL_MS = 60 * 60_000; // Match runtime saPrunePayload legacy created_at fallback.
  const SUBSCRIPTION_RETRY_BASE_MS = 15 * 60_000;
  const SUBSCRIPTION_RETRY_MAX_MS = 6 * 60 * 60_000;
  const KINDS = Object.freeze({
    SYNC: "C3E_PENDING_SYNC_RETRY",
    QUOTA: "KNOWN_PROVIDER_QUOTA_WAIT",
    RESULT: "KNOWN_RESULT_RECOVERY",
    EXPIRY: "TECHNICAL_BUFFER_EXPIRY",
    WORK: "SAFE_WORKER_RESTART_RECONSTRUCTION",
    SUBSCRIPTION: "SIGNED_ACCESS_REFRESH",
  });
  const allowedKinds = new Set(Object.values(KINDS));
  let readFlight = null;
  let writeFlight = Promise.resolve();
  let dispatchFlight = null;

  const text = (value, max = 240) => {
    const output = String(value ?? "").trim();
    return output ? output.slice(0, max) : null;
  };
  const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
  const clone = (value) => value === undefined ? undefined : structuredClone(value);
  const workerId = () => text(globalThis.WORKER_SESSION_ID, 160) || "worker-unknown";

  function empty() {
    return { version: VERSION, entries: {}, updatedAt: 0 };
  }

  function identity(value) {
    const source = value && typeof value === "object" ? value : {};
    const output = {};
    for (const key of [
      "accountId", "installationId", "sessionId", "conversationKey", "bindingId", "bindingRevision",
      "workGeneration", "executionId", "providerAttemptId", "deliveryId", "requestId",
      "retryGeneration", "serverTime", "ownerKind", "ownerId", "queueIndex", "artifactKey",
    ]) {
      const item = source[key];
      if (item === null || item === undefined || item === "") continue;
      output[key] = typeof item === "number" ? item : text(item, 240);
    }
    return output;
  }

  function normalize(raw) {
    const source = raw && typeof raw === "object" ? raw : empty();
    const result = { version: VERSION, entries: {}, updatedAt: finite(source.updatedAt) };
    if (source.version !== VERSION || !source.entries || typeof source.entries !== "object") return result;
    for (const [taskId, entry] of Object.entries(source.entries).slice(0, MAX_TASKS)) {
      if (!entry || !allowedKinds.has(entry.kind) || text(taskId, 320) !== taskId) continue;
      const normalized = {
        taskId,
        kind: entry.kind,
        dueAt: Math.max(0, finite(entry.dueAt)),
        revision: Math.max(1, Math.floor(finite(entry.revision, 1))),
        attempts: Math.max(0, Math.floor(finite(entry.attempts))),
        claimedUntil: Math.max(0, finite(entry.claimedUntil)),
        claimedBy: text(entry.claimedBy, 160),
        identity: identity(entry.identity),
      };
      result.entries[taskId] = normalized;
    }
    return result;
  }

  async function read() {
    if (!readFlight) readFlight = (async () => {
      const data = await chrome.storage.local.get(STORAGE_KEY);
      return normalize(data?.[STORAGE_KEY]);
    })().finally(() => { readFlight = null; });
    return readFlight;
  }

  function mutate(fn) {
    const next = writeFlight.then(fn, fn);
    writeFlight = next.catch(() => null);
    return next;
  }

  async function write(next) {
    const normalized = normalize(next);
    normalized.updatedAt = Date.now();
    await chrome.storage.local.set({ [STORAGE_KEY]: normalized });
    readFlight = null;
    return normalized;
  }

  async function arm(state) {
    const entries = Object.values(state.entries);
    if (!entries.length || !chrome.alarms?.create) {
      try { await chrome.alarms?.clear?.(ALARM); } catch (_) {}
      return;
    }
    const earliest = Math.min(...entries.map((entry) => entry.dueAt));
    await chrome.alarms.create(ALARM, { when: Math.max(Date.now() + 100, earliest) });
  }

  async function schedule(kind, { taskId, dueAt = Date.now(), identity: taskIdentity = {}, replace = true } = {}) {
    if (!allowedKinds.has(kind) || !text(taskId, 320)) return { ok: false, code: "TECHNICAL_TASK_INVALID" };
    const result = await mutate(async () => {
      const state = clone(await read());
      const current = state.entries[taskId];
      if (current && !replace && current.dueAt <= Number(dueAt)) return state;
      state.entries[taskId] = {
        taskId: String(taskId), kind, dueAt: Math.max(0, finite(dueAt, Date.now())),
        revision: current ? current.revision + 1 : 1, attempts: current?.attempts || 0,
        claimedUntil: 0, claimedBy: null, identity: identity(taskIdentity),
      };
      const entries = Object.values(state.entries).sort((a, b) => a.dueAt - b.dueAt || a.taskId.localeCompare(b.taskId));
      state.entries = Object.fromEntries(entries.slice(0, MAX_TASKS).map((entry) => [entry.taskId, entry]));
      return write(state);
    });
    await arm(result);
    return { ok: true, taskId: String(taskId) };
  }

  async function cancel(taskId) {
    const result = await mutate(async () => {
      const state = clone(await read());
      delete state.entries[String(taskId)];
      return write(state);
    });
    await arm(result);
    return { ok: true };
  }

  async function cancelKind(kind) {
    const result = await mutate(async () => {
      const state = clone(await read());
      for (const [taskId, entry] of Object.entries(state.entries)) if (entry.kind === kind) delete state.entries[taskId];
      return write(state);
    });
    await arm(result);
    return { ok: true };
  }

  async function claim(taskId, now) {
    return mutate(async () => {
      const state = clone(await read());
      const entry = state.entries[taskId];
      if (!entry || entry.dueAt > now || entry.claimedUntil > now) return null;
      entry.claimedUntil = now + CLAIM_MS;
      entry.claimedBy = workerId();
      entry.attempts += 1;
      await write(state);
      return entry;
    });
  }

  function subscriptionRetryGeneration(plan) {
    const value = plan?.identity;
    if (!value || !value.accountId || !value.deviceId || !Number.isSafeInteger(value.generation) || !Number.isSafeInteger(value.configVersion) || !value.serverTime) return null;
    return `${value.generation}:${value.configVersion}:${value.serverTime}:${value.paidThrough || ""}`;
  }

  function subscriptionRetryDelay(entry) {
    const attempt = Math.max(1, Math.floor(finite(entry?.attempts, 1)));
    const exponent = Math.min(8, attempt - 1);
    const base = Math.min(SUBSCRIPTION_RETRY_MAX_MS, SUBSCRIPTION_RETRY_BASE_MS * 2 ** exponent);
    let hash = 2166136261;
    const seed = `${entry?.taskId || ""}|${entry?.identity?.installationId || ""}|${attempt}`;
    for (const character of seed) hash = Math.imul(hash ^ character.charCodeAt(0), 16777619) >>> 0;
    const permille = 900 + hash % 201;
    return Math.min(SUBSCRIPTION_RETRY_MAX_MS, Math.max(1_000, Math.floor(base * permille / 1000)));
  }

  async function finish(entry, { failed = false } = {}) {
    const result = await mutate(async () => {
      const state = clone(await read());
      const current = state.entries[entry.taskId];
      if (!current || current.revision !== entry.revision) return state;
      if (failed) {
        current.dueAt = Date.now() + (entry.kind === KINDS.SUBSCRIPTION ? subscriptionRetryDelay(current) : RETRY_MS);
        current.claimedUntil = 0;
        current.claimedBy = null;
      } else delete state.entries[entry.taskId];
      return write(state);
    });
    await arm(result);
  }

  async function reconstruct() {
    const now = Date.now();
    try {
      const journal = globalThis.SellerAgentsSyncJournal;
      const state = await journal?.read?.();
      const pending = Object.values(state?.entries || {}).filter((entry) =>
        ["PENDING", "RETRY_WAIT"].includes(entry.status) && entry.kind !== "DELIVERY_MARKER");
      if (pending.length) {
        const first = pending.sort((a, b) => (a.nextAttemptAt || 0) - (b.nextAttemptAt || 0) || a.localSequence - b.localSequence)[0];
        const scheduled = (await read()).entries["sync:pending"];
        const sameRequest = scheduled?.identity?.requestId === first.requestId;
        const dueAt = first.nextAttemptAt || (sameRequest ? scheduled?.dueAt : 0) || now + 1000;
        await schedule(KINDS.SYNC, { taskId: "sync:pending", dueAt, identity: { requestId: first.requestId, installationId: first.installationId, retryGeneration: first.attempts } });
      } else await cancelKind(KINDS.SYNC);
    } catch (_) {}

    try {
      const keys = globalThis.OzonRuntime?.STORAGE_KEYS;
      const data = await chrome.storage.local.get([keys?.MANUAL_OPERATIONS, keys?.AUTO_RUNS, keys?.WORK_SESSION_RECOVERIES]);
      const manual = data?.[keys?.MANUAL_OPERATIONS] || {};
      const sellerAgentsEnabled = typeof globalThis.saEnabled === "function" && await globalThis.saEnabled();
      const autoruns = sellerAgentsEnabled ? {} : (data?.[keys?.AUTO_RUNS] || {});
      let quotaAt = null, quotaIdentity = {};
      for (const [conversationKey, owner] of [...Object.entries(manual), ...Object.entries(autoruns)]) {
        const wait = owner?.batch?.request_state === "quota_waiting" ? Number(owner.batch.quota_wait?.next_allowed_at || 0) : 0;
        if (wait && (quotaAt === null || wait < quotaAt)) {
          quotaAt = wait;
          quotaIdentity = { conversationKey, executionId: owner.operation_id || owner.run_id, queueIndex: owner.batch?.next_index, retryGeneration: owner.batch?.quota_wait?.waiting_since };
        }
      }
      if (quotaAt !== null) await schedule(KINDS.QUOTA, { taskId: "quota:pending", dueAt: quotaAt, identity: quotaIdentity });
      else await cancelKind(KINDS.QUOTA);

      let expiryAt = null;
      for (const owner of Object.values(manual)) {
        // Finished/expired owners retain a replay fence, not a report buffer.
        // Rescheduling their old expiry on every wake would create an alarm loop.
        if (!owner || (owner.outgoing_text == null && owner.batch == null && owner.delivery == null)) continue;
        // Legacy records can omit the explicit expiry. Match saPrunePayload's
        // created_at + one-hour fallback instead of retaining their bytes forever.
        const expiry = Number(owner.payload_expires_at_ms ||
          Date.parse(owner.created_at || "") + PAYLOAD_TTL_MS);
        const dueAt = Number.isFinite(expiry) && expiry > 0 ? expiry : now;
        expiryAt = expiryAt === null ? dueAt : Math.min(expiryAt, dueAt);
      }
      if (expiryAt !== null) await schedule(KINDS.EXPIRY, { taskId: "expiry:buffers", dueAt: expiryAt, identity: { retryGeneration: "payload" } });
      else await cancel("expiry:buffers");

      let knownResult = false, resultIdentity = {};
      for (const [conversationKey, owner] of Object.entries(manual)) {
        if (!["requesting", "collecting"].includes(String(owner?.status))) continue;
        const entry = (owner.batch?.entries || []).find((item) => item?.status === "requesting" && item.result_buffer?.phase === "BUFFERED");
        if (entry) {
          knownResult = true;
          resultIdentity = { conversationKey, executionId: owner.operation_id, providerAttemptId: entry.provider_attempt_id, bindingId: owner.execution_context?.bindingId, workGeneration: owner.execution_context?.workSessionId };
          break;
        }
      }
      if (knownResult) await schedule(KINDS.RESULT, { taskId: "result:known", dueAt: now, identity: resultIdentity });
      else await cancelKind(KINDS.RESULT);

      const recoveries = data?.[keys?.WORK_SESSION_RECOVERIES] || {};
      if (Object.keys(recoveries).length) await schedule(KINDS.WORK, { taskId: "work:recovery", dueAt: now, identity: { conversationKey: Object.keys(recoveries).sort()[0] } });
      else await cancelKind(KINDS.WORK);
    } catch (_) {}

    try {
      const taskId = "authority:refresh";
      const plan = await globalThis.SellerAgentsControlClient?.getSubscriptionRefreshPlan?.();
      const retryGeneration = subscriptionRetryGeneration(plan);
      if (!plan?.active || !retryGeneration) await cancel(taskId);
      else {
        const scheduled = (await read()).entries[taskId];
        const sameAuthority =
          scheduled?.kind === KINDS.SUBSCRIPTION &&
          scheduled?.identity?.retryGeneration === retryGeneration &&
          scheduled?.identity?.installationId === plan.identity.deviceId &&
          scheduled?.identity?.sessionId === plan.identity.sessionId &&
          scheduled?.identity?.accountId === plan.identity.accountId;
        const preserveBackoff =
          sameAuthority &&
          scheduled.attempts > 0 &&
          scheduled.claimedUntil <= now &&
          scheduled.dueAt > now;
        const dueAt = preserveBackoff
          ? scheduled.dueAt
          : sameAuthority
            ? Math.min(scheduled.dueAt, plan.dueAt)
            : plan.dueAt;
        if (scheduled && !sameAuthority) await cancel(taskId);
        await schedule(KINDS.SUBSCRIPTION, {
          taskId,
          dueAt,
          identity: {
            accountId: plan.identity.accountId,
            installationId: plan.identity.deviceId,
            sessionId: plan.identity.sessionId,
            retryGeneration,
            serverTime: plan.identity.serverTime,
          },
        });
      }
    } catch (_) {}
  }

  async function dispatch(entry) {
    if (entry.kind === KINDS.SYNC) return globalThis.SellerAgentsSyncJournal?.syncNow?.("technical_wake");
    if (entry.kind === KINDS.QUOTA) return globalThis.resumeProviderQuotaWaits?.();
    if (entry.kind === KINDS.RESULT) return globalThis.resumeKnownResultRecoveries?.();
    if (entry.kind === KINDS.EXPIRY) return globalThis.saCleanupExpiredPayloads?.();
    if (entry.kind === KINDS.WORK) return globalThis.resumeWorkSessionRecoveries?.();
    if (entry.kind === KINDS.SUBSCRIPTION) {
      const client = globalThis.SellerAgentsControlClient;
      const plan = await client?.getSubscriptionRefreshPlan?.();
      const retryGeneration = subscriptionRetryGeneration(plan);
      if (!plan?.active || !retryGeneration) return { status: "INACTIVE" };
      if (
        entry.identity?.retryGeneration !== retryGeneration ||
        entry.identity?.installationId !== plan.identity.deviceId ||
        entry.identity?.sessionId !== plan.identity.sessionId ||
        entry.identity?.accountId !== plan.identity.accountId
      )
        return { status: "STALE" };
      return client?.runSubscriptionRefreshTask?.(plan.identity);
    }
    return null;
  }

  async function wake(reason = "event") {
    if (dispatchFlight) return dispatchFlight;
    dispatchFlight = (async () => {
      await reconstruct();
      const now = Date.now();
      const state = await read();
      const due = Object.values(state.entries).filter((entry) => entry.dueAt <= now && entry.claimedUntil <= now)
        .sort((a, b) => a.dueAt - b.dueAt || a.taskId.localeCompare(b.taskId)).slice(0, MAX_DUE_PER_WAKE);
      for (const candidate of due) {
        const entry = await claim(candidate.taskId, now);
        if (!entry) continue;
        try { await dispatch(entry); await finish(entry); }
        catch (_) { await finish(entry, { failed: true }); }
      }
      await reconstruct();
      const finalState = await read();
      await arm(finalState);
      return { ok: true, reason, processed: due.length };
    })().finally(() => { dispatchFlight = null; });
    return dispatchFlight;
  }

  if (chrome.alarms?.onAlarm?.addListener) chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm?.name === ALARM) void wake("alarm");
  });
  chrome.runtime?.onStartup?.addListener(() => { void wake("startup"); });
  chrome.runtime?.onInstalled?.addListener(() => { void wake("installed"); });

  globalThis.SellerAgentsTechnicalScheduler = Object.freeze({
    ALARM, KINDS, schedule, cancel, cancelKind, wake,
    state: async () => clone(await read()),
  });
})();

;
/* Keep only the user's selected File in RAM while the native action popup closes. */
(() => {
  "use strict";
  if (!globalThis.chrome?.runtime?.onConnect?.addListener) return;
  const PORT = "SA_BACKUP_FILE_PICKER_V1";
  const MAX_BYTES = 8 * 1024 * 1024;
  const RETURN_WINDOW_MS = 1500;
  const LATE_RESULT_MS = 5000;
  let pending = null;
  const authority = () => globalThis.SellerAgentsControlClient;
  function discard(entry) {
    if (!entry) return;
    clearTimeout(entry.cleanup);
    if (entry.owner.disconnected) entry.owner.channel?.close();
    entry.file = null; entry.password = "";
    if (pending === entry) pending = null;
  }
  function current(entry) {
    if (pending !== entry) throw new Error("PICKER_CONTEXT_CHANGED");
    authority().assertBackupContext(entry.context);
  }
  async function sameSurface(windowId, tabId) {
    const tab = await chrome.tabs.get(tabId);
    return tab.active === true && tab.windowId === windowId;
  }
  async function reopen(entry) {
    if (entry.openAttempted || entry.claimed || !entry.hasResult) return;
    entry.openAttempted = true; // No replay on a rejected or unknown UI outcome.
    try {
      current(entry);
      const window = await chrome.windows.get(entry.windowId);
      if (!window.focused || !await sameSurface(entry.windowId, entry.tabId)) {
        discard(entry); return;
      }
      current(entry);
      if (entry.claimed) return;
      await chrome.action.openPopup({ windowId: entry.windowId });
    } catch (_) {
      // A subsequent normal opening may still claim the bounded RAM draft.
      // Never create a replacement window, tab, sidebar or popup URL.
    }
  }
  function receive(endpoint, data) {
    const entry = pending;
    if (!entry || entry.owner !== endpoint || entry.id !== data?.pickId ||
        entry.hasResult || data.type !== "result") return;
    try {
      current(entry);
      if (endpoint.disconnected && Date.now() - endpoint.closedAt > LATE_RESULT_MS) {
        discard(entry); return;
      }
      const file = data.file;
      if (file !== null && !(file instanceof File) || typeof data.password !== "string") return;
      if (file && file.size > MAX_BYTES) {
        entry.error = "BACKUP_FILE_TOO_LARGE"; entry.file = null;
      } else entry.file = file;
      entry.password = data.password;
      entry.hasResult = true; entry.resultAt = Date.now();
      clearTimeout(entry.cleanup);
      entry.cleanup = setTimeout(() => discard(entry), 60000);
      if (endpoint.disconnected) void reopen(entry);
    } catch (_) { discard(entry); }
  }
  chrome.storage?.onChanged?.addListener((changes, area) => {
    if (area === "local" && changes.seller_agents_control_auth_v2 && pending) {
      try { current(pending); } catch (_) { discard(pending); }
    }
  });
  chrome.runtime.onConnect.addListener(port => {
    if (port.name !== PORT) return;
    if (port.sender?.id !== chrome.runtime.id ||
        port.sender?.url !== chrome.runtime.getURL("popup.html") ||
        typeof BroadcastChannel !== "function" ||
        typeof chrome.action?.openPopup !== "function") {
      port.disconnect(); return;
    }
    const endpoint = { port, disconnected: false, closedAt: 0, channel: null,
      windowId: null, tabId: null, restoring: null, prepared: null, serial: Promise.resolve() };
    const reply = (requestId, fields) => {
      if (!endpoint.disconnected) {
        try { port.postMessage({ requestId, ...fields }); } catch (_) { /* closed */ }
      }
    };
    async function handle(message) {
      const requestId = message?.requestId;
      try {
        if (message?.type === "ping") return;
        if (message?.type === "hello") {
          if (endpoint.channel || !Number.isInteger(message.windowId) ||
              !Number.isInteger(message.tabId)) throw new Error("PICKER_CONTEXT_CHANGED");
          const context = await authority().captureBackupContext();
          if (!await sameSurface(message.windowId, message.tabId) || endpoint.disconnected)
            throw new Error("PICKER_CONTEXT_CHANGED");
          authority().assertBackupContext(context);
          endpoint.windowId = message.windowId; endpoint.tabId = message.tabId;
          const name = PORT + ":" + crypto.randomUUID();
          endpoint.channel = new BroadcastChannel(name);
          endpoint.channel.onmessage = event => receive(endpoint, event.data);
          const entry = pending;
          if (entry?.hasResult && !entry.claimed && entry.windowId === endpoint.windowId &&
              entry.tabId === endpoint.tabId) {
            try {
              current(entry); entry.claimed = endpoint; endpoint.restoring = entry;
            } catch (_) { discard(entry); }
          }
          reply(requestId, { ok: true, type: "hello", channel: name });
        } else if (message?.type === "ready") {
          const entry = endpoint.restoring;
          if (!entry) return;
          current(entry);
          endpoint.channel.postMessage({ type: "restore", pickId: entry.id,
            file: entry.file, password: entry.password, error: entry.error || null });
        } else if (message?.type === "prepare") {
          if (!endpoint.channel || !await sameSurface(endpoint.windowId, endpoint.tabId))
            throw new Error("PICKER_CONTEXT_CHANGED");
          const context = await authority().captureBackupContext();
          if (endpoint.disconnected) throw new Error("PICKER_CONTEXT_CHANGED");
          discard(pending);
          const entry = { id: crypto.randomUUID(), owner: endpoint, context,
            windowId: endpoint.windowId, tabId: endpoint.tabId, file: null, password: "",
            hasResult: false, resultAt: 0, openAttempted: false, claimed: null, cleanup: null };
          pending = entry; endpoint.prepared = entry;
          reply(requestId, { ok: true, type: "prepared", pickId: entry.id });
        } else if (message?.type === "restored") {
          const entry = endpoint.restoring;
          if (!entry || pending !== entry || entry.id !== message.pickId || entry.claimed !== endpoint) return;
          current(entry);
          endpoint.restoring = null;
          if (!entry.file) { discard(entry); return; }
          // ACK transfers the bounded RAM draft to the live toolbar popup; it
          // does not consume the user's File. A later ordinary opening may
          // restore it again, without another automatic open or a longer TTL.
          if (entry.owner.disconnected) entry.owner.channel?.close();
          entry.owner = endpoint; entry.claimed = null; entry.openAttempted = true;
        } else if (message?.type === "clear") {
          if (pending && pending.id === message.pickId &&
              (pending.owner === endpoint || pending.claimed === endpoint)) discard(pending);
        } else throw new Error("PICKER_CONTEXT_CHANGED");
      } catch (_) {
        if (pending?.owner === endpoint || pending?.claimed === endpoint) discard(pending);
        reply(requestId, { ok: false, code: "PICKER_CONTEXT_CHANGED" });
      }
    }
    port.onMessage.addListener(message => {
      endpoint.serial = endpoint.serial.then(() => handle(message)).catch(() => null);
    });
    port.onDisconnect.addListener(() => {
      endpoint.disconnected = true; endpoint.closedAt = Date.now();
      // A queued structured-clone result may follow the port-disconnect IPC.
      // Keep this exact receiver; closing and recreating it would lose the task.
      const entry = pending;
      if (!entry || entry.owner !== endpoint) {
        endpoint.channel?.close();
        if (entry?.claimed === endpoint) discard(entry);
        return;
      }
      if (!entry.hasResult) entry.cleanup = setTimeout(() => discard(entry), LATE_RESULT_MS);
      // A slow teardown must not lose the File. Retain it for the next normal
      // opening, but do not reopen after a later deliberate popup close.
      if (entry.hasResult && Date.now() - entry.resultAt <= RETURN_WINDOW_MS) void reopen(entry);
    });
  });
})();

;
/* Fixed, bounded reader for the code node displayed by Qwen's Monaco view.
 * Runs in MAIN only for a browser-authenticated extension content sender.
 * No application store, auth state, network, clipboard, or arbitrary JS access. */
function saQwenCodeInPage(expectedHref, messageId, blockOrdinal) {
  const unavailable = () => ({ ok: false, code: "QWEN_COMPLETE_CODE_UNAVAILABLE" });
  const own = (object, key) => {
    if (!object || (typeof object !== "object" && typeof object !== "function")) return undefined;
    const descriptor = Object.getOwnPropertyDescriptor(object, key);
    return descriptor && Object.hasOwn(descriptor, "value") ? descriptor.value : undefined;
  };
  try {
    if (location.origin !== "https://chat.qwen.ai" || location.href !== expectedHref) return unavailable();
    const selector = ".qwen-chat-message";
    const idFor = node => {
      const ids = [...new Set([node, ...node.querySelectorAll("[data-msg-id]")]
        .filter(value => value.closest(selector) === node)
        .map(value => value.getAttribute("data-msg-id")).filter(Boolean))];
      return ids.length === 1 ? ids[0] : null;
    };
    const messages = [...document.querySelectorAll(selector + ".qwen-chat-message-assistant")]
      .filter(node => node.isConnected && idFor(node) === messageId);
    if (messages.length !== 1) return unavailable();
    const section = messages[0];
    const blocks = [...section.querySelectorAll("pre.qwen-markdown-code")]
      .filter(node => node.closest(selector) === section);
    const block = blocks[blockOrdinal];
    if (!block?.isConnected) return unavailable();
    const keys = Object.getOwnPropertyNames(block).filter(key => key.startsWith("__reactFiber$"));
    if (keys.length !== 1) return unavailable();
    // Exactly the observed immediate Markdown code component; no ancestor search.
    const component = own(own(block, keys[0]), "return");
    const markdownCode = own(own(component, "memoizedProps"), "token");
    const value = own(markdownCode, "text");
    if (own(markdownCode, "type") !== "code" || typeof value !== "string" || !value.length || value.length > 524288)
      return unavailable();
    return { ok: true, text: value };
  } catch (_) { return unavailable(); }
}
async function saReadQwenCode(message, sender) {
  const invalid = () => ({ ok: false, code: "QWEN_CODE_SENDER_INVALID" });
  if (sender?.id !== chrome.runtime.id || sender?.frameId !== 0 || !Number.isInteger(sender?.tab?.id) ||
      typeof sender.documentId !== "string" || !sender.documentId.length) return invalid();
  let senderUrl;
  try { senderUrl = new URL(sender.url); } catch (_) { return invalid(); }
  if (senderUrl.origin !== "https://chat.qwen.ai" ||
      typeof message.messageId !== "string" || !message.messageId.length || message.messageId.length > 512 ||
      /[\u0000-\u001f]/.test(message.messageId) || !Number.isInteger(message.blockOrdinal) ||
      message.blockOrdinal < 0 || message.blockOrdinal > 127) return invalid();
  const before = await saBrowserPage(sender.tab.id);
  if (before.origin !== senderUrl.origin || before.aiFamily !== "qwen") return invalid();
  let results;
  try {
    results = await chrome.scripting.executeScript({
      target: { tabId: sender.tab.id, documentIds: [sender.documentId] },
      world: "MAIN", func: saQwenCodeInPage,
      args: [before.url, message.messageId, message.blockOrdinal]
    });
  } catch (_) { return { ok: false, code: "QWEN_COMPLETE_CODE_UNAVAILABLE" }; }
  if ((await saBrowserPage(sender.tab.id)).url !== before.url || results?.length !== 1 ||
      results[0].documentId !== sender.documentId || results[0].frameId !== 0)
    return { ok: false, code: "QWEN_CODE_CONTEXT_CHANGED" };
  const result = results[0].result;
  return result?.ok === true && typeof result.text === "string" && result.text.length > 0 && result.text.length <= 524288 ?
    { ok: true, text: result.text } : { ok: false, code: "QWEN_COMPLETE_CODE_UNAVAILABLE" };
}

;
/* global BB2ConversationIdentity, BB2ManualControls, OzonRuntime, OzonCredentials, OzonOperationRegistry, OzonEntitlements, OzonContract, OzonGuidance, OzonMixedBatchDiscovery, OzonWorkSessionModel, BridgeAutorunModel, ProviderTransportCore, OzonProvider */
importScripts("shared/conversation_identity.js", "shared/runtime_names.js", "shared/work_session_model.js", "shared/manual_controls.js", "shared/ozon_credentials.js", "shared/ozon_operation_registry.js", "shared/ozon_entitlements.js", "shared/ozon_contract.js", "shared/ozon_guidance.js", "shared/bridge_autorun_model.js", "shared/provider_transport_core.js", "shared/ozon_provider.js");

const VERSION = "0.2.37";
const CREDENTIAL_BACKUP_FORMAT = "ozon-bridge-credentials-backup";
const CREDENTIAL_BACKUP_VERSION = 2;
const LEGACY_CREDENTIAL_BACKUP_FORMAT = "ozon-bridge-seller-credentials-backup";
const LEGACY_CREDENTIAL_BACKUP_VERSION = 1;
const KEYS = OzonRuntime.STORAGE_KEYS;
const MAX_DIAGNOSTICS = 1500;
const WORKER_SESSION_ID = `worker-${crypto.randomUUID()}`;
let workSessionRuntimeGeneration = `work-runtime-${crypto.randomUUID()}`;
const DEFAULT_AUTO_START_TEXT = OzonRuntime.DEFAULT_AUTO_START_TEXT;
const AI_MODES = new Set(["auto", "chatgpt", "alice", "qwen", "kimi", "grok", "gemini", "claude", "deepseek"]);
function normalizeAIMode(value) {
  const mode = String(value || "auto").trim().toLowerCase();
  return AI_MODES.has(mode) ? mode : "auto";
}

let bindingWriteLock = Promise.resolve();
let autoRunsWriteLock = Promise.resolve();
const manualOperationRecords =
  globalThis.SellerAgentsLocalOperations.createRecordStore({
    read: (keys) => storageGet(keys),
    write: async (values) => {
      await storageSet(values);
      rememberManualContextOwners(values[KEYS.MANUAL_OPERATIONS]);
    },
    namespace: KEYS.MANUAL_OPERATIONS,
    writerKey: KEYS.MANUAL_OPERATIONS,
  });
let prefixWriteLock = Promise.resolve();
let startPromptWriteLock = Promise.resolve();
let migrationWriteLock = Promise.resolve();
let diagnosticsWriteLock = Promise.resolve();
let copyProfilesWriteLock = Promise.resolve();
let tabAIModesWriteLock = Promise.resolve();
let providerQuotaWriteLock = Promise.resolve();
let providerResultCacheWriteLock = Promise.resolve();

const PROVIDER_QUOTA_SCHEMA_VERSION = 1;
const ANALYTICS_QUOTA_FAMILY = "seller.analytics_data.v1";
const STOCK_TURNOVER_QUOTA_FAMILY = "seller.analytics_turnover_stocks.v1";
const ANALYTICS_MIN_INTERVAL_MS = 60_000;
const ANALYTICS_QUOTA_LAUNCH_SAFETY_MS = 5_000;
const PROVIDER_RESULT_CACHE_SCHEMA_VERSION = 1;
const ANALYTICS_CACHE_TTL_MS = 60_000;

// Reference-parity single-flight: one worker-owned browser delivery attempt per run.
// This is deliberately the same primitive used by Business Bridge 2.0.0.22.
const deliveryAttemptRequests = new Map();
const batchCollectionRequests = new Map();
function singleFlight(map, key, fn) {
  return globalThis.SellerAgentsLocalOperations.singleFlight(map, key, fn);
}

function storageGet(keys) { return chrome.storage.local.get(keys); }
function storageSet(values) { return chrome.storage.local.set(values); }
function storageRemove(keys) { return chrome.storage.local.remove(keys); }
function sessionGet(keys) { return chrome.storage.session.get(keys); }
function sessionSet(values) { return chrome.storage.session.set(values); }

function withProviderQuotaWrite(fn) {
  const next = providerQuotaWriteLock.then(fn, fn);
  providerQuotaWriteLock = next.catch(() => null);
  return next;
}

function withProviderResultCacheWrite(fn) {
  const next = providerResultCacheWriteLock.then(fn, fn);
  providerResultCacheWriteLock = next.catch(() => null);
  return next;
}

function bytesToHex(buffer) {
  return [...new Uint8Array(buffer)].map((value) => value.toString(16).padStart(2, "0")).join("");
}

async function sellerQuotaIdentity(rawCredentials) {
  const credentials = OzonCredentials.normalizeSellerCredentials(rawCredentials, { required: true });
  const encoder = new TextEncoder();
  const accountDigest = await crypto.subtle.digest("SHA-256", encoder.encode(`seller-account-v1\0${credentials.clientId}`));
  const revisionDigest = await crypto.subtle.digest("SHA-256", encoder.encode(`seller-credential-v1\0${credentials.clientId}\0${credentials.apiKey}`));
  return Object.freeze({
    account_hash: bytesToHex(accountDigest),
    credential_revision: bytesToHex(revisionDigest)
  });
}

function normalizedProviderResultCacheState(raw) {
  const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  return {
    schema_version: PROVIDER_RESULT_CACHE_SCHEMA_VERSION,
    accounts: source.accounts && typeof source.accounts === "object" && !Array.isArray(source.accounts) ? { ...source.accounts } : {}
  };
}

function jsonCacheClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function safeAnalyticsCacheMetadata(value, nowMs = Date.now()) {
  if (!value || typeof value !== "object") return null;
  const storedAt = Math.max(0, Number(value.stored_at || 0));
  const expiresAt = Math.max(0, Number(value.expires_at || 0));
  return Object.freeze({
    hit: value.hit === true,
    profile_id: value.profile_id ? String(value.profile_id).slice(0, 120) : null,
    stored_at: storedAt,
    expires_at: expiresAt,
    age_ms: storedAt ? Math.max(0, Number(nowMs) - storedAt) : 0,
    source_request_id: value.source_request_id ? String(value.source_request_id).slice(0, 200) : null,
    source_physical_command_fingerprint: value.source_physical_command_fingerprint ? String(value.source_physical_command_fingerprint).slice(0, 80) : null,
    cached_metrics: Array.isArray(value.cached_metrics) ? value.cached_metrics.map((metric) => String(metric)) : [],
    requested_metrics: Array.isArray(value.requested_metrics) ? value.requested_metrics.map((metric) => String(metric)) : []
  });
}

function acquisitionPlanning(basePlanning, profile) {
  const base = basePlanning && typeof basePlanning === "object" ? basePlanning : {};
  if (!profile?.applicable) return base;
  return {
    ...base,
    acquisition: {
      profile_id: String(profile.profile_id || "analytics_basic_metrics_v1"),
      prefetch_applied: profile.prefetch_applied === true,
      requested_metrics: Array.isArray(profile.requested_metrics) ? [...profile.requested_metrics] : [],
      physical_metrics: Array.isArray(profile.physical_metrics) ? [...profile.physical_metrics] : []
    }
  };
}

function cachePlanning(basePlanning, cacheMeta) {
  const base = basePlanning && typeof basePlanning === "object" ? basePlanning : {};
  const safe = safeAnalyticsCacheMetadata(cacheMeta);
  return safe ? { ...base, cache: safe } : base;
}

async function readAnalyticsResultCache(command, rawCredentials, nowMs = Date.now()) {
  const normalized = OzonContract.normalizeCommand(command);
  if (normalized.operation !== "analytics_data") return Object.freeze({ hit: false, reason: "operation_not_cacheable" });
  const descriptor = OzonContract.analyticsCoalescingDescriptor(normalized);
  if (!descriptor?.eligible) return Object.freeze({ hit: false, reason: "analytics_not_cacheable" });
  const identity = await sellerQuotaIdentity(rawCredentials);
  const data = await storageGet(KEYS.PROVIDER_RESULT_CACHE);
  const state = normalizedProviderResultCacheState(data[KEYS.PROVIDER_RESULT_CACHE]);
  const account = state.accounts[identity.account_hash];
  const entries = account?.entries && typeof account.entries === "object" && !Array.isArray(account.entries) ? Object.values(account.entries) : [];
  const requestedMetrics = [...descriptor.metrics];
  const candidates = [];
  for (const entry of entries) {
    if (!entry || typeof entry !== "object") continue;
    if (Number(entry.expires_at || 0) <= Number(nowMs)) continue;
    if (String(entry.compatibility_key || "") !== String(descriptor.compatibility_key || "")) continue;
    const cachedMetrics = Array.isArray(entry.metrics) ? entry.metrics.map((metric) => String(metric)) : [];
    if (!cachedMetrics.length || new Set(cachedMetrics).size !== cachedMetrics.length) continue;
    if (requestedMetrics.some((metric) => !cachedMetrics.includes(metric))) continue;
    try {
      const params = jsonCacheClone(normalized.params);
      params.metrics = cachedMetrics;
      const cachedCommand = OzonContract.normalizeCommand({ operation: "analytics_data", params });
      OzonContract.verifyProviderResponse(cachedCommand, entry.result);
      const projected = OzonContract.projectAnalyticsDataResult(entry.result, cachedMetrics, requestedMetrics);
      candidates.push({ entry, cachedMetrics, projected, extra: cachedMetrics.length - requestedMetrics.length });
    } catch (_) {}
  }
  if (!candidates.length) return Object.freeze({ hit: false, reason: "cache_miss" });
  candidates.sort((a, b) => a.extra - b.extra || Number(b.entry.stored_at || 0) - Number(a.entry.stored_at || 0));
  const chosen = candidates[0];
  const metadata = safeAnalyticsCacheMetadata({
    hit: true,
    profile_id: chosen.entry.profile_id || null,
    stored_at: chosen.entry.stored_at,
    expires_at: chosen.entry.expires_at,
    source_request_id: chosen.entry.source_request_id || null,
    source_physical_command_fingerprint: chosen.entry.source_physical_command_fingerprint || null,
    cached_metrics: chosen.cachedMetrics,
    requested_metrics: requestedMetrics
  }, nowMs);
  return Object.freeze({ hit: true, result: chosen.projected, http_status: Number(chosen.entry.http_status || 200), cache: metadata });
}

async function readAnalyticsResultCacheForCurrentSettings(
  command,
  executionContext = null,
) {
  try {
    const settings = await (executionContext
      ? executionContext.settings()
      : getSettings());
    const normalized = OzonCredentials.normalizeSellerCredentials(
      settings.sellerCredentials,
      { required: false },
    );
    if (normalized.present !== true)
      return Object.freeze({ hit: false, reason: "credentials_unavailable" });
    return await readAnalyticsResultCache(command, settings.sellerCredentials);
  } catch (_) {
    if (_?.execution_context_error) throw _;
    return Object.freeze({ hit: false, reason: "cache_read_unavailable" });
  }
}

async function storeAnalyticsResultCache(
  command,
  providerResult,
  rawCredentials,
  profile = null,
  nowMs = Date.now(),
  executionContext = null,
) {
  const normalized = OzonContract.normalizeCommand(command);
  if (
    normalized.operation !== "analytics_data" ||
    providerResult?.ok !== true ||
    !providerResult?.result
  )
    return false;
  const descriptor = OzonContract.analyticsCoalescingDescriptor(normalized);
  if (!descriptor?.eligible) return false;
  OzonContract.verifyProviderResponse(normalized, providerResult.result);
  const identity = await sellerQuotaIdentity(rawCredentials);
  const storedResult = jsonCacheClone(providerResult.result);
  await withProviderResultCacheWrite(async () => {
    const data = await storageGet(KEYS.PROVIDER_RESULT_CACHE);
    const state = normalizedProviderResultCacheState(
      data[KEYS.PROVIDER_RESULT_CACHE],
    );
    const currentAccount =
      state.accounts[identity.account_hash] &&
      typeof state.accounts[identity.account_hash] === "object"
        ? { ...state.accounts[identity.account_hash] }
        : { entries: {} };
    const currentEntries =
      currentAccount.entries &&
      typeof currentAccount.entries === "object" &&
      !Array.isArray(currentAccount.entries)
        ? { ...currentAccount.entries }
        : {};
    for (const [entryId, entry] of Object.entries(currentEntries)) {
      if (!entry || Number(entry.expires_at || 0) <= Number(nowMs))
        delete currentEntries[entryId];
    }
    let targetId = null;
    for (const [entryId, entry] of Object.entries(currentEntries)) {
      if (
        String(entry?.compatibility_key || "") !==
        String(descriptor.compatibility_key || "")
      )
        continue;
      const metrics = Array.isArray(entry?.metrics)
        ? entry.metrics.map(String)
        : [];
      if (JSON.stringify(metrics) === JSON.stringify(descriptor.metrics)) {
        targetId = entryId;
        break;
      }
    }
    if (!targetId) targetId = `analytics-${crypto.randomUUID()}`;
    currentEntries[targetId] = {
      compatibility_key: descriptor.compatibility_key,
      compatibility_fingerprint: descriptor.compatibility_fingerprint,
      metrics: [...descriptor.metrics],
      result: storedResult,
      source_request_id: providerResult.request_id
        ? String(providerResult.request_id).slice(0, 200)
        : null,
      source_physical_command_fingerprint:
        providerResult.executed_command_fingerprint
          ? String(providerResult.executed_command_fingerprint).slice(0, 80)
          : OzonContract.commandFingerprint(normalized),
      http_status: Number(providerResult.http_status || 200),
      profile_id: profile?.profile_id
        ? String(profile.profile_id).slice(0, 120)
        : null,
      stored_at: Number(nowMs),
      expires_at: Number(nowMs) + ANALYTICS_CACHE_TTL_MS,
    };
    state.accounts[identity.account_hash] = {
      entries: currentEntries,
      updated_at: new Date(Number(nowMs)).toISOString(),
    };
    if (executionContext) await executionContext.assertCurrent();
    await storageSet({ [KEYS.PROVIDER_RESULT_CACHE]: state });
  });
  return true;
}

async function storeAnalyticsResultCacheForCurrentSettings(
  command,
  providerResult,
  profile = null,
  executionContext = null,
) {
  try {
    const settings = await (executionContext
      ? executionContext.settings()
      : getSettings());
    const normalized = OzonCredentials.normalizeSellerCredentials(
      settings.sellerCredentials,
      { required: false },
    );
    if (normalized.present !== true) return false;
    return await storeAnalyticsResultCache(
      command,
      providerResult,
      settings.sellerCredentials,
      profile,
      Date.now(),
      executionContext,
    );
  } catch (_) {
    if (_?.execution_context_error) throw _;
    return false;
  }
}

function normalizedQuotaState(raw) {
  const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  return {
    schema_version: PROVIDER_QUOTA_SCHEMA_VERSION,
    accounts: source.accounts && typeof source.accounts === "object" && !Array.isArray(source.accounts) ? { ...source.accounts } : {}
  };
}

function parseRetryAfterAt(value, nowMs = Date.now()) {
  const text = String(value || "").trim();
  if (!text) return null;
  if (/^\d+(?:\.\d+)?$/.test(text)) {
    const seconds = Number(text);
    if (!Number.isFinite(seconds) || seconds < 0) return null;
    return Math.ceil(Number(nowMs) + seconds * 1000);
  }
  const parsed = Date.parse(text);
  return Number.isFinite(parsed) ? Math.max(Number(nowMs), parsed) : null;
}

function safeQuotaMetadata(value) {
  if (!value || typeof value !== "object") return null;
  return Object.freeze({
    family: String(value.family || ANALYTICS_QUOTA_FAMILY),
    min_interval_ms: Math.max(0, Number(value.min_interval_ms || 0)),
    bridge_launch_safety_ms: ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
    effective_interval_ms: ANALYTICS_MIN_INTERVAL_MS + ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
    dispatched_at: Number(value.dispatched_at || 0),
    next_allowed_at: Number(value.next_allowed_at || 0),
    credential_scope_id: String(value.account_hash || "").slice(0, 16) || null,
    credential_revision: String(value.credential_revision || "").slice(0, 16) || null,
    automatic_retry: false
  });
}

async function acquireAnalyticsProviderQuota(rawCredentials, nowMs = Date.now(), familyKey = ANALYTICS_QUOTA_FAMILY) {
  const identity = await sellerQuotaIdentity(rawCredentials);
  return withProviderQuotaWrite(async () => {
    const currentNow = Math.max(Number(nowMs || 0), Date.now());
    const data = await storageGet(KEYS.PROVIDER_QUOTA_STATE);
    const state = normalizedQuotaState(data[KEYS.PROVIDER_QUOTA_STATE]);
    const account = state.accounts[identity.account_hash] && typeof state.accounts[identity.account_hash] === "object"
      ? { ...state.accounts[identity.account_hash] }
      : { credential_revision: identity.credential_revision, families: {} };
    const families = account.families && typeof account.families === "object" ? { ...account.families } : {};
    const family = families[familyKey] && typeof families[familyKey] === "object"
      ? { ...families[familyKey] }
      : {};
    const lastProviderRequestAt = Math.max(0, Number(family.last_provider_request_at || 0));
    const guardedFromLastAttempt = lastProviderRequestAt > 0
      ? lastProviderRequestAt + ANALYTICS_MIN_INTERVAL_MS + ANALYTICS_QUOTA_LAUNCH_SAFETY_MS
      : 0;
    const nextAllowedAt = Math.max(0, Number(family.next_allowed_at || 0), guardedFromLastAttempt);
    if (currentNow < nextAllowedAt) {
      return Object.freeze({
        allowed: false,
        family: familyKey,
        min_interval_ms: ANALYTICS_MIN_INTERVAL_MS,
        bridge_launch_safety_ms: ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
        effective_interval_ms: ANALYTICS_MIN_INTERVAL_MS + ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
        account_hash: identity.account_hash,
        credential_revision: identity.credential_revision,
        next_allowed_at: nextAllowedAt,
        wait_ms: nextAllowedAt - currentNow,
        automatic_retry: false
      });
    }
    const dispatchedAt = currentNow;
    const next = dispatchedAt + ANALYTICS_MIN_INTERVAL_MS + ANALYTICS_QUOTA_LAUNCH_SAFETY_MS;
    families[familyKey] = {
      min_interval_ms: ANALYTICS_MIN_INTERVAL_MS,
      bridge_launch_safety_ms: ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
      effective_interval_ms: ANALYTICS_MIN_INTERVAL_MS + ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
      last_provider_request_at: dispatchedAt,
      next_allowed_at: next,
      credential_revision: identity.credential_revision,
      updated_at: new Date(dispatchedAt).toISOString()
    };
    state.accounts[identity.account_hash] = {
      credential_revision: identity.credential_revision,
      families,
      updated_at: new Date(dispatchedAt).toISOString()
    };
    await storageSet({ [KEYS.PROVIDER_QUOTA_STATE]: state });
    return Object.freeze({
      allowed: true,
      family: familyKey,
      min_interval_ms: ANALYTICS_MIN_INTERVAL_MS,
      bridge_launch_safety_ms: ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
      effective_interval_ms: ANALYTICS_MIN_INTERVAL_MS + ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
      account_hash: identity.account_hash,
      credential_revision: identity.credential_revision,
      dispatched_at: dispatchedAt,
      next_allowed_at: next,
      wait_ms: 0,
      automatic_retry: false
    });
  });
}

async function extendAnalyticsQuotaFromRetryAfter(quotaPermit, retryAfter, nowMs = Date.now()) {
  if (!quotaPermit?.account_hash || !retryAfter) return safeQuotaMetadata(quotaPermit);
  const familyKey = String(quotaPermit.family || ANALYTICS_QUOTA_FAMILY);
  const retryAt = parseRetryAfterAt(retryAfter, nowMs);
  if (!retryAt) return safeQuotaMetadata(quotaPermit);
  return withProviderQuotaWrite(async () => {
    const data = await storageGet(KEYS.PROVIDER_QUOTA_STATE);
    const state = normalizedQuotaState(data[KEYS.PROVIDER_QUOTA_STATE]);
    const account = state.accounts[quotaPermit.account_hash] && typeof state.accounts[quotaPermit.account_hash] === "object"
      ? { ...state.accounts[quotaPermit.account_hash] }
      : { credential_revision: quotaPermit.credential_revision || null, families: {} };
    const families = account.families && typeof account.families === "object" ? { ...account.families } : {};
    const family = families[familyKey] && typeof families[familyKey] === "object"
      ? { ...families[familyKey] }
      : {};
    const effectiveNext = Math.max(Number(family.next_allowed_at || 0), Number(quotaPermit.next_allowed_at || 0), retryAt);
    families[familyKey] = {
      ...family,
      min_interval_ms: ANALYTICS_MIN_INTERVAL_MS,
      bridge_launch_safety_ms: ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
      effective_interval_ms: ANALYTICS_MIN_INTERVAL_MS + ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
      last_provider_request_at: Number(family.last_provider_request_at || quotaPermit.dispatched_at || 0),
      next_allowed_at: effectiveNext,
      credential_revision: quotaPermit.credential_revision || family.credential_revision || null,
      retry_after_applied_at: Number(nowMs),
      updated_at: new Date(Number(nowMs)).toISOString()
    };
    state.accounts[quotaPermit.account_hash] = { ...account, families, updated_at: new Date(Number(nowMs)).toISOString() };
    await storageSet({ [KEYS.PROVIDER_QUOTA_STATE]: state });
    return safeQuotaMetadata({ ...quotaPermit, next_allowed_at: effectiveNext });
  });
}

async function prepareProviderQuotaForCommand(
  command,
  executionContext = null,
) {
  const normalized = OzonContract.normalizeCommand(command);
  const preflight = OzonContract.preflightExecution(normalized);
  if (String(preflight.meta.provider || "seller_api") !== "seller_api") {
    return Object.freeze({ required: false, allowed: true, quota: null });
  }
  const quotaFamily =
    normalized.operation === "analytics_data"
      ? ANALYTICS_QUOTA_FAMILY
      : normalized.operation === "stock_turnover_analytics"
        ? STOCK_TURNOVER_QUOTA_FAMILY
        : null;
  if (!quotaFamily)
    return Object.freeze({ required: false, allowed: true, quota: null });
  let settings;
  try {
    settings = await (executionContext
      ? executionContext.settings()
      : getSettings());
  } catch (_) {
    if (_?.execution_context_error) throw _;
    return Object.freeze({
      required: true,
      allowed: true,
      quota: null,
      scheduler_skipped: "credentials_unavailable",
    });
  }
  let present = false;
  try {
    present =
      OzonCredentials.normalizeSellerCredentials(settings.sellerCredentials, {
        required: false,
      }).present === true;
  } catch (_) {
    if (_?.execution_context_error) throw _;
    present = false;
  }
  if (!present)
    return Object.freeze({
      required: true,
      allowed: true,
      quota: null,
      scheduler_skipped: "credentials_unavailable",
    });
  try {
    const permit = await acquireAnalyticsProviderQuota(
      settings.sellerCredentials,
      Date.now(),
      quotaFamily,
    );
    return Object.freeze({
      required: true,
      allowed: permit.allowed === true,
      quota: permit,
    });
  } catch (error) {
    const blocked = Object.assign(
      new Error(
        "Persistent provider quota state недоступен; rate-limited Seller provider request заблокирован до восстановления scheduler state.",
      ),
      {
        code: "PROVIDER_QUOTA_STATE_UNAVAILABLE",
        external_request_executed: false,
        scheduler_cause_code: String(
          error?.code || error?.name || "QUOTA_STATE_ERROR",
        ).slice(0, 160),
      },
    );
    return Object.freeze({
      required: true,
      allowed: false,
      quota: null,
      error: blocked,
    });
  }
}

function scheduleProviderQuotaWake(whenMs) {
  const scheduler = globalThis.SellerAgentsTechnicalScheduler;
  if (scheduler?.schedule) {
    void scheduler.schedule(scheduler.KINDS.QUOTA, { taskId: "quota:pending", dueAt: Math.max(Date.now() + 100, Number(whenMs || 0)), identity: { retryGeneration: String(whenMs || "") } });
  }
}

async function resumeProviderQuotaWaits() {
  const sellerAgentsEnabled = await saEnabled();
  const data = await storageGet([KEYS.MANUAL_OPERATIONS, KEYS.AUTO_RUNS]);
  const now = Date.now();
  let earliest = null;
  const dueLaunches = [];
  const manual = data[KEYS.MANUAL_OPERATIONS] && typeof data[KEYS.MANUAL_OPERATIONS] === "object" ? data[KEYS.MANUAL_OPERATIONS] : {};
  const runs = data[KEYS.AUTO_RUNS] && typeof data[KEYS.AUTO_RUNS] === "object" ? data[KEYS.AUTO_RUNS] : {};
  for (const [conversationKey, operation] of Object.entries(manual)) {
    const wait = operation?.batch?.request_state === "quota_waiting" ? Number(operation.batch?.quota_wait?.next_allowed_at || 0) : 0;
    if (!wait) continue;
    if (wait <= now) dueLaunches.push(launchBatchProcessor("manual", conversationKey, operation.operation_id, "quota_wake"));
    else earliest = earliest === null ? wait : Math.min(earliest, wait);
  }
  if (!sellerAgentsEnabled) for (const [conversationKey, run] of Object.entries(runs)) {
    const wait = run?.batch?.request_state === "quota_waiting" ? Number(run.batch?.quota_wait?.next_allowed_at || 0) : 0;
    if (!wait) continue;
    if (wait <= now) dueLaunches.push(launchBatchProcessor("autorun", conversationKey, run.run_id, "quota_wake"));
    else earliest = earliest === null ? wait : Math.min(earliest, wait);
  }
  await Promise.allSettled(dueLaunches);
  if (earliest !== null) scheduleProviderQuotaWake(earliest);
}

function withTabAIModesWrite(fn) {
  const next = tabAIModesWriteLock.then(fn, fn);
  tabAIModesWriteLock = next.catch(() => null);
  return next;
}

async function getTabAIMode(tabId) {
  const tab = normalizeTabId(tabId);
  const data = await sessionGet(KEYS.AI_TAB_MODES);
  const modes = data[KEYS.AI_TAB_MODES] && typeof data[KEYS.AI_TAB_MODES] === "object" ? data[KEYS.AI_TAB_MODES] : {};
  return normalizeAIMode(modes[String(tab)]);
}

async function setTabAIMode(tabId, value) {
  const tab = normalizeTabId(tabId);
  const mode = normalizeAIMode(value);
  return withTabAIModesWrite(async () => {
    const data = await sessionGet(KEYS.AI_TAB_MODES);
    const modes = { ...(data[KEYS.AI_TAB_MODES] && typeof data[KEYS.AI_TAB_MODES] === "object" ? data[KEYS.AI_TAB_MODES] : {}) };
    if (mode === "auto") delete modes[String(tab)];
    else modes[String(tab)] = mode;
    await sessionSet({ [KEYS.AI_TAB_MODES]: modes });
    return mode;
  });
}

async function clearTabAIMode(tabId) {
  const tab = normalizeTabId(tabId);
  return withTabAIModesWrite(async () => {
    const data = await sessionGet(KEYS.AI_TAB_MODES);
    const modes = { ...(data[KEYS.AI_TAB_MODES] && typeof data[KEYS.AI_TAB_MODES] === "object" ? data[KEYS.AI_TAB_MODES] : {}) };
    if (!Object.prototype.hasOwnProperty.call(modes, String(tab))) return false;
    delete modes[String(tab)];
    await sessionSet({ [KEYS.AI_TAB_MODES]: modes });
    return true;
  });
}

async function detectedAIForTab(tabId) {
  const tab = await chrome.tabs.get(normalizeTabId(tabId));
  let origin = "";
  try { origin = new URL(String(tab?.url || "")).origin.toLowerCase(); } catch (_) {}
  return { tab, origin, ai_id: BB2ConversationIdentity.providerForOrigin(origin) };
}
function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

function withDiagnosticsWrite(fn) {
  const next = diagnosticsWriteLock.then(fn, fn);
  diagnosticsWriteLock = next.catch(() => null);
  return next;
}

function withCopyProfilesWrite(fn) {
  const next = copyProfilesWriteLock.then(fn, fn);
  copyProfilesWriteLock = next.catch(() => null);
  return next;
}

function copyProfileCollection(raw) {
  return BB2ManualControls.normalizeCopyButtonProfileCollection(raw);
}

async function getCopyButtonProfiles() {
  const data = await storageGet(KEYS.COPY_BUTTON_PROFILES);
  return copyProfileCollection(data[KEYS.COPY_BUTTON_PROFILES] || null);
}

async function broadcastCopyButtonProfiles(collection) {
  const normalized = copyProfileCollection(collection);
  const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*", "https://alice.yandex.ru/*"] }).catch(() => []);
  await Promise.all(tabs.map((tab) => tab.id ? tabMessage(tab.id, { type: "OZ_SET_COPY_BUTTON_PROFILES", profiles: normalized }).catch(() => null) : null));
  return normalized;
}

async function saveCopyButtonProfile(profile) {
  const normalized = BB2ManualControls.normalizeCopyButtonProfile(profile);
  if (!normalized) throw Object.assign(new Error("Invalid Copy button profile."), { code: "INVALID_COPY_BUTTON_PROFILE" });
  return withCopyProfilesWrite(async () => {
    const current = await getCopyButtonProfiles();
    const key = BB2ManualControls.copyButtonProfileKey(normalized);
    const currentKeys = new Set(current.profiles.map(BB2ManualControls.copyButtonProfileKey));
    const profiles = currentKeys.has(key) ? current.profiles : [...current.profiles, normalized];
    if (profiles.length > BB2ManualControls.MAX_CUSTOM_COPY_BUTTON_PROFILES) {
      throw Object.assign(new Error(`Достигнут безопасный предел ${BB2ManualControls.MAX_CUSTOM_COPY_BUTTON_PROFILES} пользовательских Copy-профилей.`), { code: "COPY_PROFILE_LIMIT" });
    }
    const merged = copyProfileCollection({ kind: "bb2_manual_copy_profiles_v2", profiles });
    await storageSet({ [KEYS.COPY_BUTTON_PROFILES]: merged });
    await broadcastCopyButtonProfiles(merged);
    return merged;
  });
}

async function clearCopyButtonProfiles() {
  return withCopyProfilesWrite(async () => {
    const empty = copyProfileCollection(null);
    await storageSet({ [KEYS.COPY_BUTTON_PROFILES]: empty });
    await broadcastCopyButtonProfiles(empty);
    return empty;
  });
}

function sanitizeDiagnosticValue(value, key = "", depth = 0) {
  const lower = String(key || "").toLowerCase();
  if (["token", "authorization", "api_key", "api-key", "client_id", "client-id", "clientid", "prompt_text", "report_text", "outgoing_text", "body", "credential"].includes(lower) || lower.includes("token") || lower.includes("secret") || lower.includes("api_key") || lower.includes("api-key") || lower.includes("client_id") || lower.includes("client-id") || lower.includes("clientid")) {
    return undefined;
  }
  if (depth > 4) return "[depth-limited]";
  if (typeof value === "string") return value.length > 500 ? `${value.slice(0, 500)}…` : value;
  if (value === null || ["number", "boolean"].includes(typeof value)) return value;
  if (Array.isArray(value)) return value.slice(0, 50).map((item) => sanitizeDiagnosticValue(item, "", depth + 1)).filter((item) => item !== undefined);
  if (typeof value === "object") {
    const result = {};
    for (const [childKey, childValue] of Object.entries(value)) {
      const safe = sanitizeDiagnosticValue(childValue, childKey, depth + 1);
      if (safe !== undefined) result[childKey] = safe;
    }
    return result;
  }
  return String(value);
}

function safeDiagnosticDetails(details = {}) {
  return sanitizeDiagnosticValue(details, "", 0) || {};
}

async function sha256Hex(value) {
  const bytes = new TextEncoder().encode(String(value || ""));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

function canonicalBackupValue(value) {
  if (Array.isArray(value)) return value.map(canonicalBackupValue);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonicalBackupValue(value[key])]));
  }
  return value;
}

async function exportCredentialsBackup() {
  const settings = await getSettings();
  const seller = OzonCredentials.normalizeSellerCredentials(settings.sellerCredentials, { required: false });
  const performance = OzonCredentials.normalizePerformanceCredentials(settings.performanceCredentials, { required: false });
  if (!seller.present && !performance.present) {
    throw Object.assign(new Error("Нет сохранённых Ozon credentials для экспорта."), { code: "NO_CREDENTIALS_TO_EXPORT" });
  }
  const payload = {
    seller_client_id: seller.clientId,
    seller_api_key: seller.apiKey,
    performance_client_id: performance.clientId,
    performance_client_secret: performance.clientSecret
  };
  return {
    format: CREDENTIAL_BACKUP_FORMAT,
    backup_version: CREDENTIAL_BACKUP_VERSION,
    exported_at: new Date().toISOString(),
    extension_version: VERSION,
    extension_id: chrome.runtime.id || null,
    contains_secrets: true,
    credentials_sha256: await sha256Hex(JSON.stringify(canonicalBackupValue(payload))),
    credentials: payload
  };
}

async function verifyBackupChecksum(backup) {
  if (backup.contains_secrets !== true) {
    throw Object.assign(new Error("Backup credentials не помечен как secret-bearing."), { code: "INVALID_CREDENTIAL_BACKUP" });
  }
  const incoming = backup.credentials;
  if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) {
    throw Object.assign(new Error("Backup не содержит credentials object."), { code: "INVALID_CREDENTIAL_BACKUP" });
  }
  const expectedHash = String(backup.credentials_sha256 || "").toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(expectedHash)) {
    throw Object.assign(new Error("Backup не содержит корректную SHA-256 checksum."), { code: "INVALID_CREDENTIAL_BACKUP_CHECKSUM" });
  }
  const actualHash = await sha256Hex(JSON.stringify(canonicalBackupValue(incoming)));
  if (actualHash !== expectedHash) {
    throw Object.assign(new Error("Контрольная сумма backup credentials не совпала."), { code: "CREDENTIAL_BACKUP_CHECKSUM_MISMATCH" });
  }
  return incoming;
}

async function importCredentialsBackup(backup) {
  const isLegacy = backup?.format === LEGACY_CREDENTIAL_BACKUP_FORMAT && Number(backup?.backup_version || 0) === LEGACY_CREDENTIAL_BACKUP_VERSION;
  const isCurrent = backup?.format === CREDENTIAL_BACKUP_FORMAT && Number(backup?.backup_version || 0) === CREDENTIAL_BACKUP_VERSION;
  if (!isLegacy && !isCurrent) {
    throw Object.assign(new Error("Это не поддерживаемый backup Октопорт credentials."), { code: "INVALID_CREDENTIAL_BACKUP" });
  }
  const incoming = await verifyBackupChecksum(backup);
  if (isLegacy) {
    const seller = OzonCredentials.normalizeSellerCredentials({
      clientId: incoming.seller_client_id,
      apiKey: incoming.seller_api_key
    }, { required: true });
    await storageSet({
      [KEYS.SELLER_CLIENT_ID]: seller.clientId,
      [KEYS.SELLER_API_KEY]: seller.apiKey
    });
    await setStatus({ ok: true, code: "CREDENTIALS_IMPORTED", message: "Legacy Seller credentials импортированы; существующие Performance credentials не изменялись." });
    const settings = await getSettings();
    return {
      ...OzonCredentials.publicCredentialState(settings.sellerCredentials),
      ...OzonCredentials.publicPerformanceCredentialState(settings.performanceCredentials),
      legacy_import: true
    };
  }

  const seller = OzonCredentials.normalizeSellerCredentials({
    clientId: incoming.seller_client_id,
    apiKey: incoming.seller_api_key
  }, { required: false });
  const performance = OzonCredentials.normalizePerformanceCredentials({
    clientId: incoming.performance_client_id,
    clientSecret: incoming.performance_client_secret
  }, { required: false });
  if (!seller.present && !performance.present) {
    throw Object.assign(new Error("Backup не содержит ни одной полной пары Ozon credentials."), { code: "INVALID_CREDENTIAL_BACKUP" });
  }
  await storageSet({
    [KEYS.SELLER_CLIENT_ID]: seller.clientId,
    [KEYS.SELLER_API_KEY]: seller.apiKey,
    [KEYS.PERFORMANCE_CLIENT_ID]: performance.clientId,
    [KEYS.PERFORMANCE_CLIENT_SECRET]: performance.clientSecret
  });
  OzonProvider.clearPerformanceToken();
  await setStatus({ ok: true, code: "CREDENTIALS_IMPORTED", message: "Seller + Performance credentials импортированы из проверенного локального backup." });
  return {
    ...OzonCredentials.publicCredentialState(seller),
    ...OzonCredentials.publicPerformanceCredentialState(performance),
    legacy_import: false
  };
}

async function diagnostic(event, details = {}, options = {}) {
  try {
    return await withDiagnosticsWrite(async () => {
      const current = await storageGet([KEYS.DIAGNOSTICS, KEYS.DIAGNOSTIC_SEQ]);
      const list = Array.isArray(current[KEYS.DIAGNOSTICS]) ? current[KEYS.DIAGNOSTICS] : [];
      const sequence = Math.max(0, Number(current[KEYS.DIAGNOSTIC_SEQ] || 0)) + 1;
      const safe = safeDiagnosticDetails(details);
      const record = {
        sequence,
        event_id: `event-${sequence}-${crypto.randomUUID()}`,
        at: new Date().toISOString(),
        runtime_version: VERSION,
        source: String(options.source || safe.source || "service_worker"),
        level: String(options.level || safe.level || "info"),
        event: String(event || "UNKNOWN_EVENT"),
        ...safe
      };
      list.push(record);
      await storageSet({
        [KEYS.DIAGNOSTICS]: list.slice(-MAX_DIAGNOSTICS),
        [KEYS.DIAGNOSTIC_SEQ]: sequence
      });
      return record;
    });
  } catch (_) {
    return null;
  }
}

function normalizeConversationKey(value) {
  const key = String(value || "").trim();
  if (!key || key.length > 300) {
    throw Object.assign(new Error("Не удалось определить текущий AI-диалог."), { code: "INVALID_CONVERSATION_KEY" });
  }
  return key;
}

function normalizeTabId(value) {
  const id = Number(value);
  if (!Number.isInteger(id) || id <= 0) throw Object.assign(new Error("Не удалось определить вкладку поддерживаемого AI."), { code: "INVALID_TAB_ID" });
  return id;
}

function normalizeIdentity(identity) {
  const origin = String(identity?.origin || "").trim().toLowerCase();
  const aiId = BB2ConversationIdentity.providerForOrigin(origin);
  if (!aiId) throw Object.assign(new Error("Origin не принадлежит поддерживаемому AI."), { code: "INVALID_AI_ORIGIN" });
  if (identity?.ai_id && String(identity.ai_id) !== aiId)
    throw Object.assign(new Error("AI adapter identity не совпадает с origin."), { code: "AI_IDENTITY_MISMATCH" });
  const candidate = typeof identity?.conversation_id === "string" ? identity.conversation_id.trim().toLowerCase() : null;
  const status = String(identity?.status || (candidate ? "confirmed" : "unknown"));
  if (status === "conflict") throw Object.assign(new Error("Свидетельства текущего диалога противоречат друг другу."), { code: "CONVERSATION_IDENTITY_CONFLICT" });
  const confirmed = status === "confirmed" && candidate && candidate.length <= 256 && !/[\s|\u0000-\u001f]/u.test(candidate);
  return {
    origin, ai_id: aiId, conversation_id: confirmed ? candidate : null,
    status: confirmed ? "confirmed" : status === "confirmed" ? "unknown" : status,
    source: String(identity?.source || "none"), chat_path: String(identity?.chat_path || ""),
    proof_version: Number(identity?.proof_version || 0),
    identity_scope: identity?.identity_scope === "document" || BB2ConversationIdentity.isLocal(candidate) ? "document" : "conversation",
    surface_id: typeof identity?.surface_id === "string" ? identity.surface_id : null,
    identity_evidence: SellerAgentsConversationIdentity.normalizeProof(identity?.identity_evidence)
  };
}

function conversationKeyFromIdentity(identity) {
  const normalized = normalizeIdentity(identity);
  if (!normalized.conversation_id) return null;
  return `${normalized.origin}|${normalized.conversation_id}`;
}

function expectedDeliveryConfirmationBasis(origin) {
  const provider = BB2ConversationIdentity.providerForOrigin(String(origin || "").toLowerCase());
  if (provider === "chatgpt") return "microphone";
  if (provider === "alice") return "alice_ready";
  if (["qwen", "kimi", "grok", "gemini", "claude", "deepseek"].includes(provider)) return provider + "_user_turn_ready";
  return "";
}

function acceptedDeliveryConfirmationBasis(origin, basis) {
  const received = String(basis || "");
  if (received === expectedDeliveryConfirmationBasis(origin)) return true;
  return BB2ConversationIdentity.providerForOrigin(String(origin || "").toLowerCase()) === "chatgpt"
    && received === "work_submit_disabled_after_click";
}

function legacyConversationKey(identity) {
  const normalized = normalizeIdentity(identity);
  return normalized.ai_id === "chatgpt" && normalized.conversation_id ? `chatgpt:c:${normalized.conversation_id}` : null;
}

function sameConversationIdentity(a, b) {
  const left = normalizeIdentity(a);
  const right = normalizeIdentity(b);
  return Boolean(left.conversation_id && right.conversation_id && left.origin === right.origin && left.conversation_id === right.conversation_id);
}

async function tabIdentity(tabId) {
  const tab = normalizeTabId(tabId);
  const response = await tabMessage(tab, { type: "OZ_GET_IDENTITY" });
  if (!response?.ok || !response.identity) {
    throw Object.assign(new Error(response?.error || "Не удалось прочитать identity AI-диалога."), { code: response?.code || "IDENTITY_UNAVAILABLE", transport_class: safeTabMessageTransportClass(response?.transport_class) });
  }
  const identity = normalizeIdentity(response.identity);
  return typeof saResolveSurfaceIdentity === "function" ? saResolveSurfaceIdentity(tab, identity) : identity;
}

async function assertTabConversation(tabId, conversationKey, expectedConversationId = null) {
  const key = normalizeConversationKey(conversationKey);
  const identity = await tabIdentity(tabId);
  const liveKey = conversationKeyFromIdentity(identity);
  if (!liveKey || liveKey !== key) {
    throw Object.assign(new Error("Привязанная вкладка открыта на другом или неподтверждённом AI-диалоге."), { code: "CONVERSATION_MISMATCH" });
  }
  if (expectedConversationId && identity.conversation_id !== String(expectedConversationId).toLowerCase()) {
    throw Object.assign(new Error("Conversation ID вкладки не совпадает с owner-run."), { code: "CONVERSATION_MISMATCH" });
  }
  return identity;
}

function withBindingWrite(fn) {
  const next = bindingWriteLock.then(fn, fn);
  bindingWriteLock = next.catch(() => null);
  return next;
}

async function getConversationBindings() {
  const data = await storageGet(KEYS.CONVERSATION_BINDINGS);
  return { ...(data[KEYS.CONVERSATION_BINDINGS] || {}) };
}

async function getWorkSessions() { const data = await storageGet(KEYS.WORK_SESSIONS); return { ...(data[KEYS.WORK_SESSIONS] || {}) }; }
async function getPendingWorkStarts() { const data = await storageGet(KEYS.PENDING_WORK_STARTS); return { ...(data[KEYS.PENDING_WORK_STARTS] || {}) }; }
async function getWorkRecoveries() { const data = await storageGet(KEYS.WORK_SESSION_RECOVERIES); return { ...(data[KEYS.WORK_SESSION_RECOVERIES] || {}) }; }
async function workSessionFor(key) { const sessions = await getWorkSessions(); return OzonWorkSessionModel.normalize(sessions[key], key); }
function transitionWorkSessionRecord(sessions, key, expectedRevision, nextState, patch = {}) {
  const current = OzonWorkSessionModel.normalize(sessions[key], key);
  if (expectedRevision !== null && Number(expectedRevision) !== current.revision) {
    throw Object.assign(new Error("Устаревшее событие work-session проигнорировано."), { code: "WORK_SESSION_STALE_EVENT" });
  }
  const next = OzonWorkSessionModel.transition(current, nextState, { ...patch, conversation_key: key });
  sessions[key] = next;
  return next;
}
async function mutateWorkSession(key, expectedRevision, nextState, patch = {}) {
  return withBindingWrite(async () => {
    OzonWorkSessionModel.assertStorageAvailable();
    let sessions;
    try { sessions = await getWorkSessions(); }
    catch (cause) {
      OzonWorkSessionModel.markStorageUnavailable();
      throw Object.assign(new Error("Work state could not be read"), {
        code: "WORK_STATE_COMMIT_UNCONFIRMED", stage: "read", cause,
      });
    }
    // Stale-context errors do not poison storage or unrelated dialogues.
    const next = transitionWorkSessionRecord(sessions, key, expectedRevision, nextState, patch);
    try {
      await storageSet({ [KEYS.WORK_SESSIONS]: sessions });
      const observed = await getWorkSessions();
      const canonical = globalThis.SellerAgentsBootstrapVerifier.canonicalJson;
      if (canonical(observed) !== canonical(sessions)) throw new Error("Work write readback mismatch");
    } catch (cause) {
      OzonWorkSessionModel.markStorageUnavailable();
      throw Object.assign(new Error("Work state write was not confirmed"), {
        code: "WORK_STATE_COMMIT_UNCONFIRMED", stage: "write_or_readback", cause,
      });
    }
    return next;
  });
}
async function retireWorkSession(key) { return mutateWorkSession(key, null, OzonWorkSessionModel.STATES.FINISHING).then((session) => mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.INACTIVE)); }
async function createPendingWorkStart(tab, identity, options = {}) {
  const pending = await getPendingWorkStarts();
  const slot = String(tab);
  const now = new Date().toISOString();
  const existing = pending[slot] || null;
  if (existing) {
    const sameSurface = existing.origin === identity.origin && existing.ai_id === identity.ai_id && (!existing.surface_id || existing.surface_id === identity.surface_id);
    const unexpired = String(existing.expires_at || "") > now;
    if (sameSurface && unexpired) return { duplicate: true, transaction: existing };
    delete pending[slot];
    await storageSet({ [KEYS.PENDING_WORK_STARTS]: pending });
    await diagnostic("WORK_PENDING_START_STALE_RETIRED", { tab_id: tab, intent_id: existing.intent_id || null, revision: Number(existing.revision || 0), reason: unexpired ? "surface_changed" : "expired", external_request_executed: false });
  }
  const revision = Math.max(1, Number(options.revision || 1));
  const observedConversationId = String(options.observed_conversation_id || identity.conversation_id || "").trim().toLowerCase() || null;
  const conversationKey = String(options.conversation_key || "").trim().toLowerCase() || null;
  const expectedSessionRevision = Number.isFinite(Number(options.expected_session_revision)) ? Number(options.expected_session_revision) : null;
  const transaction = {
    version: 2,
    store_context: saStarts.get(Number(tab)) || null,
    admission_provenance: options.admission_provenance || null,
    prompt_tree: options.prompt_tree ? JSON.parse(JSON.stringify(options.prompt_tree)) : null,
    state: OzonWorkSessionModel.STATES.PENDING_IDENTITY,
    intent_id: String(options.intent_id || "").trim() || `work-start-${crypto.randomUUID()}`,
    revision,
    tab_id: tab,
    origin: identity.origin,
    ai_id: identity.ai_id,
    conversation_key: conversationKey,
    surface_id: identity.surface_id || null,
    identity_scope: identity.identity_scope || null,
    expected_session_revision: expectedSessionRevision,
    created_at: now,
    expires_at: new Date(Date.now() + 120000).toISOString(),
    prompt_delivered: false,
    observed_conversation_id: observedConversationId,
    first_response_complete: false,
    send_commit_actor_id: null,
    send_committed_at: null,
    send_outcome: "not_started",
    assistant_baseline_ids: [],
    content_runtime_generation: null
  };
  pending[slot] = transaction;
  await diagnostic("WORK_START_PENDING_CREATED", { intent_id: transaction.intent_id, revision: transaction.revision, tab_id: tab, conversation_id: observedConversationId, state_before: options.state_before || null, state_after: transaction.state, external_request_executed: false });
  await saAdmissionMutationGuard({ operation: "start", tabId: tab, conversationKey, intentId: transaction.intent_id });
  await storageSet({ [KEYS.PENDING_WORK_STARTS]: pending });
  await diagnostic("WORK_START_PENDING_PERSISTED", { intent_id: transaction.intent_id, revision: transaction.revision, tab_id: tab, conversation_id: observedConversationId, external_request_executed: false });
  const readback = (await getPendingWorkStarts())[slot] || null;
  // Browser storage can reorder object fields. Compare the complete JSON store context without depending on field order.
  const canonicalStoreContext = (value) => JSON.stringify(value, (_key, entry) =>
    entry && typeof entry === "object" && !Array.isArray(entry)
      ? Object.fromEntries(Object.keys(entry).sort().map((key) => [key, entry[key]]))
      : entry
  );
  if (!readback || readback.intent_id !== transaction.intent_id || Number(readback.revision) !== transaction.revision || readback.origin !== transaction.origin || readback.ai_id !== transaction.ai_id || readback.surface_id !== transaction.surface_id || readback.identity_scope !== transaction.identity_scope || readback.conversation_key !== transaction.conversation_key || canonicalStoreContext(readback.store_context) !== canonicalStoreContext(transaction.store_context)) {
    throw Object.assign(new Error("Pending Work Start transaction was not durably read back before Send."), { code: "WORK_START_PENDING_COMMIT_READBACK_FAILED" });
  }
  await diagnostic("WORK_START_PENDING_COMMIT_ACK", { intent_id: transaction.intent_id, revision: transaction.revision, tab_id: tab, conversation_id: observedConversationId, external_request_executed: false });
  return { duplicate: false, transaction: readback };
}

async function pendingWorkStartForMessage(message, sender) {
  const tab = normalizeTabId(sender?.tab?.id || message.tab_id);
  const starts = await getPendingWorkStarts();
  const pending = starts[String(tab)] || null;
  if (!pending || pending.intent_id !== String(message.intent_id || "") || Number(pending.revision) !== Number(message.revision)) {
    throw Object.assign(new Error("Pending Work Start correlation is stale or invalid."), { code: "WORK_PENDING_STALE_OR_INVALID" });
  }
  if (String(pending.expires_at || "") <= new Date().toISOString()) {
    await clearPendingWorkStartUnlocked(starts, tab, pending.intent_id, pending.revision, "response_timeout");
    throw Object.assign(new Error("Pending Work Start expired."), { code: "WORK_PENDING_TIMEOUT" });
  }
  await saPendingGuard(pending);
  const identity = normalizeIdentity(message.identity || {});
  if (!identity.origin || !identity.ai_id || identity.origin !== pending.origin || identity.ai_id !== pending.ai_id) {
    throw Object.assign(new Error("Pending Work Start origin/AI correlation mismatch."), { code: "WORK_PENDING_IDENTITY_MISMATCH" });
  }
  if (pending.surface_id && pending.surface_id !== identity.surface_id) throw Object.assign(new Error("Dialogue surface changed during Start."), { code: "WORK_PENDING_SURFACE_CHANGED" });
  if (pending.observed_conversation_id && identity.conversation_id && pending.observed_conversation_id !== identity.conversation_id) {
    throw Object.assign(new Error("Pending Work Start conversation correlation mismatch."), { code: "WORK_PENDING_CONVERSATION_CHANGED" });
  }
  return { tab, starts, pending, identity };
}

async function commitPendingWorkStartSend(message, sender) {
  return withBindingWrite(async () => {
    const { tab, starts, pending, identity } = await pendingWorkStartForMessage(message, sender);
    const slot = String(tab);
    const actorId = String(message.actor_id || "").trim();
    if (!actorId) return { ok: false, committed: false, click_allowed: false, code: "WORK_START_ACTOR_REQUIRED" };
    if (pending.send_commit_actor_id) {
      return { ok: true, committed: true, click_allowed: false, outcome_unknown: pending.send_outcome !== "sent_acknowledged", code: "WORK_START_ALREADY_COMMITTED_NO_RETRY", pending_start: pending };
    }
    const next = { ...pending, send_commit_actor_id: actorId, send_committed_at: new Date().toISOString(), send_outcome: "committed_before_click", content_runtime_generation: String(message.runtime_generation || "") || null, observed_conversation_id: pending.observed_conversation_id || identity.conversation_id || null };
    starts[slot] = next;
    await storageSet({ [KEYS.PENDING_WORK_STARTS]: starts });
    const readback = (await getPendingWorkStarts())[slot] || null;
    if (!readback || readback.send_commit_actor_id !== actorId || readback.intent_id !== pending.intent_id || Number(readback.revision) !== Number(pending.revision)) {
      throw Object.assign(new Error("Work Start send commit was not durably acknowledged."), { code: "WORK_START_SEND_COMMIT_READBACK_FAILED" });
    }
    await diagnostic("WORK_START_PENDING_COMMIT_ACK", { intent_id: pending.intent_id, revision: pending.revision, tab_id: tab, conversation_id: readback.observed_conversation_id || null, runtime_generation: readback.content_runtime_generation || null, phase: "send_commit", external_request_executed: false });
    return { ok: true, committed: true, click_allowed: true, intent_id: pending.intent_id, revision: pending.revision };
  });
}

function workStartWatchPayload(pending) {
  return {
    intent_id: String(pending?.intent_id || ""),
    revision: Number(pending?.revision || 0),
    origin: String(pending?.origin || "").toLowerCase(),
    ai_id: String(pending?.ai_id || ""),
    conversation_id: String(pending?.observed_conversation_id || "").toLowerCase() || null,
    surface_id: pending?.surface_id || null,
    assistant_baseline_ids: Array.isArray(pending?.assistant_baseline_ids) ? pending.assistant_baseline_ids.map((id) => String(id)).filter(Boolean) : [],
    runtime_generation: pending?.content_runtime_generation || null
  };
}

async function pushPendingWorkStartWatch(tab, pending, reason = "send_acknowledged") {
  if (!pending || pending.prompt_delivered !== true || pending.send_outcome !== "sent_acknowledged") return { ok: false, code: "WORK_START_WATCH_NOT_READY" };
  const payload = workStartWatchPayload(pending);
  const pushed = await tabMessage(tab, { type: "OZ_WORK_START_WATCH", ...payload });
  await diagnostic("WORK_START_WATCHER_BOOTSTRAP", {
    intent_id: pending.intent_id,
    revision: pending.revision,
    tab_id: tab,
    conversation_id: pending.observed_conversation_id || null,
    runtime_generation: pending.content_runtime_generation || null,
    reason,
    ok: pushed?.ok === true && pushed?.started === true,
    code: pushed?.code || null,
    external_request_executed: false
  }, { level: pushed?.ok === true && pushed?.started === true ? "info" : "warning" });
  return pushed || { ok: false, code: "WORK_START_WATCH_PUSH_NO_RESPONSE" };
}

async function acknowledgePendingWorkStartSend(message, sender) {
  return withBindingWrite(async () => {
    const { tab, starts, pending, identity } = await pendingWorkStartForMessage(message, sender);
    const slot = String(tab);
    const actorId = String(message.actor_id || "").trim();
    if (!pending.send_commit_actor_id || pending.send_commit_actor_id !== actorId) {
      return { ok: false, accepted: false, code: "WORK_START_SEND_ACTOR_MISMATCH" };
    }
    const clickObserved = message.click_event_observed === true;
    const composerEmpty = message.composer_empty === true;
    const sendOutcome = clickObserved && composerEmpty ? "sent_acknowledged" : clickObserved ? "outcome_unknown_no_retry" : "failed_before_irreversible_click";
    const next = {
      ...pending,
      prompt_delivered: sendOutcome === "sent_acknowledged",
      send_outcome: sendOutcome,
      observed_conversation_id: pending.observed_conversation_id || identity.conversation_id || null,
      assistant_baseline_ids: Array.isArray(message.assistant_baseline_ids) ? message.assistant_baseline_ids.map((id) => String(id)).filter(Boolean) : [],
      content_runtime_generation: String(message.runtime_generation || pending.content_runtime_generation || "") || null
    };
    starts[slot] = next;
    await storageSet({ [KEYS.PENDING_WORK_STARTS]: starts });
    await diagnostic("WORK_START_SEND_OUTCOME", { intent_id: pending.intent_id, revision: pending.revision, tab_id: tab, conversation_id: next.observed_conversation_id || null, runtime_generation: next.content_runtime_generation || null, click_event_observed: clickObserved, composer_empty: composerEmpty, send_outcome: sendOutcome, external_request_executed: false }, { level: sendOutcome === "sent_acknowledged" ? "info" : "warning" });
    await diagnostic("WORK_START_WORKER_ACK_RECEIVED", { intent_id: pending.intent_id, revision: pending.revision, tab_id: tab, conversation_id: next.observed_conversation_id || null, send_outcome: sendOutcome, external_request_executed: false });
    let watcherBootstrap = null;
    if (sendOutcome === "sent_acknowledged") watcherBootstrap = await pushPendingWorkStartWatch(tab, next, "worker_send_outcome_ack");
    return { ok: true, accepted: true, intent_id: pending.intent_id, revision: pending.revision, send_outcome: sendOutcome, no_retry: sendOutcome !== "failed_before_irreversible_click", watcher_bootstrap: watcherBootstrap };
  });
}

async function markKnownWorkStartError(pending, code) {
  const key = String(pending?.conversation_key || "").trim().toLowerCase();
  if (!key) return;
  const session = await workSessionFor(key);
  if (![OzonWorkSessionModel.STATES.INACTIVE, OzonWorkSessionModel.STATES.ERROR].includes(session.state)) return;
  if (Number.isFinite(Number(pending.expected_session_revision)) && session.revision !== Number(pending.expected_session_revision)) return;
  if (session.state === OzonWorkSessionModel.STATES.ERROR) return;
  await mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.ERROR, { error: { code: String(code || "WORK_START_SEND_FAILED") } });
}

async function dispatchPendingWorkStartPrompt(tab, pending, promptText) {
  await diagnostic("WORK_START_DISPATCH_PROGRESS", { tab_id: tab, intent_id: pending.intent_id, revision: pending.revision, stage: "guard_enter" });
  await saPendingGuard(pending);
  await diagnostic("WORK_START_DISPATCH_PROGRESS", { tab_id: tab, intent_id: pending.intent_id, revision: pending.revision, stage: "guard_passed" });
  if (pending.store_context) promptText = await saPendingPrompt(pending);
  await diagnostic("WORK_START_CONTENT_DISPATCHED", { intent_id: pending.intent_id, revision: pending.revision, tab_id: tab, conversation_id: pending.observed_conversation_id || null, external_request_executed: false });
  const sent = await tabMessage(tab, {
    type: "OZ_WORK_SEND_INITIAL_PROMPT",
    intent_id: pending.intent_id,
    revision: pending.revision,
    conversation_key: pending.conversation_key || null,
    expected_conversation_id: pending.observed_conversation_id || null,
    prompt_text: String(promptText || DEFAULT_AUTO_START_TEXT)
  });
  await diagnostic("WORK_START_DISPATCH_PROGRESS", { tab_id: tab, intent_id: pending.intent_id, revision: pending.revision,
    stage: "content_response", response_ok: sent?.ok === true, response_sent: sent?.sent === true });
  const latest = (await getPendingWorkStarts())[String(tab)] || null;
  if (!sent?.ok || sent.sent !== true) {
    if (latest?.intent_id === pending.intent_id && latest.send_commit_actor_id) {
      if (latest.send_outcome === "failed_before_irreversible_click") {
        await clearPendingWorkStart(tab, pending.intent_id, pending.revision, sent?.code || "send_failed_before_irreversible_click");
        await markKnownWorkStartError(pending, sent?.code || "WORK_START_SEND_FAILED");
        await diagnostic("WORK_START_SEND_FAILED", { intent_id: pending.intent_id, revision: pending.revision, tab_id: tab, conversation_id: latest.observed_conversation_id || null, send_outcome: latest.send_outcome, code: sent?.code || "WORK_START_SEND_FAILED", external_request_executed: false }, { level: "error" });
        return;
      }
      const lostTransportClass = sent?.code === "TAB_MESSAGE_ERROR"
        ? safeTabMessageTransportClass(sent?.transport_class) || "OTHER_TAB_MESSAGE_ERROR"
        : null;
      await diagnostic("WORK_START_CONTENT_RESPONSE_LOST_NO_RETRY", { intent_id: pending.intent_id, revision: pending.revision, tab_id: tab, conversation_id: latest.observed_conversation_id || null, send_outcome: latest.send_outcome || null, code: sent?.code || "WORK_START_CONTENT_RESPONSE_LOST", transport_class: lostTransportClass, external_request_executed: false }, { level: "warning" });
      return;
    }
    await clearPendingWorkStart(tab, pending.intent_id, pending.revision, sent?.code || "send_failed_before_commit");
    await markKnownWorkStartError(pending, sent?.code || "WORK_START_SEND_FAILED");
    await diagnostic("WORK_START_SEND_FAILED", { intent_id: pending.intent_id, revision: pending.revision, tab_id: tab, conversation_id: pending.observed_conversation_id || null, code: sent?.code || "WORK_START_SEND_FAILED", external_request_executed: false }, { level: "error" });
    return;
  }
  if (String(sent.intent_id || "") !== pending.intent_id || Number(sent.revision) !== Number(pending.revision)) {
    await diagnostic("WORK_START_CONTENT_ACK_CORRELATION_MISMATCH", { intent_id: pending.intent_id, revision: pending.revision, tab_id: tab, received_intent_id: sent.intent_id || null, received_revision: Number(sent.revision || 0), external_request_executed: false }, { level: "error" });
  }
}

async function clearPendingWorkStartUnlocked(starts, tab, intentId, revision, reason) {
  const slot = String(tab);
  const current = starts[slot] || null;
  if (!current || current.intent_id !== String(intentId || "") || Number(current.revision) !== Number(revision)) return false;
  delete starts[slot];
  await storageSet({ [KEYS.PENDING_WORK_STARTS]: starts });
  await diagnostic("WORK_PENDING_START_TERMINAL", { tab_id: tab, intent_id: current.intent_id, revision: current.revision, reason: String(reason || "terminal"), external_request_executed: false });
  return true;
}

async function clearPendingWorkStart(tab, intentId, revision, reason) {
  return withBindingWrite(async () => clearPendingWorkStartUnlocked(await getPendingWorkStarts(), tab, intentId, revision, reason));
}

async function clearPendingWorkStartForTab(tab, reason = "tab_closed") {
  return withBindingWrite(async () => {
    const starts = await getPendingWorkStarts();
    const slot = String(tab);
    const current = starts[slot] || null;
    if (!current) return false;
    delete starts[slot];
    await storageSet({ [KEYS.PENDING_WORK_STARTS]: starts });
    await diagnostic("WORK_PENDING_START_CANCELLED_TAB_CLOSED", { tab_id: tab, external_request_executed: false });
    return true;
  });
}

async function updatePendingWorkStartObservation(tab, expected, identity) {
  return withBindingWrite(async () => {
    const starts = await getPendingWorkStarts();
    const slot = String(tab);
    const current = starts[slot] || null;
    if (!current || current.intent_id !== expected.intent_id || Number(current.revision) !== Number(expected.revision)) return false;
    starts[slot] = { ...current, observed_conversation_id: identity.conversation_id, first_response_complete: false };
    await storageSet({ [KEYS.PENDING_WORK_STARTS]: starts });
    return true;
  });
}
async function terminalizeRefreshOperation(key) {
  const operation = await getManualOperation(key);
  if (!operation || !manualOperationActive(operation)) return { operation_id: null, phase: "none", provider_dispatched: false, delivery_preserved: false };

  if (operation.status === MANUAL_OPERATION_STATUSES.DELIVERING) {
    return {
      operation_id: operation.operation_id,
      phase: `delivery:${String(operation.delivery?.phase || "unknown")}`,
      provider_dispatched: true,
      provider_result_durable: true,
      delivery_preserved: true,
      delivery_id: operation.delivery?.delivery_id || operation.delivery_id || null
    };
  }

  const requestState = String(operation.batch?.request_state || "idle");
  const entries = Array.isArray(operation.batch?.entries) ? operation.batch.entries : [];
  const requestInFlight = requestState === "requesting" || entries.some((entry) => entry?.status === "requesting");
  const code = requestInFlight ? "REQUEST_OUTCOME_UNKNOWN_NO_RETRY" : "OPERATOR_REFRESH_BEFORE_PROVIDER";
  const message = requestInFlight
    ? "Refresh выполнен во время provider request: исход запроса неизвестен; автоматический повтор запрещён."
    : requestState === "quota_waiting"
      ? "Refresh отменил только текущую logical operation во время quota wait. Глобальные quota timers/state сохранены; автоматическое продолжение этой operation запрещено."
      : "Refresh отменил текущую logical operation до следующего provider dispatch.";

  await mutateManualOperation(key, (current) => {
    if (!current || current.operation_id !== operation.operation_id) return current;
    return {
      ...current,
      status: MANUAL_OPERATION_STATUSES.FAILED,
      request_worker_session_id: null,
      completed_at: new Date().toISOString(),
      last_error: { code, message, at: new Date().toISOString() },
      batch: current.batch ? {
        ...current.batch,
        request_state: requestInFlight ? "outcome_unknown" : "terminal",
        request_worker_session_id: null
      } : current.batch
    };
  });
  return { operation_id: operation.operation_id, phase: requestState, provider_dispatched: requestInFlight, delivery_preserved: false, code };
}

async function terminalizeFinishOperation(key) {
  const operation = await getManualOperation(key);
  if (!operation || !manualOperationActive(operation)) return { operation_id: null, code: null, provider_dispatched: false };
  const requestState = String(operation.batch?.request_state || "idle");
  const entries = Array.isArray(operation.batch?.entries) ? operation.batch.entries : [];
  const requestInFlight = operation.status === MANUAL_OPERATION_STATUSES.REQUESTING && (requestState === "requesting" || entries.some((entry) => entry?.status === "requesting"));
  const deliveryPending = operation.status === MANUAL_OPERATION_STATUSES.DELIVERING;
  const code = requestInFlight ? "REQUEST_OUTCOME_UNKNOWN_NO_RETRY" : (deliveryPending ? "OPERATOR_FINISH_DELIVERY_ABANDONED" : "OPERATOR_FINISH_BEFORE_PROVIDER");
  const message = requestInFlight
    ? "Finish выполнен во время provider request: исход неизвестен; автоматический повтор запрещён."
    : deliveryPending
      ? "Finish завершил work-session после сохранения provider result; недоставленный результат не будет автоматически replay-иться."
      : "Finish отменил текущую logical operation до provider dispatch.";
  await mutateManualOperation(key, (current) => {
    if (!current || current.operation_id !== operation.operation_id) return current;
    return {
      ...current,
      status: MANUAL_OPERATION_STATUSES.FAILED,
      request_worker_session_id: null,
      completed_at: new Date().toISOString(),
      last_error: { code, message, at: new Date().toISOString() },
      batch: current.batch ? {
        ...current.batch,
        request_state: requestInFlight ? "outcome_unknown" : "terminal",
        request_worker_session_id: null
      } : current.batch
    };
  });
  return { operation_id: operation.operation_id, code, provider_dispatched: requestInFlight || deliveryPending };
}

async function beginWorkSessionRefresh(tab, key) {
  const session = await workSessionFor(key);
  if (![OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN].includes(session.state)) {
    throw Object.assign(new Error("Refresh доступен только для активной work-session."), { code: "WORK_SESSION_NOT_ACTIVE" });
  }
  const recoveries = await getWorkRecoveries();
  if (recoveries[key]) return { already_in_progress: true, recovery: recoveries[key] };
  const live = await assertTabConversation(tab, key);
  const operation = await terminalizeRefreshOperation(key);
  const recovering = await mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.RECOVERING);
  await setWorkSessionCommandAcceptance(key, false);
  await tabMessage(tab, { type: "OZ_WORK_APPLY_VISIBILITY", visible: false, conversation_key: key });
  const recovery = {
    version: 1,
    recovery_id: `work-recovery-${crypto.randomUUID()}`,
    revision: recovering.revision,
    old_runtime_generation: workSessionRuntimeGeneration,
    new_runtime_generation: `work-runtime-${crypto.randomUUID()}`,
    worker_session_id: WORKER_SESSION_ID,
    tab_id: tab,
    origin: live.origin,
    ai_id: live.ai_id,
    conversation_id: live.conversation_id,
    conversation_key: key,
    previous_state: session.state,
    operation,
    created_at: new Date().toISOString(),
    expires_at: new Date(Date.now() + 120000).toISOString(),
    expected_visible: session.state === OzonWorkSessionModel.STATES.ACTIVE_VISIBLE
  };
  recoveries[key] = recovery;
  await storageSet({ [KEYS.WORK_SESSION_RECOVERIES]: recoveries });
  await diagnostic("WORK_SESSION_REFRESH_PREPARED", { recovery_id: recovery.recovery_id, old_runtime_generation: recovery.old_runtime_generation, new_runtime_generation: recovery.new_runtime_generation, worker_session_id: WORKER_SESSION_ID, operation_phase: operation.phase, provider_dispatched: operation.provider_dispatched, delivery_preserved: operation.delivery_preserved === true });
  return { already_in_progress: false, recovery };
}

async function waitForRefreshTabIdentity(recovery, timeoutMs = 15000) {
  const deadline = Date.now() + Math.max(1000, Number(timeoutMs || 15000));
  let lastCode = "IDENTITY_UNAVAILABLE";
  let lastError = "Content runtime is not ready after extension reload.";
  while (Date.now() < deadline) {
    const response = await tabMessage(Number(recovery.tab_id), { type: "OZ_GET_IDENTITY" });
    if (response?.ok && response.identity) {
      const identity = normalizeIdentity(response.identity);
      const matches = identity.origin === recovery.origin && identity.ai_id === recovery.ai_id && identity.conversation_id === recovery.conversation_id;
      if (!matches) return { ok: false, code: "WORK_REFRESH_CONTEXT_INVALID", identity };
      return { ok: true, identity };
    }
    lastCode = response?.code || "IDENTITY_UNAVAILABLE";
    lastError = response?.error || lastError;
    await sleep(250);
  }
  return { ok: false, code: "WORK_REFRESH_CONTENT_RECONNECT_TIMEOUT", error: lastError, last_code: lastCode };
}

async function reloadRefreshOwnerTabInProcess(recovery, timeoutMs = 15000) {
  const tabId = Number(recovery?.tab_id || 0);
  if (!Number.isInteger(tabId) || tabId <= 0) {
    return { ok: false, code: "WORK_REFRESH_TAB_RELOAD_FAILED", error: "Recovery owner tab is missing." };
  }
  const loaded = await new Promise((resolve) => {
    let settled = false;
    let sawLoading = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try { chrome.tabs.onUpdated.removeListener(listener); } catch (_) {}
      resolve(result);
    };
    const listener = (updatedTabId, changeInfo, tab) => {
      if (Number(updatedTabId) !== tabId) return;
      if (changeInfo?.status === "loading") sawLoading = true;
      if (changeInfo?.status === "complete" && sawLoading) finish({ ok: true, tab });
    };
    const timer = setTimeout(() => finish({ ok: false, code: "WORK_REFRESH_TAB_RELOAD_TIMEOUT", error: "AI tab reload did not complete in time." }), Math.max(1000, Number(timeoutMs || 15000)));
    chrome.tabs.onUpdated.addListener(listener);
    Promise.resolve(chrome.tabs.reload(tabId)).catch((error) => {
      finish({ ok: false, code: "WORK_REFRESH_TAB_RELOAD_FAILED", error: error?.message || String(error) });
    });
  });
  if (!loaded?.ok) return loaded;
  await diagnostic("WORK_SESSION_REFRESH_TAB_RELOAD_COMPLETED", {
    recovery_id: recovery.recovery_id,
    tab_id: tabId,
    conversation_key: recovery.conversation_key,
    worker_session_id: WORKER_SESSION_ID,
    runtime_generation: recovery.new_runtime_generation
  });
  return { ok: true, tab_id: tabId };
}

let workSessionRecoveryResumeInFlight = null;
async function resumeWorkSessionRecoveries() {
  if (workSessionRecoveryResumeInFlight) return workSessionRecoveryResumeInFlight;
  workSessionRecoveryResumeInFlight = resumeWorkSessionRecoveriesOnce().finally(() => { workSessionRecoveryResumeInFlight = null; });
  return workSessionRecoveryResumeInFlight;
}

async function resumeWorkSessionRecoveriesOnce() {
  const recoveries = await getWorkRecoveries();
  for (const [key, recovery] of Object.entries(recoveries)) {
    if (!recovery || recovery.expires_at < new Date().toISOString()) {
      delete recoveries[key];
      continue;
    }
    const session = await workSessionFor(key);
    if (session.state !== OzonWorkSessionModel.STATES.RECOVERING || Number(session.revision) !== Number(recovery.revision)) continue;
    const identityCheck = await waitForRefreshTabIdentity(recovery);
    if (!identityCheck.ok) {
      await setWorkSessionCommandAcceptance(key, false);
      await mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.ERROR, { error: { code: identityCheck.code || "WORK_REFRESH_CONTEXT_INVALID" } });
      await diagnostic(identityCheck.code || "WORK_REFRESH_CONTEXT_INVALID", { recovery_id: recovery.recovery_id, tab_id: recovery.tab_id, last_code: identityCheck.last_code || null, error: identityCheck.error || null }, { level: "error" });
      delete recoveries[key];
      continue;
    }

    // Runtime/content renewal is a handshake while the session is still RECOVERING and command acceptance is closed.
    // Only after the new generation confirms the exact tab/conversation do we restore active_visible/active_hidden.
    const runtimeGeneration = String(recovery.new_runtime_generation || workSessionRuntimeGeneration);
    const handshake = await tabMessage(Number(recovery.tab_id), { type: "OZ_WORK_RUNTIME_RENEW", runtime_generation: runtimeGeneration, conversation_key: key, visible: false });
    if (!handshake?.ok || handshake.runtime_generation !== runtimeGeneration || handshake.applied !== true) {
      await setWorkSessionCommandAcceptance(key, false);
      await mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.ERROR, { error: { code: handshake?.code || "WORK_REFRESH_CONTENT_RECONNECT_FAILED" } });
      delete recoveries[key];
      continue;
    }

    const target = recovery.expected_visible ? OzonWorkSessionModel.STATES.ACTIVE_VISIBLE : OzonWorkSessionModel.STATES.ACTIVE_HIDDEN;
    const restored = await mutateWorkSession(key, session.revision, target);
    await setWorkSessionCommandAcceptance(key, target === OzonWorkSessionModel.STATES.ACTIVE_VISIBLE);
    if (target === OzonWorkSessionModel.STATES.ACTIVE_VISIBLE) {
      const applied = await tabMessage(Number(recovery.tab_id), { type: "OZ_WORK_APPLY_VISIBILITY", visible: true, conversation_key: key });
      if (!applied?.ok || applied.applied !== true) {
        await setWorkSessionCommandAcceptance(key, false);
        await mutateWorkSession(key, restored.revision, OzonWorkSessionModel.STATES.ERROR, { error: { code: applied?.code || "WORK_REFRESH_VISIBLE_RESTORE_FAILED" } });
        delete recoveries[key];
        continue;
      }
    }
    delete recoveries[key];
    await diagnostic("WORK_SESSION_REFRESH_RESUMED", { recovery_id: recovery.recovery_id, old_runtime_generation: recovery.old_runtime_generation, new_runtime_generation: runtimeGeneration, worker_session_id: WORKER_SESSION_ID, restored_state: target, delivery_preserved: recovery.operation?.delivery_preserved === true, ui_record_generation: handshake.ui_record_generation || null });
  }
  await storageSet({ [KEYS.WORK_SESSION_RECOVERIES]: recoveries });
  if (Object.keys(recoveries).length === 0) {
    try { await chrome.alarms.clear(WORK_SESSION_REFRESH_WAKE_ALARM); } catch (_) {}
  }
}

function normalizeBindingRecord(record, key = null) {
  if (!record || typeof record !== "object") return null;
  const origin = String(record.origin || "").trim().toLowerCase();
  const conversationId = String(record.conversation_id || "").trim().toLowerCase();
  const conversationKey = String(record.conversation_key || key || "").trim();
  const bindingId = String(record.binding_id || "").trim();
  const revision = Math.max(1, Number(record.revision || 1));
  if (!bindingId || !origin || !conversationId || !conversationKey) return null;
  if (`${origin}|${conversationId}` !== conversationKey) return null;
  return {
    binding_id: bindingId,
    revision,
    origin,
    ai_id: BB2ConversationIdentity.providerForOrigin(origin),
    conversation_id: conversationId,
    conversation_key: conversationKey,
    bound_at: record.bound_at || null,
    updated_at: record.updated_at || record.bound_at || null,
    store_context: record.store_context || null,
    assistant_baseline_ids: record.assistant_baseline_ids || [],
    identity_evidence: SellerAgentsConversationIdentity.normalizeProof(record.identity_evidence),
    identity_scope: record.identity_scope || null
  };
}

async function bindingForConversationKey(conversationKey) {
  const key = normalizeConversationKey(conversationKey);
  const bindings = await getConversationBindings();
  return normalizeBindingRecord(bindings[key], key);
}

async function strictBindingForIdentity(identity) {
  const normalized = normalizeIdentity(identity);
  const key = conversationKeyFromIdentity(normalized);
  if (!key) {
    throw Object.assign(new Error("AI conversation identity не подтверждена; явная привязка невозможна."), { code: "CONVERSATION_NOT_CONFIRMED" });
  }
  const binding = await bindingForConversationKey(key);
  if (!binding) {
    throw Object.assign(new Error("Этот AI-диалог не привязан к Октопорт. Сначала нажмите «Привязать диалог» в popup."), { code: "CONVERSATION_NOT_BOUND" });
  }
  if (binding.origin !== normalized.origin || binding.conversation_id !== normalized.conversation_id || binding.conversation_key !== key) {
    throw Object.assign(new Error("Conversation binding не совпадает с текущим AI-диалогом."), { code: "CONVERSATION_BINDING_MISMATCH" });
  }
  return binding;
}

function bindingSnapshot(binding) {
  return {
    binding_id: String(binding.binding_id),
    binding_revision: Math.max(1, Number(binding.revision || 1)),
    origin: String(binding.origin),
    ai_id: String(binding.ai_id || BB2ConversationIdentity.providerForOrigin(binding.origin) || ""),
    conversation_id: String(binding.conversation_id),
    conversation_key: String(binding.conversation_key)
  };
}

async function assertRunBinding(run) {
  if (!run) throw Object.assign(new Error("Run отсутствует."), { code: "AUTO_RUN_NOT_FOUND" });
  const liveBinding = await bindingForConversationKey(run.conversation_key);
  if (!liveBinding) {
    throw Object.assign(new Error("Привязка AI-диалога к Октопорт отсутствует. Run заблокирован fail-closed."), { code: "CONVERSATION_NOT_BOUND" });
  }
  const snap = run.binding_snapshot || null;
  if (!snap) {
    throw Object.assign(new Error("Активный run не содержит binding snapshot. Снова явно привяжите этот диалог в popup для безопасной миграции run."), { code: "RUN_BINDING_SNAPSHOT_MISSING" });
  }
  if (String(snap.binding_id || "") !== liveBinding.binding_id ||
      String(snap.origin || "") !== liveBinding.origin ||
      String(snap.conversation_id || "") !== liveBinding.conversation_id ||
      String(snap.conversation_key || "") !== liveBinding.conversation_key) {
    throw Object.assign(new Error("Binding активного run не совпадает с текущей явной привязкой диалога."), { code: "RUN_BINDING_MISMATCH" });
  }
  return liveBinding;
}

async function bindConversation(context, options = {}) {
  const tab = normalizeTabId(context?.tab_id);
  const expected = normalizeIdentity({
    origin: context?.origin,
    conversation_id: context?.conversation_id,
    status: context?.conversation_id ? "confirmed" : "unknown"
  });
  if (!expected.conversation_id) {
    throw Object.assign(new Error("Не удалось подтвердить текущий диалог. Дождитесь загрузки переписки и повторите Start."), { code: "CONVERSATION_NOT_CONFIRMED" });
  }
  const live = await tabIdentity(tab);
  if (!sameConversationIdentity(live, expected)) {
    throw Object.assign(new Error("Контекст popup изменился. Откройте popup заново в нужном AI-диалоге."), { code: "POPUP_CONTEXT_STALE" });
  }
  const key = await resolveConfirmedConversationKey(live);
  const workStartIntentId = String(options?.work_start_intent_id || "").trim() || null;
  return withBindingWrite(async () => {
    const bindings = await getConversationBindings();
    const previous = normalizeBindingRecord(bindings[key], key);
    const now = new Date().toISOString();
    const record = {
      binding_id: (previous?.binding_id && String(previous.binding_id).startsWith("ozbind-")) ? previous.binding_id : `ozbind-${crypto.randomUUID()}`,
      revision: Math.max(0, Number(previous?.revision || 0)) + 1,
      origin: live.origin,
      ai_id: live.ai_id,
      conversation_id: live.conversation_id,
      conversation_key: key,
      bound_at: previous?.bound_at || now,
      identity_evidence: live.identity_evidence || null,
      identity_scope: live.identity_scope || null,
      updated_at: now
    };
    if (await saEnabled()) {
      record.store_context = await saStoreForPending(tab, workStartIntentId);
      record.assistant_baseline_ids = (await getPendingWorkStarts())[String(tab)]?.assistant_baseline_ids || [];
    }
    bindings[key] = record;
    const bindingUpdates = { [KEYS.CONVERSATION_BINDINGS]: bindings };

    if (!previous) {
      const manualData = await storageGet(KEYS.MANUAL_MODES);
      const modes = { ...(manualData[KEYS.MANUAL_MODES] || {}) };
      delete modes[key];
      bindingUpdates[KEYS.MANUAL_MODES] = modes;
    }

    if (workStartIntentId) {
      const sessions = await getWorkSessions();
      const currentSession = OzonWorkSessionModel.normalize(sessions[key], key);
      if (![OzonWorkSessionModel.STATES.INACTIVE, OzonWorkSessionModel.STATES.ERROR].includes(currentSession.state)) {
        throw Object.assign(new Error("Work-session уже существует; повторный Start не должен перепривязывать диалог."), { code: "WORK_SESSION_ALREADY_EXISTS" });
      }
      transitionWorkSessionRecord(sessions, key, currentSession.revision, OzonWorkSessionModel.STATES.BINDING, {
        tab_id: tab,
        origin: live.origin,
        ai_id: live.ai_id,
        conversation_id: live.conversation_id,
        start_intent_id: workStartIntentId,
        error: null
      });
      bindingUpdates[KEYS.WORK_SESSIONS] = sessions;
    }

    await storageSet(bindingUpdates);

    const existing = await getAutoRun(key);
    if (existing && !existing.binding_snapshot && !BridgeAutorunModel.isTerminalStatus(existing.status)) {
      await mutateAutoRun(key, (current) => current ? { ...current, binding_snapshot: bindingSnapshot(record) } : current);
      await diagnostic("LEGACY_RUN_BOUND_BY_EXPLICIT_OPERATOR_ACTION", { run_id: existing.run_id, binding_id: record.binding_id, conversation_key: key });
    }
    await diagnostic("CONVERSATION_BOUND", { binding_id: record.binding_id, binding_revision: record.revision, conversation_key: key, tab_id: tab, work_session_start: Boolean(workStartIntentId) });
    return record;
  });
}

function withMigrationWrite(fn) {
  const next = migrationWriteLock.then(fn, fn);
  migrationWriteLock = next.catch(() => null);
  return next;
}

async function migrateLegacyConversationStorage(identity) {
  const normalized = normalizeIdentity(identity);
  const realKey = conversationKeyFromIdentity(normalized);
  const oldKey = legacyConversationKey(normalized);
  if (!realKey || !oldKey || realKey === oldKey) return realKey;
  return withMigrationWrite(async () => {
    const data = await storageGet([KEYS.MANUAL_MODES, KEYS.AUTO_RUNS, KEYS.REPORT_PREFIXES, KEYS.AUTO_START_PROMPTS]);
    const maps = {
      [KEYS.MANUAL_MODES]: { ...(data[KEYS.MANUAL_MODES] || {}) },
      [KEYS.AUTO_RUNS]: { ...(data[KEYS.AUTO_RUNS] || {}) },
      [KEYS.REPORT_PREFIXES]: { ...(data[KEYS.REPORT_PREFIXES] || {}) },
      [KEYS.AUTO_START_PROMPTS]: { ...(data[KEYS.AUTO_START_PROMPTS] || {}) }
    };
    const updates = {};
    for (const storageKey of Object.keys(maps)) {
      const map = maps[storageKey];
      if (Object.prototype.hasOwnProperty.call(map, oldKey) && !Object.prototype.hasOwnProperty.call(map, realKey)) {
        map[realKey] = map[oldKey];
        if (storageKey === KEYS.AUTO_RUNS && map[realKey]) {
          map[realKey] = {
            ...map[realKey],
            conversation_key: realKey,
            conversation_id: normalized.conversation_id,
            origin: normalized.origin
          };
        }
      }
      delete map[oldKey];
      updates[storageKey] = map;
    }
    await storageSet(updates);
    return realKey;
  });
}

async function resolveConfirmedConversationKey(identity) {
  const normalized = normalizeIdentity(identity);
  const key = conversationKeyFromIdentity(normalized);
  if (!key) {
    throw Object.assign(new Error("Нужен подтверждённый AI-диалог. Для нового Alice-чата на "/" сначала отправьте обычное первое сообщение и дождитесь /chat/<id>/ с активным history item; до этого Октопорт fail-closed."), { code: "CONVERSATION_NOT_CONFIRMED" });
  }
  await migrateLegacyConversationStorage(normalized);
  return key;
}

async function resolvePopupContext(tabId, expectedIdentity = null) {
  const tab = normalizeTabId(tabId);
  const live = await tabIdentity(tab);
  if (expectedIdentity) {
    const expected = normalizeIdentity(expectedIdentity);
    const eitherConfirmed = Boolean(live.conversation_id || expected.conversation_id);
    const sameUnconfirmedSurface = !eitherConfirmed && live.origin === expected.origin && live.ai_id === expected.ai_id;
    if (!sameUnconfirmedSurface && !sameConversationIdentity(live, expected)) {
      throw Object.assign(new Error("Контекст popup изменился. Откройте popup заново в нужном AI-диалоге."), { code: "POPUP_CONTEXT_STALE" });
    }
  }
  const key = await resolveConfirmedConversationKey(live);
  return { tab_id: tab, conversation_key: key, identity: live };
}

async function getSettings() {
  const data = await storageGet([
    KEYS.SELLER_CLIENT_ID, KEYS.SELLER_API_KEY,
    KEYS.PERFORMANCE_CLIENT_ID, KEYS.PERFORMANCE_CLIENT_SECRET,
    KEYS.AUTO_SEND, KEYS.PERSONAL_DATA_ENABLED, KEYS.SELLER_API_METADATA, KEYS.LAST_STATUS
  ]);
  return {
    sellerCredentials: OzonCredentials.normalizeSellerCredentials({
      clientId: data[KEYS.SELLER_CLIENT_ID] || "",
      apiKey: data[KEYS.SELLER_API_KEY] || ""
    }),
    performanceCredentials: OzonCredentials.normalizePerformanceCredentials({
      clientId: data[KEYS.PERFORMANCE_CLIENT_ID] || "",
      clientSecret: data[KEYS.PERFORMANCE_CLIENT_SECRET] || ""
    }),
    autoSend: data[KEYS.AUTO_SEND] !== false,
    personalDataEnabled: data[KEYS.PERSONAL_DATA_ENABLED] === true,
    sellerApiMetadata: OzonEntitlements.normalizeSnapshot(data[KEYS.SELLER_API_METADATA] || null),
    lastStatus: data[KEYS.LAST_STATUS] || null
  };
}

function sellerApiMetadataDiff(previousSnapshot, nextSnapshot) {
  const previous = OzonEntitlements.normalizeSnapshot(previousSnapshot);
  const next = OzonEntitlements.normalizeSnapshot(nextSnapshot);
  const previousInventory = previous.inventory && typeof previous.inventory === "object" ? previous.inventory : {};
  const nextInventory = next.inventory && typeof next.inventory === "object" ? next.inventory : {};
  const previousKeys = new Set(Object.keys(previousInventory));
  const nextKeys = new Set(Object.keys(nextInventory));
  const added = [...nextKeys].filter((key) => !previousKeys.has(key));
  const removed = [...previousKeys].filter((key) => !nextKeys.has(key));
  const changed = [...nextKeys].filter((key) => previousKeys.has(key) && JSON.stringify(previousInventory[key]) !== JSON.stringify(nextInventory[key]));
  const previousRules = previous.operations && typeof previous.operations === "object" ? previous.operations : {};
  const nextRules = next.operations && typeof next.operations === "object" ? next.operations : {};
  const ruleKeys = new Set([...Object.keys(previousRules), ...Object.keys(nextRules)]);
  const entitlementChanged = [...ruleKeys].filter((key) => JSON.stringify(previousRules[key] || null) !== JSON.stringify(nextRules[key] || null));
  return Object.freeze({ added: added.length, removed: removed.length, changed: changed.length, entitlement_changed: entitlementChanged.length });
}

async function refreshSellerApiMetadata() {
  const fixedUrl = OzonEntitlements.OFFICIAL_SWAGGER_URL;
  const beforeData = await storageGet(KEYS.SELLER_API_METADATA);
  const before = OzonEntitlements.normalizeSnapshot(beforeData[KEYS.SELLER_API_METADATA] || null);
  let response;
  try {
    response = await fetch(fixedUrl, { method: "GET", redirect: "follow", cache: "no-store", credentials: "omit", headers: { Accept: "application/json" } });
  } catch (error) {
    throw Object.assign(new Error(`Не удалось загрузить официальный Seller Swagger: ${error.message || String(error)}. Предыдущие правила сохранены.`), { code: "SELLER_METADATA_FETCH_FAILED" });
  }
  let finalUrl;
  try { finalUrl = new URL(String(response.url || fixedUrl)); }
  catch (_) { throw Object.assign(new Error("Ozon Swagger вернул некорректный final URL. Предыдущие правила сохранены."), { code: "SELLER_METADATA_FINAL_URL_INVALID" }); }
  if (finalUrl.protocol !== "https:" || finalUrl.hostname !== "docs.ozon.ru") {
    throw Object.assign(new Error(`Ozon Swagger redirect на неподтверждённый host ${finalUrl.hostname || "unknown"}; обновление отклонено.`), { code: "SELLER_METADATA_REDIRECT_REJECTED" });
  }
  if (!response.ok) throw Object.assign(new Error(`Ozon Swagger HTTP ${response.status}. Предыдущие правила сохранены.`), { code: "SELLER_METADATA_HTTP_ERROR", http_status: response.status });
  const text = await response.text();
  if (!text || text.length < 100000) throw Object.assign(new Error("Ozon Swagger выглядит неполным; обновление отклонено."), { code: "SELLER_METADATA_PAYLOAD_TOO_SMALL" });
  const sourceHash = bytesToHex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)));
  let swagger;
  try { swagger = JSON.parse(text); }
  catch (error) { throw Object.assign(new Error(`Ozon Swagger не является корректным JSON: ${error.message || String(error)}.`), { code: "SELLER_METADATA_JSON_INVALID" }); }
  const next = OzonEntitlements.compileSnapshot(swagger, { sourceHash, capturedAt: new Date().toISOString() });
  const validation = OzonEntitlements.validateSwagger(swagger);
  if (!validation.ok || Number(next?.source?.operation_count || 0) !== validation.operation_count) {
    throw Object.assign(new Error("Скомпилированный Seller metadata snapshot не прошёл проверку целостности."), { code: "SELLER_METADATA_COMPILE_INVALID" });
  }
  const diff = sellerApiMetadataDiff(before, next);
  await storageSet({ [KEYS.SELLER_API_METADATA]: next });
  const summary = OzonEntitlements.summary(next);
  await diagnostic("SELLER_API_METADATA_UPDATED", {
    source_hash: summary.source_hash,
    operation_count: summary.operation_count,
    entitlement_rule_count: summary.entitlement_rule_count,
    unresolved_rule_count: summary.unresolved_rule_count,
    added: diff.added,
    removed: diff.removed,
    changed: diff.changed,
    entitlement_changed: diff.entitlement_changed,
    external_request_executed: false
  });
  return Object.freeze({ ...summary, ...diff, updated: true, business_request_executed: false });
}

async function getManualMode(conversationKey) {
  const key = normalizeConversationKey(conversationKey);
  const data = await storageGet(KEYS.MANUAL_MODES);
  const modes = data[KEYS.MANUAL_MODES] || {};
  return modes[key] === true;
}

const MANUAL_OPERATION_STATUSES = Object.freeze({
  REQUESTING: "requesting",
  DELIVERING: "delivering",
  COMPLETED: "completed",
  FAILED: "failed"
});

function manualOperationActive(operation) {
  return Boolean(operation && [MANUAL_OPERATION_STATUSES.REQUESTING, MANUAL_OPERATION_STATUSES.DELIVERING].includes(operation.status));
}

function publicQuotaWait(owner) {
  const batch = owner?.batch;
  const wait = batch?.request_state === "quota_waiting" && batch?.quota_wait && typeof batch.quota_wait === "object"
    ? batch.quota_wait
    : null;
  const nextAllowedAt = Math.max(0, Number(wait?.next_allowed_at || 0));
  if (!wait || nextAllowedAt <= 0) return null;
  if (owner?.execution_context?.marketplace === "wildberries") return Object.freeze({
    marketplace: "wildberries", source: "provider_retry_after", next_allowed_at: nextAllowedAt,
    automatic_retry: false, explicit_resume_required: true
  });
  return Object.freeze({
    family: String(wait.family || ANALYTICS_QUOTA_FAMILY),
    min_interval_ms: ANALYTICS_MIN_INTERVAL_MS,
    bridge_launch_safety_ms: ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
    effective_interval_ms: ANALYTICS_MIN_INTERVAL_MS + ANALYTICS_QUOTA_LAUNCH_SAFETY_MS,
    next_allowed_at: nextAllowedAt,
    queue_index: Math.max(0, Number(wait.queue_index || 0)),
    waiting_since: wait.waiting_since ? String(wait.waiting_since) : null,
    automatic_retry: false
  });
}

function publicManualOperation(operation) {
  if (!operation) return null;
  return {
    operation_id: operation.operation_id || null,
    manual_request_id: operation.manual_request_id || null,
    status: operation.status || null,
    owner_tab_id: operation.tab_id || null,
    request_id: operation.request_id || null,
    delivery_id: operation.delivery_id || null,
    operation: operation.operation || null,
    command_summary: operation.command_summary || null,
    delivery_confirmed: operation.delivery_confirmed === true,
    created_at: operation.created_at || null,
    updated_at: operation.updated_at || null,
    completed_at: operation.completed_at || null,
    quota_wait: publicQuotaWait(operation),
    last_error: operation.last_error || null
  };
}

async function getManualOperation(conversationKey) {
  return saPrunePayload(await manualOperationRecords.get(normalizeConversationKey(conversationKey)));
}

function withManualOperationsWrite(fn) {
  return manualOperationRecords.withWrite(fn);
}

async function mutateManualOperation(conversationKey, mutator) {
  return manualOperationRecords.mutate(
    normalizeConversationKey(conversationKey),
    async current => {
      let next = saPrunePayload(await mutator(saPrunePayload(current)));
      // A confirmed delivery may be copied only while its original buffer is still alive.
      // Completion does not renew TTL; expiry and owner replacement keep their existing cleanup.
      if (current?.r3_execution_id && current.outgoing_text && current.payload_expires_at_ms > Date.now() &&
          next?.operation_id === current.operation_id && current.status === MANUAL_OPERATION_STATUSES.DELIVERING &&
          next.status === MANUAL_OPERATION_STATUSES.COMPLETED && next.delivery_confirmed === true &&
          next.last_confirmed_delivery_id === current.delivery?.delivery_id) {
        next = { ...next, outgoing_text: current.outgoing_text, delivery: current.delivery,
          batch: current.batch, payload_expires_at_ms: current.payload_expires_at_ms };
      }
      // Legacy owner replacement and payload cleanup must not erase hash-only
      // UNKNOWN/approval/delivery receipts. Only the ledger may mutate these.
      if (!current?.r3_commands) return next;
      return { ...(next || {}), r3_commands: current.r3_commands };
    },
  );
}

function manualDeliveryPendingBeforeInsert(operation) {
  return Boolean(
    operation
    && operation.status === MANUAL_OPERATION_STATUSES.DELIVERING
    && operation.delivery?.mode === "batch_watch_v1"
    && operation.delivery?.phase === BridgeAutorunModel.DELIVERY_PHASES.CLAIMED
  );
}

async function cancelManualPendingPreInsertDelivery(conversationKey, reason = "manual_mode_disabled") {
  const key = normalizeConversationKey(conversationKey);
  let cancelled = null;
  await mutateManualOperation(key, (current) => {
    if (!manualDeliveryPendingBeforeInsert(current)) return current;
    cancelled = {
      operation_id: current.operation_id || null,
      manual_request_id: current.manual_request_id || null,
      delivery_id: current.delivery?.delivery_id || current.delivery_id || null,
      tab_id: current.tab_id || null
    };
    return null;
  });
  if (cancelled) {
    await diagnostic("MANUAL_PENDING_DELIVERY_CANCELLED", {
      conversation_key: key,
      operation_id: cancelled.operation_id,
      manual_request_id: cancelled.manual_request_id,
      delivery_id: cancelled.delivery_id,
      tab_id: cancelled.tab_id,
      reason
    });
  }
  return cancelled;
}

async function getAutoRun(conversationKey) {
  const key = normalizeConversationKey(conversationKey);
  const data = await storageGet(KEYS.AUTO_RUNS);
  const runs = data[KEYS.AUTO_RUNS] || {};
  return runs[key] || null;
}

function withAutoRunsWrite(fn) {
  const next = autoRunsWriteLock.then(fn, fn);
  autoRunsWriteLock = next.catch(() => null);
  return next;
}

async function mutateAutoRun(conversationKey, mutator) {
  const key = normalizeConversationKey(conversationKey);
  return withAutoRunsWrite(async () => {
    const data = await storageGet(KEYS.AUTO_RUNS);
    const runs = { ...(data[KEYS.AUTO_RUNS] || {}) };
    const current = runs[key] || null;
    const next = await mutator(current);
    if (next) runs[key] = { ...next, updated_at: new Date().toISOString() };
    else delete runs[key];
    await storageSet({ [KEYS.AUTO_RUNS]: runs });
    return runs[key] || null;
  });
}

async function writeManualModeState(conversationKey, enabled) {
  const key = normalizeConversationKey(conversationKey);
  if (enabled === true) {
    const run = await getAutoRun(key);
    if (run && !BridgeAutorunModel.canEnableManualMode(run.status)) {
      throw Object.assign(new Error("Авторежим активен. Сначала нажмите «Пауза», затем включайте работу через кнопку «Октопорт»."), { code: "AUTO_MODE_ACTIVE" });
    }
  }
  const data = await storageGet(KEYS.MANUAL_MODES);
  const modes = { ...(data[KEYS.MANUAL_MODES] || {}) };
  if (enabled === true) modes[key] = true;
  else delete modes[key];
  await storageSet({ [KEYS.MANUAL_MODES]: modes });
  return enabled === true;
}
async function setManualMode(conversationKey, enabled) {
  const key = normalizeConversationKey(conversationKey);
  const result = await writeManualModeState(key, enabled);
  if (enabled !== true) await cancelManualPendingPreInsertDelivery(key, "manual_mode_disabled");
  return result;
}
async function setWorkSessionCommandAcceptance(conversationKey, enabled) {
  return writeManualModeState(conversationKey, enabled === true);
}
async function workSessionManualEnabled(conversationKey) {
  const key = normalizeConversationKey(conversationKey);
  const [manualEnabled, session] = await Promise.all([getManualMode(key), workSessionFor(key)]);
  return manualEnabled === true && session.state === OzonWorkSessionModel.STATES.ACTIVE_VISIBLE;
}

function withPrefixWrite(fn) {
  const next = prefixWriteLock.then(fn, fn);
  prefixWriteLock = next.catch(() => null);
  return next;
}

async function getReportPrefix(conversationKey) {
  const key = normalizeConversationKey(conversationKey);
  const data = await storageGet(KEYS.REPORT_PREFIXES);
  return (data[KEYS.REPORT_PREFIXES] || {})[key] || null;
}

async function saveReportPrefix(conversationKey, payload) {
  const key = normalizeConversationKey(conversationKey);
  return withPrefixWrite(async () => {
    const data = await storageGet(KEYS.REPORT_PREFIXES);
    const prefixes = { ...(data[KEYS.REPORT_PREFIXES] || {}) };
    const current = prefixes[key] || null;
    const normalized = BridgeAutorunModel.normalizePrefixRecord({
      enabled: payload.report_prefix_enabled === true,
      text: String(payload.report_prefix_text ?? current?.text ?? ""),
      interval: payload.report_prefix_interval,
      delivered_count: current?.delivered_count || 0,
      last_applied_at_count: current?.last_applied_at_count || 0,
      last_confirmed_delivery_id: current?.last_confirmed_delivery_id || null,
      updated_at: new Date().toISOString()
    });
    if (normalized && (normalized.enabled || normalized.text)) prefixes[key] = normalized;
    else delete prefixes[key];
    await storageSet({ [KEYS.REPORT_PREFIXES]: prefixes });
    return prefixes[key] || null;
  });
}

async function noteConfirmedPrefix(conversationKey, applied, deliveryId = "") {
  const key = normalizeConversationKey(conversationKey);
  return withPrefixWrite(async () => {
    const data = await storageGet(KEYS.REPORT_PREFIXES);
    const prefixes = { ...(data[KEYS.REPORT_PREFIXES] || {}) };
    const current = prefixes[key] || null;
    if (!current) return null;
    prefixes[key] = BridgeAutorunModel.noteConfirmedPrefix(current, applied === true, deliveryId);
    await storageSet({ [KEYS.REPORT_PREFIXES]: prefixes });
    return prefixes[key];
  });
}

function withStartPromptWrite(fn) {
  const next = startPromptWriteLock.then(fn, fn);
  startPromptWriteLock = next.catch(() => null);
  return next;
}

function normalizeAutoStartPromptText(value) {
  const text = String(value ?? "").replace(/\r\n?/g, "\n").trim();
  if (!text) throw Object.assign(new Error("Стартовый prompt autorun не может быть пустым."), { code: "AUTO_START_PROMPT_EMPTY" });
  if (Array.from(text).length > 30000) throw Object.assign(new Error("Стартовый prompt autorun слишком длинный (максимум 30000 символов)."), { code: "AUTO_START_PROMPT_TOO_LONG" });
  return text;
}

function normalizeGlobalAutoStartPromptRecord(raw) {
  const current = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : null;
  const now = new Date().toISOString();
  if (current?.text && String(current.text).trim()) {
    const normalizedText = normalizeAutoStartPromptText(current.text);
    if (current.is_default === true && normalizedText !== DEFAULT_AUTO_START_TEXT) {
      return { record: { text: DEFAULT_AUTO_START_TEXT, is_default: true, updated_at: now }, changed: true };
    }
    return {
      record: { text: normalizedText, is_default: current.is_default === true, updated_at: current.updated_at || null },
      changed: normalizedText !== current.text
    };
  }
  return { record: { text: DEFAULT_AUTO_START_TEXT, is_default: true, updated_at: now }, changed: true };
}

async function getGlobalAutoStartPrompt({ ensureStored = true } = {}) {
  return withStartPromptWrite(async () => {
    const data = await storageGet(KEYS.GLOBAL_AUTO_START_PROMPT);
    const normalized = normalizeGlobalAutoStartPromptRecord(data[KEYS.GLOBAL_AUTO_START_PROMPT]);
    if (ensureStored && normalized.changed) await storageSet({ [KEYS.GLOBAL_AUTO_START_PROMPT]: normalized.record });
    return normalized.record;
  });
}

async function saveGlobalAutoStartPrompt(text) {
  const normalizedText = normalizeAutoStartPromptText(text);
  return withStartPromptWrite(async () => {
    const record = {
      text: normalizedText,
      is_default: normalizedText === DEFAULT_AUTO_START_TEXT,
      updated_at: new Date().toISOString()
    };
    await storageSet({ [KEYS.GLOBAL_AUTO_START_PROMPT]: record });
    return record;
  });
}

async function resetGlobalAutoStartPrompt() {
  return saveGlobalAutoStartPrompt(DEFAULT_AUTO_START_TEXT);
}

async function getAutoStartPrompt(conversationKey, { ensureStored = true } = {}) {
  const key = normalizeConversationKey(conversationKey);
  return withStartPromptWrite(async () => {
    const data = await storageGet([KEYS.AUTO_START_PROMPTS, KEYS.GLOBAL_AUTO_START_PROMPT]);
    const prompts = { ...(data[KEYS.AUTO_START_PROMPTS] || {}) };
    const current = prompts[key] || null;
    const globalResolved = normalizeGlobalAutoStartPromptRecord(data[KEYS.GLOBAL_AUTO_START_PROMPT]);
    const updates = {};

    if (globalResolved.changed && ensureStored) updates[KEYS.GLOBAL_AUTO_START_PROMPT] = globalResolved.record;

    if (current?.text && String(current.text).trim() && current.is_default !== true) {
      if (Object.keys(updates).length) await storageSet(updates);
      return {
        text: normalizeAutoStartPromptText(current.text),
        is_default: false,
        is_override: true,
        source: "conversation_override",
        updated_at: current.updated_at || null
      };
    }

    if (current && ensureStored) {
      delete prompts[key];
      updates[KEYS.AUTO_START_PROMPTS] = prompts;
    }
    if (Object.keys(updates).length) await storageSet(updates);
    return { ...globalResolved.record, is_override: false, source: "global" };
  });
}

async function saveAutoStartPrompt(conversationKey, text) {
  const key = normalizeConversationKey(conversationKey);
  const normalizedText = normalizeAutoStartPromptText(text);
  return withStartPromptWrite(async () => {
    const data = await storageGet(KEYS.AUTO_START_PROMPTS);
    const prompts = { ...(data[KEYS.AUTO_START_PROMPTS] || {}) };
    prompts[key] = {
      text: normalizedText,
      is_default: false,
      updated_at: new Date().toISOString()
    };
    await storageSet({ [KEYS.AUTO_START_PROMPTS]: prompts });
    return { ...prompts[key], is_override: true, source: "conversation_override" };
  });
}

async function resetAutoStartPrompt(conversationKey) {
  const key = normalizeConversationKey(conversationKey);
  await withStartPromptWrite(async () => {
    const data = await storageGet(KEYS.AUTO_START_PROMPTS);
    const prompts = { ...(data[KEYS.AUTO_START_PROMPTS] || {}) };
    if (Object.prototype.hasOwnProperty.call(prompts, key)) {
      delete prompts[key];
      await storageSet({ [KEYS.AUTO_START_PROMPTS]: prompts });
    }
  });
  return getAutoStartPrompt(key);
}

function publicRun(run) {
  if (!run) return null;
  return {
    run_id: run.run_id,
    status: run.status,
    owner_tab_id: run.tab_id || null,
    conversation_id: run.conversation_id || null,
    binding_id: run.binding_snapshot?.binding_id || null,
    binding_revision: Number(run.binding_snapshot?.binding_revision || 0) || null,
    sequence: Number(run.sequence || 0),
    pause_requested: run.pause_requested === true,
    finish_requested: run.finish_requested === true,
    last_operation: run.last_operation || null,
    last_command_summary: run.last_command_summary || null,
    last_assistant_turn_id: run.last_assistant_turn_id || null,
    batch_total: Array.isArray(run.batch?.entries) ? run.batch.entries.length : 0,
    batch_completed: run.batch ? Math.max(0, Number(run.batch.next_index || 0)) : 0,
    created_at: run.created_at || null,
    updated_at: run.updated_at || null,
    quota_wait: publicQuotaWait(run),
    last_error: run.last_error || null
  };
}

async function commonPublicSettingsFields() {
  const settings = await getSettings();
  const [sendData, microphoneData, copyProfiles, globalStartPrompt] = await Promise.all([
    storageGet(KEYS.SEND_BUTTON_PROFILE),
    storageGet(KEYS.MICROPHONE_BUTTON_PROFILE),
    getCopyButtonProfiles(),
    getGlobalAutoStartPrompt()
  ]);
  const credentialState = OzonCredentials.publicCredentialState(settings.sellerCredentials);
  const performanceCredentialState = OzonCredentials.publicPerformanceCredentialState(settings.performanceCredentials);
  const operationNames = Object.keys(OzonContract.OPERATIONS || {});
  const enabledOperations = operationNames.filter((name) => OzonContract.OPERATIONS[name]?.execution_enabled === true);
  return {
    version: VERSION,
    ...credentialState,
    ...performanceCredentialState,
    provider_execution_ready: enabledOperations.length > 0,
    provider_operation_count: operationNames.length,
    provider_enabled_operation_count: enabledOperations.length,
    provider_enabled_operations: enabledOperations,
    provider_gate: enabledOperations.length > 0 ? "OPEN" : "CLOSED",
    ai_mode: "auto",
    ai_mode_scope: "per_tab",
    auto_send: settings.autoSend,
    personal_data_enabled: settings.personalDataEnabled === true,
    global_auto_start_prompt: {
      text: String(globalStartPrompt?.text || DEFAULT_AUTO_START_TEXT),
      is_default: globalStartPrompt?.is_default === true,
      updated_at: globalStartPrompt?.updated_at || null
    },
    seller_api_metadata: OzonEntitlements.summary(settings.sellerApiMetadata),
    send_button_profile: sendData[KEYS.SEND_BUTTON_PROFILE] || null,
    microphone_button_profile: microphoneData[KEYS.MICROPHONE_BUTTON_PROFILE] || null,
    copy_button_profiles: copyProfiles,
    copy_button_profile_count: copyProfiles.profiles.length,
    copy_button_builtin_adapter_count: BB2ManualControls.BUILTIN_MANUAL_COPY_ADAPTER_COUNT,
    last_status: settings.lastStatus?.scope === "provider" && settings.lastStatus?.code !== "SAFE_PROBE_NOT_CONFIGURED" ? settings.lastStatus : null
  };
}

async function publicSettingsState(conversationKey) {
  const key = normalizeConversationKey(conversationKey);
  const common = await commonPublicSettingsFields();
  const [manualMode, manualOperation, run, prefix, startPrompt, binding, workSession] = await Promise.all([
    getManualMode(key), getManualOperation(key), getAutoRun(key), getReportPrefix(key), getAutoStartPrompt(key), bindingForConversationKey(key), workSessionFor(key)
  ]);
  return {
    ...common,
    page_context_available: true,
    conversation_key: key,
    binding: binding ? { bound: true, ...binding } : { bound: false, binding_id: null, revision: null },
    manual_mode: binding && workSession.state === OzonWorkSessionModel.STATES.ACTIVE_VISIBLE ? manualMode : false,
    manual_operation: binding ? publicManualOperation(manualOperation) : null,
    manual_operation_active: binding ? manualOperationActive(manualOperation) : false,
    work_session: workSession,
    auto_run: publicRun(run),
    auto_start_prompt: {
      text: String(startPrompt?.text || DEFAULT_AUTO_START_TEXT),
      is_default: startPrompt?.is_default === true,
      is_override: startPrompt?.is_override === true,
      source: String(startPrompt?.source || "global"),
      updated_at: startPrompt?.updated_at || null
    },
    report_prefix: prefix ? {
      enabled: prefix.enabled === true,
      text: String(prefix.text || ""),
      interval: Number(prefix.interval || 1),
      delivered_count: Number(prefix.delivered_count || 0),
      last_applied_at_count: Number(prefix.last_applied_at_count || 0),
      updated_at: prefix.updated_at || null
    } : null
  };
}

async function publicGlobalSettingsState(pageContextError = null) {
  const common = await commonPublicSettingsFields();
  return {
    ...common,
    page_context_available: false,
    page_context_error: pageContextError ? String(pageContextError).slice(0, 800) : null,
    conversation_key: null,
    binding: { bound: false, binding_id: null, revision: null },
    manual_mode: false,
    manual_operation: null,
    manual_operation_active: false,
    work_session: OzonWorkSessionModel.normalize(null, null),
    auto_run: null,
    auto_start_prompt: { ...common.global_auto_start_prompt, is_override: false, source: "global" },
    report_prefix: null
  };
}

async function setStatus(status) {
  const clean = {
    scope: "provider",
    ok: Boolean(status.ok),
    code: String(status.code || "").slice(0, 120),
    message: String(status.message || "").slice(0, 800),
    http_status: Number(status.http_status || 0),
    at: new Date().toISOString()
  };
  await storageSet({ [KEYS.LAST_STATUS]: clean });
  return clean;
}

async function executeOzonCore(
  commandText,
  {
    executionCommand = null,
    planning = null,
    quotaPermit = null,
    executionContext = null,
    onProviderResponse = null,
    onProviderResult = null,
  } = {},
) {
  const settings = await (executionContext
    ? executionContext.settings()
    : getSettings());
  const command = OzonContract.parseCommand(commandText);
  const physicalCommand = executionCommand
    ? OzonContract.normalizeCommand(executionCommand)
    : command;
  if (physicalCommand.operation !== command.operation)
    throw Object.assign(
      new Error("Planned physical operation не совпадает с logical operation."),
      { code: "PLANNED_OPERATION_MISMATCH" },
    );
  await saCheckOzonFileRef(command, executionContext);
  const fingerprint = OzonContract.commandFingerprint(command);
  const physicalFingerprint = OzonContract.commandFingerprint(physicalCommand);
  await diagnostic("OZON_REQUEST_STARTED", {
    operation: command.operation,
    command_fingerprint: fingerprint,
    physical_command_fingerprint: physicalFingerprint,
    command_transformed: fingerprint !== physicalFingerprint,
  });
  try {
    const response =
      typeof OzonProvider.executeCommandObject === "function"
        ? await OzonProvider.executeCommandObject(
            physicalCommand,
            settings.sellerCredentials,
            settings.performanceCredentials,
            {
              reportCommand: command,
              executionGuard: executionContext,
              planning,
              quota: safeQuotaMetadata(quotaPermit),
              onProviderResponse: async (providerResponse) => {
                if (typeof onProviderResponse === "function")
                  await onProviderResponse(providerResponse);
                if (quotaPermit)
                  return extendAnalyticsQuotaFromRetryAfter(
                    quotaPermit,
                    providerResponse?.response?.responseMeta?.retry_after,
                  );
                return null;
              },
              onProviderResult,
            },
          )
        : await OzonProvider.executeCommand(
            commandText,
            settings.sellerCredentials,
            settings.performanceCredentials,
          );
    if (executionContext) await executionContext.assertCurrent();
    await saRememberOzonFileRefs(response, executionContext);
    await diagnostic(
      "OZON_REQUEST_FINISHED",
      {
        request_id: response.request_id || null,
        operation: command.operation,
        provider:
          response.provider ||
          OzonContract.preflightExecution(command).meta.provider ||
          "seller_api",
        command_fingerprint: fingerprint,
        physical_command_fingerprint:
          response.executed_command_fingerprint || physicalFingerprint,
        http_status: response.http_status,
        ok: response.ok,
        quota_family: response.rate_limit?.quota_family || null,
        next_allowed_at: Number(response.rate_limit?.next_allowed_at || 0),
      },
      { level: response.ok ? "info" : "warning" },
    );
    await setStatus(
      response.ok
        ? {
            ok: true,
            code: "CONNECTED",
            message: "Последний Ozon API запрос выполнен успешно.",
            http_status: response.http_status,
          }
        : {
            ok: false,
            code: "OZON_API_ERROR",
            message: `Ozon API вернул HTTP ${response.http_status}.`,
            http_status: response.http_status,
          },
    );
    return { ...response, auto_send: settings.autoSend };
  } catch (error) {
    const safe = OzonContract.safeBridgeErrorPayload(
      error,
      Number(error?.http_status || 0),
    );
    await diagnostic(
      "OZON_REQUEST_FAILED",
      {
        operation: command.operation,
        command_fingerprint: fingerprint,
        physical_command_fingerprint: physicalFingerprint,
        code: safe.code,
        error: safe.message,
        http_status: safe.http_status,
        external_request_executed: safe.external_request_executed === true,
      },
      { level: "error" },
    );
    await setStatus({
      ok: false,
      code: safe.code,
      message: safe.message,
      http_status: safe.http_status,
    });
    throw error;
  }
}

function buildExecutionErrorResult(command, fingerprint, error, elapsedMs = 0, planning = null) {
  const safe = OzonContract.safeBridgeErrorPayload(error, Number(error?.http_status || 0));
  const preflight = OzonContract.preflightExecution(command);
  const requestId = crypto.randomUUID();
  const reportText = OzonContract.formatResultReport({
    requestId,
    command,
    requestMeta: {
      host_alias: String(preflight.meta.provider || "seller_api"),
      http_method: preflight.meta.method,
      path_alias: command.operation,
      external_request_executed: safe.external_request_executed === true,
      capability_probe_executed: planning?.capability?.probe_performed === true,
      capability_probe_http_status: Number(planning?.capability?.probe_http_status || 0)
    },
    httpStatus: safe.http_status,
    result: { error: safe },
    elapsedMs: Math.max(0, Number(elapsedMs || 0)),
    pagination: null,
    rateLimit: error?.rate_limit || null,
    planning
  });
  return Object.freeze({
    ok: false,
    bridge_error: true,
    request_id: requestId,
    operation: command.operation,
    command_fingerprint: fingerprint,
    http_status: safe.http_status,
    report_text: reportText,
    response_meta: null,
    error: safe,
    external_request_executed: safe.external_request_executed === true
  });
}

function buildCapabilityPlanningErrorResult(command, fingerprint, plan) {
  const source = Object.assign(new Error(String(plan?.error?.message || "Capability planning rejected the command.")), { code: String(plan?.error?.code || "CAPABILITY_PLANNING_REJECTED") });
  const safe = OzonContract.safeBridgeErrorPayload(source, 0);
  const preflight = OzonContract.preflightExecution(command);
  const requestId = `capability-${crypto.randomUUID()}`;
  const planning = plan?.planning || null;
  const reportText = OzonContract.formatResultReport({
    requestId,
    command,
    requestMeta: {
      host_alias: String(preflight.meta.provider || "seller_api"),
      http_method: preflight.meta.method,
      path_alias: command.operation,
      external_request_executed: false,
      capability_probe_executed: planning?.capability?.probe_performed === true,
      capability_probe_http_status: Number(planning?.capability?.probe_http_status || 0)
    },
    httpStatus: 0,
    result: {
      error: {
        ...safe,
        stage: "capability_planning",
        external_request_executed: false
      }
    },
    elapsedMs: 0,
    pagination: null,
    rateLimit: null,
    planning
  });
  return Object.freeze({
    ok: false,
    bridge_error: true,
    pre_execution_error: true,
    request_id: requestId,
    operation: command.operation,
    command_fingerprint: fingerprint,
    http_status: 0,
    report_text: reportText,
    response_meta: null,
    error: safe,
    external_request_executed: false
  });
}

function buildPersonalDataPolicyErrorResult(command, fingerprint) {
  const source = Object.assign(new Error("Операция может передать личные данные в AI-чат. Чтобы выполнить запрос, включите «Показывать личные данные» в настройках Октопорт, затем явно запустите новую команду."), { code: "OPERATION_DISABLED_BY_USER" });
  const safe = OzonContract.safeBridgeErrorPayload(source, 0);
  const preflight = OzonContract.preflightExecution(command);
  const requestId = `policy-${crypto.randomUUID()}`;
  const reportText = OzonContract.formatResultReport({
    requestId,
    command,
    requestMeta: {
      host_alias: String(preflight.meta.provider || "seller_api"),
      http_method: preflight.meta.method,
      path_alias: command.operation,
      external_request_executed: false,
      capability_probe_executed: false,
      capability_probe_http_status: 0
    },
    httpStatus: 0,
    result: {
      status: "personal_data_setting_required",
      error: { ...safe, stage: "personal_data_policy", external_request_executed: false },
      operator_action: "enable_personal_data_setting_and_submit_new_command"
    },
    elapsedMs: 0,
    pagination: null,
    rateLimit: null,
    planning: {
      capability: { status: "not_needed", subscription_type: "UNKNOWN", probe_performed: false, probe_http_status: 0, probe_error_code: null },
      entitlement: { status: "POLICY_BLOCKED", partial: false, reason: "personal_data_setting_off" }
    }
  });
  return Object.freeze({
    ok: false, bridge_error: true, pre_execution_error: true, request_id: requestId, operation: command.operation,
    command_fingerprint: fingerprint, http_status: 0, report_text: reportText, response_meta: null, error: safe, external_request_executed: false
  });
}

async function applyPrefixToReport(conversationKey, reportText) {
  const prefix = await getReportPrefix(conversationKey);
  const result = BridgeAutorunModel.applyReportPrefix(reportText, prefix);
  return { outgoing_text: result.text, report_prefix_applied: result.applied };
}

function buildPreExecutionErrorResult({ error, stage = "command_parse", commandFingerprint = "", requestIdPrefix = "preexec" }) {
  const sourceError = error instanceof Error ? error : Object.assign(new Error(String(error || "Октопорт pre-execution error.")), { code: "PREEXEC_ERROR" });
  const safe = OzonContract.safeBridgeErrorPayload(sourceError, 0);
  const cleanStage = String(stage || "pre_execution").slice(0, 80);
  const suppliedFingerprint = String(commandFingerprint || "").trim().toLowerCase();
  const fingerprint = /^[a-f0-9]{8,64}$/.test(suppliedFingerprint)
    ? suppliedFingerprint
    : OzonContract.textFingerprint(`${cleanStage}|${safe.code}|${safe.message}`);
  const requestId = `${String(requestIdPrefix || "preexec").replace(/[^a-z0-9_-]/gi, "").slice(0, 40) || "preexec"}-${crypto.randomUUID()}`;
  const reportText = OzonContract.formatPreExecutionErrorReport({
    requestId,
    error: sourceError,
    stage: cleanStage,
    commandFingerprint: fingerprint
  });
  return Object.freeze({
    ok: false,
    bridge_error: true,
    pre_execution_error: true,
    request_id: requestId,
    operation: null,
    command_fingerprint: fingerprint,
    http_status: 0,
    report_text: reportText,
    external_request_executed: false
  });
}


async function executeManualCommand(
  commandText,
  conversationKey,
  sender,
  manualRequestId,
  commandSource = null,
  recovery = null,
) {
  if (recovery && !saR3RetryPermits.delete(recovery)) throw saError("RETRY_INTERNAL_PERMIT_REQUIRED");
  const key = normalizeConversationKey(conversationKey);
  const senderTabId = Number(sender?.tab?.id || 0);
  if (!Number.isInteger(senderTabId) || senderTabId <= 0) {
    throw Object.assign(
      new Error(
        "Ручная Ozon-команда должна приходить из content script поддерживаемого AI.",
      ),
      { code: "MANUAL_SENDER_TAB_MISSING" },
    );
  }
  let requestToken = String(manualRequestId || "").trim();
  if (!requestToken)
    throw Object.assign(new Error("Manual request ID отсутствует."), {
      code: "MANUAL_REQUEST_ID_MISSING",
    });
  const ingressRequestToken = requestToken;
  const liveIdentity = await assertTabConversation(senderTabId, key);
  const binding = await strictBindingForIdentity(liveIdentity);
  const manualAutoSend = (await getSettings()).autoSend !== false;
  const workSession = await workSessionFor(key);

  let entries;
  let sourceStage = "command_discovery";
  if (workSession.state !== OzonWorkSessionModel.STATES.ACTIVE_VISIBLE) {
    sourceStage = "work_session_gate";
    entries = [
      batchErrorEntry(
        Object.assign(
          new Error(
            "Work-session этого AI-диалога не находится в состоянии active_visible. Ozon API request не выполнен.",
          ),
          { code: "WORK_SESSION_NOT_VISIBLE" },
        ),
        sourceStage,
        OzonContract.textFingerprint(commandText),
      ),
    ];
  } else if (!(await getManualMode(key))) {
    sourceStage = "manual_gate";
    entries = [
      batchErrorEntry(
        Object.assign(
          new Error(
            "Кнопка Ozon выключена для этого AI-диалога. API-запрос не выполнен.",
          ),
          { code: "MANUAL_MODE_OFF" },
        ),
        sourceStage,
        OzonContract.textFingerprint(commandText),
      ),
    ];
  } else {
    const run = await getAutoRun(key);
    if (run && !BridgeAutorunModel.canEnableManualMode(run.status)) {
      sourceStage = "manual_gate";
      entries = [
        batchErrorEntry(
          Object.assign(
            new Error("Авторежим активен. Ручной API-вызов не выполнен."),
            { code: "AUTO_MODE_ACTIVE" },
          ),
          sourceStage,
          OzonContract.textFingerprint(commandText),
        ),
      ];
    } else {
      try {
        entries = binding.store_context?.marketplace === "wildberries" ? SellerAgentsWBAdapter.discover(commandText) : discoverBatchEntries(commandText);
        if (binding.store_context?.marketplace === "ozon" && /\bWB_(?:API|HELP|FILE)_V[12]\b/.test(commandText)) throw saError("MIXED_MARKETPLACE_BLOCK");
      } catch (error) {
        entries = [
          batchErrorEntry(
            error,
            "command_discovery",
            OzonContract.textFingerprint(commandText),
          ),
        ];
      }
      if (!entries.length) {
        entries = [
          batchErrorEntry(
            Object.assign(
              new Error("В тексте не найдено ни одной OZON_API_V1 команды."),
              { code: "NO_OZON_COMMANDS" },
            ),
            "command_discovery",
            OzonContract.textFingerprint(commandText),
          ),
        ];
      }
    }
  }

  const r3Enabled = await saEnabled();
  const r3Prepared = r3Enabled ? await saR3PrepareCommandSource(commandSource, sender, liveIdentity, binding, workSession, key, commandText) : null;
  if (r3Prepared) requestToken = recovery?.context.requestId || r3Prepared.requestToken;
  if (r3Enabled && !await SellerAgentsControlClient.canWork(liveIdentity))
    throw Object.assign(new Error("Work policy blocked"), { code: "WORK_POLICY_BLOCKED" });
  const promptTree = { pin: null };
  if (r3Enabled && workSession.state === OzonWorkSessionModel.STATES.ACTIVE_VISIBLE) {
    if (!Object.prototype.hasOwnProperty.call(workSession, "prompt_tree"))
      throw saError("WORK_PROMPT_TREE_PIN_MISSING_START_REQUIRED");
    if (workSession.prompt_tree)
      promptTree.pin = await SellerAgentsControlClient.validatePromptTreePin(liveIdentity, workSession.prompt_tree);
  }
  if (r3Prepared && promptTree.pin) r3Prepared.source.promptTree = { aiId: promptTree.pin.aiId, version: promptTree.pin.version, sha256: promptTree.pin.sha256 };
  const executionContext = await captureBatchContext(
    key,
    commandText,
    requestToken,
  );
  if (recovery) {
    SellerAgentsExecutionContext.assertSame(recovery.context, await saReadContext(key, { commandHash: executionContext.commandHash, requestId: executionContext.requestId }));
    if (!r3Prepared || recovery.blockVersion !== r3Prepared.blockVersion || recovery.blockOriginKey !== r3Prepared.blockOriginKey)
      throw saError("RETRY_PREVIEW_CHANGED");
    entries = recovery.ordinals.map(ordinal => {
      if (!entries[ordinal]) throw saError("RETRY_SELECTION_CHANGED");
      return { ...entries[ordinal], r3_original_ordinal: ordinal };
    });
  }
  const r3Reservation = recovery?.reservation || (r3Prepared ? await saR3ReserveCommand(r3Prepared, executionContext, entries, ingressRequestToken) : null);
  const operationId = `ozmanual-${crypto.randomUUID()}`;
  const now = new Date().toISOString();
  let duplicateOperation = null;
  const operation = await mutateManualOperation(key, async (current) => {
    let seen = [];
    if (await saEnabled()) {
      const guard = SellerAgentsExecutionContext.createGuard(executionContext, () => readBatchContextState(key, { commandHash: executionContext.commandHash, requestId: requestToken }));
      await guard.assertCurrent();
      seen = current?.execution_context?.workSessionId === executionContext.workSessionId ? (current.seen_request_ids || []) : [];
      if (seen.includes(ingressRequestToken)) throw saError("MANUAL_REQUEST_DUPLICATE");
      if (seen.length >= 2000) throw saError("WORK_MARKER_CAPACITY_START_REQUIRED");
    }
    if (current?.manual_request_id === ingressRequestToken) {
      duplicateOperation = current;
      return current;
    }
    if (manualOperationActive(current)) return current;
    return {
      operation_id: operationId,
      manual_request_id: ingressRequestToken,
      conversation_key: key,
      origin: liveIdentity.origin,
      conversation_id: liveIdentity.conversation_id,
      binding_snapshot: bindingSnapshot(binding),
      execution_context: executionContext,
      prompt_tree: promptTree.pin,
      ...(r3Reservation ? { r3_execution_id: r3Reservation.executionId, r3_source: r3Prepared.source,
        r3_block_origin_key: r3Prepared.blockOriginKey, r3_block_version: r3Prepared.blockVersion } : {}),
      seen_request_ids: [...seen, ingressRequestToken],
      payload_expires_at_ms: r3Reservation?.payloadExpiresAt || Date.now() + 3600000,
      tab_id: senderTabId,
      status: MANUAL_OPERATION_STATUSES.REQUESTING,
      operation: null,
      last_operation: null,
      command_summary: `${entries.length} queued OZON_API_V1 item(s)`,
      request_id: null,
      request_worker_session_id: null,
      delivery_id: null,
      outgoing_text: null,
      auto_send: manualAutoSend,
      report_prefix_applied: false,
      delivery_confirmed: false,
      delivery: null,
      batch: {
        phase: "collecting",
        source: "manual_copy",
        entries,
        next_index: 0,
        request_state: "idle",
        request_worker_session_id: null,
        planning_state: "pending",
        capability_resolution: null,
        query_planning_state: "pending",
        query_plan: null,
        quota_wait: null,
        request_quota: null,
        created_at: now,
      },
      created_at: now,
      completed_at: null,
      last_error: null,
    };
  });
  if (duplicateOperation) {
    throw Object.assign(
      new Error(
        "Эта ручная операция уже принята. Повторный API-вызов запрещён.",
      ),
      {
        code: "MANUAL_REQUEST_DUPLICATE",
        operation_id: duplicateOperation.operation_id,
      },
    );
  }
  if (!operation || operation.operation_id !== operationId) {
    throw Object.assign(
      new Error("Bridge уже выполняет или доставляет ручной Ozon batch."),
      { code: "MANUAL_OPERATION_ACTIVE" },
    );
  }
  await diagnostic("MANUAL_BATCH_ACCEPTED", {
    operation_id: operationId,
    manual_request_id: ingressRequestToken,
    conversation_id: liveIdentity.conversation_id,
    tab_id: senderTabId,
    item_count: entries.length,
    command_count: entries.filter((entry) => entry.kind === "command").length,
    pre_execution_error_count: entries.filter(
      (entry) => entry.kind !== "command",
    ).length,
    source_stage: sourceStage,
  });
  launchBatchProcessor("manual", key, operationId, "manual_admission");
  return {
    ok: true,
    accepted: true,
    manual_operation_id: operationId,
    manual_request_id: ingressRequestToken,
    item_count: entries.length,
    command_count: entries.filter((entry) => entry.kind === "command").length,
    pre_execution_error_count: entries.filter(
      (entry) => entry.kind !== "command",
    ).length,
  };
}

function manualBatchRecoveryPayload(operation, type) {
  if (!operation || operation.status !== MANUAL_OPERATION_STATUSES.DELIVERING || operation.delivery?.mode !== "batch_watch_v1") return null;
  return {
    type,
    owner_kind: "manual",
    owner_id: operation.operation_id,
    operation_id: operation.operation_id,
    manual_request_id: operation.manual_request_id || "",
    conversation_key: operation.conversation_key,
    origin: operation.origin,
    conversation_id: operation.conversation_id,
    delivery_id: operation.delivery?.delivery_id || operation.delivery_id || "",
    delivery_mode: operation.delivery?.mode || "batch_watch_v1",
    delivery_phase: operation.delivery?.phase || null,
    request_id: "",
    outgoing_text: String(operation.delivery?.outgoing_text || operation.outgoing_text || ""),
    outgoing_hash: "",
    report_prefix_applied: operation.delivery?.report_prefix_applied === true || operation.report_prefix_applied === true,
    send_click_committed: Boolean(operation.delivery?.sa_send_actor),
    chatgpt_user_baseline: Array.isArray(operation.delivery?.sa_chatgpt_user_baseline) ? operation.delivery.sa_chatgpt_user_baseline : null,
    user_observation_epoch: typeof operation.delivery?.sa_user_observation_epoch === "string" ? operation.delivery.sa_user_observation_epoch : null,
    baseline_user_turn_ids: [],
    baseline_assistant_turn_ids: Array.isArray(operation.delivery?.baseline_assistant_turn_ids) ? operation.delivery.baseline_assistant_turn_ids : []
  };
}

async function manualOwnerDecision(operation, candidateTabId, { allowRebind = true } = {}) {
  const candidate = normalizeTabId(candidateTabId);
  if (!operation || !manualOperationActive(operation)) return { owner: false, reason: "manual_operation_missing", operation };
  if (Number(operation.tab_id) === candidate) {
    await assertTabConversation(candidate, operation.conversation_key, operation.conversation_id);
    return { owner: true, rebound: false, operation };
  }
  const oldTab = await chrome.tabs.get(Number(operation.tab_id)).catch(() => null);
  let oldOwnsConversation = false;
  if (oldTab?.id) {
    const oldIdentity = await tabIdentity(oldTab.id).catch(() => null);
    if (oldIdentity) oldOwnsConversation = conversationKeyFromIdentity(oldIdentity) === operation.conversation_key;
  }
  if (oldOwnsConversation) return { owner: false, reason: "duplicate_non_owner", owner_tab_id: operation.tab_id, operation };
  if (!allowRebind) return { owner: false, reason: "owner_unavailable", owner_tab_id: operation.tab_id, operation };
  await assertTabConversation(candidate, operation.conversation_key, operation.conversation_id);
  const rebound = await mutateManualOperation(operation.conversation_key, (current) => {
    if (!current || current.operation_id !== operation.operation_id || !manualOperationActive(current)) return current;
    return { ...current, tab_id: candidate };
  });
  return { owner: true, rebound: true, operation: rebound || operation };
}

async function manualRecoveryForContent(operation, candidateTabId) {
  if (!operation || !manualOperationActive(operation))
    return { owner: true, recovery: null, operation };
  const owner = await manualOwnerDecision(operation, candidateTabId, {
    allowRebind: true,
  });
  if (!owner.owner) return { ...owner, recovery: null };
  let current = owner.operation || operation;
  if (current.status === MANUAL_OPERATION_STATUSES.REQUESTING) {
    const requestState = String(current.batch?.request_state || "idle");
    const requestWorker = String(
      current.batch?.request_worker_session_id || "",
    );
    if (
      requestState === "requesting" &&
      requestWorker &&
      requestWorker !== WORKER_SESSION_ID
    ) {
      const requesting = (current.batch?.entries || []).filter((entry) => entry?.status === "requesting");
      const knownBuffered = requesting.length > 0 && requesting.every((entry) =>
        entry?.provider_attempt?.state === SellerAgentsProviderOutcome.STATES.RESPONSE_RECEIVED &&
        entry?.result_buffer?.phase === SellerAgentsResultRecovery.RESULT_PHASES.BUFFERED,
      );
      if (knownBuffered) {
        setTimeout(() => {
          launchBatchProcessor("manual", current.conversation_key, current.operation_id, "known_result_recovery");
        }, 0);
        return {
          owner: true,
          rebound: owner.rebound === true,
          operation: current,
          recovery: { type: "resume_local_result", code: "KNOWN_RESULT_RECOVERY_SAFE", provider_calls: 0 },
        };
      }
      const knownWithoutBuffer = requesting.some((entry) =>
        [SellerAgentsProviderOutcome.STATES.RESPONSE_RECEIVED, SellerAgentsProviderOutcome.STATES.COMPLETED_KNOWN, SellerAgentsProviderOutcome.STATES.FAILED_KNOWN].includes(entry?.provider_attempt?.state) &&
        entry?.result_buffer?.phase !== SellerAgentsResultRecovery.RESULT_PHASES.BUFFERED,
      );
      if (knownWithoutBuffer) {
        current = await failManualBatch(
          current.conversation_key,
          current.operation_id,
          "RESULT_RECOVERY_UNAVAILABLE_NO_REPLAY",
          "Известный provider result не имеет локального projection buffer; повторный provider request запрещён.",
        );
        return {
          owner: true,
          rebound: owner.rebound === true,
          operation: current,
          recovery: { type: "blocked", code: "RESULT_RECOVERY_UNAVAILABLE_NO_REPLAY" },
        };
      }
      current = await mutateManualOperation(
        current.conversation_key,
        (value) => {
          if (!value || value.operation_id !== current.operation_id || !value.batch)
            return value;
          const entries = (value.batch.entries || []).map((entry) => {
            if (entry?.provider_attempt?.state !== "DISPATCH_INTENT_COMMITTED") return entry;
            const attempt = SellerAgentsProviderOutcome.markUnknown(
              entry.provider_attempt,
              Date.now(),
              "worker_restart",
            );
            return {
              ...entry,
              provider_attempt: attempt,
              provider_attempt_history: (entry.provider_attempt_history || []).map((row) =>
                row.provider_attempt_id === attempt.provider_attempt_id ? attempt : row,
              ),
            };
          });
          return { ...value, batch: { ...value.batch, entries } };
        },
      );
      current = await failManualBatch(
        current.conversation_key,
        current.operation_id,
        "REQUEST_OUTCOME_UNKNOWN_NO_RETRY",
        "Service worker перезапустился во время ручного Ozon API request. Исход запроса неизвестен; автоматический повтор запрещён.",
      );
      await diagnostic(
        "REQUEST_RECOVERY_BLOCKED_NO_RETRY",
        {
          owner_kind: "manual",
          owner_id: current?.operation_id || operation.operation_id,
          previous_worker_session_id: requestWorker,
          worker_session_id: WORKER_SESSION_ID,
        },
        { level: "error" },
      );
      return {
        owner: true,
        rebound: owner.rebound === true,
        operation: current,
        recovery: null,
      };
    }
    setTimeout(() => {
      launchBatchProcessor(
        "manual",
        current.conversation_key,
        current.operation_id,
        "manual_recovery",
      );
    }, 0);
    return {
      owner: true,
      rebound: owner.rebound === true,
      operation: current,
      recovery: null,
    };
  }
  if (
    current.status !== MANUAL_OPERATION_STATUSES.DELIVERING ||
    current.delivery?.mode !== "batch_watch_v1"
  )
    return {
      owner: true,
      rebound: owner.rebound === true,
      operation: current,
      recovery: null,
    };
  try {
    await assertManualBatchContext(
      current.conversation_key,
      current.operation_id,
    );
  } catch (error) {
    if (!error?.execution_context_error) throw error;
    current = await failManualBatch(
      current.conversation_key,
      current.operation_id,
      error.code,
      error.message,
    );
    return { owner: true, operation: current, recovery: null };
  }
  if (current.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.CLAIMED)
    return {
      owner: true,
      rebound: owner.rebound === true,
      operation: current,
      recovery: manualBatchRecoveryPayload(current, "deliver_claimed"),
    };
  if (current.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERTED)
    return {
      owner: true,
      rebound: owner.rebound === true,
      operation: current,
      recovery: manualBatchRecoveryPayload(current, "watch_delivery"),
    };
  if (
    current.delivery.phase ===
    BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED
  )
    return {
      owner: true,
      rebound: owner.rebound === true,
      operation: current,
      recovery: {
        ...manualBatchRecoveryPayload(
          current,
          "delivery_insert_outcome_unknown",
        ),
        code: "DELIVERY_INSERT_OUTCOME_UNKNOWN_NO_RETRY",
      },
    };
  return {
    owner: true,
    rebound: owner.rebound === true,
    operation: current,
    recovery: null,
  };
}


const TAB_MESSAGE_TRANSPORT_CLASSES = new Set([
  "NO_RECEIVER",
  "PORT_CLOSED",
  "TAB_GONE",
  "CONTEXT_INVALIDATED",
  "SYNC_SEND_EXCEPTION",
  "OTHER_TAB_MESSAGE_ERROR",
  "RESPONSE_TIMEOUT"
]);
const TAB_IDENTITY_RESPONSE_TIMEOUT_MS = 3000;

function safeTabMessageTransportClass(value) {
  const candidate = typeof value === "string" ? value : "";
  return TAB_MESSAGE_TRANSPORT_CLASSES.has(candidate) ? candidate : null;
}

function classifyTabMessageTransportError(error, source = "runtime_last_error") {
  if (source === "sync_exception") return "SYNC_SEND_EXCEPTION";
  const message = String(error?.message || "").toLowerCase();
  if (message.includes("extension context invalidated")) return "CONTEXT_INVALIDATED";
  if (message.includes("receiving end does not exist")) return "NO_RECEIVER";
  if (message.includes("message port closed") || message.includes("message channel closed")) return "PORT_CLOSED";
  if (message.includes("no tab with id") || message.includes("tab was closed") || message.includes("frame was removed")) return "TAB_GONE";
  return "OTHER_TAB_MESSAGE_ERROR";
}

async function tabMessage(tabId, message) {
  return new Promise((resolve) => {
    let settled = false, deadline = null;
    const complete = (response) => {
      if (settled) return;
      settled = true;
      if (deadline !== null) clearTimeout(deadline);
      resolve(response);
    };
    // Reading identity has no side effects. A silent renderer cannot hold
    // popup/support/Finish validation forever. Mutating messages keep their
    // existing outcome protocol and never gain a deadline or retry here.
    if (message?.type === "OZ_GET_IDENTITY") deadline = setTimeout(() => complete({
      ok: false, code: "TAB_MESSAGE_TIMEOUT", transport_class: "RESPONSE_TIMEOUT"
    }), TAB_IDENTITY_RESPONSE_TIMEOUT_MS);
    try {
      chrome.tabs.sendMessage(tabId, message, (response) => {
        // Consume lastError even when this callback arrives after the deadline.
        const error = chrome.runtime.lastError;
        if (settled) return;
        if (error) return complete({
          ok: false,
          code: "TAB_MESSAGE_ERROR",
          transport_class: classifyTabMessageTransportError(error)
        });
        complete(response || { ok: false, code: "EMPTY_RESPONSE", error: "Пустой ответ вкладки." });
      });
    } catch (error) {
      complete({
        ok: false,
        code: "TAB_MESSAGE_ERROR",
        transport_class: classifyTabMessageTransportError(error, "sync_exception")
      });
    }
  });
}

async function stopWatch(run, reason) {
  if (!run?.tab_id) return;
  await diagnostic("PROMPT_WATCH_STOP_REQUESTED", { run_id: run.run_id, tab_id: run.tab_id, reason: reason || "worker" });
  const response = await tabMessage(run.tab_id, { type: "OZ_AUTO_STOP_WATCH", run_id: run.run_id, reason: reason || "worker" });
  await diagnostic("PROMPT_WATCH_STOP_RESPONSE", { run_id: run.run_id, tab_id: run.tab_id, ok: response?.ok === true, code: response?.code || null, error: response?.error || null }, { level: response?.ok === true ? "info" : "warning" });
}

async function beginWatch(run) {
  if (!run || run.status !== BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) return { ok: false, code: "RUN_NOT_WAITING" };
  await assertRunBinding(run);
  await assertTabConversation(run.tab_id, run.conversation_key, run.conversation_id);
  return tabMessage(run.tab_id, {
    type: "OZ_AUTO_BEGIN_WATCH",
    run_id: run.run_id,
    conversation_key: run.conversation_key,
    origin: run.origin,
    conversation_id: run.conversation_id,
    watch_id: run.watch_id,
    assistant_baseline_ids: Array.isArray(run.assistant_baseline_ids) ? run.assistant_baseline_ids : []
  });
}

async function markRunError(conversationKey, code, message) {
  const key = normalizeConversationKey(conversationKey);
  const run = await mutateAutoRun(key, (current) => current ? {
    ...current,
    status: BridgeAutorunModel.RUN_STATUSES.ERROR,
    last_error: { code: String(code || "AUTO_RUN_ERROR"), message: String(message || "Autorun error"), at: new Date().toISOString() }
  } : null);
  if (run) await stopWatch(run, "run_error");
  return run;
}

async function ownerDecision(run, candidateTabId, { allowRebind = true } = {}) {
  const candidate = normalizeTabId(candidateTabId);
  if (!run) return { owner: false, reason: "run_missing", run: null };
  await assertRunBinding(run);
  if (Number(run.tab_id) === candidate) {
    await assertTabConversation(candidate, run.conversation_key, run.conversation_id);
    return { owner: true, rebound: false, run };
  }

  const oldTab = await chrome.tabs.get(Number(run.tab_id)).catch(() => null);
  let oldOwnsConversation = false;
  if (oldTab?.id) {
    const oldIdentity = await tabIdentity(oldTab.id).catch(() => null);
    if (oldIdentity) oldOwnsConversation = conversationKeyFromIdentity(oldIdentity) === run.conversation_key;
  }
  if (oldOwnsConversation) {
    return { owner: false, reason: "duplicate_non_owner", owner_tab_id: run.tab_id, run };
  }

  if (!allowRebind || BridgeAutorunModel.isTerminalStatus(run.status)) {
    return { owner: false, reason: "owner_unavailable", owner_tab_id: run.tab_id, run };
  }
  await assertTabConversation(candidate, run.conversation_key, run.conversation_id);
  const rebound = await mutateAutoRun(run.conversation_key, (current) => {
    if (!current || current.run_id !== run.run_id) return current;
    return { ...current, tab_id: candidate };
  });
  return { owner: true, rebound: true, run: rebound };
}

async function commitAutoStart(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const runId = String(message.run_id || "");
  const actorId = String(message.actor_id || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  let run = await getAutoRun(key);
  if (!run || run.run_id !== runId) {
    return { ok: false, committed: false, click_allowed: false, code: "AUTO_START_STATE_MISMATCH", error: "Run не найден или не совпадает." };
  }
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(run.tab_id)) {
    return { ok: false, committed: false, click_allowed: false, code: "AUTO_NON_OWNER_TAB", error: "Start commit пришёл не из owner-вкладки." };
  }
  await assertTabConversation(senderTabId, key, run.conversation_id);
  await assertRunBinding(run);
  const phase = run.start_delivery?.phase || BridgeAutorunModel.START_PHASES.NONE;
  if (phase === BridgeAutorunModel.START_PHASES.CONFIRMED) {
    return { ok: true, committed: true, click_allowed: false, already_confirmed: true };
  }
  if (phase === BridgeAutorunModel.START_PHASES.COMMITTED) {
    // Commit is the irreversible boundary. Even the same content runtime must never receive a second click grant.
    return { ok: true, committed: true, click_allowed: false, already_committed: true };
  }
  if (run.status !== BridgeAutorunModel.RUN_STATUSES.STARTING) {
    return { ok: false, committed: false, click_allowed: false, code: "AUTO_START_STATE_MISMATCH", error: "Run не находится в start state." };
  }
  let clickAllowed = false;
  run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId || current.status !== BridgeAutorunModel.RUN_STATUSES.STARTING) return current;
    const currentPhase = current.start_delivery?.phase || BridgeAutorunModel.START_PHASES.NONE;
    if (currentPhase !== BridgeAutorunModel.START_PHASES.NONE) return current;
    clickAllowed = true;
    return BridgeAutorunModel.commitStart(current, {
      baselineUserTurnIds: message.baseline_user_turn_ids,
      actorId
    });
  });
  if (!clickAllowed) {
    return { ok: true, committed: true, click_allowed: false, already_committed: true };
  }
  await diagnostic("START_COMMITTED_BEFORE_CLICK", { run_id: runId, tab_id: senderTabId, actor_id: actorId || null, baseline_user_turn_count: run?.start_delivery?.baseline_user_turn_ids?.length || 0 });
  return { ok: true, committed: true, click_allowed: true, run: publicRun(run) };
}

async function finalizeCommittedStartFromComposerEmpty(key, runId, senderTabId, assistantBaselineIds = [], diagnostics = {}) {
  let didConfirm = false;
  let run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId) return current;
    if (current.start_delivery?.phase === BridgeAutorunModel.START_PHASES.CONFIRMED) return current;
    if (current.status !== BridgeAutorunModel.RUN_STATUSES.STARTING || current.start_delivery?.phase !== BridgeAutorunModel.START_PHASES.COMMITTED) return current;
    didConfirm = true;
    return BridgeAutorunModel.afterConfirmedStart(current, assistantBaselineIds || []);
  });
  if (!didConfirm && run?.start_delivery?.phase !== BridgeAutorunModel.START_PHASES.CONFIRMED) {
    return { ok: false, code: "AUTO_START_CONFIRM_RACE", error: "Start state изменился конкурентно до подтверждения." };
  }
  if (didConfirm) {
    await diagnostic("START_CONFIRMED", {
      run_id: runId,
      tab_id: senderTabId,
      confirmation_basis: "composer_empty_after_committed_click",
      click_attempts: Number(diagnostics.click_attempts || 0),
      status: run?.status || null
    });
    if (run?.status === BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) await beginWatch(run);
    else if (run) await stopWatch(run, `start_complete:${run.status}`);
  }
  return { ok: true, confirmed: true, already_confirmed: !didConfirm, run: publicRun(run) };
}

async function completeAutoStart(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const runId = String(message.run_id || "");
  const actorId = String(message.actor_id || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  const run = await getAutoRun(key);
  if (!run || run.run_id !== runId) {
    return { ok: false, code: "AUTO_START_STATE_MISMATCH", error: "Run не найден или не совпадает." };
  }
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(run.tab_id)) {
    return { ok: false, code: "AUTO_NON_OWNER_TAB", error: "Start confirmation пришёл не из owner-вкладки." };
  }
  await assertTabConversation(senderTabId, key, run.conversation_id);
  await assertRunBinding(run);
  if (run.start_delivery?.phase === BridgeAutorunModel.START_PHASES.CONFIRMED) {
    return { ok: true, confirmed: true, already_confirmed: true, run: publicRun(run) };
  }
  if (run.status !== BridgeAutorunModel.RUN_STATUSES.STARTING) {
    return { ok: false, code: "AUTO_START_STATE_MISMATCH", error: "Run не находится в start state." };
  }
  if (run.start_delivery?.phase !== BridgeAutorunModel.START_PHASES.COMMITTED) {
    return { ok: false, code: "AUTO_START_NOT_COMMITTED", error: "Start ещё не committed." };
  }
  if (message.reconcile !== true && run.start_delivery?.commit_actor_id && actorId && run.start_delivery.commit_actor_id !== actorId) {
    return { ok: false, code: "AUTO_START_ACTOR_MISMATCH", error: "Start confirmation пришёл от другого content runtime." };
  }

  // Reference parity: for the normal start path, a committed click followed by an empty composer is the confirmation boundary.
  // Reconciliation may prove the same fact by locating the already-created user turn, but no user-turn DOM match is required here.
  if (message.composer_empty !== true) {
    await diagnostic("START_CONFIRMATION_PENDING", { run_id: runId, tab_id: senderTabId, click_attempts: Number(message.click_attempts || 0), confirmation_basis: "composer_not_empty" }, { level: "warning" });
    return { ok: true, confirmed: false, pending_reconciliation: true, run: publicRun(run) };
  }
  return await finalizeCommittedStartFromComposerEmpty(key, runId, senderTabId, message.assistant_baseline_ids || [], {
    click_attempts: message.click_attempts
  });
}

function startRecoveryPayload(run) {
  return {
    type: "dispatch_start",
    run_id: run.run_id,
    conversation_key: run.conversation_key,
    origin: run.origin,
    conversation_id: run.conversation_id,
    message_text: String(run.start_delivery?.message_text || "")
  };
}

function deliveryRecoveryPayload(run, type) {
  return {
    type,
    owner_kind: "autorun",
    owner_id: run.run_id,
    run_id: run.run_id,
    conversation_key: run.conversation_key,
    origin: run.origin,
    conversation_id: run.conversation_id,
    delivery_id: run.delivery?.delivery_id || "",
    delivery_mode: run.delivery?.mode || "legacy",
    delivery_phase: run.delivery?.phase || null,
    request_id: run.delivery?.request_id || "",
    outgoing_text: String(run.delivery?.outgoing_text || ""),
    outgoing_hash: run.delivery?.outgoing_hash || "",
    report_prefix_applied: run.delivery?.report_prefix_applied === true,
    baseline_user_turn_ids: Array.isArray(run.delivery?.baseline_user_turn_ids) ? run.delivery.baseline_user_turn_ids : [],
    baseline_assistant_turn_ids: Array.isArray(run.delivery?.baseline_assistant_turn_ids) ? run.delivery.baseline_assistant_turn_ids : []
  };
}

async function recoveryPayloadForRun(run) {
  if (!run || BridgeAutorunModel.isTerminalStatus(run.status)) return null;
  await assertRunBinding(run);
  const decision = BridgeAutorunModel.recoveryDecision(run, WORKER_SESSION_ID);
  if (decision.type === "unsafe_request_outcome") {
    const previousWorkerSessionId = run.status === BridgeAutorunModel.RUN_STATUSES.COLLECTING
      ? (run.batch?.request_worker_session_id || null)
      : (run.request_worker_session_id || null);
    const failed = await markRunError(run.conversation_key, decision.code, "Service worker перезапустился во время Ozon API request. Исход запроса неизвестен; автоматический повтор запрещён, чтобы не создать второй provider API-вызов.");
    await diagnostic("REQUEST_RECOVERY_BLOCKED_NO_RETRY", { run_id: run.run_id, previous_worker_session_id: previousWorkerSessionId, worker_session_id: WORKER_SESSION_ID }, { level: "error" });
    return { type: "request_outcome_unknown", code: decision.code, run: publicRun(failed) };
  }
  if (decision.type === "dispatch_start") return startRecoveryPayload(run);
  if (decision.type === "reconcile_start") {
    return {
      ...startRecoveryPayload(run),
      type: "reconcile_start",
      baseline_user_turn_ids: Array.isArray(run.start_delivery?.baseline_user_turn_ids) ? run.start_delivery.baseline_user_turn_ids : []
    };
  }
  if (decision.type === "resume_collection") {
    setTimeout(() => { launchBatchProcessor("autorun", run.conversation_key, run.run_id, "autorun_recovery"); }, 0);
    return { type: "collection_resuming", run_id: run.run_id };
  }
  if (decision.type === "deliver_claimed") return deliveryRecoveryPayload(run, "deliver_claimed");
  if (decision.type === "watch_delivery") return deliveryRecoveryPayload(run, "watch_delivery");
  if (decision.type === "unsafe_insert_outcome") {
    await diagnostic("DELIVERY_INSERT_OUTCOME_UNKNOWN_NO_RETRY", { run_id: run.run_id, delivery_id: run.delivery?.delivery_id || null, phase: run.delivery?.phase || null }, { level: "error" });
    return { ...deliveryRecoveryPayload(run, "delivery_insert_outcome_unknown"), code: decision.code };
  }
  if (decision.type === "reconcile_delivery") return deliveryRecoveryPayload(run, "reconcile_delivery");
  if (decision.type === "request_in_progress") return { type: "request_in_progress", run_id: run.run_id };
  if (decision.type === "paused") return { type: "paused", run_id: run.run_id };
  return null;
}

async function startAutoRun(conversationKey, tabId) {
  const key = normalizeConversationKey(conversationKey);
  const tab = normalizeTabId(tabId);
  const liveIdentity = await assertTabConversation(tab, key);
  await migrateLegacyConversationStorage(liveIdentity);
  const binding = await strictBindingForIdentity(liveIdentity);
  const settings = await getSettings();
  OzonCredentials.normalizeSellerCredentials(settings.sellerCredentials, { required: true });
  if (!Object.values(OzonContract.OPERATIONS).some((meta) => meta.execution_enabled === true)) throw Object.assign(new Error("Ozon provider execution gate закрыт: нет ни одной implementation-ready READ operation."), { code: "PROVIDER_GATE_CLOSED" });
  if (await getManualMode(key)) throw Object.assign(new Error("Сначала отключите ручной режим Ozon."), { code: "MANUAL_MODE_ACTIVE" });
  const manualOperation = await getManualOperation(key);
  if (manualOperationActive(manualOperation)) {
    await diagnostic("AUTO_MODE_START_BLOCKED_BY_MANUAL_OPERATION", { operation_id: manualOperation.operation_id || null, status: manualOperation.status || null, conversation_id: liveIdentity.conversation_id || null, tab_id: tab }, { level: "warning" });
    throw Object.assign(new Error("Дождитесь завершения уже принятого ручного Ozon request/delivery."), { code: "MANUAL_OPERATION_ACTIVE" });
  }
  const existing = await getAutoRun(key);
  if (existing && !BridgeAutorunModel.isTerminalStatus(existing.status)) {
    throw Object.assign(new Error("Для этого диалога уже существует активный Ozon autorun."), { code: "AUTO_RUN_ALREADY_ACTIVE" });
  }

  const startPrompt = await getAutoStartPrompt(key);
  const now = new Date().toISOString();
  let run = {
    run_id: `ozrun-${crypto.randomUUID()}`,
    conversation_key: key,
    origin: liveIdentity.origin,
    conversation_id: liveIdentity.conversation_id,
    binding_snapshot: bindingSnapshot(binding),
    tab_id: tab,
    status: BridgeAutorunModel.RUN_STATUSES.STARTING,
    sequence: 0,
    pause_requested: false,
    finish_requested: false,
    assistant_baseline_ids: [],
    watch_id: null,
    last_assistant_turn_id: null,
    last_command_fingerprint: null,
    last_operation: null,
    last_command_summary: null,
    last_error: null,
    start_delivery: {
      phase: BridgeAutorunModel.START_PHASES.NONE,
      message_text: String(startPrompt.text || ""),
      baseline_user_turn_ids: [],
      commit_actor_id: null,
      committed_at: null,
      confirmed_at: null
    },
    delivery: null,
    last_confirmed_delivery_id: null,
    last_confirmed_report_prefix_applied: false,
    last_confirmed_user_turn_id: null,
    created_at: now,
    updated_at: now
  };
  run = await mutateAutoRun(key, () => run);

  // Report prefix is deliberately NOT read or applied here. It belongs only to post-API result delivery.
  await diagnostic("START_DISPATCH_REQUESTED", { run_id: run.run_id, tab_id: tab });
  const response = await tabMessage(tab, {
    type: "OZ_AUTO_SEND_START",
    run_id: run.run_id,
    conversation_key: key,
    origin: run.origin,
    conversation_id: run.conversation_id,
    message_text: startPrompt.text
  });
  await diagnostic("START_DISPATCH_RESPONSE", {
    run_id: run.run_id,
    tab_id: tab,
    ok: response?.ok === true,
    committed: response?.committed === true,
    composer_empty: response?.composer_empty === true,
    click_attempts: Number(response?.click_attempts || 0),
    code: response?.code || null,
    error: response?.error || null
  }, { level: response?.ok === true ? "info" : "warning" });

  run = await getAutoRun(key) || run;
  if (response?.ok && response?.composer_empty === true) {
    const finalized = await finalizeCommittedStartFromComposerEmpty(
      key,
      run.run_id,
      tab,
      Array.isArray(response.assistant_baseline_ids) ? response.assistant_baseline_ids : [],
      { click_attempts: response.click_attempts }
    );
    if (!finalized?.ok) throw Object.assign(new Error(finalized?.error || "Start composer confirmation failed."), { code: finalized?.code || "AUTO_START_CONFIRM_FAILED" });
    await diagnostic("START_SEND_COMPLETED", { run_id: run.run_id, tab_id: tab, click_attempts: Number(response?.click_attempts || 0) });
    return finalized.run;
  }
  if (!response?.ok) {
    if ((run.start_delivery?.phase || BridgeAutorunModel.START_PHASES.NONE) === BridgeAutorunModel.START_PHASES.NONE) {
      run = await markRunError(key, response?.code || "AUTO_START_FAILED", response?.error || "Не удалось подготовить/отправить стартовое сообщение autorun.");
      throw Object.assign(new Error(response?.error || "Не удалось отправить стартовое сообщение autorun."), { code: response?.code || "AUTO_START_FAILED" });
    }
    // After commit the click outcome can be ambiguous. Never auto-resend; leave STARTING for reconciliation.
    await diagnostic("START_RESPONSE_LOST_AFTER_COMMIT", { run_id: run.run_id, phase: run.start_delivery?.phase || null }, { level: "warning" });
  } else if ((run.start_delivery?.phase || BridgeAutorunModel.START_PHASES.NONE) === BridgeAutorunModel.START_PHASES.COMMITTED) {
    await diagnostic("START_CONFIRMATION_PENDING", { run_id: run.run_id, tab_id: tab, click_attempts: Number(response?.click_attempts || 0), confirmation_basis: "composer_not_empty" }, { level: "warning" });
  }
  return publicRun(await getAutoRun(key) || run);
}

async function handleAutoPreExecutionError(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const runId = String(message.run_id || "");
  const assistantTurnId = String(message.assistant_turn_id || "").slice(0, 240);
  const senderTabId = Number(sender?.tab?.id || 0);
  const currentRun = await getAutoRun(key);
  if (!currentRun || currentRun.run_id !== runId) return { ok: false, accepted: false, code: "AUTO_RUN_NOT_FOUND", error: "Autorun не найден." };
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(currentRun.tab_id)) {
    return { ok: false, accepted: false, code: "AUTO_NON_OWNER_TAB", error: "Ошибка OZON_API_V1 обнаружена не во вкладке-owner активного autorun." };
  }
  try {
    await assertTabConversation(senderTabId, key, currentRun.conversation_id);
    await assertRunBinding(currentRun);
  } catch (error) {
    return { ok: false, accepted: false, code: error.code || "CONVERSATION_MISMATCH", error: error.message };
  }
  if (await getManualMode(key)) return { ok: false, paused: true, code: "MANUAL_MODE_ACTIVE", error: "Ручной режим включён; autorun не доставляет ошибку команды." };

  const sourceError = Object.assign(new Error(String(message.error_message || "Октопорт не смог обработать команду до API-вызова.")), {
    code: String(message.error_code || "AUTO_PREEXEC_ERROR")
  });
  const safe = OzonContract.safeBridgeErrorPayload(sourceError, 0);
  const stage = String(message.error_stage || "pre_execution").slice(0, 80);
  const preexec = buildPreExecutionErrorResult({
    error: sourceError,
    stage,
    commandFingerprint: String(message.command_fingerprint || ""),
    requestIdPrefix: "auto-preexec"
  });
  const fingerprint = preexec.command_fingerprint;
  const requestId = preexec.request_id;
  const reportText = preexec.report_text;
  const prefixed = await applyPrefixToReport(key, reportText);
  const outgoingHash = await sha256Hex(prefixed.outgoing_text);
  const deliveryId = `delivery-${crypto.randomUUID()}`;
  let deliveryGranted = false;

  const run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId) return current;
    if (Number(current.tab_id) !== senderTabId) return current;
    if (current.status !== BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) return current;
    if (current.last_assistant_turn_id === assistantTurnId && current.last_command_fingerprint === fingerprint) return current;
    deliveryGranted = true;
    const claimed = BridgeAutorunModel.claimDelivery({
      ...current,
      last_assistant_turn_id: assistantTurnId,
      last_command_fingerprint: fingerprint,
      last_operation: null,
      last_command_summary: `pre_execution_error:${safe.code}`,
      last_error: {
        code: safe.code,
        message: safe.message,
        stage,
        external_request_executed: false,
        recoverable: true,
        at: new Date().toISOString()
      }
    }, {
      deliveryId,
      requestId,
      outgoingText: prefixed.outgoing_text,
      outgoingHash,
      reportPrefixApplied: prefixed.report_prefix_applied === true
    });
    claimed.request_worker_session_id = null;
    claimed.request_completed_at = new Date().toISOString();
    return claimed;
  });

  if (!run || run.run_id !== runId) return { ok: false, accepted: false, code: "AUTO_RUN_NOT_FOUND", error: "Autorun не найден." };
  if (!deliveryGranted) return { ok: true, accepted: false, ignored: true, status: run.status };

  await diagnostic("AUTO_PREEXEC_ERROR_ACCEPTED", {
    run_id: runId,
    tab_id: senderTabId,
    assistant_turn_id: assistantTurnId || null,
    stage,
    code: safe.code,
    command_fingerprint: fingerprint,
    delivery_id: deliveryId,
    request_id: requestId,
    external_request_executed: false,
    outgoing_hash: outgoingHash
  }, { level: "warning" });
  await diagnostic("DELIVERY_CLAIMED", {
    run_id: runId,
    delivery_id: deliveryId,
    request_id: requestId,
    report_prefix_applied: prefixed.report_prefix_applied === true,
    outgoing_hash: outgoingHash,
    source: "pre_execution_error"
  }, { level: "warning" });

  void attemptAutoDelivery(key, runId);
  return {
    ok: false,
    bridge_error: true,
    pre_execution_error: true,
    accepted: true,
    request_id: requestId,
    operation: null,
    command_fingerprint: fingerprint,
    http_status: 0,
    report_text: reportText,
    ...prefixed,
    run_id: runId,
    delivery_id: deliveryId,
    outgoing_hash: outgoingHash,
    sequence: Number(run.sequence || 0),
    external_request_executed: false
  };
}

function batchEntryFromDiscovery(entry) {
  if (entry?.ok === true) {
    return {
      kind: "command",
      status: "pending",
      operation: entry.command.operation,
      command_text: entry.command_text,
      command: entry.command,
      command_fingerprint: entry.command_fingerprint,
      request_id: null,
      http_status: null,
      external_request_executed: null,
      report_text: null
    };
  }
  const sourceError = Object.assign(new Error(String(entry?.message || "Некорректная OZON_API_V1 команда.")), { code: String(entry?.code || "INVALID_COMMAND") });
  return batchErrorEntry(sourceError, String(entry?.stage || "command_discovery"), String(entry?.command_fingerprint || ""), entry?.attempt_descriptor || null);
}

function batchErrorEntry(error, stage = "command_discovery", commandFingerprint = "", attemptDescriptor = null) {
  const sourceError = error instanceof Error ? error : Object.assign(new Error(String(error || "Некорректная OZON_API_V1 команда.")), { code: "INVALID_COMMAND" });
  const safe = OzonContract.safeBridgeErrorPayload(sourceError, 0);
  return {
    kind: "pre_execution_error",
    status: "pending",
    error: {
      code: safe.code,
      message: safe.message,
      stage: String(stage || "command_discovery").slice(0, 80),
      command_fingerprint: String(commandFingerprint || "").trim().toLowerCase(),
      attempt_descriptor: attemptDescriptor || null
    },
    request_id: null,
    http_status: 0,
    external_request_executed: false,
    report_text: null
  };
}

function discoverBatchEntries(text) {
  const source = String(text || "");
  if (!globalThis.OzonMixedBatchDiscovery?.discover) {
    return [batchErrorEntry(Object.assign(new Error("Ordered mixed HELP/API discovery module is unavailable."), { code: "MIXED_BATCH_DISCOVERY_UNAVAILABLE" }), "mixed_batch_discovery", OzonContract.textFingerprint(source))];
  }
  let discovered;
  try {
    discovered = OzonMixedBatchDiscovery.discover(source, {
      commandPrefix: OzonRuntime.RUNTIME.commandPrefix,
      helpPrefixV1: OzonRuntime.RUNTIME.helpPrefix,
      helpPrefixV2: OzonRuntime.RUNTIME.helpPrefixV2 || "OZON_HELP_V2",
      apiDiscover: (value) => OzonContract.discoverCommands(value),
      parseHelp: (value) => OzonGuidance.parseHelp(value)
    });
  } catch (error) {
    return [batchErrorEntry(Object.assign(new Error(String(error?.message || error || "Mixed batch discovery failed.")), { code: String(error?.code || "MIXED_BATCH_DISCOVERY_FAILED_CLOSED") }), "mixed_batch_discovery", OzonContract.textFingerprint(source))];
  }
  return discovered.map((item) => {
    if (item.kind === "api") return batchEntryFromDiscovery(item.discovery);
    const help = item.help;
    if (!help?.ok) {
      return {
        kind: "guidance",
        status: "pending",
        guidance: {
          status: "guidance_error",
          cluster: null,
          section: null,
          version: Number(item.version || 1),
          error: String(help?.code || "HELP_DISCOVERY_FAILED_CLOSED")
        },
        request_id: null,
        http_status: 0,
        external_request_executed: false,
        report_text: null
      };
    }
    return {
      kind: "guidance",
      status: "pending",
      guidance: {
        status: help.section ? "section_selected" : "cluster_selected",
        cluster: help.cluster,
        section: help.section || null,
        version: Number(help.version || item.version || 1),
        error: null
      },
      request_id: null,
      http_status: 0,
      external_request_executed: false,
      report_text: null
    };
  });
}

function localGuidanceResult(entry) {
  const error = entry?.error || {};
  const descriptor = error.attempt_descriptor || OzonContract.sanitizedAttemptDescriptor(null, error.code || "INVALID_COMMAND");
  const classified = entry?.kind === "guidance" ? entry.guidance : OzonGuidance.classify(descriptor);
  const status = String(classified.status || "cluster_required");
  const cluster = classified.cluster || null;
  const section = classified.section || null;
  const version = Number(classified.version || 1) >= 2 ? 2 : 1;
  const payload = OzonGuidance.result({ status, cluster, section, version, error: error.code || classified.error || null, descriptor });
  return { request_id: `guidance-${crypto.randomUUID()}`, report_text: OzonGuidance.format(payload), status, cluster, section, version, external_request_executed: false };
}

function safeBatchCapabilitySummary(batch) {
  const resolution = batch?.capability_resolution;
  if (!resolution || typeof resolution !== "object") return { performed: false, status: "not_resolved", subscription_type: null, http_status: 0, error_code: null };
  const profile = resolution.profile && typeof resolution.profile === "object" ? resolution.profile : {};
  return {
    performed: resolution.probe_performed === true || profile.probe_performed === true,
    status: String(profile.status || (resolution.state === "not_needed" ? "not_needed" : "unknown")),
    subscription_type: profile.subscription_type ? String(profile.subscription_type) : null,
    http_status: Number(profile.probe_http_status || 0),
    error_code: profile.probe_error_code ? String(profile.probe_error_code).slice(0, 160) : null
  };
}

function formatCombinedBatchReport(entries, batch = null) {
  const reports = (Array.isArray(entries) ? entries : []).map((entry) => String(entry?.report_text || "").trim()).filter(Boolean);
  const capabilitySummary = safeBatchCapabilitySummary(batch);
  const queryPlannerSummary = safeBatchQueryPlannerSummary(batch, entries);
  const header = {
    bridge: "ozon-llm-api-bridge",
    version: VERSION,
    delivery_mode: "sequential_batch_single_delivery",
    result_count: reports.length,
    capability_probe: capabilitySummary,
    query_planner: queryPlannerSummary
  };
  const parts = ["OZON_BATCH_RESULT_V1", JSON.stringify(header, null, 2)];
  reports.forEach((report, index) => {
    parts.push(`===== OZON RESULT ${index + 1}/${reports.length} =====`, report);
  });
  return parts.join("\n\n");
}

function commandRequiresPersonalDataPolicy(command) {
  const meta = OzonOperationRegistry.operation(command?.operation);
  if (meta?.policy_group === "personal_data_read") return true;
  if (command?.operation !== "report_file_get") return false;
  const refPolicy = typeof OzonProvider.reportFileRefPolicy === "function"
    ? OzonProvider.reportFileRefPolicy(command?.params?.file_ref)
    : null;
  return refPolicy?.known === true && refPolicy.personal_data_required === true;
}

async function ensureBatchLocalPolicy({
  ownerKind,
  ownerId,
  getOwner,
  mutateOwner,
  ownerMatches,
  isCollecting,
  failOwner,
  executionContext = null,
}) {
  let owner = await getOwner();
  if (!owner || !ownerMatches(owner))
    return { ok: false, code: "BATCH_OWNER_NOT_ACTIVE" };
  if (!isCollecting(owner) || !owner.batch)
    return { ok: true, code: "BATCH_NOT_COLLECTING", owner };
  if (owner.batch.policy_state === "complete")
    return { ok: true, code: "BATCH_POLICY_READY", owner };
  if (
    Math.max(0, Number(owner.batch.next_index || 0)) !== 0 ||
    (owner.batch.entries || []).some(
      (entry) => entry?.status === "requesting" || entry?.status === "complete",
    )
  ) {
    await failOwner(
      "BATCH_POLICY_MIGRATION_UNSAFE",
      "Batch уже начал исполнение до применения personal-data policy; новые provider requests запрещены.",
    );
    return { ok: false, code: "BATCH_POLICY_MIGRATION_UNSAFE" };
  }
  const settings = await (executionContext
    ? executionContext.settings()
    : getSettings());
  const personalDataEnabled = settings.personalDataEnabled === true;
  const nextEntries = (owner.batch.entries || []).map((entry) => {
    if (!entry || entry.kind !== "command" || !entry.command) return entry;
    if (
      !commandRequiresPersonalDataPolicy(entry.command) ||
      personalDataEnabled
    )
      return entry;
    return {
      ...entry,
      kind: "policy_error",
      status: "pending",
      error: {
        code: "OPERATION_DISABLED_BY_USER",
        message:
          "Операция может передать личные данные в AI-чат. Чтобы выполнить запрос, включите «Показывать личные данные» в настройках Октопорт, затем явно запустите новую команду.",
        policy: "personal_data_setting_required",
      },
      execution_command: null,
      planning: null,
    };
  });
  let stored = false;
  owner = await mutateOwner((current) => {
    if (
      !current ||
      !ownerMatches(current) ||
      !isCollecting(current) ||
      !current.batch ||
      current.batch.policy_state === "complete"
    )
      return current;
    if (
      Math.max(0, Number(current.batch.next_index || 0)) !== 0 ||
      current.batch.request_state !== "idle"
    )
      return current;
    stored = true;
    return {
      ...current,
      batch: {
        ...current.batch,
        entries: nextEntries,
        policy_state: "complete",
        policy_personal_data_enabled: personalDataEnabled,
        policy_completed_at: new Date().toISOString(),
      },
    };
  });
  if (!stored) {
    await failOwner(
      "BATCH_POLICY_STORE_RACE",
      "Personal-data policy не удалось сохранить до provider execution; business requests запрещены.",
    );
    return { ok: false, code: "BATCH_POLICY_STORE_RACE" };
  }
  const blockedCount = nextEntries.filter(
    (entry) => entry?.kind === "policy_error",
  ).length;
  if (blockedCount)
    await diagnostic(
      "PERSONAL_DATA_POLICY_BLOCKED",
      {
        owner_kind: ownerKind,
        owner_id: ownerId,
        blocked_count: blockedCount,
        external_request_executed: false,
      },
      { level: "warning" },
    );
  return { ok: true, code: "BATCH_POLICY_READY", owner };
}

function capabilityUnknownProfile(code = "CAPABILITY_PROBE_OUTCOME_UNKNOWN_NO_RETRY") {
  return Object.freeze({
    status: "unknown",
    subscription_type: "UNKNOWN",
    is_premium: null,
    probe_performed: true,
    probe_http_status: 0,
    probe_error_code: String(code || "CAPABILITY_PROBE_OUTCOME_UNKNOWN_NO_RETRY").slice(0, 160)
  });
}

async function ensureBatchCapabilityAndPlanning({
  ownerKind,
  ownerId,
  getOwner,
  mutateOwner,
  ownerMatches,
  isCollecting,
  failOwner,
  executionContext = null,
}) {
  let owner = await getOwner();
  if (!owner || !ownerMatches(owner))
    return { ok: false, code: "BATCH_OWNER_NOT_ACTIVE" };
  if (!isCollecting(owner) || !owner.batch)
    return { ok: true, code: "BATCH_NOT_COLLECTING", owner };
  if (owner.batch.planning_state === "complete")
    return { ok: true, code: "BATCH_PLANNING_READY", owner };

  const entries = Array.isArray(owner.batch.entries) ? owner.batch.entries : [];
  const nextIndex = Math.max(0, Number(owner.batch.next_index || 0));
  if (
    nextIndex > 0 ||
    entries.some(
      (entry) => entry?.status === "requesting" || entry?.status === "complete",
    )
  ) {
    await failOwner(
      "BATCH_PLANNING_MIGRATION_UNSAFE",
      "Batch уже начал исполнение без Step 1 capability plan; новые provider requests запрещены.",
    );
    return { ok: false, code: "BATCH_PLANNING_MIGRATION_UNSAFE" };
  }

  const commandEntries = entries.filter(
    (entry) => entry?.kind === "command" && entry?.command,
  );
  const planningAtMs = Date.now();
  const settingsForPlanning = await (executionContext
    ? executionContext.settings()
    : getSettings());
  const entitlementSnapshot = settingsForPlanning.sellerApiMetadata;
  const capabilityRequired = commandEntries.some((entry) => {
    try {
      return (
        OzonContract.sellerCapabilityRequirement(
          entry.command,
          planningAtMs,
          entitlementSnapshot,
        ).required === true
      );
    } catch (_) {
      return false;
    }
  });

  let resolution =
    owner.batch.capability_resolution &&
    typeof owner.batch.capability_resolution === "object"
      ? owner.batch.capability_resolution
      : null;
  if (!capabilityRequired) {
    const profile = {
      status: "not_needed",
      subscription_type: "UNKNOWN",
      is_premium: null,
      probe_performed: false,
      probe_http_status: 0,
      probe_error_code: null,
    };
    owner = await mutateOwner((current) => {
      if (
        !current ||
        !ownerMatches(current) ||
        !isCollecting(current) ||
        !current.batch ||
        current.batch.planning_state === "complete"
      )
        return current;
      if (
        Math.max(0, Number(current.batch.next_index || 0)) !== 0 ||
        current.batch.request_state !== "idle"
      )
        return current;
      return {
        ...current,
        batch: {
          ...current.batch,
          capability_resolution: {
            state: "not_needed",
            probe_performed: false,
            profile,
            resolved_at: new Date().toISOString(),
          },
        },
      };
    });
    resolution = owner?.batch?.capability_resolution || {
      state: "not_needed",
      profile,
    };
  } else {
    if (
      resolution?.state === "requesting" &&
      String(resolution.request_worker_session_id || "") !== WORKER_SESSION_ID
    ) {
      const profile = capabilityUnknownProfile();
      owner = await mutateOwner((current) => {
        if (
          !current ||
          !ownerMatches(current) ||
          !isCollecting(current) ||
          !current.batch
        )
          return current;
        const live = current.batch.capability_resolution;
        if (
          live?.state !== "requesting" ||
          String(live.request_worker_session_id || "") === WORKER_SESSION_ID
        )
          return current;
        return {
          ...current,
          batch: {
            ...current.batch,
            capability_resolution: {
              state: "complete",
              probe_performed: true,
              profile,
              resolved_at: new Date().toISOString(),
              request_worker_session_id: null,
            },
          },
        };
      });
      resolution = owner?.batch?.capability_resolution || {
        state: "complete",
        profile,
      };
      await diagnostic(
        "CAPABILITY_PROBE_RECOVERY_NO_RETRY",
        {
          owner_kind: ownerKind,
          owner_id: ownerId,
          code: profile.probe_error_code,
        },
        { level: "warning" },
      );
    }

    if (
      !resolution ||
      !["complete", "not_needed"].includes(String(resolution.state || ""))
    ) {
      let probeGranted = false;
      owner = await mutateOwner((current) => {
        if (
          !current ||
          !ownerMatches(current) ||
          !isCollecting(current) ||
          !current.batch
        )
          return current;
        if (current.batch.planning_state === "complete") return current;
        const live = current.batch.capability_resolution;
        if (live?.state === "complete" || live?.state === "not_needed")
          return current;
        if (live?.state === "requesting") return current;
        if (
          Math.max(0, Number(current.batch.next_index || 0)) !== 0 ||
          current.batch.request_state !== "idle"
        )
          return current;
        probeGranted = true;
        return {
          ...current,
          batch: {
            ...current.batch,
            capability_resolution: {
              state: "requesting",
              probe_performed: true,
              request_worker_session_id: WORKER_SESSION_ID,
              started_at: new Date().toISOString(),
              profile: null,
            },
          },
        };
      });
      if (probeGranted) {
        await diagnostic("CAPABILITY_PROBE_STARTED", {
          owner_kind: ownerKind,
          owner_id: ownerId,
          path_alias: "seller_info_internal",
        });
        const profile = await OzonProvider.resolveSellerCapability(
          settingsForPlanning.sellerCredentials,
          executionContext,
        );
        let stored = false;
        owner = await mutateOwner((current) => {
          if (
            !current ||
            !ownerMatches(current) ||
            !isCollecting(current) ||
            !current.batch
          )
            return current;
          const live = current.batch.capability_resolution;
          if (
            live?.state !== "requesting" ||
            live?.request_worker_session_id !== WORKER_SESSION_ID
          )
            return current;
          stored = true;
          return {
            ...current,
            batch: {
              ...current.batch,
              capability_resolution: {
                state: "complete",
                probe_performed: true,
                profile,
                resolved_at: new Date().toISOString(),
                request_worker_session_id: null,
              },
            },
          };
        });
        if (!stored) {
          await failOwner(
            "CAPABILITY_PROBE_STORE_RACE",
            "Capability probe завершился, но durable batch state изменился; business requests запрещены.",
          );
          return { ok: false, code: "CAPABILITY_PROBE_STORE_RACE" };
        }
        await diagnostic(
          "CAPABILITY_PROBE_FINISHED",
          {
            owner_kind: ownerKind,
            owner_id: ownerId,
            status: profile.status,
            subscription_type: profile.subscription_type,
            http_status: profile.probe_http_status,
            error_code: profile.probe_error_code,
          },
          { level: profile.status === "known" ? "info" : "warning" },
        );
        resolution = owner.batch.capability_resolution;
      } else {
        owner = await getOwner();
        resolution = owner?.batch?.capability_resolution || null;
        if (
          resolution?.state === "requesting" &&
          resolution.request_worker_session_id === WORKER_SESSION_ID
        )
          return { ok: true, code: "CAPABILITY_PROBE_IN_PROGRESS", owner };
        if (
          !resolution ||
          !["complete", "not_needed"].includes(String(resolution.state || ""))
        )
          return { ok: false, code: "CAPABILITY_PROBE_NOT_READY" };
      }
    }
  }

  owner = await getOwner();
  if (!owner || !ownerMatches(owner) || !isCollecting(owner) || !owner.batch)
    return { ok: false, code: "BATCH_OWNER_NOT_ACTIVE" };
  if (owner.batch.planning_state === "complete")
    return { ok: true, code: "BATCH_PLANNING_READY", owner };
  const profile = owner.batch.capability_resolution?.profile || {
    status: "not_needed",
    subscription_type: "UNKNOWN",
    is_premium: null,
    probe_performed: false,
    probe_http_status: 0,
    probe_error_code: null,
  };
  let plannedEntries;
  try {
    plannedEntries = (owner.batch.entries || []).map((entry) => {
      if (!entry || entry.kind !== "command" || !entry.command) return entry;
      const plan = OzonContract.planCommandForSellerCapability(
        entry.command,
        profile,
        planningAtMs,
        entitlementSnapshot,
      );
      if (plan.action === "reject") {
        return {
          ...entry,
          kind: "planning_error",
          status: "pending",
          error: {
            code: String(plan.error?.code || "CAPABILITY_PLANNING_REJECTED"),
            message: String(
              plan.error?.message || "Capability planning rejected command.",
            ),
          },
          execution_command: null,
          planning: plan.planning || null,
        };
      }
      return {
        ...entry,
        execution_command: plan.command,
        planning: plan.planning || null,
      };
    });
  } catch (error) {
    await failOwner(
      error.code || "BATCH_CAPABILITY_PLANNING_FAILED",
      error.message || String(error),
    );
    return {
      ok: false,
      code: error.code || "BATCH_CAPABILITY_PLANNING_FAILED",
    };
  }

  let planningStored = false;
  owner = await mutateOwner((current) => {
    if (
      !current ||
      !ownerMatches(current) ||
      !isCollecting(current) ||
      !current.batch
    )
      return current;
    if (current.batch.planning_state === "complete") return current;
    if (
      Math.max(0, Number(current.batch.next_index || 0)) !== 0 ||
      current.batch.request_state !== "idle"
    )
      return current;
    planningStored = true;
    return {
      ...current,
      batch: {
        ...current.batch,
        entries: plannedEntries,
        planning_state: "complete",
        planning_at_ms: planningAtMs,
        planning_completed_at: new Date().toISOString(),
      },
    };
  });
  if (!planningStored) {
    await failOwner(
      "BATCH_PLANNING_STORE_RACE",
      "Capability plan не удалось сохранить до provider execution; business requests запрещены.",
    );
    return { ok: false, code: "BATCH_PLANNING_STORE_RACE" };
  }
  await diagnostic("BATCH_CAPABILITY_PLANNING_COMPLETED", {
    owner_kind: ownerKind,
    owner_id: ownerId,
    capability_probe_performed:
      owner.batch.capability_resolution?.probe_performed === true,
    capability_status:
      owner.batch.capability_resolution?.profile?.status || "not_needed",
    planned_command_count: plannedEntries.filter(
      (entry) => entry?.kind === "command",
    ).length,
    planning_error_count: plannedEntries.filter(
      (entry) => entry?.kind === "planning_error",
    ).length,
  });
  return { ok: true, code: "BATCH_PLANNING_READY", owner };
}

function safeBatchQueryPlannerSummary(batch, entries = []) {
  const plan = batch?.query_plan && typeof batch.query_plan === "object" ? batch.query_plan : {};
  const groups = Array.isArray(plan.groups) ? plan.groups : [];
  const completed = Array.isArray(entries) ? entries : [];
  const businessEntries = completed.filter((entry) => entry?.external_request_executed === true);
  const physicalIds = new Set();
  for (const entry of businessEntries) {
    const identity = String(entry?.physical_request_id || entry?.request_id || "").trim();
    if (identity) physicalIds.add(identity);
  }
  return {
    status: String(batch?.query_planning_state || "not_planned"),
    coalesced_group_count: groups.length,
    coalesced_logical_count: groups.reduce((total, group) => total + (Array.isArray(group?.member_indexes) ? group.member_indexes.length : 0), 0),
    logical_business_result_count: businessEntries.length,
    physical_business_request_count: physicalIds.size
  };
}

function buildBatchQueryPlan(entries) {
  const source = Array.isArray(entries) ? entries : [];
  const plannedEntries = source.map((entry) => entry && typeof entry === "object" ? { ...entry } : entry);
  const groups = [];
  let index = 0;
  while (index < plannedEntries.length) {
    const first = plannedEntries[index];
    if (!first || first.kind !== "command" || !first.command) {
      index += 1;
      continue;
    }
    const firstExecution = first.execution_command || first.command;
    let firstDescriptor;
    try {
      firstDescriptor = OzonContract.analyticsCoalescingDescriptor(firstExecution);
    } catch (_) {
      index += 1;
      continue;
    }
    if (!firstDescriptor?.eligible) {
      index += 1;
      continue;
    }

    const memberIndexes = [index];
    const executionCommands = [firstExecution];
    const unionMetrics = [...firstDescriptor.metrics];
    const seenMetrics = new Set(unionMetrics);
    let cursor = index + 1;
    while (cursor < plannedEntries.length) {
      const candidate = plannedEntries[cursor];
      if (!candidate || candidate.kind !== "command" || !candidate.command) break;
      const candidateExecution = candidate.execution_command || candidate.command;
      let descriptor;
      try {
        descriptor = OzonContract.analyticsCoalescingDescriptor(candidateExecution);
      } catch (_) {
        break;
      }
      if (!descriptor?.eligible || descriptor.compatibility_key !== firstDescriptor.compatibility_key) break;
      const nextUnion = [...unionMetrics];
      const nextSeen = new Set(seenMetrics);
      for (const metric of descriptor.metrics) {
        if (!nextSeen.has(metric)) {
          nextSeen.add(metric);
          nextUnion.push(metric);
        }
      }
      if (nextUnion.length > 14) break;
      memberIndexes.push(cursor);
      executionCommands.push(candidateExecution);
      unionMetrics.splice(0, unionMetrics.length, ...nextUnion);
      seenMetrics.clear();
      for (const metric of nextSeen) seenMetrics.add(metric);
      cursor += 1;
    }

    if (memberIndexes.length < 2) {
      index += 1;
      continue;
    }

    const physical = OzonContract.buildAnalyticsCoalescedCommand(executionCommands);
    const physicalFingerprint = OzonContract.commandFingerprint(physical.command);
    const groupId = `analytics-${memberIndexes[0]}-${physical.compatibility_fingerprint}-${physicalFingerprint}`;
    const group = {
      group_id: groupId,
      operation: "analytics_data",
      leader_index: memberIndexes[0],
      member_indexes: [...memberIndexes],
      physical_command: physical.command,
      physical_command_fingerprint: physicalFingerprint,
      physical_metrics: [...physical.metrics],
      compatibility_fingerprint: physical.compatibility_fingerprint
    };
    groups.push(group);
    for (const memberIndex of memberIndexes) {
      plannedEntries[memberIndex] = {
        ...plannedEntries[memberIndex],
        query_group_id: groupId,
        query_group_leader_index: memberIndexes[0]
      };
    }
    index = cursor;
  }
  return Object.freeze({
    version: 1,
    strategy: "contiguous_analytics_metric_union",
    groups: groups.map((group) => Object.freeze({ ...group, member_indexes: Object.freeze([...group.member_indexes]), physical_metrics: Object.freeze([...group.physical_metrics]) })),
    entries: plannedEntries
  });
}

async function ensureBatchQueryPlanning({ ownerKind, ownerId, getOwner, mutateOwner, ownerMatches, isCollecting, failOwner }) {
  let owner = await getOwner();
  if (!owner || !ownerMatches(owner)) return { ok: false, code: "BATCH_OWNER_NOT_ACTIVE" };
  if (!isCollecting(owner) || !owner.batch) return { ok: true, code: "BATCH_NOT_COLLECTING", owner };
  if (owner.batch.query_planning_state === "complete") return { ok: true, code: "BATCH_QUERY_PLANNING_READY", owner };
  if (owner.batch.planning_state !== "complete") {
    await failOwner("BATCH_QUERY_PLANNING_BEFORE_CAPABILITY", "Query planning запрещён до завершения Step 1 capability/entitlement planning.");
    return { ok: false, code: "BATCH_QUERY_PLANNING_BEFORE_CAPABILITY" };
  }
  const entries = Array.isArray(owner.batch.entries) ? owner.batch.entries : [];
  const nextIndex = Math.max(0, Number(owner.batch.next_index || 0));
  if (nextIndex > 0 || entries.some((entry) => entry?.status === "requesting" || entry?.status === "complete")) {
    await failOwner("BATCH_QUERY_PLANNING_MIGRATION_UNSAFE", "Batch уже начал business execution без Step 2 query plan; новые provider requests запрещены.");
    return { ok: false, code: "BATCH_QUERY_PLANNING_MIGRATION_UNSAFE" };
  }

  let queryPlan;
  try {
    queryPlan = buildBatchQueryPlan(entries);
  } catch (error) {
    await failOwner(error.code || "BATCH_QUERY_PLANNING_FAILED", error.message || String(error));
    return { ok: false, code: error.code || "BATCH_QUERY_PLANNING_FAILED" };
  }

  let stored = false;
  owner = await mutateOwner((current) => {
    if (!current || !ownerMatches(current) || !isCollecting(current) || !current.batch) return current;
    if (current.batch.query_planning_state === "complete") return current;
    if (current.batch.planning_state !== "complete") return current;
    if (Math.max(0, Number(current.batch.next_index || 0)) !== 0 || current.batch.request_state !== "idle") return current;
    if ((current.batch.entries || []).some((entry) => entry?.status === "requesting" || entry?.status === "complete")) return current;
    stored = true;
    return {
      ...current,
      batch: {
        ...current.batch,
        entries: queryPlan.entries,
        query_planning_state: "complete",
        query_plan: {
          version: queryPlan.version,
          strategy: queryPlan.strategy,
          groups: queryPlan.groups,
          completed_at: new Date().toISOString()
        }
      }
    };
  });
  if (!stored) {
    owner = await getOwner();
    if (owner?.batch?.query_planning_state === "complete") return { ok: true, code: "BATCH_QUERY_PLANNING_READY", owner };
    await failOwner("BATCH_QUERY_PLANNING_STORE_RACE", "Query plan не удалось сохранить до provider execution; business requests запрещены.");
    return { ok: false, code: "BATCH_QUERY_PLANNING_STORE_RACE" };
  }
  await diagnostic("BATCH_QUERY_PLANNING_COMPLETED", {
    owner_kind: ownerKind,
    owner_id: ownerId,
    coalesced_group_count: queryPlan.groups.length,
    coalesced_logical_count: queryPlan.groups.reduce((total, group) => total + group.member_indexes.length, 0)
  });
  return { ok: true, code: "BATCH_QUERY_PLANNING_READY", owner };
}

function findBatchQueryGroup(batch, groupId) {
  const groups = Array.isArray(batch?.query_plan?.groups) ? batch.query_plan.groups : [];
  return groups.find((group) => String(group?.group_id || "") === String(groupId || "")) || null;
}

function coalescedPlanningForEntry(entry, group, physicalRequestId, physicalFingerprint, cacheMeta = null) {
  const base = entry?.planning && typeof entry.planning === "object" ? entry.planning : {};
  const logicalFingerprint = String(entry?.command_fingerprint || OzonContract.commandFingerprint(entry?.command));
  const withCache = cachePlanning(base, cacheMeta);
  return {
    ...withCache,
    execution: {
      ...(withCache.execution && typeof withCache.execution === "object" ? withCache.execution : {}),
      logical_command_fingerprint: logicalFingerprint,
      physical_command_fingerprint: String(physicalFingerprint || group?.physical_command_fingerprint || ""),
      command_transformed: logicalFingerprint !== String(physicalFingerprint || group?.physical_command_fingerprint || ""),
      coalesced: true,
      physical_request_id: physicalRequestId ? String(physicalRequestId) : null,
      coalescing_group_id: String(group?.group_id || ""),
      coalesced_logical_count: Array.isArray(group?.member_indexes) ? group.member_indexes.length : 0,
      physical_metrics: Array.isArray(group?.physical_metrics) ? [...group.physical_metrics] : [],
      projected_metrics: Array.isArray(entry?.execution_command?.params?.metrics) ? [...entry.execution_command.params.metrics] : (Array.isArray(entry?.command?.params?.metrics) ? [...entry.command.params.metrics] : [])
    }
  };
}

function buildCoalescedLogicalResult(entry, group, physicalResult, projectionError = null) {
  const command = OzonContract.normalizeCommand(entry.command);
  const preflight = OzonContract.preflightExecution(command);
  const physicalRequestId = physicalResult?.request_id || physicalResult?.physical_attempt_id || null;
  const physicalFingerprint = physicalResult?.executed_command_fingerprint || group?.physical_command_fingerprint || null;
  const planning = coalescedPlanningForEntry(entry, group, physicalRequestId, physicalFingerprint, physicalResult?.cache || null);
  const requestId = `logical-${crypto.randomUUID()}`;
  const externalRequestExecuted = physicalResult?.external_request_executed !== false;
  let resultPayload;
  let bridgeError = false;
  let safeError = null;
  if (projectionError) {
    safeError = OzonContract.safeBridgeErrorPayload(projectionError, Number(physicalResult?.http_status || 0));
    resultPayload = { error: { ...safeError, stage: "query_projection", external_request_executed: externalRequestExecuted } };
    bridgeError = true;
  } else if (physicalResult?.ok === true) {
    const logicalMetrics = Array.isArray(entry?.execution_command?.params?.metrics) ? entry.execution_command.params.metrics : entry.command.params.metrics;
    resultPayload = OzonContract.projectAnalyticsDataResult(physicalResult.result, group.physical_metrics, logicalMetrics);
  } else {
    resultPayload = physicalResult?.result && typeof physicalResult.result === "object"
      ? physicalResult.result
      : { error: OzonContract.safeBridgeErrorPayload(Object.assign(new Error("Coalesced provider request failed without a safe result payload."), { code: "COALESCED_PROVIDER_RESULT_MISSING" }), Number(physicalResult?.http_status || 0)) };
  }
  const reportText = OzonContract.formatResultReport({
    requestId,
    command,
    requestMeta: {
      host_alias: String(physicalResult?.provider || preflight.meta.provider || "seller_api"),
      http_method: preflight.meta.method,
      path_alias: command.operation,
      external_request_executed: externalRequestExecuted,
      capability_probe_executed: planning?.capability?.probe_performed === true,
      capability_probe_http_status: Number(planning?.capability?.probe_http_status || 0),
      physical_request_id: physicalRequestId,
      physical_command_fingerprint: physicalFingerprint,
      coalescing_group_id: group.group_id,
      coalesced_logical_count: group.member_indexes.length
    },
    httpStatus: Number(physicalResult?.http_status || 0),
    result: resultPayload,
    elapsedMs: Number(physicalResult?.elapsed_ms || 0),
    pagination: null,
    rateLimit: physicalResult?.rate_limit || null,
    planning
  });
  return Object.freeze({
    ok: projectionError ? false : physicalResult?.ok === true,
    bridge_error: bridgeError,
    request_id: requestId,
    physical_request_id: physicalRequestId,
    operation: command.operation,
    command_fingerprint: String(entry.command_fingerprint || OzonContract.commandFingerprint(command)),
    executed_command_fingerprint: physicalFingerprint,
    http_status: Number(physicalResult?.http_status || 0),
    report_text: reportText,
    error: safeError,
    external_request_executed: externalRequestExecuted
  });
}

function buildCoalescedExecutionErrorResult(entry, group, error, elapsedMs = 0, physicalAttemptId = null) {
  const command = OzonContract.normalizeCommand(entry.command);
  const preflight = OzonContract.preflightExecution(command);
  const safe = OzonContract.safeBridgeErrorPayload(error, Number(error?.http_status || 0));
  const physicalFingerprint = group?.physical_command_fingerprint || null;
  const planning = coalescedPlanningForEntry(entry, group, physicalAttemptId, physicalFingerprint);
  const requestId = `logical-${crypto.randomUUID()}`;
  const reportText = OzonContract.formatResultReport({
    requestId,
    command,
    requestMeta: {
      host_alias: String(preflight.meta.provider || "seller_api"),
      http_method: preflight.meta.method,
      path_alias: command.operation,
      external_request_executed: safe.external_request_executed === true,
      capability_probe_executed: planning?.capability?.probe_performed === true,
      capability_probe_http_status: Number(planning?.capability?.probe_http_status || 0),
      physical_request_id: physicalAttemptId,
      physical_command_fingerprint: physicalFingerprint,
      coalescing_group_id: group.group_id,
      coalesced_logical_count: group.member_indexes.length
    },
    httpStatus: Number(safe.http_status || 0),
    result: { error: { ...safe, external_request_executed: safe.external_request_executed === true } },
    elapsedMs: Math.max(0, Number(elapsedMs || 0)),
    pagination: null,
    rateLimit: error?.rate_limit || null,
    planning
  });
  return Object.freeze({
    ok: false,
    bridge_error: true,
    request_id: requestId,
    physical_request_id: physicalAttemptId,
    operation: command.operation,
    command_fingerprint: String(entry.command_fingerprint || OzonContract.commandFingerprint(command)),
    executed_command_fingerprint: physicalFingerprint,
    http_status: Number(safe.http_status || 0),
    report_text: reportText,
    error: safe,
    external_request_executed: safe.external_request_executed === true
  });
}

function buildCachedSingleResult(entry, cacheHit) {
  const command = OzonContract.normalizeCommand(entry.command);
  const executionCommand = OzonContract.normalizeCommand(entry.execution_command || entry.command);
  const preflight = OzonContract.preflightExecution(command);
  const cacheMeta = safeAnalyticsCacheMetadata(cacheHit?.cache);
  const planning = cachePlanning(entry.planning || null, cacheMeta);
  const requestId = `cache-${crypto.randomUUID()}`;
  const executionFingerprint = OzonContract.commandFingerprint(executionCommand);
  const reportText = OzonContract.formatResultReport({
    requestId,
    command,
    requestMeta: {
      host_alias: String(preflight.meta.provider || "seller_api"),
      http_method: preflight.meta.method,
      path_alias: command.operation,
      external_request_executed: false,
      capability_probe_executed: planning?.capability?.probe_performed === true,
      capability_probe_http_status: Number(planning?.capability?.probe_http_status || 0),
      physical_command_fingerprint: executionFingerprint
    },
    httpStatus: Number(cacheHit?.http_status || 200),
    result: cacheHit.result,
    elapsedMs: 0,
    pagination: null,
    rateLimit: null,
    planning
  });
  return Object.freeze({
    ok: true,
    cache_hit: true,
    request_id: requestId,
    physical_request_id: null,
    operation: command.operation,
    command_fingerprint: String(entry.command_fingerprint || OzonContract.commandFingerprint(command)),
    executed_command_fingerprint: executionFingerprint,
    http_status: Number(cacheHit?.http_status || 200),
    report_text: reportText,
    result: cacheHit.result,
    external_request_executed: false,
    cache: cacheMeta
  });
}

function projectPrefetchedSingleResult(entry, providerResult, profile) {
  if (providerResult?.ok !== true || !profile?.applicable) return providerResult;
  const executionCommand = OzonContract.normalizeCommand(entry.execution_command || entry.command);
  const requestedMetrics = Array.isArray(executionCommand.params?.metrics) ? executionCommand.params.metrics : [];
  const physicalMetrics = Array.isArray(profile.physical_metrics) ? profile.physical_metrics : requestedMetrics;
  const projected = OzonContract.projectAnalyticsDataResult(providerResult.result, physicalMetrics, requestedMetrics);
  const command = OzonContract.normalizeCommand(entry.command);
  const preflight = OzonContract.preflightExecution(command);
  const planning = acquisitionPlanning(entry.planning || null, profile);
  const reportText = OzonContract.formatResultReport({
    requestId: providerResult.request_id,
    command,
    requestMeta: {
      host_alias: String(providerResult.provider || preflight.meta.provider || "seller_api"),
      http_method: preflight.meta.method,
      path_alias: command.operation,
      external_request_executed: true,
      capability_probe_executed: planning?.capability?.probe_performed === true,
      capability_probe_http_status: Number(planning?.capability?.probe_http_status || 0),
      physical_request_id: providerResult.request_id || null,
      physical_command_fingerprint: providerResult.executed_command_fingerprint || OzonContract.commandFingerprint(profile.command)
    },
    httpStatus: Number(providerResult.http_status || 0),
    result: projected,
    elapsedMs: Number(providerResult.elapsed_ms || 0),
    pagination: null,
    rateLimit: providerResult.rate_limit || null,
    planning
  });
  return Object.freeze({
    ...providerResult,
    report_text: reportText,
    result: projected,
    external_request_executed: true,
    acquisition_profile: profile.profile_id || null
  });
}

async function persistBatchQuotaWait({ ownerKind, ownerId, nextIndex, quota, mutateOwner, ownerMatches, isCollecting, groupId = null }) {
  let stored = false;
  const safe = safeQuotaMetadata(quota);
  await mutateOwner((current) => {
    if (!current || !ownerMatches(current) || !isCollecting(current) || !current.batch) return current;
    if (Number(current.batch.next_index || 0) !== Number(nextIndex)) return current;
    if (current.batch.request_state === "requesting") return current;
    stored = true;
    return {
      ...current,
      batch: {
        ...current.batch,
        request_state: "quota_waiting",
        request_worker_session_id: null,
        quota_wait: {
          ...safe,
          owner_kind: String(ownerKind || "batch"),
          owner_id: String(ownerId || "").slice(0, 200),
          queue_index: Number(nextIndex),
          coalescing_group_id: groupId ? String(groupId).slice(0, 120) : null,
          waiting_since: new Date().toISOString()
        }
      }
    };
  });
  if (stored) {
    await diagnostic("PROVIDER_QUOTA_WAITING", {
      owner_kind: ownerKind,
      owner_id: ownerId,
      queue_index: Number(nextIndex),
      quota_family: safe?.family || null,
      next_allowed_at: Number(safe?.next_allowed_at || 0),
      min_interval_ms: Number(safe?.min_interval_ms || 0),
      credential_scope_id: safe?.credential_scope_id || null
    });
    scheduleProviderQuotaWake(Number(safe?.next_allowed_at || Date.now() + 1000));
  }
  return stored;
}

function processBatchQueue(options) {
  return runComposedBatchQueue(options);
}

async function failManualBatch(conversationKey, operationId, code, message) {
  const key = normalizeConversationKey(conversationKey);
  const operation = await mutateManualOperation(key, (current) => {
    if (!current || current.operation_id !== operationId) return current;
    return {
      ...current,
      status: MANUAL_OPERATION_STATUSES.FAILED,
      request_worker_session_id: null,
      completed_at: new Date().toISOString(),
      last_error: { code: String(code || "MANUAL_BATCH_ERROR"), message: String(message || "Manual batch error"), at: new Date().toISOString() }
    };
  });
  await diagnostic("MANUAL_BATCH_FAILED", { operation_id: operationId, code: String(code || "MANUAL_BATCH_ERROR") }, { level: "error" });
  return operation;
}

async function finalizeAutoBatch(conversationKey, runId, entries, batchSnapshot = null) {
  const key = normalizeConversationKey(conversationKey);
  const combinedReport = formatCombinedBatchReport(entries, batchSnapshot);
  const prefixed = await applyPrefixToReport(key, combinedReport);
  const deliveryId = `delivery-${crypto.randomUUID()}`;
  let claimed = false;
  const run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId || current.status !== BridgeAutorunModel.RUN_STATUSES.COLLECTING || !current.batch) return current;
    const currentEntries = Array.isArray(current.batch.entries) ? current.batch.entries : [];
    if (Math.max(0, Number(current.batch.next_index || 0)) < currentEntries.length) return current;
    if (currentEntries.some((entry) => entry?.status !== "complete")) return current;
    claimed = true;
    const next = BridgeAutorunModel.claimDelivery(current, {
      deliveryId,
      requestId: "",
      outgoingText: prefixed.outgoing_text,
      outgoingHash: "",
      reportPrefixApplied: prefixed.report_prefix_applied === true,
      mode: "batch_watch_v1"
    });
    next.batch = {
      ...current.batch,
      phase: "collected",
      request_state: "idle",
      request_worker_session_id: null,
      combined_report_ready: true,
      collected_at: new Date().toISOString()
    };
    return next;
  });
  if (!claimed) return { ok: false, code: "BATCH_FINALIZE_RACE" };
  await diagnostic("BATCH_COLLECTION_COMPLETED", { owner_kind: "autorun", owner_id: runId, result_count: entries.length, delivery_id: deliveryId, report_prefix_applied: prefixed.report_prefix_applied === true });
  void attemptAutoDelivery(key, runId);
  return { ok: true, collected: true, result_count: entries.length, delivery_id: deliveryId };
}

async function finalizeManualBatch(
  conversationKey,
  operationId,
  entries,
  batchSnapshot = null,
) {
  const key = normalizeConversationKey(conversationKey);
  await assertManualBatchContext(key, operationId);
  const owner = await getManualOperation(key);
  entries = await saPrepareDelivery(entries, owner);
  const combinedReport = owner?.execution_context && await saEnabled() ? saCombinedReport(entries, owner) : formatCombinedBatchReport(entries, batchSnapshot);
  const prefixed = await saEnabled() ? { outgoing_text: combinedReport, report_prefix_applied: false } : await applyPrefixToReport(key, combinedReport);
  const deliveryId = `manual-delivery-${crypto.randomUUID()}`;
  await assertManualBatchContext(key, operationId);
  let claimed = false;
  const operation = await mutateManualOperation(key, (current) => {
    if (
      !current ||
      current.operation_id !== operationId ||
      current.status !== MANUAL_OPERATION_STATUSES.REQUESTING ||
      !current.batch
    )
      return current;
    const currentEntries = Array.isArray(current.batch.entries)
      ? current.batch.entries
      : [];
    if (
      Math.max(0, Number(current.batch.next_index || 0)) < currentEntries.length
    )
      return current;
    if (currentEntries.some((entry) => entry?.status !== "complete"))
      return current;
    claimed = true;
    const next = BridgeAutorunModel.claimDelivery({ ...current, batch: { ...current.batch, entries } }, {
      deliveryId,
      requestId: "",
      outgoingText: prefixed.outgoing_text,
      outgoingHash: "",
      reportPrefixApplied: prefixed.report_prefix_applied === true,
      mode: "batch_watch_v1",
    });
    next.delivery.payload_expires_at_ms = current.payload_expires_at_ms;
    next.delivery.marketplace = current.execution_context?.marketplace;
    next.delivery_id = deliveryId;
    next.outgoing_text = prefixed.outgoing_text;
    next.report_prefix_applied = prefixed.report_prefix_applied === true;
    next.request_worker_session_id = null;
    next.batch = {
      ...current.batch,
      entries,
      phase: "collected",
      request_state: "idle",
      request_worker_session_id: null,
      combined_report_ready: true,
      collected_at: new Date().toISOString(),
    };
    return next;
  });
  if (!claimed) return { ok: false, code: "BATCH_FINALIZE_RACE" };
  await diagnostic("BATCH_COLLECTION_COMPLETED", {
    owner_kind: "manual",
    owner_id: operationId,
    result_count: entries.length,
    delivery_id: deliveryId,
    report_prefix_applied: prefixed.report_prefix_applied === true,
  });
  void attemptManualBatchDelivery(key, operationId);
  return {
    ok: true,
    collected: true,
    result_count: entries.length,
    delivery_id: deliveryId,
    operation,
  };
}

function launchBatchProcessor(ownerKind, conversationKey, ownerId, source = "batch_launch") {
  if (ownerKind === "autorun") return { ok: false, code: "CLIENT_AUTORUN_REMOVED" };
  const kind = String(ownerKind || "");
  return Promise.resolve().then(() => {
    if (kind === "manual") return processManualBatch(conversationKey, ownerId);
    if (kind === "autorun") return processAutoBatch(conversationKey, ownerId);
    throw Object.assign(new Error("Неизвестный тип batch owner."), { code: "BATCH_OWNER_KIND_INVALID" });
  }).catch(async (error) => {
    const safe = OzonContract.safeBridgeErrorPayload(error, Number(error?.http_status || 0));
    const code = String(safe?.code || "BATCH_PROCESSOR_FAILED");
    const message = String(safe?.message || "Batch processor failed.");
    await diagnostic("BATCH_PROCESSOR_UNCAUGHT", {
      owner_kind: kind || null,
      owner_id: String(ownerId || ""),
      code,
      source: String(source || "batch_launch")
    }, { level: "error" }).catch(() => null);
    try {
      if (kind === "manual") await failManualBatch(conversationKey, ownerId, code, message);
      else if (kind === "autorun") await markRunError(normalizeConversationKey(conversationKey), code, message);
    } catch (_) {}
    return { ok: false, code, owner_kind: kind || null, owner_id: String(ownerId || "") };
  });
}

function processAutoBatch(conversationKey, runId) {
  const key = normalizeConversationKey(conversationKey);
  return processBatchQueue({
    conversationKey: key,
    ownerKind: "autorun",
    ownerId: runId,
    getOwner: () => getAutoRun(key),
    mutateOwner: (mutator) => mutateAutoRun(key, mutator),
    ownerMatches: (current) => Boolean(current && current.run_id === runId),
    isCollecting: (current) => Boolean(current && current.status === BridgeAutorunModel.RUN_STATUSES.COLLECTING && current.batch),
    failOwner: (code, message) => markRunError(key, code, message),
    finalizeOwner: (owner, entries) => finalizeAutoBatch(key, runId, entries, owner?.batch || null)
  });
}

function processManualBatch(conversationKey, operationId) {
  const key = normalizeConversationKey(conversationKey);
  return processBatchQueue({
    conversationKey: key,
    ownerKind: "manual",
    ownerId: operationId,
    getOwner: () => getManualOperation(key),
    mutateOwner: (mutator) => mutateManualOperation(key, mutator),
    ownerMatches: (current) => Boolean(current && current.operation_id === operationId),
    isCollecting: (current) => Boolean(current && current.status === MANUAL_OPERATION_STATUSES.REQUESTING && current.batch),
    failOwner: (code, message) => failManualBatch(key, operationId, code, message),
    finalizeOwner: (owner, entries) => finalizeManualBatch(key, operationId, entries, owner?.batch || null)
  });
}

async function handleAutoMessage(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const runId = String(message.run_id || "");
  const assistantTurnId = String(message.assistant_turn_id || "");
  const assistantText = String(message.assistant_text || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  const currentRun = await getAutoRun(key);
  if (!currentRun || currentRun.run_id !== runId) return { ok: false, accepted: false, code: "AUTO_RUN_NOT_FOUND", error: "Autorun не найден." };
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(currentRun.tab_id)) {
    return { ok: false, accepted: false, code: "AUTO_NON_OWNER_TAB", error: "Assistant message появился не во вкладке-owner активного autorun." };
  }
  try {
    await assertTabConversation(senderTabId, key, currentRun.conversation_id);
    await assertRunBinding(currentRun);
  } catch (error) { return { ok: false, accepted: false, code: error.code || "CONVERSATION_MISMATCH", error: error.message }; }
  if (await getManualMode(key)) return { ok: false, paused: true, code: "MANUAL_MODE_ACTIVE", error: "Ручной режим включён; autorun не выполняет команды." };
  if (currentRun.status !== BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) return { ok: true, accepted: false, ignored: true, status: currentRun.status };
  if (assistantTurnId && currentRun.last_assistant_turn_id === assistantTurnId) return { ok: true, accepted: false, ignored: true, status: currentRun.status };

  let entries;
  try { entries = discoverBatchEntries(assistantText); }
  catch (error) {
    return await handleAutoPreExecutionError({
      ...message,
      error_stage: "assistant_message_discovery",
      error_code: error.code || "COMMAND_DISCOVERY_FAILED",
      error_message: error.message || String(error),
      command_fingerprint: OzonContract.textFingerprint(assistantText)
    }, sender);
  }
  if (!entries.length) return { ok: true, accepted: false, ignored: true, code: "NO_OZON_COMMANDS", status: currentRun.status };
  const guidanceOnly = entries.every((entry) => entry?.kind !== "command");
  const nextGuidanceRound = guidanceOnly ? Number(currentRun.guidance_rounds || 0) + 1 : 0;
  const guidanceLimitReached = guidanceOnly && nextGuidanceRound >= 5;
  if (guidanceLimitReached) entries = [{ kind: "guidance", status: "pending", guidance: { status: "guidance_error", cluster: null, error: "GUIDANCE_ROUND_LIMIT" }, request_id: null, http_status: 0, external_request_executed: false, report_text: null }];

  const messageFingerprint = OzonContract.textFingerprint(assistantText);
  let collectionGranted = false;
  const run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId || current.status !== BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) return current;
    if (assistantTurnId && current.last_assistant_turn_id === assistantTurnId) return current;
    collectionGranted = true;
    return {
      ...current,
      status: BridgeAutorunModel.RUN_STATUSES.COLLECTING,
      last_assistant_turn_id: assistantTurnId || null,
      last_command_fingerprint: messageFingerprint,
      last_operation: null,
      last_command_summary: `${entries.length} queued OZON_API_V1 item(s)`,
      last_error: null,
      guidance_rounds: nextGuidanceRound,
      pause_after_guidance_limit: guidanceLimitReached,
      batch: {
        phase: "collecting",
        assistant_turn_id: assistantTurnId || null,
        entries,
        next_index: 0,
        request_state: "idle",
        request_worker_session_id: null,
        planning_state: "pending",
        capability_resolution: null,
        query_planning_state: "pending",
        query_plan: null,
        quota_wait: null,
        request_quota: null,
        created_at: new Date().toISOString()
      }
    };
  });
  if (!collectionGranted) return { ok: true, accepted: false, ignored: true, status: run?.status || null };

  await diagnostic("BATCH_ACCEPTED", {
    run_id: runId,
    tab_id: senderTabId,
    assistant_turn_id: assistantTurnId || null,
    item_count: entries.length,
    command_count: entries.filter((entry) => entry.kind === "command").length,
    pre_execution_error_count: entries.filter((entry) => entry.kind !== "command").length,
    message_fingerprint: messageFingerprint
  });
  if (guidanceLimitReached) await diagnostic("GUIDANCE_ROUND_LIMIT", { run_id: runId, guidance_rounds: nextGuidanceRound, external_request_executed: false }, { level: "warning" });
  launchBatchProcessor("autorun", key, runId, "autorun_admission");
  return {
    ok: true,
    accepted: true,
    run_id: runId,
    item_count: entries.length,
    command_count: entries.filter((entry) => entry.kind === "command").length,
    pre_execution_error_count: entries.filter((entry) => entry.kind !== "command").length
  };
}

function attemptAutoDelivery(conversationKey, runId) {
  const key = normalizeConversationKey(conversationKey);
  return singleFlight(deliveryAttemptRequests, String(runId || ""), async () => {
    const run = await getAutoRun(key);
    if (!run || BridgeAutorunModel.isTerminalStatus(run.status)) return { ok: false, code: "AUTO_RUN_NOT_ACTIVE" };
    if (run.status !== BridgeAutorunModel.RUN_STATUSES.DELIVERING || !run.delivery) return { ok: false, code: "AUTO_RUN_NOT_DELIVERING" };
    const phase = run.delivery.phase;
    let recoveryType = null;
    if (run.delivery.mode === "batch_watch_v1") {
      if (phase === BridgeAutorunModel.DELIVERY_PHASES.CLAIMED) recoveryType = "deliver_claimed";
      else if (phase === BridgeAutorunModel.DELIVERY_PHASES.INSERTED) recoveryType = "watch_delivery";
      else if (phase === BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED) return { ok: false, code: "DELIVERY_INSERT_OUTCOME_UNKNOWN_NO_RETRY" };
    } else {
      if (phase === BridgeAutorunModel.DELIVERY_PHASES.CLAIMED) recoveryType = "deliver_claimed";
      else if (phase === BridgeAutorunModel.DELIVERY_PHASES.COMMITTED) recoveryType = "reconcile_delivery";
    }
    if (!recoveryType) return { ok: false, code: "AUTO_DELIVERY_NOT_ACTIONABLE" };
    const recovery = deliveryRecoveryPayload(run, recoveryType);
    const pushType = run.delivery.mode === "batch_watch_v1" ? "OZ_BATCH_DELIVERY_AVAILABLE" : "OZ_AUTO_DELIVERY_AVAILABLE";
    const push = await tabMessage(Number(run.tab_id), { type: pushType, recovery });
    await diagnostic("DELIVERY_PUSH_RESPONSE", {
      run_id: run.run_id,
      delivery_id: run.delivery.delivery_id,
      delivery_mode: run.delivery.mode || "legacy",
      phase,
      recovery_type: recoveryType,
      ok: push?.ok === true,
      code: push?.code || null
    }, { level: push?.ok === true ? "info" : "warning" });
    return push;
  });
}

function attemptManualBatchDelivery(conversationKey, operationId) {
  const key = normalizeConversationKey(conversationKey);
  return singleFlight(
    deliveryAttemptRequests,
    `manual:${String(operationId || "")}`,
    async () => {
      const operation = await getManualOperation(key);
      if (
        !operation ||
        operation.operation_id !== operationId ||
        operation.status !== MANUAL_OPERATION_STATUSES.DELIVERING ||
        operation.delivery?.mode !== "batch_watch_v1"
      ) {
        return { ok: false, code: "MANUAL_BATCH_NOT_DELIVERING" };
      }
      await assertManualBatchContext(key, operationId);
      let recoveryType = null;
      if (
        operation.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.CLAIMED
      )
        recoveryType = "deliver_claimed";
      else if (
        operation.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERTED
      )
        recoveryType = "watch_delivery";
      else if (
        operation.delivery.phase ===
        BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED
      )
        return { ok: false, code: "DELIVERY_INSERT_OUTCOME_UNKNOWN_NO_RETRY" };
      if (!recoveryType)
        return { ok: false, code: "MANUAL_BATCH_DELIVERY_NOT_ACTIONABLE" };
      const recovery = manualBatchRecoveryPayload(operation, recoveryType);
      const push = await tabMessage(Number(operation.tab_id), {
        type: "OZ_BATCH_DELIVERY_AVAILABLE",
        recovery,
      });
      await diagnostic(
        "DELIVERY_PUSH_RESPONSE",
        {
          owner_kind: "manual",
          owner_id: operationId,
          delivery_id: operation.delivery.delivery_id,
          delivery_mode: "batch_watch_v1",
          phase: operation.delivery.phase,
          recovery_type: recoveryType,
          ok: push?.ok === true,
          code: push?.code || null,
        },
        { level: push?.ok === true ? "info" : "warning" },
      );
      return push;
    },
  ).catch(async (error) => {
    if (!error?.execution_context_error) throw error;
    const current = await getManualOperation(key);
    if (current?.operation_id === operationId && manualOperationActive(current))
      await failManualBatch(key, operationId, error.code, error.message);
    return { ok: false, code: error.code };
  });
}

async function commitManualBatchDeliveryInsert(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const operationId = String(message.owner_id || message.operation_id || "");
  const deliveryId = String(message.delivery_id || "");
  const actorId = String(message.actor_id || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  let operation = await getManualOperation(key);
  if (
    !operation ||
    operation.operation_id !== operationId ||
    operation.status !== MANUAL_OPERATION_STATUSES.DELIVERING ||
    operation.delivery?.mode !== "batch_watch_v1"
  ) {
    return {
      ok: false,
      committed: false,
      insert_allowed: false,
      code: "MANUAL_DELIVERY_STATE_MISMATCH",
      error: "Manual batch delivery не находится в ожидаемом state.",
    };
  }
  if (
    !Number.isInteger(senderTabId) ||
    senderTabId !== Number(operation.tab_id)
  )
    return {
      ok: false,
      committed: false,
      insert_allowed: false,
      code: "MANUAL_NON_OWNER_TAB",
      error: "Manual batch delivery insert commit пришёл не из owner-вкладки.",
    };
  if (!(await getManualMode(key)))
    return {
      ok: false,
      committed: false,
      insert_allowed: false,
      code: "MANUAL_MODE_DISABLED",
      error:
        "Ручной режим выключен; pending delivery отменена до вставки отчёта.",
    };
  await assertManualBatchContext(key, operationId);
  const liveIdentity = await assertTabConversation(
    senderTabId,
    key,
    operation.conversation_id,
  );
  const binding = await strictBindingForIdentity(liveIdentity);
  if (
    String(operation.binding_snapshot?.binding_id || "") !==
    String(binding.binding_id || "")
  )
    return {
      ok: false,
      committed: false,
      insert_allowed: false,
      code: "MANUAL_BINDING_MISMATCH",
      error: "Manual batch binding изменился.",
    };
  if (operation.delivery?.delivery_id !== deliveryId)
    return {
      ok: false,
      committed: false,
      insert_allowed: false,
      code: "MANUAL_DELIVERY_ID_MISMATCH",
      error: "Delivery ID не совпадает.",
    };
  if (operation.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERTED)
    return {
      ok: true,
      committed: true,
      insert_allowed: false,
      already_inserted: true,
      recovery: manualBatchRecoveryPayload(operation, "watch_delivery"),
    };
  if (
    operation.delivery.phase ===
    BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED
  )
    return {
      ok: true,
      committed: true,
      insert_allowed: false,
      outcome_unknown: true,
      code: "DELIVERY_INSERT_OUTCOME_UNKNOWN_NO_RETRY",
    };
  if (operation.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.CLAIMED)
    return {
      ok: false,
      committed: false,
      insert_allowed: false,
      code: "MANUAL_DELIVERY_NOT_CLAIMED",
      error: "Delivery ещё не готов к insertion commit.",
    };
  await assertManualBatchContext(key, operationId);
  let insertAllowed = false;
  operation = await mutateManualOperation(key, (current) => {
    if (
      !current ||
      current.operation_id !== operationId ||
      current.delivery?.delivery_id !== deliveryId ||
      current.delivery?.mode !== "batch_watch_v1"
    )
      return current;
    if (current.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.CLAIMED)
      return current;
    insertAllowed = true;
    return BridgeAutorunModel.commitDeliveryInsert(current, {
      deliveryId,
      actorId,
      assistantBaselineIds: message.assistant_baseline_ids,
    });
  });
  if (!insertAllowed)
    return {
      ok: true,
      committed: true,
      insert_allowed: false,
      outcome_unknown: true,
      code: "DELIVERY_INSERT_OUTCOME_UNKNOWN_NO_RETRY",
    };
  await diagnostic("DELIVERY_INSERT_COMMITTED", {
    owner_kind: "manual",
    owner_id: operationId,
    delivery_id: deliveryId,
    tab_id: senderTabId,
    actor_id: actorId || null,
  });
  return {
    ok: true,
    committed: true,
    insert_allowed: true,
    operation: publicManualOperation(operation),
  };
}

async function markManualBatchDeliveryInserted(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const operationId = String(message.owner_id || message.operation_id || "");
  const deliveryId = String(message.delivery_id || "");
  const actorId = String(message.actor_id || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  let operation = await getManualOperation(key);
  if (!operation || operation.operation_id !== operationId || operation.status !== MANUAL_OPERATION_STATUSES.DELIVERING || operation.delivery?.mode !== "batch_watch_v1") return { ok: false, inserted: false, code: "MANUAL_DELIVERY_STATE_MISMATCH", error: "Manual batch delivery не находится в expected state." };
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(operation.tab_id)) return { ok: false, inserted: false, code: "MANUAL_NON_OWNER_TAB", error: "Inserted ack пришёл не из owner-вкладки." };
  await assertTabConversation(senderTabId, key, operation.conversation_id);
  if (operation.delivery?.delivery_id !== deliveryId) return { ok: false, inserted: false, code: "MANUAL_DELIVERY_ID_MISMATCH", error: "Delivery ID не совпадает." };
  if (operation.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERTED) return { ok: true, inserted: true, already_inserted: true, recovery: manualBatchRecoveryPayload(operation, "watch_delivery") };
  if (operation.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED) return { ok: false, inserted: false, code: "MANUAL_DELIVERY_INSERT_NOT_COMMITTED", error: "Insertion не committed." };
  if (operation.delivery.commit_actor_id && actorId && operation.delivery.commit_actor_id !== actorId) return { ok: false, inserted: false, code: "MANUAL_DELIVERY_ACTOR_MISMATCH", error: "Inserted ack пришёл от другого content runtime." };
  let inserted = false;
  operation = await mutateManualOperation(key, (current) => {
    if (!current || current.operation_id !== operationId || current.delivery?.delivery_id !== deliveryId || current.delivery?.mode !== "batch_watch_v1") return current;
    if (current.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED) return current;
    const next = BridgeAutorunModel.markDeliveryInserted(current, { deliveryId, actorId });
    inserted = next?.delivery?.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERTED;
    return next;
  });
  if (!inserted) return { ok: false, inserted: false, code: "MANUAL_DELIVERY_INSERT_ACK_RACE", error: "Delivery state изменился до inserted ack." };
  await diagnostic("DELIVERY_INSERTED", { owner_kind: "manual", owner_id: operationId, delivery_id: deliveryId, tab_id: senderTabId });
  return { ok: true, inserted: true, recovery: manualBatchRecoveryPayload(operation, "watch_delivery") };
}

async function completeManualBatchDelivery(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const operationId = String(message.owner_id || message.operation_id || "");
  const deliveryId = String(message.delivery_id || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  let operation = await getManualOperation(key);
  if (!operation || operation.operation_id !== operationId) throw Object.assign(new Error("Batch delivery confirmation не соответствует активной manual operation."), { code: "MANUAL_DELIVERY_STATE_MISMATCH" });
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(operation.tab_id)) throw Object.assign(new Error("Batch delivery confirmation пришёл не из owner-вкладки."), { code: "MANUAL_NON_OWNER_TAB" });
  await assertTabConversation(senderTabId, key, operation.conversation_id);
  if (operation.status === MANUAL_OPERATION_STATUSES.COMPLETED && operation.last_confirmed_delivery_id === deliveryId) return publicManualOperation(operation);
  if (operation.status !== MANUAL_OPERATION_STATUSES.DELIVERING || operation.delivery?.mode !== "batch_watch_v1") throw Object.assign(new Error("Manual operation больше не находится в batch delivery state."), { code: "MANUAL_DELIVERY_STATE_MISMATCH" });
  if (!deliveryId || operation.delivery.delivery_id !== deliveryId) throw Object.assign(new Error("Batch delivery ID не совпадает."), { code: "MANUAL_DELIVERY_ID_MISMATCH" });
  if (operation.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.INSERTED) throw Object.assign(new Error("Delivery confirmation разрешён только после confirmed insertion."), { code: "MANUAL_DELIVERY_NOT_INSERTED" });
  const expectedBasis = expectedDeliveryConfirmationBasis(operation.origin);
  const confirmed = message.delivery_confirmed === true && acceptedDeliveryConfirmationBasis(operation.origin, message.confirmation_basis);
  await diagnostic("DELIVERY_CONFIRMATION_RECEIVED", { owner_kind: "manual", owner_id: operationId, delivery_id: deliveryId, delivery_mode: "batch_watch_v1", delivery_confirmed: confirmed, confirmation_basis: String(message.confirmation_basis || ""), click_attempts: Number(message.click_attempts || 0) }, { level: confirmed ? "info" : "warning" });
  if (!confirmed) return publicManualOperation(operation);
  const prefixApplied = operation.delivery.report_prefix_applied === true;
  await noteConfirmedPrefix(key, prefixApplied, deliveryId);
  let didConfirm = false;
  operation = await mutateManualOperation(key, (current) => {
    if (!current || current.operation_id !== operationId) return current;
    if (current.status === MANUAL_OPERATION_STATUSES.COMPLETED && current.last_confirmed_delivery_id === deliveryId) return current;
    if (current.status !== MANUAL_OPERATION_STATUSES.DELIVERING || current.delivery?.delivery_id !== deliveryId || current.delivery?.mode !== "batch_watch_v1" || current.delivery?.phase !== BridgeAutorunModel.DELIVERY_PHASES.INSERTED) return current;
    didConfirm = true;
    return {
      ...current,
      status: MANUAL_OPERATION_STATUSES.COMPLETED,
      delivery_confirmed: true,
      last_confirmed_delivery_id: deliveryId,
      last_confirmed_report_prefix_applied: prefixApplied,
      click_attempts: Number(message.click_attempts || 0),
      batch: null,
      delivery: null,
      outgoing_text: null,
      request_worker_session_id: null,
      completed_at: new Date().toISOString(),
      last_error: null
    };
  });
  if (!didConfirm && operation?.last_confirmed_delivery_id !== deliveryId) throw Object.assign(new Error("Manual batch delivery state изменился конкурентно до подтверждения."), { code: "MANUAL_DELIVERY_CONFIRM_RACE" });
  if (didConfirm) await diagnostic("DELIVERY_SUCCESS", { owner_kind: "manual", owner_id: operationId, delivery_id: deliveryId, confirmation_basis: String(message.confirmation_basis || expectedBasis) });
  return publicManualOperation(operation);
}

async function failManualBatchDelivery(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const operationId = String(message.owner_id || message.operation_id || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  const operation = await getManualOperation(key);
  if (!operation || operation.operation_id !== operationId) return null;
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(operation.tab_id)) return publicManualOperation(operation);
  const preserved = await mutateManualOperation(key, (current) => {
    if (!current || current.operation_id !== operationId || current.status !== MANUAL_OPERATION_STATUSES.DELIVERING || !current.delivery) return current;
    return { ...current, last_error: { code: String(message.code || "DELIVERY_FAILED"), message: String(message.error || "Не удалось доставить Ozon batch result в текущий AI."), at: new Date().toISOString(), recoverable: true } };
  });
  await diagnostic("DELIVERY_FAILED_BUT_PRESERVED", { owner_kind: "manual", owner_id: operationId, delivery_id: operation.delivery?.delivery_id || null, phase: operation.delivery?.phase || null, code: message.code || "DELIVERY_FAILED" }, { level: "warning" });
  return publicManualOperation(preserved);
}

async function completeBatchDelivery(message, sender) {
  return String(message.owner_kind || "autorun") === "manual"
    ? await completeManualBatchDelivery(message, sender)
    : await completeBatchAutoDelivery({ ...message, run_id: String(message.owner_id || message.run_id || "") }, sender);
}

async function failBatchDelivery(message, sender) {
  return String(message.owner_kind || "autorun") === "manual"
    ? await failManualBatchDelivery(message, sender)
    : await failAutoDelivery({ ...message, run_id: String(message.owner_id || message.run_id || "") }, sender);
}

async function commitBatchDeliveryInsert(message, sender) {
  if (String(message.owner_kind || "autorun") === "manual") return await commitManualBatchDeliveryInsert(message, sender);
  const key = normalizeConversationKey(message.conversation_key);
  const runId = String(message.run_id || "");
  const deliveryId = String(message.delivery_id || "");
  const actorId = String(message.actor_id || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  let run = await getAutoRun(key);
  if (!run || run.run_id !== runId || run.status !== BridgeAutorunModel.RUN_STATUSES.DELIVERING || run.delivery?.mode !== "batch_watch_v1") {
    return { ok: false, committed: false, insert_allowed: false, code: "AUTO_DELIVERY_STATE_MISMATCH", error: "Batch delivery не находится в ожидаемом state." };
  }
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(run.tab_id)) {
    return { ok: false, committed: false, insert_allowed: false, code: "AUTO_NON_OWNER_TAB", error: "Batch delivery insert commit пришёл не из owner-вкладки." };
  }
  await assertTabConversation(senderTabId, key, run.conversation_id);
  await assertRunBinding(run);
  if (run.delivery?.delivery_id !== deliveryId) return { ok: false, committed: false, insert_allowed: false, code: "AUTO_DELIVERY_ID_MISMATCH", error: "Delivery ID не совпадает." };
  if (run.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERTED) {
    return { ok: true, committed: true, insert_allowed: false, already_inserted: true, recovery: deliveryRecoveryPayload(run, "watch_delivery") };
  }
  if (run.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED) {
    return { ok: true, committed: true, insert_allowed: false, outcome_unknown: true, code: "DELIVERY_INSERT_OUTCOME_UNKNOWN_NO_RETRY" };
  }
  if (run.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.CLAIMED) {
    return { ok: false, committed: false, insert_allowed: false, code: "AUTO_DELIVERY_NOT_CLAIMED", error: "Delivery ещё не готов к insertion commit." };
  }
  let insertAllowed = false;
  run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId || current.delivery?.delivery_id !== deliveryId || current.delivery?.mode !== "batch_watch_v1") return current;
    if (current.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.CLAIMED) return current;
    insertAllowed = true;
    return BridgeAutorunModel.commitDeliveryInsert(current, {
      deliveryId,
      actorId,
      assistantBaselineIds: message.assistant_baseline_ids
    });
  });
  if (!insertAllowed) return { ok: true, committed: true, insert_allowed: false, outcome_unknown: true, code: "DELIVERY_INSERT_OUTCOME_UNKNOWN_NO_RETRY" };
  await diagnostic("DELIVERY_INSERT_COMMITTED", { run_id: runId, delivery_id: deliveryId, tab_id: senderTabId, actor_id: actorId || null, assistant_baseline_count: run?.delivery?.baseline_assistant_turn_ids?.length || 0 });
  return { ok: true, committed: true, insert_allowed: true, run: publicRun(run) };
}

async function markBatchDeliveryInserted(message, sender) {
  if (String(message.owner_kind || "autorun") === "manual") return await markManualBatchDeliveryInserted(message, sender);
  const key = normalizeConversationKey(message.conversation_key);
  const runId = String(message.run_id || "");
  const deliveryId = String(message.delivery_id || "");
  const actorId = String(message.actor_id || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  let run = await getAutoRun(key);
  if (!run || run.run_id !== runId || run.status !== BridgeAutorunModel.RUN_STATUSES.DELIVERING || run.delivery?.mode !== "batch_watch_v1") {
    return { ok: false, inserted: false, code: "AUTO_DELIVERY_STATE_MISMATCH", error: "Batch delivery не находится в expected state." };
  }
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(run.tab_id)) return { ok: false, inserted: false, code: "AUTO_NON_OWNER_TAB", error: "Inserted ack пришёл не из owner-вкладки." };
  await assertTabConversation(senderTabId, key, run.conversation_id);
  await assertRunBinding(run);
  if (run.delivery?.delivery_id !== deliveryId) return { ok: false, inserted: false, code: "AUTO_DELIVERY_ID_MISMATCH", error: "Delivery ID не совпадает." };
  if (run.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERTED) return { ok: true, inserted: true, already_inserted: true, recovery: deliveryRecoveryPayload(run, "watch_delivery") };
  if (run.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED) return { ok: false, inserted: false, code: "AUTO_DELIVERY_INSERT_NOT_COMMITTED", error: "Insertion не committed." };
  if (run.delivery.commit_actor_id && actorId && run.delivery.commit_actor_id !== actorId) return { ok: false, inserted: false, code: "AUTO_DELIVERY_ACTOR_MISMATCH", error: "Inserted ack пришёл от другого content runtime." };
  let inserted = false;
  run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId || current.delivery?.delivery_id !== deliveryId || current.delivery?.mode !== "batch_watch_v1") return current;
    if (current.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED) return current;
    const next = BridgeAutorunModel.markDeliveryInserted(current, { deliveryId, actorId });
    inserted = next?.delivery?.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERTED;
    return next;
  });
  if (!inserted) return { ok: false, inserted: false, code: "AUTO_DELIVERY_INSERT_ACK_RACE", error: "Delivery state изменился до inserted ack." };
  await diagnostic("DELIVERY_INSERTED", { run_id: runId, delivery_id: deliveryId, tab_id: senderTabId });
  return { ok: true, inserted: true, recovery: deliveryRecoveryPayload(run, "watch_delivery") };
}

async function commitAutoDelivery(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const runId = String(message.run_id || "");
  const deliveryId = String(message.delivery_id || "");
  const actorId = String(message.actor_id || "");
  const senderTabId = Number(sender?.tab?.id || 0);
  let run = await getAutoRun(key);
  if (!run || run.run_id !== runId || run.status !== BridgeAutorunModel.RUN_STATUSES.DELIVERING) {
    return { ok: false, committed: false, click_allowed: false, code: "AUTO_DELIVERY_STATE_MISMATCH", error: "Run не находится в delivery state." };
  }
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(run.tab_id)) {
    return { ok: false, committed: false, click_allowed: false, code: "AUTO_NON_OWNER_TAB", error: "Delivery commit пришёл не из owner-вкладки." };
  }
  await assertTabConversation(senderTabId, key, run.conversation_id);
  await assertRunBinding(run);
  if (run.delivery?.delivery_id !== deliveryId) {
    return { ok: false, committed: false, click_allowed: false, code: "AUTO_DELIVERY_ID_MISMATCH", error: "Delivery ID не совпадает с активной доставкой." };
  }
  if (run.delivery?.phase === BridgeAutorunModel.DELIVERY_PHASES.CONFIRMED) {
    return { ok: true, committed: true, click_allowed: false, already_confirmed: true };
  }
  if (run.delivery?.phase === BridgeAutorunModel.DELIVERY_PHASES.COMMITTED) {
    // Commit is the irreversible boundary. Never grant a second browser click after it, even to the same runtime.
    return { ok: true, committed: true, click_allowed: false, already_committed: true, recovery: deliveryRecoveryPayload(run, "reconcile_delivery") };
  }
  if (run.delivery?.phase !== BridgeAutorunModel.DELIVERY_PHASES.CLAIMED) {
    return { ok: false, committed: false, click_allowed: false, code: "AUTO_DELIVERY_NOT_CLAIMED", error: "Delivery ещё не claimable." };
  }
  let clickAllowed = false;
  run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId || current.delivery?.delivery_id !== deliveryId) return current;
    if (current.delivery?.phase !== BridgeAutorunModel.DELIVERY_PHASES.CLAIMED) return current;
    clickAllowed = true;
    return BridgeAutorunModel.commitDelivery(current, {
      deliveryId,
      baselineUserTurnIds: message.baseline_user_turn_ids,
      actorId
    });
  });
  if (!clickAllowed) {
    const latest = await getAutoRun(key);
    return { ok: true, committed: true, click_allowed: false, already_committed: true, recovery: latest ? deliveryRecoveryPayload(latest, "reconcile_delivery") : null };
  }
  await diagnostic("DELIVERY_COMMITTED_BEFORE_CLICK", { run_id: runId, delivery_id: deliveryId, tab_id: senderTabId, actor_id: actorId || null, baseline_user_turn_count: run?.delivery?.baseline_user_turn_ids?.length || 0 });
  return { ok: true, committed: true, click_allowed: true, run: publicRun(run) };
}

async function completeBatchAutoDelivery(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const runId = String(message.run_id || "");
  const deliveryId = String(message.delivery_id || "");
  let currentRun = await getAutoRun(key);
  if (!currentRun || currentRun.run_id !== runId) throw Object.assign(new Error("Batch delivery confirmation не соответствует активному autorun."), { code: "AUTO_DELIVERY_STATE_MISMATCH" });
  const senderTabId = Number(sender?.tab?.id || 0);
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(currentRun.tab_id)) throw Object.assign(new Error("Batch delivery confirmation пришёл не из owner-вкладки."), { code: "AUTO_NON_OWNER_TAB" });
  await assertTabConversation(senderTabId, key, currentRun.conversation_id);
  await assertRunBinding(currentRun);
  if (deliveryId && currentRun.last_confirmed_delivery_id === deliveryId) {
    await noteConfirmedPrefix(key, currentRun.last_confirmed_report_prefix_applied === true, deliveryId);
    return publicRun(currentRun);
  }
  if (currentRun.status !== BridgeAutorunModel.RUN_STATUSES.DELIVERING || currentRun.delivery?.mode !== "batch_watch_v1") throw Object.assign(new Error("Run больше не находится в batch delivery state."), { code: "AUTO_DELIVERY_STATE_MISMATCH" });
  if (!deliveryId || currentRun.delivery.delivery_id !== deliveryId) throw Object.assign(new Error("Batch delivery ID не совпадает."), { code: "AUTO_DELIVERY_ID_MISMATCH" });
  if (currentRun.delivery.phase !== BridgeAutorunModel.DELIVERY_PHASES.INSERTED) throw Object.assign(new Error("Delivery confirmation разрешён только после confirmed insertion."), { code: "AUTO_DELIVERY_NOT_INSERTED" });

  const expectedBasis = expectedDeliveryConfirmationBasis(currentRun.origin);
  const confirmed = message.delivery_confirmed === true && acceptedDeliveryConfirmationBasis(currentRun.origin, message.confirmation_basis);
  await diagnostic("DELIVERY_CONFIRMATION_RECEIVED", {
    run_id: runId,
    delivery_id: deliveryId,
    delivery_mode: "batch_watch_v1",
    delivery_confirmed: confirmed,
    confirmation_basis: String(message.confirmation_basis || ""),
    click_attempts: Number(message.click_attempts || 0)
  }, { level: confirmed ? "info" : "warning" });
  if (!confirmed) return publicRun(currentRun);

  const prefixApplied = currentRun.delivery.report_prefix_applied === true;
  const baselineAssistantIds = Array.isArray(currentRun.delivery.baseline_assistant_turn_ids) ? currentRun.delivery.baseline_assistant_turn_ids : [];
  await noteConfirmedPrefix(key, prefixApplied, deliveryId);
  let didConfirm = false;
  let run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId) return current;
    if (current.last_confirmed_delivery_id === deliveryId) return current;
    if (current.status !== BridgeAutorunModel.RUN_STATUSES.DELIVERING || current.delivery?.delivery_id !== deliveryId || current.delivery?.mode !== "batch_watch_v1" || current.delivery?.phase !== BridgeAutorunModel.DELIVERY_PHASES.INSERTED) return current;
    didConfirm = true;
    const confirmedCurrent = {
      ...current,
      delivery: { ...current.delivery, phase: BridgeAutorunModel.DELIVERY_PHASES.CONFIRMED, confirmed_at: new Date().toISOString() }
    };
    const next = BridgeAutorunModel.afterConfirmedDelivery(confirmedCurrent);
    if (current.pause_after_guidance_limit === true) {
      next.status = BridgeAutorunModel.RUN_STATUSES.PAUSED;
      next.last_error = { code: "GUIDANCE_ROUND_LIMIT", message: "Достигнут лимит локальных guidance rounds; продолжите в Manual mode или начните задачу с более точной командой." };
      next.pause_after_guidance_limit = false;
    }
    next.last_confirmed_delivery_id = deliveryId;
    next.last_confirmed_report_prefix_applied = prefixApplied;
    next.last_confirmed_user_turn_id = null;
    next.delivery = null;
    if (next.status === BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) {
      next.assistant_baseline_ids = baselineAssistantIds;
      next.watch_id = `watch-${crypto.randomUUID()}`;
    }
    return next;
  });
  if (!run || run.run_id !== runId) return null;
  if (!didConfirm && run.last_confirmed_delivery_id !== deliveryId) throw Object.assign(new Error("Batch delivery state изменился конкурентно до подтверждения."), { code: "AUTO_DELIVERY_CONFIRM_RACE" });
  if (didConfirm) {
    await diagnostic("DELIVERY_SUCCESS", { run_id: runId, status: run.status, sequence: Number(run.sequence || 0), delivery_id: deliveryId, confirmation_basis: String(message.confirmation_basis || expectedBasis) });
    if (run.status === BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) await beginWatch(run);
    else await stopWatch(run, `delivery_complete:${run.status}`);
  }
  return publicRun(run);
}

async function completeAutoDelivery(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const runId = String(message.run_id || "");
  const deliveryId = String(message.delivery_id || "");
  let currentRun = await getAutoRun(key);
  if (!currentRun || currentRun.run_id !== runId) {
    throw Object.assign(new Error("Delivery confirmation не соответствует активному autorun."), { code: "AUTO_DELIVERY_STATE_MISMATCH" });
  }
  if (currentRun.delivery?.mode === "batch_watch_v1") return await completeBatchAutoDelivery(message, sender);
  const senderTabId = Number(sender?.tab?.id || 0);
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(currentRun.tab_id)) {
    throw Object.assign(new Error("Delivery confirmation пришёл не из owner-вкладки autorun."), { code: "AUTO_NON_OWNER_TAB" });
  }
  await assertTabConversation(senderTabId, key, currentRun.conversation_id);
  await assertRunBinding(currentRun);

  // Duplicate confirmation after an already finalized delivery is idempotent.
  if (deliveryId && currentRun.last_confirmed_delivery_id === deliveryId) {
    await noteConfirmedPrefix(key, currentRun.last_confirmed_report_prefix_applied === true, deliveryId);
    return publicRun(currentRun);
  }
  if (currentRun.status !== BridgeAutorunModel.RUN_STATUSES.DELIVERING) {
    throw Object.assign(new Error("Run больше не находится в delivery state."), { code: "AUTO_DELIVERY_STATE_MISMATCH" });
  }
  if (!deliveryId || currentRun.delivery?.delivery_id !== deliveryId) {
    throw Object.assign(new Error("Delivery confirmation ID не совпадает с активной доставкой."), { code: "AUTO_DELIVERY_ID_MISMATCH" });
  }
  if (currentRun.delivery?.phase !== BridgeAutorunModel.DELIVERY_PHASES.COMMITTED) {
    throw Object.assign(new Error("Delivery confirmation разрешён только после commit."), { code: "AUTO_DELIVERY_NOT_COMMITTED" });
  }
  await diagnostic("DELIVERY_CONFIRMATION_RECEIVED", { run_id: runId, delivery_id: deliveryId, delivery_confirmed: message.delivery_confirmed === true, composer_empty: message.composer_empty === true, click_attempts: Number(message.click_attempts || 0) }, { level: message.delivery_confirmed === true ? "info" : "warning" });
  if (message.delivery_confirmed !== true) {
    const pending = await mutateAutoRun(key, (current) => {
      if (!current || current.run_id !== runId || current.delivery?.delivery_id !== deliveryId) return current;
      return {
        ...current,
        last_error: {
          code: "DELIVERY_CONFIRMATION_PENDING",
          message: "Send был committed, но новый user-turn пока не подтверждён. Автоматический повтор Send/API запрещён; разрешена только reconciliation.",
          at: new Date().toISOString(),
          recoverable: true
        }
      };
    });
    return publicRun(pending);
  }

  // Prefix accounting is idempotent by delivery_id, so duplicate/concurrent confirmations cannot increment twice.
  const prefixApplied = currentRun.delivery?.report_prefix_applied === true;
  await noteConfirmedPrefix(key, prefixApplied, deliveryId);

  let didConfirm = false;
  let run = await mutateAutoRun(key, (current) => {
    if (!current || current.run_id !== runId) return current;
    if (current.last_confirmed_delivery_id === deliveryId) return current;
    if (current.status !== BridgeAutorunModel.RUN_STATUSES.DELIVERING || current.delivery?.delivery_id !== deliveryId || current.delivery?.phase !== BridgeAutorunModel.DELIVERY_PHASES.COMMITTED) return current;
    didConfirm = true;
    const confirmedCurrent = {
      ...current,
      delivery: {
        ...current.delivery,
        phase: BridgeAutorunModel.DELIVERY_PHASES.CONFIRMED,
        confirmed_at: new Date().toISOString(),
        confirmed_user_turn_id: message.confirmed_user_turn_id || null
      }
    };
    const next = BridgeAutorunModel.afterConfirmedDelivery(confirmedCurrent);
    next.last_confirmed_delivery_id = deliveryId;
    next.last_confirmed_report_prefix_applied = prefixApplied;
    next.last_confirmed_user_turn_id = message.confirmed_user_turn_id || null;
    next.delivery = null;
    if (next.status === BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) {
      next.assistant_baseline_ids = Array.isArray(message.assistant_baseline_ids) ? message.assistant_baseline_ids : [];
      next.watch_id = `watch-${crypto.randomUUID()}`;
    }
    return next;
  });
  if (!run || run.run_id !== runId) return null;
  if (!didConfirm && run.last_confirmed_delivery_id !== deliveryId) {
    throw Object.assign(new Error("Delivery state изменился конкурентно до подтверждения."), { code: "AUTO_DELIVERY_CONFIRM_RACE" });
  }
  if (didConfirm) {
    await diagnostic("DELIVERY_COMPLETED", { run_id: runId, status: run.status, sequence: Number(run.sequence || 0), delivery_id: deliveryId });
    if (run.status === BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) await beginWatch(run);
    else await stopWatch(run, `delivery_complete:${run.status}`);
  }
  return publicRun(run);
}

async function failAutoDelivery(message, sender) {
  const key = normalizeConversationKey(message.conversation_key);
  const run = await getAutoRun(key);
  if (!run || run.run_id !== String(message.run_id || "")) return null;
  const senderTabId = Number(sender?.tab?.id || 0);
  if (!Number.isInteger(senderTabId) || senderTabId !== Number(run.tab_id)) return publicRun(run);
  await assertTabConversation(senderTabId, key, run.conversation_id).catch(() => null);
  if (run.status === BridgeAutorunModel.RUN_STATUSES.DELIVERING && run.delivery) {
    const preserved = await mutateAutoRun(key, (current) => {
      if (!current || current.run_id !== run.run_id) return current;
      return {
        ...current,
        last_error: {
          code: String(message.code || "DELIVERY_FAILED"),
          message: String(message.error || "Не удалось доставить Ozon result в текущий AI."),
          at: new Date().toISOString(),
          recoverable: true
        }
      };
    });
    await diagnostic("DELIVERY_FAILED_BUT_PRESERVED", { run_id: run.run_id, delivery_id: run.delivery?.delivery_id || null, phase: run.delivery?.phase || null, code: message.code || "DELIVERY_FAILED" }, { level: "warning" });
    return publicRun(preserved);
  }
  const failed = await markRunError(key, message.code || "DELIVERY_FAILED", message.error || "Не удалось доставить Ozon result в текущий AI.");
  return publicRun(failed);
}

async function pauseAutoRun(conversationKey) {
  const key = normalizeConversationKey(conversationKey);
  const existing = await getAutoRun(key);
  if (!existing) throw Object.assign(new Error("Активный autorun не найден."), { code: "AUTO_RUN_NOT_FOUND" });
  await assertRunBinding(existing);
  let shouldStopWatch = false;
  const run = await mutateAutoRun(key, (current) => {
    if (!current) return null;
    const decision = BridgeAutorunModel.pauseDecision(current.status);
    if (decision === "immediate") {
      shouldStopWatch = true;
      return { ...current, status: BridgeAutorunModel.RUN_STATUSES.PAUSED, pause_requested: false };
    }
    if (decision === "deferred") return { ...current, pause_requested: true };
    return current;
  });
  if (!run) throw Object.assign(new Error("Активный autorun не найден."), { code: "AUTO_RUN_NOT_FOUND" });
  if (shouldStopWatch) await stopWatch(run, "operator_pause");
  return publicRun(run);
}

async function resumeAutoRun(conversationKey, tabId) {
  const key = normalizeConversationKey(conversationKey);
  const tab = normalizeTabId(tabId);
  if (await getManualMode(key)) throw Object.assign(new Error("Перед продолжением autorun выключите ручной режим Ozon."), { code: "MANUAL_MODE_ACTIVE" });
  const manualOperation = await getManualOperation(key);
  if (manualOperationActive(manualOperation)) throw Object.assign(new Error("Дождитесь завершения уже принятого ручного Ozon request/delivery."), { code: "MANUAL_OPERATION_ACTIVE" });
  const settings = await getSettings();
  OzonCredentials.normalizeSellerCredentials(settings.sellerCredentials, { required: true });
  if (!Object.values(OzonContract.OPERATIONS).some((meta) => meta.execution_enabled === true)) throw Object.assign(new Error("Ozon provider execution gate закрыт: нет ни одной implementation-ready READ operation."), { code: "PROVIDER_GATE_CLOSED" });
  const current = await getAutoRun(key);
  if (!current || current.status !== BridgeAutorunModel.RUN_STATUSES.PAUSED) throw Object.assign(new Error("Run не находится на паузе."), { code: "AUTO_RUN_NOT_PAUSED" });
  await assertRunBinding(current);

  const owner = await ownerDecision(current, tab, { allowRebind: true });
  if (!owner.owner) {
    throw Object.assign(new Error(`Этот autorun принадлежит другой AI-вкладке (tab ${owner.owner_tab_id || current.tab_id}).`), { code: "AUTO_NON_OWNER_TAB" });
  }
  const ownedRun = owner.run || current;
  const baseline = await tabMessage(tab, {
    type: "OZ_AUTO_GET_BASELINE",
    run_id: ownedRun.run_id,
    conversation_key: key,
    conversation_id: ownedRun.conversation_id
  });
  if (!baseline.ok) throw Object.assign(new Error(baseline.error || "Не удалось получить baseline текущего AI."), { code: baseline.code || "BASELINE_FAILED" });
  const run = await mutateAutoRun(key, (runNow) => {
    if (!runNow || runNow.run_id !== ownedRun.run_id || runNow.status !== BridgeAutorunModel.RUN_STATUSES.PAUSED) return runNow;
    return {
      ...runNow,
      tab_id: tab,
      status: BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND,
      pause_requested: false,
      assistant_baseline_ids: Array.isArray(baseline.assistant_baseline_ids) ? baseline.assistant_baseline_ids : [],
      watch_id: `watch-${crypto.randomUUID()}`
    };
  });
  if (run?.status === BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND) await beginWatch(run);
  return publicRun(run);
}

async function stopAutoRun(conversationKey) {
  const key = normalizeConversationKey(conversationKey);
  const existing = await getAutoRun(key);
  if (!existing) throw Object.assign(new Error("Autorun не найден."), { code: "AUTO_RUN_NOT_FOUND" });
  await assertRunBinding(existing);
  let stopNow = false;
  const run = await mutateAutoRun(key, (current) => {
    if (!current) return null;
    if (current.status === BridgeAutorunModel.RUN_STATUSES.DELIVERING && current.delivery?.mode === "batch_watch_v1") {
      stopNow = true;
      return { ...current, status: BridgeAutorunModel.RUN_STATUSES.STOPPED, finish_requested: false, pause_requested: false, batch: null, delivery: null };
    }
    if (current.status === BridgeAutorunModel.RUN_STATUSES.REQUESTING || current.status === BridgeAutorunModel.RUN_STATUSES.COLLECTING || current.status === BridgeAutorunModel.RUN_STATUSES.DELIVERING || current.status === BridgeAutorunModel.RUN_STATUSES.STARTING) {
      return { ...current, finish_requested: true };
    }
    stopNow = true;
    return { ...current, status: BridgeAutorunModel.RUN_STATUSES.STOPPED, finish_requested: false, pause_requested: false, batch: null, delivery: null };
  });
  if (!run) throw Object.assign(new Error("Autorun не найден."), { code: "AUTO_RUN_NOT_FOUND" });
  if (stopNow) await stopWatch(run, "operator_finish");
  return publicRun(run);
}

async function testConnection() {
  const settings = await getSettings();
  const sellerConfigured = OzonCredentials.normalizeSellerCredentials(settings.sellerCredentials, { required: false }).present;
  const performanceConfigured = OzonCredentials.normalizePerformanceCredentials(settings.performanceCredentials, { required: false }).present;
  if (!sellerConfigured && !performanceConfigured) {
    const status = await setStatus({ ok: false, code: "MISSING_CREDENTIALS", message: "Seller и Performance credentials не сохранены.", http_status: 0 });
    return { ok: false, ...status };
  }
  try {
    const seller = sellerConfigured ? await OzonProvider.testConnection(settings.sellerCredentials) : null;
    const performance = performanceConfigured ? await OzonProvider.testPerformanceConnection(settings.performanceCredentials) : null;
    const ok = (!sellerConfigured || seller?.ok === true) && (!performanceConfigured || performance?.ok === true);
    const parts = [];
    if (sellerConfigured) parts.push(seller?.ok ? `Seller /v1/roles HTTP ${seller.http_status}` : `Seller ERROR ${seller?.code || seller?.http_status || "unknown"}`);
    else parts.push("Seller: не настроен");
    if (performanceConfigured) parts.push(performance?.ok ? "Performance auth: OK" : `Performance ERROR ${performance?.code || performance?.http_status || "unknown"}`);
    else parts.push("Performance: не настроен");
    const message = parts.join(" · ");
    const status = await setStatus({
      ok,
      code: ok ? "CONNECTED" : (performance?.code || seller?.code || "OZON_API_ERROR"),
      message,
      http_status: Number(performance?.http_status || seller?.http_status || 0)
    });
    return {
      ok,
      ...status,
      message,
      seller,
      performance,
      expires_at: seller?.expires_at || null,
      roles_count: Number.isInteger(seller?.roles_count) ? seller.roles_count : null,
      methods_count: Number.isInteger(seller?.methods_count) ? seller.methods_count : null,
      elapsed_ms: Number(seller?.elapsed_ms || 0)
    };
  } catch (error) {
    const status = await setStatus({ ok: false, code: error.code || "CONNECTION_TEST_FAILED", message: error.message || String(error), http_status: Number(error?.http_status || 0) });
    return { ok: false, ...status };
  }
}

chrome.tabs.onRemoved.addListener((tabId) => {
  void (async () => { await clearTabAIMode(tabId); await clearPendingWorkStartForTab(tabId, "tab_closed"); })().catch(() => null);
});



async function saLegacyMessage(message, sender) {
    switch (message?.type) {
      case "OZ_RESOLVE_POPUP_CONTEXT": {
        const context = await resolvePopupContext(message.tab_id, message.identity || null);
        return { ok: true, context };
      }
      case "OZ_BIND_CONVERSATION": {
        const binding = await bindConversation(message.context || {});
        return { ok: true, binding, state: await publicSettingsState(binding.conversation_key) };
      }
      case "OZ_GET_SETTINGS_STATE":
        return { ok: true, state: await publicSettingsState(message.conversation_key) };
      case "OZ_GET_GLOBAL_SETTINGS_STATE":
        return { ok: true, state: await publicGlobalSettingsState(message.page_context_error || null) };
      case "OZ_REFRESH_SELLER_API_METADATA": {
        try {
          const summary = await refreshSellerApiMetadata();
          return { ok: true, summary, state: await publicGlobalSettingsState(null) };
        } catch (error) {
          await diagnostic("SELLER_API_METADATA_UPDATE_FAILED", { code: error.code || "SELLER_METADATA_UPDATE_FAILED", http_status: Number(error?.http_status || 0), external_request_executed: false }, { level: "warning" });
          return { ok: false, code: error.code || "SELLER_METADATA_UPDATE_FAILED", error: error.message || String(error), state: await publicGlobalSettingsState(null) };
        }
      }
      case "OZ_GET_TAB_AI_MODE": {
        const tabId = sender?.tab?.id ? normalizeTabId(sender.tab.id) : normalizeTabId(message.tab_id);
        const [{ ai_id: detectedAIId }, mode] = await Promise.all([detectedAIForTab(tabId), getTabAIMode(tabId)]);
        return { ok: true, tab_id: tabId, ai_mode: mode, ai_mode_scope: "per_tab", detected_ai_id: detectedAIId || null };
      }
      case "OZ_SET_TAB_AI_MODE": {
        const tabId = normalizeTabId(message.tab_id);
        const detected = await detectedAIForTab(tabId);
        if (!detected.ai_id) {
          return { ok: false, code: "UNSUPPORTED_AI_TAB", error: "Текущая вкладка не принадлежит поддерживаемому AI." };
        }
        const previousMode = await getTabAIMode(tabId);
        const mode = await setTabAIMode(tabId, message.ai_mode);
        const applied = await tabMessage(tabId, { type: "OZ_APPLY_AI_MODE", ai_mode: mode });
        if (!applied?.ok) {
          await setTabAIMode(tabId, previousMode);
          return { ok: false, code: applied?.code || "TAB_AI_MODE_APPLY_FAILED", error: applied?.error || "Не удалось применить AI adapter к текущей вкладке; override откатан." };
        }
        await diagnostic("TAB_AI_MODE_CHANGED", { tab_id: tabId, ai_mode: mode, previous_ai_mode: previousMode, detected_ai_id: detected.ai_id, adapter_id: applied.adapter_id || null });
        return { ok: true, tab_id: tabId, ai_mode: mode, ai_mode_scope: "per_tab", detected_ai_id: detected.ai_id, adapter_id: applied.adapter_id || null };
      }
      case "OZ_SET_AI_MODE":
        return { ok: false, code: "GLOBAL_AI_MODE_REMOVED", error: "Глобальный AI mode удалён: adapter override задаётся только для текущей вкладки." };
      case "OZ_SAVE_GLOBAL_SETTINGS": {
        const current = await getSettings();
        const values = { [KEYS.AUTO_SEND]: message.auto_send !== false, [KEYS.PERSONAL_DATA_ENABLED]: message.personal_data_enabled === true };
        const newClientId = typeof message.seller_client_id === "string" ? message.seller_client_id.trim() : "";
        const newApiKey = typeof message.seller_api_key === "string" ? message.seller_api_key.trim() : "";
        if (newClientId || newApiKey) {
          const credentials = OzonCredentials.normalizeSellerCredentials({
            clientId: newClientId || current.sellerCredentials.clientId,
            apiKey: newApiKey || current.sellerCredentials.apiKey
          }, { required: true });
          values[KEYS.SELLER_CLIENT_ID] = credentials.clientId;
          values[KEYS.SELLER_API_KEY] = credentials.apiKey;
        }
        const newPerformanceClientId = typeof message.performance_client_id === "string" ? message.performance_client_id.trim() : "";
        const newPerformanceClientSecret = typeof message.performance_client_secret === "string" ? message.performance_client_secret.trim() : "";
        if (newPerformanceClientId || newPerformanceClientSecret) {
          const performanceCredentials = OzonCredentials.normalizePerformanceCredentials({
            clientId: newPerformanceClientId || current.performanceCredentials.clientId,
            clientSecret: newPerformanceClientSecret || current.performanceCredentials.clientSecret
          }, { required: true });
          values[KEYS.PERFORMANCE_CLIENT_ID] = performanceCredentials.clientId;
          values[KEYS.PERFORMANCE_CLIENT_SECRET] = performanceCredentials.clientSecret;
          OzonProvider.clearPerformanceToken();
        }
        await storageSet(values);
        if (typeof message.global_auto_start_prompt_text === "string") await saveGlobalAutoStartPrompt(message.global_auto_start_prompt_text);
        return { ok: true, state: await publicGlobalSettingsState(message.page_context_error || null) };
      }
      case "OZ_SAVE_SETTINGS": {
        const key = normalizeConversationKey(message.conversation_key);
        const current = await getSettings();
        const values = { [KEYS.AUTO_SEND]: message.auto_send !== false, [KEYS.PERSONAL_DATA_ENABLED]: message.personal_data_enabled === true };
        const newClientId = typeof message.seller_client_id === "string" ? message.seller_client_id.trim() : "";
        const newApiKey = typeof message.seller_api_key === "string" ? message.seller_api_key.trim() : "";
        if (newClientId || newApiKey) {
          const credentials = OzonCredentials.normalizeSellerCredentials({
            clientId: newClientId || current.sellerCredentials.clientId,
            apiKey: newApiKey || current.sellerCredentials.apiKey
          }, { required: true });
          values[KEYS.SELLER_CLIENT_ID] = credentials.clientId;
          values[KEYS.SELLER_API_KEY] = credentials.apiKey;
        }
        const newPerformanceClientId = typeof message.performance_client_id === "string" ? message.performance_client_id.trim() : "";
        const newPerformanceClientSecret = typeof message.performance_client_secret === "string" ? message.performance_client_secret.trim() : "";
        if (newPerformanceClientId || newPerformanceClientSecret) {
          const performanceCredentials = OzonCredentials.normalizePerformanceCredentials({
            clientId: newPerformanceClientId || current.performanceCredentials.clientId,
            clientSecret: newPerformanceClientSecret || current.performanceCredentials.clientSecret
          }, { required: true });
          values[KEYS.PERFORMANCE_CLIENT_ID] = performanceCredentials.clientId;
          values[KEYS.PERFORMANCE_CLIENT_SECRET] = performanceCredentials.clientSecret;
          OzonProvider.clearPerformanceToken();
        }
        await storageSet(values);
        if (typeof message.global_auto_start_prompt_text === "string") await saveGlobalAutoStartPrompt(message.global_auto_start_prompt_text);
        await saveReportPrefix(key, message);
        if (message.auto_start_prompt_override_enabled === true) {
          if (typeof message.auto_start_prompt_text !== "string") throw Object.assign(new Error("Для индивидуального start prompt нужен текст."), { code: "AUTO_START_PROMPT_TEXT_REQUIRED" });
          await saveAutoStartPrompt(key, message.auto_start_prompt_text);
        } else if (message.auto_start_prompt_override_enabled === false) {
          await resetAutoStartPrompt(key);
        } else if (typeof message.auto_start_prompt_text === "string") {
          // Backward-compatible message contract for an older popup talking to this worker.
          await saveAutoStartPrompt(key, message.auto_start_prompt_text);
        }
        return { ok: true, state: await publicSettingsState(key) };
      }
      case "OZ_RESET_GLOBAL_AUTO_START_PROMPT": {
        await resetGlobalAutoStartPrompt();
        if (typeof message.conversation_key === "string" && message.conversation_key.trim()) {
          return { ok: true, state: await publicSettingsState(message.conversation_key) };
        }
        return { ok: true, state: await publicGlobalSettingsState(message.page_context_error || null) };
      }
      case "OZ_RESET_AUTO_START_PROMPT": {
        const key = normalizeConversationKey(message.conversation_key);
        await resetAutoStartPrompt(key);
        return { ok: true, state: await publicSettingsState(key) };
      }
      case "OZ_WORK_RESUME": {
        const tab = normalizeTabId(message.tab_id);
        const key = normalizeConversationKey(message.conversation_key);
        const session = await workSessionFor(key);
        if (session.state !== OzonWorkSessionModel.STATES.INACTIVE) {
          return { ok: false, code: "WORK_SESSION_NOT_INACTIVE", error: "Продолжить работу без prompt можно только из inactive work-session." };
        }
        const live = await assertTabConversation(tab, key);
        const binding = await strictBindingForIdentity(live);
        const manualOperation = await getManualOperation(key);
        if (manualOperationActive(manualOperation)) {
          return { ok: false, code: "WORK_RESUME_OPERATION_ACTIVE", error: "Нельзя продолжить inactive work-session: обнаружена незавершённая manual operation." };
        }
        await saAdmissionMutationGuard({ operation: "resume", tabId: tab, conversationKey: key });
        const bindingSession = await mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.BINDING, {
          tab_id: tab,
          origin: live.origin,
          ai_id: live.ai_id,
          conversation_id: live.conversation_id,
          start_intent_id: null,
          error: null
        });
        const visible = await mutateWorkSession(key, bindingSession.revision, OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, { error: null, admission_provenance: SellerAgentsOfflineWorkAuthority.createProvenance(message.admission_provenance, { conversationKey: key, conversationId: live.conversation_id, bindingId: binding.binding_id, bindingRevision: Number(binding.revision), marketplace: binding.store_context?.marketplace || null, storeId: binding.store_context?.storeId || null, credentialRevision: binding.store_context?.credentialRevision || null }) });
        try {
          await setWorkSessionCommandAcceptance(key, true);
          const applied = await tabMessage(tab, { type: "OZ_WORK_APPLY_VISIBILITY", visible: true, conversation_key: key });
          if (!applied?.ok || applied.applied !== true) throw Object.assign(new Error(applied?.error || "Content script не подтвердил Resume."), { code: applied?.code || "WORK_RESUME_CONTENT_REJECTED" });
        } catch (error) {
          await setWorkSessionCommandAcceptance(key, false);
          await mutateWorkSession(key, visible.revision, OzonWorkSessionModel.STATES.ERROR, { error: { code: error.code || "WORK_RESUME_FAILED" } });
          return { ok: false, code: error.code || "WORK_RESUME_FAILED", error: error.message || String(error) };
        }
        await diagnostic("WORK_SESSION_RESUMED_WITHOUT_PROMPT", {
          tab_id: tab,
          conversation_key: key,
          binding_id: binding.binding_id,
          binding_revision: binding.revision,
          session_revision: visible.revision,
          external_request_executed: false
        });
        return { ok: true, resumed_without_prompt: true, binding, session: visible, state: await publicSettingsState(key) };
      }
      case "OZ_WORK_SHOW": {
        const tab = normalizeTabId(message.tab_id);
        const key = normalizeConversationKey(message.conversation_key);
        const session = await workSessionFor(key);
        if (session.state !== OzonWorkSessionModel.STATES.ACTIVE_HIDDEN) return { ok: false, code: "WORK_SESSION_NOT_HIDDEN", error: "Показать кнопку разрешено только для активной скрытой work-session." };
        const live = await assertTabConversation(tab, key);
        await strictBindingForIdentity(live);
        const next = await mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.ACTIVE_VISIBLE);
        try {
          await setWorkSessionCommandAcceptance(key, true);
          const applied = await tabMessage(tab, { type: "OZ_WORK_APPLY_VISIBILITY", visible: true, conversation_key: key });
          if (!applied?.ok || applied.applied !== true) throw Object.assign(new Error(applied?.error || "Content script не подтвердил Show."), { code: applied?.code || "WORK_SHOW_CONTENT_REJECTED" });
        } catch (error) {
          await setWorkSessionCommandAcceptance(key, false);
          await mutateWorkSession(key, next.revision, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN);
          return { ok: false, code: error.code || "WORK_SHOW_FAILED", error: error.message || String(error) };
        }
        return { ok: true, session: next, state: await publicSettingsState(key) };
      }
      case "OZ_WORK_REFRESH": {
        const tab = normalizeTabId(message.tab_id);
        const key = normalizeConversationKey(message.conversation_key);
        const begun = await beginWorkSessionRefresh(tab, key);
        if (begun.already_in_progress) return { ok: true, code: "REFRESH_ALREADY_IN_PROGRESS", recovery: begun.recovery };
        const oldRuntimeGeneration = String(begun.recovery.old_runtime_generation || workSessionRuntimeGeneration);
        const newRuntimeGeneration = String(begun.recovery.new_runtime_generation || `work-runtime-${crypto.randomUUID()}`);
        workSessionRuntimeGeneration = newRuntimeGeneration;
        await diagnostic("WORK_SESSION_REFRESH_RUNTIME_REINITIALIZED", {
          recovery_id: begun.recovery.recovery_id,
          tab_id: tab,
          conversation_key: key,
          worker_session_id: WORKER_SESSION_ID,
          old_runtime_generation: oldRuntimeGeneration,
          new_runtime_generation: newRuntimeGeneration
        });
        const pageReload = await reloadRefreshOwnerTabInProcess(begun.recovery);
        if (!pageReload.ok) {
          const session = await workSessionFor(key);
          await setWorkSessionCommandAcceptance(key, false);
          if (session.state === OzonWorkSessionModel.STATES.RECOVERING && Number(session.revision) === Number(begun.recovery.revision)) {
            await mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.ERROR, { error: { code: pageReload.code || "WORK_REFRESH_TAB_RELOAD_FAILED" } });
          }
          const recoveries = await getWorkRecoveries();
          if (recoveries[key]?.recovery_id === begun.recovery.recovery_id) {
            delete recoveries[key];
            await storageSet({ [KEYS.WORK_SESSION_RECOVERIES]: recoveries });
          }
          await diagnostic(pageReload.code || "WORK_REFRESH_TAB_RELOAD_FAILED", { recovery_id: begun.recovery.recovery_id, tab_id: tab, worker_session_id: WORKER_SESSION_ID, runtime_generation: newRuntimeGeneration, error: pageReload.error || null }, { level: "error" });
          return { ok: false, code: pageReload.code || "WORK_REFRESH_TAB_RELOAD_FAILED", error: pageReload.error || "AI tab reload failed.", recovery: begun.recovery };
        }
        await resumeWorkSessionRecoveries();
        const restored = await workSessionFor(key);
        const restoredOk = [OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN].includes(restored.state);
        if (!restoredOk) {
          return { ok: false, code: restored.error?.code || "WORK_REFRESH_RECOVERY_FAILED", error: "Work-session recovery did not restore an active state.", recovery: begun.recovery, session: restored };
        }
        return {
          ok: true,
          recovery: begun.recovery,
          runtime_reinitialized: true,
          physical_worker_reloaded: false,
          worker_session_id: WORKER_SESSION_ID,
          old_runtime_generation: oldRuntimeGeneration,
          new_runtime_generation: newRuntimeGeneration,
          page_reload_completed: true,
          restored_state: restored.state
        };
      }

      case "OZ_WORK_START": {
        const tab = normalizeTabId(message.tab_id);
        const requestedIntentId = String(message.start_intent_id || "").trim() || `work-start-${crypto.randomUUID()}`;
        const live = await tabIdentity(tab);
        if (!live.ai_id || !live.origin) return { ok: false, code: "WORK_START_UNSUPPORTED_PAGE", error: "Текущая вкладка не является поддерживаемым AI-диалогом." };
        let key = null;
        let currentSession = null;
        if (live.conversation_id) {
          key = await resolveConfirmedConversationKey(live);
          currentSession = await workSessionFor(key);
          if ([OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN].includes(currentSession.state)) {
            return { ok: false, accepted: false, code: "WORK_SESSION_ALREADY_ACTIVE", error: "Work-session уже активна; повторный Start не должен отправлять второй bootstrap prompt." };
          }
          if (![OzonWorkSessionModel.STATES.INACTIVE, OzonWorkSessionModel.STATES.ERROR].includes(currentSession.state)) {
            return { ok: false, accepted: false, code: "WORK_START_ALREADY_IN_PROGRESS", error: `Work-session уже находится в состоянии ${currentSession.state}.` };
          }
        }
        const nextRevision = currentSession ? currentSession.revision + 1 : 1;
        await diagnostic("WORK_START_REQUESTED", { intent_id: requestedIntentId, revision: nextRevision, tab_id: tab, conversation_id: live.conversation_id || null, state_before: currentSession?.state || OzonWorkSessionModel.STATES.INACTIVE, external_request_executed: false });
        await saAdmissionMutationGuard({ operation: "start", tabId: tab, conversationKey: key, intentId: requestedIntentId });
        const pending = await withBindingWrite(() => createPendingWorkStart(tab, live, { intent_id: requestedIntentId, revision: nextRevision, observed_conversation_id: live.conversation_id || null, conversation_key: key, expected_session_revision: currentSession?.revision ?? 0, state_before: currentSession?.state || OzonWorkSessionModel.STATES.INACTIVE, admission_provenance: message.admission_provenance || null, prompt_tree: message.prompt_tree || null }));
        if (pending.duplicate) return { ok: true, accepted: false, code: "WORK_START_ALREADY_PENDING", pending_start: pending.transaction };
        const prompt = key ? await getAutoStartPrompt(key) : await getGlobalAutoStartPrompt();
        void dispatchPendingWorkStartPrompt(tab, pending.transaction, String(prompt?.text || DEFAULT_AUTO_START_TEXT)).catch((error) => {
          void diagnostic("WORK_START_ASYNC_DISPATCH_FAILED", { intent_id: pending.transaction.intent_id, revision: pending.transaction.revision, tab_id: tab, code: error?.code || "WORK_START_ASYNC_DISPATCH_FAILED", error: error?.message || String(error), external_request_executed: false }, { level: "error" });
        });
        return { ok: true, accepted: true, pending_start: pending.transaction, start_intent_id: pending.transaction.intent_id, revision: pending.transaction.revision };
      }
      case "OZ_WORK_START_COMMIT_REQUEST":
        return await commitPendingWorkStartSend(message, sender);
      case "OZ_WORK_START_VERIFY_COMMITTED":
        return await saVerifyCommittedWorkStart(message, sender);
      case "OZ_WORK_START_SEND_OUTCOME":
        return await acknowledgePendingWorkStartSend(message, sender);
      case "OZ_WORK_PENDING_IDENTITY": {
        const tab = normalizeTabId(sender?.tab?.id || message.tab_id);
        const starts = await getPendingWorkStarts();
        const pending = starts[String(tab)] || null;
        if (!pending || pending.intent_id !== String(message.intent_id || "") || Number(pending.revision) !== Number(message.revision)) return { ok: false, code: "WORK_PENDING_STALE_OR_INVALID" };
        const identity = normalizeIdentity(message.identity || {});
        if (String(pending.expires_at || "") <= new Date().toISOString()) {
          await clearPendingWorkStart(tab, pending.intent_id, pending.revision, "response_timeout");
          return { ok: false, code: "WORK_PENDING_TIMEOUT" };
        }
        if (pending.origin !== identity.origin || pending.ai_id !== identity.ai_id || !identity.conversation_id) {
          await clearPendingWorkStart(tab, pending.intent_id, pending.revision, "identity_mismatch");
          return { ok: false, code: "WORK_PENDING_IDENTITY_MISMATCH" };
        }
        if (pending.surface_id && pending.surface_id !== identity.surface_id) {
          await clearPendingWorkStart(tab, pending.intent_id, pending.revision, "surface_changed");
          return { ok: false, code: "WORK_PENDING_SURFACE_CHANGED" };
        }
        if (pending.observed_conversation_id && pending.observed_conversation_id !== identity.conversation_id) {
          await clearPendingWorkStart(tab, pending.intent_id, pending.revision, "conversation_changed");
          return { ok: false, code: "WORK_PENDING_CONVERSATION_CHANGED" };
        }
        if (pending.prompt_delivered !== true || pending.send_outcome !== "sent_acknowledged") {
          return { ok: false, waiting: true, code: pending.send_outcome === "outcome_unknown_no_retry" ? "WORK_START_SEND_OUTCOME_UNKNOWN_NO_RETRY" : "WORK_START_SEND_NOT_ACKNOWLEDGED" };
        }
        // An observed own reply permits the existing binding/manual-command path.
        // Completion stays separate; older content may still prove it explicitly.
        if (message.first_response_observed !== true && message.first_response_complete !== true) {
          const updated = await updatePendingWorkStartObservation(tab, pending, identity);
          if (!updated) return { ok: false, code: "WORK_PENDING_STALE_OR_INVALID" };
          return { ok: true, waiting: true };
        }
        try {
          await diagnostic("WORK_START_CORRELATION_ACCEPTED", { intent_id: pending.intent_id, revision: pending.revision, tab_id: tab, conversation_id: identity.conversation_id, runtime_generation: pending.content_runtime_generation || null, external_request_executed: false });
          const binding = await bindConversation({ tab_id: tab, origin: identity.origin, conversation_id: identity.conversation_id }, { work_start_intent_id: pending.intent_id });
          const key = binding.conversation_key;
          const bindingSession = await workSessionFor(key);
          if (bindingSession.state !== OzonWorkSessionModel.STATES.BINDING || Number(bindingSession.revision) !== Number(pending.revision) || bindingSession.start_intent_id !== pending.intent_id) throw Object.assign(new Error("Pending Start не вошёл в correlation-safe binding."), { code: "WORK_PENDING_BINDING_STATE_INVALID" });
          await diagnostic("WORK_START_BINDING", { intent_id: pending.intent_id, revision: bindingSession.revision, tab_id: tab, conversation_id: identity.conversation_id, state_before: OzonWorkSessionModel.STATES.INACTIVE, state_after: bindingSession.state, external_request_executed: false });
          const visible = await mutateWorkSession(key, bindingSession.revision, OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, { error: null, prompt_tree: pending.prompt_tree || null, admission_provenance: SellerAgentsOfflineWorkAuthority.createProvenance(pending.admission_provenance, { conversationKey: key, conversationId: identity.conversation_id, bindingId: binding.binding_id, bindingRevision: Number(binding.revision), marketplace: binding.store_context?.marketplace || null, storeId: binding.store_context?.storeId || null, credentialRevision: binding.store_context?.credentialRevision || null }) });
          await diagnostic("WORK_START_ACTIVE_VISIBLE", { intent_id: pending.intent_id, revision: visible.revision, tab_id: tab, conversation_id: identity.conversation_id, state_before: bindingSession.state, state_after: visible.state, external_request_executed: false });
          try {
            await setWorkSessionCommandAcceptance(key, true);
            const applied = await tabMessage(tab, { type: "OZ_WORK_APPLY_VISIBILITY", visible: true, conversation_key: key });
            if (!applied?.ok || applied.applied !== true) throw Object.assign(new Error(applied?.error || "Content script не подтвердил включение кнопки «Октопорт»."), { code: applied?.code || "WORK_PENDING_CONTENT_REJECTED" });
          } catch (error) {
            await setWorkSessionCommandAcceptance(key, false);
            await mutateWorkSession(key, visible.revision, OzonWorkSessionModel.STATES.ERROR, { error: { code: error.code || "WORK_PENDING_CONTENT_REJECTED" } });
            throw error;
          }
          await clearPendingWorkStart(tab, pending.intent_id, pending.revision, "bound_after_first_response");
          return { ok: true, binding, session: visible };
        } catch (error) {
          await clearPendingWorkStart(tab, pending.intent_id, pending.revision, error.code || "binding_failed");
          return { ok: false, code: error.code || "WORK_PENDING_BIND_FAILED", error: error.message || String(error) };
        }
      }
      case "OZ_WORK_PENDING_TIMEOUT": {
        const tab = normalizeTabId(sender?.tab?.id || message.tab_id);
        const cleared = await clearPendingWorkStart(tab, message.intent_id, message.revision, "response_timeout");
        return { ok: true, cleared };
      }
      case "OZ_WORK_PENDING_CANCEL": {
        const tab = normalizeTabId(sender?.tab?.id || message.tab_id);
        const cleared = await clearPendingWorkStart(tab, message.intent_id, message.revision, message.reason || "content_cancelled");
        return { ok: true, cleared };
      }
      case "OZ_WORK_HIDE": {
        const tab = normalizeTabId(message.tab_id);
        const key = normalizeConversationKey(message.conversation_key);
        const session = await workSessionFor(key);
        if (session.state !== OzonWorkSessionModel.STATES.ACTIVE_VISIBLE) return { ok: false, code: "WORK_SESSION_NOT_VISIBLE", error: "Убрать кнопку разрешено только для активной visible work-session." };
        await assertTabConversation(tab, key);
        const next = await mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN);
        await setWorkSessionCommandAcceptance(key, false);
        const applied = await tabMessage(tab, { type: "OZ_WORK_APPLY_VISIBILITY", visible: false, conversation_key: key });
        if (!applied?.ok || applied.applied !== true) return { ok: false, code: applied?.code || "WORK_HIDE_CONTENT_REJECTED", error: applied?.error || "Work-session уже скрыта и provider gate закрыт, но content script не подтвердил удаление UI." };
        return { ok: true, session: next, state: await publicSettingsState(key) };
      }
      case "OZ_WORK_FINISH": {
        const tab = normalizeTabId(message.tab_id);
        const key = normalizeConversationKey(message.conversation_key);
        await saAdmissionMutationGuardIfActive({ operation: "start", tabId: tab, conversationKey: key });
        const session = await workSessionFor(key);
        if (![OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN, OzonWorkSessionModel.STATES.ERROR].includes(session.state)) return { ok: false, code: "WORK_SESSION_NOT_ACTIVE", error: "Завершить работу можно только для активной work-session." };
        const finishing = await mutateWorkSession(key, session.revision, OzonWorkSessionModel.STATES.FINISHING);
        await setWorkSessionCommandAcceptance(key, false);
        await tabMessage(tab, { type: "OZ_WORK_APPLY_VISIBILITY", visible: false, conversation_key: key });
        const terminalized = await terminalizeFinishOperation(key);
        const autoRun = await getAutoRun(key);
        if (autoRun) {
          try {
            await stopAutoRun(key);
          } catch (error) {
            if (error?.code !== "AUTO_RUN_NOT_FOUND") throw error;
          }
        }
        await withBindingWrite(async () => {
          const sessions = await getWorkSessions();
          const current = OzonWorkSessionModel.normalize(sessions[key], key);
          if (current.state !== OzonWorkSessionModel.STATES.FINISHING || current.revision !== finishing.revision) throw Object.assign(new Error("Work-session изменилась во время Finish."), { code: "WORK_FINISH_STALE_SESSION" });
          transitionWorkSessionRecord(sessions, key, current.revision, OzonWorkSessionModel.STATES.INACTIVE, { tab_id: null, origin: null, ai_id: null, conversation_id: null, start_intent_id: null, error: null, admission_provenance: null });
          await storageSet({ [KEYS.WORK_SESSIONS]: sessions });
        });
        await diagnostic("WORK_SESSION_FINISHED_BINDING_PRESERVED", { conversation_key: key, tab_id: tab, external_request_executed: false });
        return { ok: true, terminalized_operation: terminalized, binding_preserved: true, state: await publicSettingsState(key) };
      }
      case "OZ_SET_MANUAL_MODE": {
        const key = normalizeConversationKey(message.conversation_key);
        if (message.enabled === true) {
          const tab = normalizeTabId(message.tab_id);
          const liveIdentity = await assertTabConversation(tab, key);
          await strictBindingForIdentity(liveIdentity);
          const session = await workSessionFor(key);
          if (session.state !== OzonWorkSessionModel.STATES.ACTIVE_VISIBLE) return { ok: false, code: "WORK_SESSION_NOT_VISIBLE", error: "Legacy Manual ON не может обходить Work-session; используйте «Начать работу» / «Показать кнопку»." };
        }
        const enabled = await setManualMode(key, message.enabled === true);
        return { ok: true, enabled, state: await publicSettingsState(key) };
      }
      case "OZ_GET_MANUAL_STATE": {
        const key = normalizeConversationKey(message.conversation_key);
        const senderTabId = Number(sender?.tab?.id || 0);
        if (senderTabId <= 0) return { ok: true, enabled: false, ready: false, bound: false, manual_operation_active: false };
        const liveIdentity = await assertTabConversation(senderTabId, key);
        try {
          await strictBindingForIdentity(liveIdentity);
        } catch (error) {
          if (error?.code === "CONVERSATION_NOT_BOUND") return { ok: true, enabled: false, ready: false, bound: false, manual_operation_active: false };
          throw error;
        }
        const [storedEnabled, operation, session] = await Promise.all([getManualMode(key), getManualOperation(key), workSessionFor(key)]);
        const enabled = storedEnabled === true && session.state === OzonWorkSessionModel.STATES.ACTIVE_VISIBLE;
        const active = manualOperationActive(operation);
        return { ok: true, enabled, ready: enabled === true && !active, bound: true, work_session_state: session.state, manual_operation_active: active, manual_operation: publicManualOperation(operation) };
      }
      case "OZ_CONTENT_READY":
      case "OZ_CONTENT_SYNC": {
        void globalThis.SellerAgentsTechnicalScheduler?.wake?.("content_reconnect");
        const senderTabId = Number(sender?.tab?.id || 0);
        if (!Number.isInteger(senderTabId) || senderTabId <= 0) return { ok: false, code: "CONTENT_TAB_MISSING", error: "Content sync пришёл без AI tab." };
        const identity = normalizeIdentity(message.identity || {});
        const key = await resolveConfirmedConversationKey(identity);
        const liveIdentity = await assertTabConversation(senderTabId, key, identity.conversation_id);
        let binding = null;
        try { binding = await strictBindingForIdentity(liveIdentity); } catch (error) { if (error?.code !== "CONVERSATION_NOT_BOUND") throw error; }
        let run = await getAutoRun(key);
        let manualOperation = binding ? await getManualOperation(key) : null;
        let manualRecovery = null;
        let manualOwner = Boolean(binding);
        let manualRebound = false;
        if (binding && manualOperationActive(manualOperation)) {
          const manualDecision = await manualRecoveryForContent(manualOperation, senderTabId);
          manualOwner = manualDecision.owner === true;
          manualRebound = manualDecision.rebound === true;
          manualOperation = manualDecision.operation || manualOperation;
          manualRecovery = manualDecision.recovery || null;
          if (manualRebound) await diagnostic("MANUAL_OPERATION_TAB_REBOUND_AFTER_OLD_TAB_GONE", { operation_id: manualOperation?.operation_id || null, tab_id: senderTabId, status: manualOperation?.status || null });
        }
        let owner = Boolean(binding);
        let ownerTabId = run?.tab_id || null;
        let rebound = false;
        if (binding && run && !BridgeAutorunModel.isTerminalStatus(run.status)) {
          const decision = await ownerDecision(run, senderTabId, { allowRebind: true });
          owner = decision.owner === true;
          ownerTabId = decision.owner_tab_id || decision.run?.tab_id || run.tab_id;
          rebound = decision.rebound === true;
          run = decision.run || run;
          if (rebound) await diagnostic("RUN_TAB_REBOUND_AFTER_OLD_TAB_GONE", { run_id: run.run_id, tab_id: senderTabId, status: run.status });
        }
        let recovery = null;
        if (owner && run && !BridgeAutorunModel.isTerminalStatus(run.status)) {
          if (run.status === BridgeAutorunModel.RUN_STATUSES.DELIVERING && run.delivery) {
            if (run.delivery.mode === "batch_watch_v1" && run.delivery.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED) {
              recovery = await recoveryPayloadForRun(run);
            } else {
              setTimeout(() => { void attemptAutoDelivery(key, run.run_id); }, 0);
            }
          } else {
            recovery = await recoveryPayloadForRun(run);
          }
          run = await getAutoRun(key) || run;
        }
        const pendingStarts = await getPendingWorkStarts();
        const pendingStart = pendingStarts[String(senderTabId)] || null;
        const workStartWatch = pendingStart && pendingStart.prompt_delivered === true && pendingStart.send_outcome === "sent_acknowledged" &&
          pendingStart.origin === liveIdentity.origin && pendingStart.ai_id === liveIdentity.ai_id &&
          (!pendingStart.observed_conversation_id || pendingStart.observed_conversation_id === liveIdentity.conversation_id)
          ? workStartWatchPayload(pendingStart)
          : null;
        return {
          ok: true,
          conversation_key: key,
          identity: liveIdentity,
          binding: binding ? { bound: true, ...binding } : { bound: false, binding_id: null, revision: null },
          owner,
          owner_tab_id: ownerTabId,
          rebound,
          manual_mode: binding ? await workSessionManualEnabled(key) : false,
          manual_operation: binding ? publicManualOperation(manualOperation) : null,
          manual_operation_owner: manualOwner,
          manual_operation_rebound: manualRebound,
          manual_recovery: manualOwner ? manualRecovery : null,
          auto_run: publicRun(run),
          recovery,
          work_start_watch: workStartWatch,
          auto_watch: owner && run?.status === BridgeAutorunModel.RUN_STATUSES.WAITING_COMMAND ? {
            run_id: run.run_id,
            conversation_key: run.conversation_key,
            origin: run.origin,
            conversation_id: run.conversation_id,
            watch_id: run.watch_id,
            assistant_baseline_ids: Array.isArray(run.assistant_baseline_ids) ? run.assistant_baseline_ids : [],
            status: run.status
          } : null
        };
      }
      case "OZ_EXPORT_CREDENTIALS": {
        const backup = await exportCredentialsBackup();
        await diagnostic("CREDENTIALS_EXPORTED", { backup_version: backup.backup_version, contains_secrets: true });
        return { ok: true, backup };
      }
      case "OZ_IMPORT_CREDENTIALS": {
        const credentialState = await importCredentialsBackup(message.backup);
        await diagnostic("CREDENTIALS_IMPORTED", { backup_version: Number(message.backup?.backup_version || 0), seller_credentials_present: credentialState.seller_credentials_present === true, performance_credentials_present: credentialState.performance_credentials_present === true, legacy_import: credentialState.legacy_import === true });
        if (typeof message.conversation_key === "string" && message.conversation_key.trim()) return { ok: true, state: await publicSettingsState(message.conversation_key) };
        return { ok: true, state: await publicGlobalSettingsState(message.page_context_error || null) };
      }
      case "OZ_CLEAR_CREDENTIALS": {
        await storageRemove([KEYS.SELLER_CLIENT_ID, KEYS.SELLER_API_KEY, KEYS.PERFORMANCE_CLIENT_ID, KEYS.PERFORMANCE_CLIENT_SECRET]);
        OzonProvider.clearPerformanceToken();
        await setStatus({ ok: false, code: "CREDENTIALS_CLEARED", message: "Ozon Seller + Performance credentials удалены из chrome.storage.local." });
        if (typeof message.conversation_key === "string" && message.conversation_key.trim()) return { ok: true, state: await publicSettingsState(message.conversation_key) };
        return { ok: true, state: await publicGlobalSettingsState(message.page_context_error || null) };
      }
      case "OZ_TEST_CONNECTION":
        return await testConnection();
      case "OZ_EXECUTE_COMMAND":
        return await executeManualCommand(String(message.command_text || ""), message.conversation_key, sender, message.manual_request_id, message.command_source);
      case "OZ_BATCH_DELIVERY_INSERT_COMMIT":
        return await commitBatchDeliveryInsert(message, sender);
      case "OZ_BATCH_DELIVERY_INSERTED":
        return await markBatchDeliveryInserted(message, sender);
      case "OZ_BATCH_DELIVERY_COMPLETE":
        return { ok: true, owner: await completeBatchDelivery(message, sender) };
      case "OZ_BATCH_DELIVERY_FAILED":
        return { ok: true, owner: await failBatchDelivery(message, sender) };
      case "OZ_REPORT_DELIVERY_CONFIRMED": {
        const key = normalizeConversationKey(message.conversation_key);
        const senderTabId = Number(sender?.tab?.id || 0);
        if (!Number.isInteger(senderTabId) || senderTabId <= 0) throw Object.assign(new Error("Delivery confirmation пришёл без AI tab."), { code: "DELIVERY_SENDER_TAB_MISSING" });
        const liveIdentity = await assertTabConversation(senderTabId, key);
        await strictBindingForIdentity(liveIdentity);
        await noteConfirmedPrefix(key, message.report_prefix_applied === true, String(message.delivery_id || ""));
        return { ok: true };
      }
      case "OZ_GET_AUTO_RECOVERY": {
        const key = normalizeConversationKey(message.conversation_key);
        const senderTabId = Number(sender?.tab?.id || 0);
        const run = await getAutoRun(key);
        if (!run || run.run_id !== String(message.run_id || "")) return { ok: false, code: "AUTO_RUN_NOT_FOUND", error: "Autorun не найден." };
        const owner = await ownerDecision(run, senderTabId, { allowRebind: true });
        if (!owner.owner) return { ok: false, code: "AUTO_NON_OWNER_TAB", error: "Recovery запрошен не owner-вкладкой." };
        const recovery = await recoveryPayloadForRun(owner.run || run);
        return { ok: true, recovery };
      }
      case "OZ_AUTO_START":
        return { ok: true, run: await startAutoRun(message.conversation_key, message.tab_id) };
      case "OZ_AUTO_START_COMMIT_REQUEST":
        return await commitAutoStart(message, sender);
      case "OZ_AUTO_START_COMPLETE":
        return await completeAutoStart(message, sender);
      case "OZ_AUTO_PAUSE":
        return { ok: true, run: await pauseAutoRun(message.conversation_key) };
      case "OZ_AUTO_RESUME":
        return { ok: true, run: await resumeAutoRun(message.conversation_key, message.tab_id) };
      case "OZ_AUTO_STOP":
        return { ok: true, run: await stopAutoRun(message.conversation_key) };
      case "OZ_AUTO_MESSAGE_READY":
        return await handleAutoMessage(message, sender);
      case "OZ_AUTO_COMMAND_READY":
        return await handleAutoMessage({ ...message, assistant_text: String(message.command_text || "") }, sender);
      case "OZ_AUTO_PREEXEC_ERROR":
        return await handleAutoPreExecutionError(message, sender);
      case "OZ_AUTO_DELIVERY_INSERT_COMMIT":
        return await commitBatchDeliveryInsert(message, sender);
      case "OZ_AUTO_DELIVERY_INSERTED":
        return await markBatchDeliveryInserted(message, sender);
      case "OZ_AUTO_DELIVERY_COMMIT_REQUEST":
        return await commitAutoDelivery(message, sender);
      case "OZ_AUTO_DELIVERY_COMPLETE":
        return { ok: true, run: await completeAutoDelivery(message, sender) };
      case "OZ_AUTO_DELIVERY_FAILED":
        return { ok: true, run: await failAutoDelivery(message, sender) };
      case "OZ_GET_SEND_BUTTON_PROFILE": {
        const data = await storageGet(KEYS.SEND_BUTTON_PROFILE);
        return { ok: true, profile: data[KEYS.SEND_BUTTON_PROFILE] || null };
      }
      case "OZ_SAVE_SEND_BUTTON_PROFILE": {
        const profile = message.profile || null;
        if (!profile || profile.kind !== "bb2_manual_send_button_v1") throw new Error("Invalid send button profile.");
        await storageSet({ [KEYS.SEND_BUTTON_PROFILE]: profile });
        const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*", "https://alice.yandex.ru/*"] }).catch(() => []);
        await Promise.all(tabs.map((tab) => tab.id ? tabMessage(tab.id, { type: "OZ_SET_SEND_BUTTON_PROFILE", profile }).catch(() => null) : null));
        await diagnostic("SEND_BUTTON_PROFILE_SAVED", { kind: profile.kind, tag: profile.tag, testid: profile.testid, aria: profile.aria });
        return { ok: true };
      }
      case "OZ_CLEAR_SEND_BUTTON_PROFILE": {
        await storageSet({ [KEYS.SEND_BUTTON_PROFILE]: null });
        const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*", "https://alice.yandex.ru/*"] }).catch(() => []);
        await Promise.all(tabs.map((tab) => tab.id ? tabMessage(tab.id, { type: "OZ_SET_SEND_BUTTON_PROFILE", profile: null }).catch(() => null) : null));
        await diagnostic("SEND_BUTTON_PROFILE_CLEARED", {});
        return { ok: true };
      }
      case "OZ_GET_MICROPHONE_BUTTON_PROFILE": {
        const data = await storageGet(KEYS.MICROPHONE_BUTTON_PROFILE);
        return { ok: true, profile: data[KEYS.MICROPHONE_BUTTON_PROFILE] || null };
      }
      case "OZ_SAVE_MICROPHONE_BUTTON_PROFILE": {
        const profile = message.profile || null;
        if (!profile || profile.kind !== "bb2_manual_microphone_button_v1") throw new Error("Invalid microphone button profile.");
        await storageSet({ [KEYS.MICROPHONE_BUTTON_PROFILE]: profile });
        const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*", "https://alice.yandex.ru/*"] }).catch(() => []);
        await Promise.all(tabs.map((tab) => tab.id ? tabMessage(tab.id, { type: "OZ_SET_MICROPHONE_BUTTON_PROFILE", profile }).catch(() => null) : null));
        await diagnostic("MICROPHONE_BUTTON_PROFILE_SAVED", { kind: profile.kind, tag: profile.tag, testid: profile.testid, aria: profile.aria });
        return { ok: true };
      }
      case "OZ_CLEAR_MICROPHONE_BUTTON_PROFILE": {
        await storageSet({ [KEYS.MICROPHONE_BUTTON_PROFILE]: null });
        const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*", "https://alice.yandex.ru/*"] }).catch(() => []);
        await Promise.all(tabs.map((tab) => tab.id ? tabMessage(tab.id, { type: "OZ_SET_MICROPHONE_BUTTON_PROFILE", profile: null }).catch(() => null) : null));
        await diagnostic("MICROPHONE_BUTTON_PROFILE_CLEARED", {});
        return { ok: true };
      }
      case "OZ_GET_COPY_BUTTON_PROFILES": {
        const profiles = await getCopyButtonProfiles();
        return { ok: true, profiles, builtin_adapter_count: BB2ManualControls.BUILTIN_MANUAL_COPY_ADAPTER_COUNT };
      }
      case "OZ_SAVE_COPY_BUTTON_PROFILE": {
        const normalized = BB2ManualControls.normalizeCopyButtonProfile(message.profile || null);
        if (!normalized) throw Object.assign(new Error("Invalid Copy button profile."), { code: "INVALID_COPY_BUTTON_PROFILE" });
        const profiles = await saveCopyButtonProfile(normalized);
        await diagnostic("COPY_BUTTON_PROFILE_ADDED", { adapter_id: normalized.adapter_id, testid: normalized.testid || null, aria: normalized.aria || null, custom_profile_count: profiles.profiles.length });
        return { ok: true, profiles, builtin_adapter_count: BB2ManualControls.BUILTIN_MANUAL_COPY_ADAPTER_COUNT };
      }
      case "OZ_CLEAR_COPY_BUTTON_PROFILES": {
        const profiles = await clearCopyButtonProfiles();
        await diagnostic("COPY_BUTTON_PROFILES_CLEARED", { builtin_adapter_count: BB2ManualControls.BUILTIN_MANUAL_COPY_ADAPTER_COUNT });
        return { ok: true, profiles, builtin_adapter_count: BB2ManualControls.BUILTIN_MANUAL_COPY_ADAPTER_COUNT };
      }
      case "OZ_GET_DIAGNOSTICS": {
        const data = await storageGet(KEYS.DIAGNOSTICS);
        return { ok: true, diagnostics: data[KEYS.DIAGNOSTICS] || [] };
      }
      case "OZ_CLEAR_DIAGNOSTICS":
        await storageSet({ [KEYS.DIAGNOSTICS]: [] });
        return { ok: true };
      case "OZ_RECORD_DIAGNOSTIC":
        await diagnostic(String(message.event || "CONTENT_DIAGNOSTIC"), { source: "content_script", tab_id: sender.tab?.id || null, ...(message.details || {}) });
        return { ok: true };
      default:
        return { ok: false, code: "UNKNOWN_MESSAGE", error: "Неизвестная команда расширения." };
    }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  saHandleMessage(message, sender).then(sendResponse).catch(async (error) => {
    const code = String(error?.code || (error?.name === "AbortError" ? "REQUEST_TIMEOUT" : "EXTENSION_ERROR"));
    const text = String(error?.message || error || "Unknown error");
    await diagnostic("EXTENSION_MESSAGE_FAILED", { message_type: String(message?.type || ""), code, error: text, tab_id: sender?.tab?.id || null }, { level: "error" }).catch(() => null);
    sendResponse({ ok: false, code, error: text });
  });
  return true;
});
