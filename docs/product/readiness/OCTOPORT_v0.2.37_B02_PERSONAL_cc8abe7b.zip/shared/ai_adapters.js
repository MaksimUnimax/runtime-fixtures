/* S04-S06 code DOM observed 19 Oct 2026: DeepSeek, Claude, Gemini, Grok.
 * Read-only readers; no composer, Copy click, Send, completion, chat-ID
 * authority or provider activation. Message/parent nodes are local witnesses.
 * DeepSeek/Claude snapshots did not supply persistent message IDs. */
(() => {
  "use strict";
  const EXCLUDED = '[hidden], [aria-hidden="true"], [inert], [contenteditable="true"], [role="dialog"]';
  function rendered(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected ||
        node.isContentEditable || node.closest(EXCLUDED)) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let p = node; p instanceof Element; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse" ||
          s.contentVisibility === "hidden" || Number(s.opacity) === 0) return false;
    }
    return true;
  }
  function editableDescendant(node) {
    return [...node.querySelectorAll("[contenteditable]")].some(n => n.isContentEditable);
  }
  const SPECS = Object.freeze({
    deepseek: {
      origin: "https://chat.deepseek.com",
      message: ".ds-markdown.ds-assistant-message-main-content",
      block: ".md-code-block > pre",
      context(message) {
        const parent = message.parentElement;
        return parent?.matches(".ds-message") && !parent.parentElement?.closest(".ds-message") &&
          parent.querySelectorAll(this.message).length === 1
          ? { parent, witness: "" } : null;
      },
      content(block, message) {
        return block.parentElement?.matches(".md-code-block") &&
          block.parentElement.parentElement === message ? block : null;
      }
    },
    claude: {
      origin: "https://claude.ai",
      message: '[data-testid="assistant-message"]',
      block: "pre.code-block__code",
      context(message) {
        const roles = '[data-testid="assistant-message"], [data-testid="user-message"]';
        if (message.parentElement?.closest(roles) || message.querySelector(roles)) return null;
        const article = message.closest('[role="article"]');
        return article && article.querySelectorAll(roles).length === 1
          ? { parent: article, witness: article.getAttribute("aria-label") || "" } : null;
      },
      content(block, message) {
        const group = block.closest('[role="group"]');
        const codes = [...block.querySelectorAll(":scope > code")];
        return group && message.contains(group) && group.querySelectorAll("pre.code-block__code").length === 1 &&
          codes.length === 1 && block.querySelectorAll("code").length === 1 ? codes[0] : null;
      }
    },
    grok: {
      origin: "https://grok.com",
      message: 'div[data-testid="assistant-message"][role="article"]',
      block: '.response-content-markdown [data-testid="code-block"] pre.shiki',
      context(message) {
        const roles = '[data-testid="assistant-message"], [data-testid="user-message"]';
        const parent = message.parentElement;
        return parent?.matches('div[id^="response-"]') && parent.id.length > 9 &&
          !message.parentElement?.closest(roles) && !message.querySelector(roles) &&
          parent.querySelectorAll(roles).length === 1
          ? { parent, witness: parent.id + "|" + (message.getAttribute("aria-labelledby") || "") } : null;
      },
      content(block, message) {
        const owner = block.closest('[data-testid="code-block"]');
        const codes = [...block.querySelectorAll(":scope > code")];
        return owner && owner.closest(this.message) === message &&
          owner.querySelectorAll("pre.shiki").length === 1 &&
          codes.length === 1 && block.querySelectorAll("code").length === 1 ? codes[0] : null;
      }
    },
    gemini: {
      origin: "https://gemini.google.com",
      message: "model-response",
      block: 'response-container pre > code[data-test-id="code-content"]',
      context(message) {
        const parent = message.parentElement;
        if (!parent?.matches(".conversation-container[id]") || !parent.id ||
            message.closest("user-query") || message.parentElement?.closest("model-response") ||
            message.querySelector("model-response, user-query") ||
            parent.querySelectorAll("model-response").length !== 1) return null;
        return { parent, witness: parent.id };
      },
      content(code, message) {
        const pre = code.parentElement, response = code.closest("response-container");
        return pre?.matches("pre") && pre.querySelectorAll("code").length === 1 &&
          response && response.closest("model-response") === message ? code : null;
      }
    }
  });
  function createReader(spec) {
    const captures = new WeakMap();
    const matchesLocation = () => globalThis.location?.origin === spec.origin;
    function context(message) {
      if (!matchesLocation() || !(message instanceof Element) || !message.matches(spec.message) ||
          !rendered(message)) return null;
      return spec.context(message);
    }
    function blockContext(block, message) {
      const owner = context(message);
      if (!owner || !(block instanceof Element) || !block.matches(spec.block) ||
          block.closest(spec.message) !== message || !rendered(block) || editableDescendant(block)) return null;
      const content = spec.content(block, message);
      if (!content || content.isContentEditable || editableDescendant(content)) return null;
      return { message, content, parent: owner.parent, witness: owner.witness };
    }
    function assistantMessages() {
      return matchesLocation() ? [...document.querySelectorAll(spec.message)].filter(m => context(m)) : [];
    }
    function findCodeBlocks(message) {
      if (!context(message)) return [];
      return [...message.querySelectorAll(spec.block)].filter(block => {
        const c = blockContext(block, message);
        if (!c) return false;
        captures.set(block, { ...c, href: location.href });
        return true;
      });
    }
    function current(block) {
      const old = block instanceof Element ? captures.get(block) : null;
      if (!old || old.href !== location.href) return null;
      const c = blockContext(block, old.message);
      return c && c.content === old.content && c.parent === old.parent && c.witness === old.witness ? c : null;
    }
    return Object.freeze({
      matchesLocation, assistantMessages, findCodeBlocks,
      readCodeText(block) { const c = current(block); return c ? String(c.content.textContent || "") : ""; },
      geometryAnchor(block) { return current(block) ? block : null; }
    });
  }
  const readers = Object.freeze(Object.fromEntries(
    Object.entries(SPECS).map(([id, spec]) => [id, createReader(spec)])
  ));
  globalThis.SellerAgentsObservedAICodeReaders = Object.freeze({
    readers,
    forLocation() { return Object.values(readers).find(r => r.matchesLocation()) || null; }
  });
})();

;
/* Observed Kimi final-code DOM, 19 Oct 2026.
 * Read-only component: no Start/Send, clipboard action, completion inference,
 * identity authority or provider activation. IDs are context-change witnesses.
 * Frozen donor and signed-profile gates stay independent of this reader. */
(() => {
  "use strict";
  const MESSAGE = ".chat-content-item";
  const ASSISTANT = ".chat-content-item.chat-content-item-assistant";
  const USER = ".chat-content-item-user";
  const REASONING = ".thinking-container, .toolcall-content-text";
  const EXCLUDED = '[hidden], [aria-hidden="true"], [inert], [contenteditable="true"], [role="dialog"]';
  const captures = new WeakMap();
  const matchesLocation = () => globalThis.location?.origin === "https://www.kimi.ai";

  function rendered(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected || node.isContentEditable || node.closest(EXCLUDED)) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let parent = node; parent instanceof Element; parent = parent.parentElement) {
      const style = getComputedStyle(parent);
      if (style.display === "none" || style.visibility === "hidden" ||
          style.visibility === "collapse" || style.contentVisibility === "hidden" ||
          Number(style.opacity) === 0) return false;
    }
    return true;
  }

  function eligibleMessage(message) {
    return matchesLocation() && message instanceof Element &&
      message.matches(ASSISTANT) && !message.closest(USER) &&
      !message.parentElement?.closest(MESSAGE) && !message.closest(REASONING) &&
      rendered(message);
  }

  function blockContext(block, message) {
    if (!eligibleMessage(message) || !(block instanceof Element) ||
        !block.matches("pre") || block.closest(MESSAGE) !== message ||
        block.closest(REASONING) || !rendered(block)) return null;
    const content = block.parentElement;
    const segment = block.closest(".segment-code");
    const markdown = block.closest(".markdown-container");
    const final = markdown?.closest(".toolcall-rollup__flat");
    if (!content?.matches(".segment-code-content") || !segment ||
        !markdown?.contains(segment) || !final || !message.contains(final) ||
        final.closest(MESSAGE) !== message) return null;
    const codes = [...block.querySelectorAll(":scope > code")];
    if (codes.length !== 1 || block.querySelectorAll("code").length !== 1 ||
        codes[0].isContentEditable ||
        [...codes[0].querySelectorAll("[contenteditable]")].some(node => node.isContentEditable) ||
        codes[0].querySelector(MESSAGE + ", " + REASONING)) return null;
    return { message, code: codes[0] };
  }

  function assistantMessages() {
    if (!matchesLocation()) return [];
    return [...document.querySelectorAll(ASSISTANT)].filter(eligibleMessage);
  }

  function findCodeBlocks(message) {
    if (!eligibleMessage(message)) return [];
    const blocks = [];
    for (const block of message.querySelectorAll(".segment-code-content > pre")) {
      const context = blockContext(block, message);
      if (!context) continue;
      captures.set(block, {
        ...context,
        href: location.href,
        observedMessageId: message.getAttribute("data-archer-id")
      });
      blocks.push(block);
    }
    return blocks;
  }

  function currentCapture(block) {
    const captured = block instanceof Element ? captures.get(block) : null;
    if (!captured || !matchesLocation() || location.href !== captured.href ||
        captured.message.getAttribute("data-archer-id") !== captured.observedMessageId) return null;
    const current = blockContext(block, captured.message);
    return current?.code === captured.code ? current : null;
  }

  function readCodeText(block) {
    const current = currentCapture(block);
    return current ? String(current.code.textContent || "") : "";
  }

  function geometryAnchor(block) {
    return currentCapture(block) ? block : null;
  }

  globalThis.SellerAgentsKimiCodeReader = Object.freeze({
    assistantMessages, findCodeBlocks, readCodeText, geometryAnchor
  });
})();

;
/* DeepSeek B02 text transport using accepted roots and 09:05 transition.
 * Messages use conservative document-only node witnesses; replacement retires them.
 * Natural completion uses the current assistant's own terminal toolbar and no Stop.
 * Upload readiness follows the observed same-card loading-to-TXT transition.
 * Forced Stop/retry variants remain unobserved; provider bytes are not inferred.
 * No click, execution or signed authority is created here. */
(() => {
  "use strict";
  const ID = "deepseek", ORIGIN = "https://chat.deepseek.com";
  const EDITOR = "textarea[placeholder=\"Сообщение для DeepSeek\"]", ROOT = "div._77cefa5._3d616d3", MESSAGE = ".ds-message";
  const INPUT = "input[type=\"file\"][multiple]", CARD = ".cd314545";
  const CHAT_ROOT = "div.ds-virtual-list.ds-virtual-list--printable._2bd7b35";
  const EXCLUDED = '[hidden],[aria-hidden="true"],[inert],[role="dialog"]';
  const fail = code => { throw Object.assign(new Error(code), {code}); };
  const matchesLocation = () => location.origin === ORIGIN;
  function rendered(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected || node.closest(EXCLUDED)) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let p = node; p instanceof Element; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse" ||
          s.contentVisibility === "hidden" || Number(s.opacity) === 0) return false;
    }
    return true;
  }
  const validName = name => typeof name === "string" && name.length > 4 && name.length <= 255 &&
    !/[\\/\u0000-\u001f]/u.test(name) && /\.txt$/i.test(name);
  function create({readComposerText, setComposerText}) {
    const reader = globalThis.SellerAgentsObservedAICodeReaders.readers[ID];
    function composerContext() {
      if (!matchesLocation()) return null;
      const editors = [...document.querySelectorAll(EDITOR)].filter(n => rendered(n) &&
        !n.closest(MESSAGE) && !n.closest('[aria-disabled="true"]') &&
        (n instanceof HTMLTextAreaElement ? !n.disabled && !n.readOnly : n.isContentEditable));
      if (editors.length !== 1) return null;
      const composer = editors[0], root = composer.closest(ROOT);
      if (!root || !rendered(root) || root.isContentEditable || root.closest(MESSAGE) ||
          root.parentElement?.closest(ROOT) || root.querySelectorAll(EDITOR).length !== 1 ||
          root.querySelectorAll('input[type="file"]').length !== 1 ||
          root.querySelectorAll(INPUT).length !== 1 || root.querySelector(MESSAGE)) return null;
      if (!composer.closest("div._020ab5b") || composer.closest("div._020ab5b").parentElement !== root) return null;
      return {root, composer, form:composer.closest("form"), locationHref:location.href};
    }
    function conversationRoot() {
      const c=composerContext();
      if (!c) return null;
      const roots=[...document.querySelectorAll(CHAT_ROOT)].filter(rendered);
      return roots.length===1 && roots[0].contains(c.root) && c.composer.closest(CHAT_ROOT)===roots[0] ? roots[0] : null;
    }
    function roleOf(node,root) {
      if (!(node instanceof HTMLElement) || !rendered(node) || node.closest(CHAT_ROOT) !== root ||
          node.parentElement?.closest(MESSAGE) || node.querySelector(MESSAGE) ||
          [...node.querySelectorAll("[contenteditable]")].some(n=>n.isContentEditable)) return "";
      const p1=node.parentElement,p2=p1?.parentElement,p3=p2?.parentElement;
      if (!p2?.matches("div.ds-virtual-list-visible-items") || !p3?.matches("div.ds-virtual-list-items._6f2c522")) return "";
      if (node.matches("div.ds-message.d29f3d7d") && p1?.matches("div._9663006")) return "user";
      if (node.matches("div.ds-message:not(.d29f3d7d)") && p1?.matches("div._4f9bf79") &&
          node.querySelector(".ds-markdown.ds-assistant-message-main-content")) return "assistant";
      return "";
    }
    function nativeWitness() { return ""; }
    function bodyText(node,role) {
      if (role==="user") {
        const body=[...node.querySelectorAll(".ds-collapsible-text")].filter(n=>n.closest(MESSAGE)===node && rendered(n));
        return body.length===1 ? body[0].innerText || "" : "";
      }
      return role==="assistant" ? node.innerText || "" : "";
    }
    // These witnesses belong only to this document/root epoch. They are not
    // provider conversation IDs and are never written back into the page.
    // Retiring any previously observed node (including virtualization/remount)
    // retires ALL witnesses, so partial history replacement cannot look like Send.
    let observation=null, sequence=0;
    function observeMessages() {
      const root=conversationRoot();
      if (!root) { observation=null; return {rows:[],ids:new Map()}; }
      const rows=[...root.querySelectorAll(MESSAGE)].map(node=>{
        const role=roleOf(node,root);
        return {node,role,native:nativeWitness(node,role),text:role==="user"?bodyText(node,role):null};
      }).filter(row=>row.role);
      const retained=observation && observation.root===root && observation.href===location.href &&
        observation.rows.every((old,i)=>rows[i]?.node===old.node && rows[i].role===old.role &&
          rows[i].native===old.native && rows[i].text===old.text);
      if (!retained) { observation={root,href:location.href,epoch:crypto.randomUUID(),rows:[],nodes:new WeakMap()}; sequence=0; }
      const ids=new Map();
      for (const row of rows) {
        if (!observation.nodes.has(row.node)) observation.nodes.set(row.node,++sequence);
        const local=row.role+":node-"+observation.nodes.get(row.node);
        if (local) ids.set(row.node,"local:"+observation.epoch+":"+local);
      }
      observation.rows=rows;
      return {rows,ids};
    }
    function userMessages() { return observeMessages().rows.filter(r=>r.role==="user").map(r=>r.node); }
    function assistantMessages() {
      const eligible=new Set(reader.assistantMessages());
      return observeMessages().rows.filter(r=>r.role==="assistant" && eligible.has(r.node.querySelector(".ds-markdown.ds-assistant-message-main-content"))).map(r=>r.node);
    }
    function messageId(node) { return observeMessages().ids.get(node) || ""; }
    function messageObservationEpoch() { observeMessages(); return observation?.epoch || ""; }
    function messageText(node) {
      const root=conversationRoot(),role=root ? roleOf(node,root) : "";
      return role ? bodyText(node,role) : "";
    }
    function currentContext(context) {
      if (!context || context.locationHref !== location.href) return null;
      const fresh = composerContext();
      return fresh && fresh.root === context.root && fresh.composer === context.composer ? fresh : null;
    }
    function cards(root) {
      return [...root.querySelectorAll(CARD)].filter(n => !n.closest(MESSAGE) && rendered(n));
    }
    const validDescriptor = d => validName(d?.filename) && Number.isSafeInteger(d.byte_length) &&
      d.byte_length >= 0 && d.byte_length <= 1024 * 1024;
    function cardDetails(card) {
      if (!(card instanceof HTMLElement) || !rendered(card) ||
          card.querySelector('[data-icon="spin"],.ds-loading,svg[role="img"][aria-label],[role="progressbar"],[aria-busy="true"],[role="alert"]')) return null;
      const names=card.querySelectorAll(".e70accd6"), types=card.querySelectorAll("._7103a25");
      if (names.length!==1 || types.length!==1 || !rendered(names[0]) || !rendered(types[0]) ||
          !validName(names[0].textContent) || !/^TXT\s+\d+(?:\.\d+)?(?:B|KB|MB)$/.test(types[0].textContent.trim())) return null;
      return {filename:names[0].textContent};
    }
    function stagedReadyCard(c) {
      if (!c || c.root.querySelectorAll(CARD).length!==1) return null;
      const card=cards(c.root)[0], branch=card?.closest("div.b40079d7._2113217");
      if (!branch || branch.parentElement!==c.root || !cardDetails(card) ||
          card.querySelectorAll('div._8402d8c[tabindex="0"]').length!==1) return null;
      const files=c.root.querySelector(INPUT)?.files;
      if (files?.length && (files.length!==1 || files[0].name!==cardDetails(card).filename)) return null;
      return card;
    }
    function attachmentReady(descriptors) {
      if (!Array.isArray(descriptors) || descriptors.length!==1 || !validDescriptor(descriptors[0])) return false;
      const c=composerContext(),card=stagedReadyCard(c),d=descriptors[0];
      if (!card || cardDetails(card).filename!==d.filename ||
          !["send_active","send_disabled"].includes(classify(c).kind)) return false;
      const files=c.root.querySelector(INPUT)?.files;
      return !files?.length || (files.length===1 && files[0].name===d.filename && files[0].size===d.byte_length);
    }
    function sentAttachmentMessage(node,descriptors) {
      const root=conversationRoot();
      if (!root || roleOf(node,root)!=="user" || !messageId(node) ||
          !Array.isArray(descriptors) || descriptors.length!==1 || !validDescriptor(descriptors[0])) return null;
      const found=[...node.querySelectorAll(CARD)];
      if (found.length!==1 || found[0].closest(MESSAGE)!==node ||
          found[0].closest(".eafda4ae")?.parentElement!==node ||
          found[0].querySelector("._8402d8c") || cardDetails(found[0])?.filename!==descriptors[0].filename) return null;
      const bodies=[...node.querySelectorAll(".ds-collapsible-text")].filter(n=>n.closest(MESSAGE)===node && rendered(n));
      if (bodies.length!==1 || bodies[0].contains(found[0])) return null;
      return Object.freeze({text:bodyText(node,"user")});
    }
    function controls(context) {
      const c = currentContext(context);
      return c ? [...c.root.querySelectorAll("div[role=\"button\"].ds-button")].filter(n => !n.closest(MESSAGE) && rendered(n)) : [];
    }
    function classify(context) {
      const c = currentContext(context);
      if (!c) return {kind:"unknown",button:null};
      if (c.root.querySelector('[data-icon="spin"],[role="progressbar"],[aria-busy="true"]')) return {kind:"busy",button:null};
      const all = controls(c), sends = all.filter(n => n.matches(".ds-button--primary._52c986b"));
      if (sends.length !== 1) return {kind:"unknown",button:null};
      const button = sends[0], paths = button.querySelectorAll("svg path");
      if (paths.length === 1 && paths[0].getAttribute("d") === "M2 4.88C2 3.68009 2 3.08013 2.30557 2.65954C2.40426 2.52371 2.52371 2.40426 2.65954 2.30557C3.08013 2 3.68009 2 4.88 2H11.12C12.3199 2 12.9199 2 13.3405 2.30557C13.4763 2.40426 13.5957 2.52371 13.6944 2.65954C14 3.08013 14 3.68009 14 4.88V11.12C14 12.3199 14 12.9199 13.6944 13.3405C13.5957 13.4763 13.4763 13.5957 13.3405 13.6944C12.9199 14 12.3199 14 11.12 14H4.88C3.68009 14 3.08013 14 2.65954 13.6944C2.52371 13.5957 2.40426 13.4763 2.30557 13.3405C2 12.9199 2 12.3199 2 11.12V4.88Z")
        return {kind:"stop",button};
      if (paths.length !== 1 || paths[0].getAttribute("d") !== "M8.3125 0.980206C8.66767 1.05312 8.97902 1.2042 9.2627 1.43235C9.48724 1.613 9.73029 1.85795 9.97949 2.10716L14.707 6.8347L13.293 8.24876L9 3.95579V15.0417H7V3.95579L2.70703 8.24876L1.29297 6.8347L6.02051 2.10716C6.26971 1.85795 6.51277 1.613 6.7373 1.43235C6.97662 1.23988 7.28445 1.04404 7.6875 0.980206C7.8973 0.947029 8.1031 0.955183 8.3125 0.980206Z") return {kind:"unknown",button:null};
      const disabled = button.classList.contains("ds-button--disabled") || button.getAttribute("aria-disabled") === "true";
      const staged=c.root.querySelectorAll(CARD).length>0;
      if (staged ? !stagedReadyCard(c) : c.root.querySelector(INPUT)?.files?.length)
        return {kind:"unknown",button:null};
      if (staged && !disabled && button.getAttribute("tabindex")!=="0") return {kind:"unknown",button:null};
      if (!staged && !readComposerText(c.composer).trim()) return {kind:"ready",button:null};
      // Only the observed arrow permits text Send; spinner and square Stop do not.
      return {kind:disabled ? "send_disabled" : "send_active",button};
    }
    function completionObservation(node) {
      const unknown = (reason, actionsObserved=false) => Object.freeze({
        status:"unknown", reason, actionsObserved
      });
      const assistants=assistantMessages();
      if (!assistants.includes(node) || assistants.at(-1)!==node || !messageId(node) ||
          !messageText(node).trim()) return unknown("current_assistant_not_owned");
      const rows=observeMessages().rows;
      const lastUser=rows.findLastIndex(row=>row.role==="user");
      // An older completed answer is not the response to a newer submitted turn.
      if (lastUser<0 || rows.findIndex(row=>row.node===node)<=lastUser)
        return unknown("current_user_response_not_observed");
      const state=classify(composerContext());
      if (!["ready","send_active","send_disabled"].includes(state.kind))
        return unknown("composer_busy_or_unknown");
      const parent=node.parentElement, toolbar=node.nextElementSibling;
      if (!parent.matches("div._4f9bf79._43c05b5") || parent.children.length!==2 || parent.firstElementChild!==node ||
          !toolbar?.matches("div.ds-flex._0a3d93b") || !rendered(toolbar) ||
          toolbar.querySelector(MESSAGE)) return unknown("terminal_actions_not_observed");
      const group=toolbar.firstElementChild;
      if (!group?.matches("div.ds-flex._965abe9._54866f7") || !rendered(group))
        return unknown("terminal_actions_not_observed");
      const buttons=[...group.children];
      if (buttons.length!==6 || toolbar.querySelectorAll('[role="button"]').length!==6 ||
          buttons.some(n=>!n.matches('div.ds-button.db183363[role="button"][tabindex="0"]') ||
            !rendered(n) || n.getAttribute("aria-disabled")==="true" || n.matches(":disabled") ||
            n.classList.contains("ds-button--disabled") || getComputedStyle(n).pointerEvents==="none") ||
          buttons[1].getAttribute("aria-disabled")!=="false" ||
          buttons[4].getAttribute("aria-label")!=="Читать вслух" ||
          buttons.filter(n=>n.getAttribute("aria-label")==="Читать вслух").length!==1)
        return unknown("terminal_actions_not_observed");
      // Same-assistant 09:05 snapshots show no own toolbar with square Stop,
      // then this terminal structure and the Send arrow after natural completion.
      // No dependency on snapshot key14, capture text or inferred icon functions.
      return Object.freeze({status:"complete",reason:"observed_natural_terminal_toolbar",actionsObserved:true});
    }
    function attachmentPreview(filename) {
      const c = composerContext();
      if (!c || !validName(filename)) return null;
      const list = cards(c.root);
      if (list.length !== 1) return null;
      const name = list[0].querySelectorAll(".e70accd6"), type = list[0].querySelectorAll("._7103a25");
      return name.length === 1 && type.length === 1 && name[0].textContent === filename &&
        /^TXT(?:\s|$)/.test(type[0].textContent.trim()) ? list[0] : null;
    }
    function attachmentSurface() {
      const c = composerContext();
      if (!c || !["ready","send_disabled"].includes(classify(c).kind) ||
          readComposerText(c.composer).trim() || cards(c.root).length) return null;
      const input = c.root.querySelector(INPUT);
      if (!(input instanceof HTMLInputElement) || !input.isConnected || !input.multiple ||
          input.disabled || input.matches(":disabled") || input.files?.length ||
          input.getAttribute("aria-disabled") === "true" || input.closest(EXCLUDED) ||
          !((input.getAttribute("accept") || "").toLowerCase().split(",").map(s=>s.trim()).includes(".txt"))) return null;
      return {kind:"file_input_v1",input,root:c.root,locationHref:c.locationHref};
    }
    return Object.freeze({
      id:ID, label:"DeepSeek", matchesLocation, composerContext,
      classifyComposerControl:classify, allComposerControls:controls,
      readComposerText(composer) { return composerContext()?.composer === composer ? readComposerText(composer) : ""; },
      setComposerText(composer,value) {
        const c = composerContext();
        if (!c || c.composer !== composer || !["ready","send_active","send_disabled"].includes(classify(c).kind))
          fail("COMPOSER_NOT_AVAILABLE");
        setComposerText(composer,value);
        if (!currentContext(c) || readComposerText(composer) !== String(value || "")) fail("COMPOSER_CONTEXT_CHANGED");
      },
      sendButtonCandidates(context) {
        const s = classify(context);
        return s.kind === "send_active" ? [{button:s.button,score:2000}] : [];
      },
      sendButton(context) { return this.sendButtonCandidates(context)[0]?.button || null; },
      sendButtonFingerprint(button) {
        const s = classify(composerContext());
        return s.button === button && button instanceof HTMLElement ?
          [button.tagName,button.getAttribute("data-testid") || "",button.getAttribute("aria-label") || "","observed_arrow"].join("|") : "";
      },
      isGenerating() { return ["stop","busy","unknown"].includes(classify(composerContext()).kind); },
      conversationRoot, userMessages, assistantMessages, messageId, messageText, messageObservationEpoch,
      findCodeBlocks(node) {
        if (!assistantMessages().includes(node)) return [];
        return reader.findCodeBlocks(node.querySelector(".ds-markdown.ds-assistant-message-main-content"));
      },
      readCodeText:reader.readCodeText, geometryAnchor:reader.geometryAnchor,
      completionObservation,
      messageComplete(node) { return completionObservation(node).status==="complete"; },
      deliveryCapabilities() { return globalThis.OzonAIDeliveryCapabilities?.profile?.("deepseek") || null; },
      attachmentSurface, attachmentPreview,
      attachFiles(surface,files) {
        const c = attachmentSurface();
        if (!c || c.input !== surface?.input || c.root !== surface?.root ||
            c.locationHref !== surface?.locationHref || c.kind !== surface?.kind)
          fail("TARGET_AI_ATTACHMENT_SURFACE_UNAVAILABLE");
        if (!Array.isArray(files) || files.length !== 1 || !(files[0] instanceof File) ||
            !validName(files[0].name) || files[0].size > 1024 * 1024 || !["","text/plain"].includes(files[0].type))
          fail("TARGET_AI_FILE_TYPE_UNSUPPORTED");
        return globalThis.OzonWebFileAttachment.setInputFiles(c.input,files);
      },
      // Readiness and a new owned sent-card witness are separate checks.
      attachmentReady, sentAttachmentMessage,
      integrationStatus() {
        return Object.freeze({status:"implemented",message_identity:"document_scoped_nodes",
          assistant_completion:"observed_natural_terminal_toolbar",
          upload_end:"observed_same_card_status_transition",registry_activated:true});
      }
    });
  }
  globalThis.SellerAgentsDeepSeekAdapter = Object.freeze({create});
})();

;
/* Claude B02 text adapter using accepted 19 Oct controls and 20 Oct 07:05 parents.
 * Native turn/user-parent IDs are document-scoped witnesses, not permanent chat IDs.
 * Upload readiness uses the observed pending/Skeleton-to-CardLink transition.
 * Sent-file confirmation is scoped to one observed user article, not the composer.
 * No click, execution or signed authority is created here. */
(() => {
  "use strict";
  const ID = "claude", ORIGIN = "https://claude.ai";
  const EDITOR = "[data-testid=\"chat-input\"][contenteditable=\"true\"][role=\"textbox\"]", ROOT = "div.flex.w-full.min-w-0.flex-col", MESSAGE = "[data-testid=\"user-message\"],[data-testid=\"assistant-message\"]";
  const INPUT = "input[type=\"file\"][data-testid=\"file-upload\"]#chat-input-file-upload-bottom", CARD = "[data-testid=\"file-thumbnail\"]";
  const CHAT_ROOT = "[data-testid=\"chat-column\"]";
  const EXCLUDED = '[hidden],[aria-hidden="true"],[inert],[role="dialog"]';
  const fail = code => { throw Object.assign(new Error(code), {code}); };
  const matchesLocation = () => location.origin === ORIGIN;
  function rendered(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected || node.closest(EXCLUDED)) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let p = node; p instanceof Element; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse" ||
          s.contentVisibility === "hidden" || Number(s.opacity) === 0) return false;
    }
    return true;
  }
  const validName = name => typeof name === "string" && name.length > 4 && name.length <= 255 &&
    !/[\\/\u0000-\u001f]/u.test(name) && /\.txt$/i.test(name);
  function create({readComposerText, setComposerText}) {
    const reader = globalThis.SellerAgentsObservedAICodeReaders.readers[ID];
    function composerContext() {
      if (!matchesLocation()) return null;
      const editors = [...document.querySelectorAll(EDITOR)].filter(n => rendered(n) &&
        !n.closest(MESSAGE) && !n.closest('[aria-disabled="true"]') &&
        (n instanceof HTMLTextAreaElement ? !n.disabled && !n.readOnly : n.isContentEditable));
      if (editors.length !== 1) return null;
      const composer = editors[0], semantic = composer.closest('[data-cds="ChatComposer"]'), root = semantic || composer.closest(ROOT);
      if (!root || !rendered(root) || root.isContentEditable || root.closest(MESSAGE) ||
          (!semantic && root.parentElement?.closest(ROOT)) || root.querySelectorAll(EDITOR).length !== 1 ||
          root.querySelectorAll('[data-cds="ChatComposer"]').length ||
          root.querySelectorAll('input[type="file"]').length > 1 ||
          (!semantic && root.querySelectorAll(INPUT).length !== 1) ||
          (root.querySelectorAll('input[type="file"]').length && root.querySelectorAll(INPUT).length !== 1) ||
          root.querySelector(MESSAGE)) return null;
      
      return {root, composer, form:composer.closest("form"), locationHref:location.href};
    }
    function conversationRoot() {
      const c=composerContext();
      if (!c) return null;
      const roots=[...document.querySelectorAll(CHAT_ROOT)].filter(rendered);
      return roots.length===1 && roots[0].contains(c.root) && c.composer.closest(CHAT_ROOT)===roots[0] ? roots[0] : null;
    }
    function roleOf(node,root) {
      if (!(node instanceof HTMLElement) || !rendered(node) || node.closest(CHAT_ROOT) !== root ||
          node.parentElement?.closest(MESSAGE) || node.querySelector(MESSAGE) ||
          [...node.querySelectorAll("[contenteditable]")].some(n=>n.isContentEditable)) return "";
      const p1=node.parentElement,p2=p1?.parentElement,p3=p2?.parentElement;
      if (node.matches('[data-testid="user-message"]') && p1?.matches("div.cds-user-message-body") &&
          p2?.matches("div[id]") && p3?.matches("div.relative.flex.min-w-0.flex-col.gap-xs")) return "user";
      if (node.matches('[data-testid="assistant-message"]') && p1?.classList.contains("group") &&
          p1?.classList.contains("group/message-row") && p2?.matches("div.mt-xs") && p3?.matches("div.contents")) return "assistant";
      return "";
    }
    function nativeWitness(node,role) {
      const value=role==="assistant" ? node.getAttribute("data-turn-key") : node.parentElement?.parentElement?.id;
      if (typeof value!=="string" || value.length>180 || /[\s|\u0000-\u001f]/u.test(value)) return "";
      if (role==="assistant" ? !/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(value) : !/^_r_[A-Za-z0-9_-]+_$/.test(value)) return "";
      return role+":"+value;
    }
    function bodyText(node,role) {
      if (role==="user") return node.innerText || "";
      return role==="assistant" ? node.innerText || "" : "";
    }
    // These witnesses belong only to this document/root epoch. They are not
    // provider conversation IDs and are never written back into the page.
    // Retiring any previously observed node (including virtualization/remount)
    // retires ALL witnesses, so partial history replacement cannot look like Send.
    let observation=null, sequence=0;
    function observeMessages() {
      const root=conversationRoot();
      if (!root) { observation=null; return {rows:[],ids:new Map()}; }
      const rows=[...root.querySelectorAll(MESSAGE)].map(node=>{
        const role=roleOf(node,root);
        return {node,role,native:nativeWitness(node,role),text:role==="user"?bodyText(node,role):null};
      }).filter(row=>row.role);
      const retained=observation && observation.root===root && observation.href===location.href &&
        observation.rows.every((old,i)=>rows[i]?.node===old.node && rows[i].role===old.role &&
          (rows[i].native===old.native || (old.role==="assistant" && !old.native)) && rows[i].text===old.text);
      if (!retained) { observation={root,href:location.href,epoch:crypto.randomUUID(),rows:[],nodes:new WeakMap()}; sequence=0; }
      const ids=new Map();
      for (const row of rows) {
        if (!observation.nodes.has(row.node)) observation.nodes.set(row.node,++sequence);
        const local=row.native && rows.filter(other=>other.native===row.native).length===1 ? row.native : "";
        if (local) ids.set(row.node,"local:"+observation.epoch+":"+local);
      }
      observation.rows=rows;
      return {rows,ids};
    }
    function userMessages() { return observeMessages().rows.filter(r=>r.role==="user").map(r=>r.node); }
    function assistantMessages() {
      const eligible=new Set(reader.assistantMessages());
      return observeMessages().rows.filter(r=>r.role==="assistant" && eligible.has(r.node)).map(r=>r.node);
    }
    function messageId(node) { return observeMessages().ids.get(node) || ""; }
    function messageObservationEpoch() { observeMessages(); return observation?.epoch || ""; }
    function messageText(node) {
      const root=conversationRoot(),role=root ? roleOf(node,root) : "";
      return role ? bodyText(node,role) : "";
    }
    function currentContext(context) {
      if (!context || context.locationHref !== location.href) return null;
      const fresh = composerContext();
      return fresh && fresh.root === context.root && fresh.composer === context.composer ? fresh : null;
    }
    function cards(root) {
      return [...root.querySelectorAll(CARD)].filter(n => !n.closest(MESSAGE) && rendered(n));
    }
    const validDescriptor = d => validName(d?.filename) && Number.isSafeInteger(d.byte_length) &&
      d.byte_length >= 0 && d.byte_length <= 1024 * 1024;
    function inputContext(c) {
      // The observed file input may be a sibling of the semantic ChatComposer.
      // Only the prior observed LCA shape with one editor/input and no messages qualifies.
      for (let root=c?.root; root instanceof HTMLElement && root!==document.body; root=root.parentElement) {
        if (root.matches(CHAT_ROOT) || root.closest(EXCLUDED) || root.closest(MESSAGE) || root.closest('[role="article"]')) return null;
        if (!root.matches(ROOT)) continue;
        if (root.querySelector(MESSAGE) || root.querySelectorAll(EDITOR).length!==1 ||
            root.querySelector(EDITOR)!==c.composer) return null;
        const inputs=root.querySelectorAll('input[type="file"]');
        if (inputs.length>1) return null;
        if (inputs.length===1) return inputs[0].matches(INPUT) ? {root,input:inputs[0]} : null;
      }
      return null;
    }
    function cardDetails(card) {
      if (!(card instanceof HTMLElement) || !rendered(card) ||
          card.matches('[data-state="pending"],[aria-busy="true"]') ||
          card.querySelector('[data-state="pending"],[aria-busy="true"],[data-cds="Skeleton"],[role="progressbar"],[role="alert"]')) return null;
      const names=card.querySelectorAll('[data-cds="CardLink"][title]'),badges=card.querySelectorAll('[data-cds="Badge"]');
      if (names.length!==1 || badges.length!==1 || !validName(names[0].getAttribute("title")) ||
          names[0].getAttribute("role")!=="button" || names[0].getAttribute("tabindex")!=="0" ||
          !rendered(badges[0]) || badges[0].closest(".invisible") || badges[0].textContent.trim()!=="TXT") return null;
      return {filename:names[0].getAttribute("title")};
    }
    function stagedReadyCard(c) {
      if (!c || c.root.querySelectorAll(CARD).length!==1) return null;
      const card=cards(c.root)[0],branch=card?.closest("[data-cds-composer-attachments]"),detail=cardDetails(card);
      if (!branch || !c.root.contains(branch) || branch.closest('[data-cds="ChatComposer"]')!==c.root ||
          !card.matches('[data-cds="MessageAttachmentsFile"]') || card.hasAttribute("data-state") ||
          !detail || card.querySelectorAll("button[data-cds-attachment-remove]").length!==1) return null;
      const remove=card.querySelector("button[data-cds-attachment-remove]");
      if (remove.getAttribute("aria-label")!=="Удалить: "+detail.filename) return null;
      const files=inputContext(c)?.input.files;
      if (files?.length && (files.length!==1 || files[0].name!==detail.filename)) return null;
      return card;
    }
    function attachmentReady(descriptors) {
      if (!Array.isArray(descriptors) || descriptors.length!==1 || !validDescriptor(descriptors[0])) return false;
      const c=composerContext(),card=stagedReadyCard(c),d=descriptors[0];
      if (!card || cardDetails(card).filename!==d.filename ||
          !["send_active","send_disabled"].includes(classify(c).kind)) return false;
      const files=inputContext(c)?.input.files;
      return !files?.length || (files.length===1 && files[0].name===d.filename && files[0].size===d.byte_length);
    }
    function sentAttachmentMessage(node,descriptors) {
      const root=conversationRoot();
      if (!root || roleOf(node,root)!=="user" || !messageId(node) ||
          !Array.isArray(descriptors) || descriptors.length!==1 || !validDescriptor(descriptors[0])) return null;
      const article=node.closest('[role="article"]');
      if (!article || !rendered(article) || article.closest(CHAT_ROOT)!==root ||
          article.querySelectorAll(MESSAGE).length!==1 || article.querySelector(MESSAGE)!==node ||
          article.querySelector('[role="article"],[contenteditable="true"],[data-cds="ChatComposer"]')) return null;
      const found=article.querySelectorAll(CARD);
      if (found.length!==1 || !rendered(found[0]) || node.contains(found[0]) ||
          found[0].closest('[role="article"]')!==article ||
          found[0].closest("[data-cds-composer-attachments]") ||
          found[0].matches('[data-state="pending"],[aria-busy="true"]') ||
          found[0].querySelector('[data-cds-attachment-remove],[aria-busy="true"],[data-cds="Skeleton"],[role="progressbar"],[role="alert"]')) return null;
      let name=cardDetails(found[0])?.filename;
      // Earlier accepted S08 completed card used a button/h3/TXT badge.
      if (!name && found[0].classList.contains("group/thumbnail")) {
        const buttons=found[0].querySelectorAll('button[type="button"]'),names=found[0].querySelectorAll("h3"),
          types=found[0].querySelectorAll("p.uppercase");
        if (buttons.length!==1 || names.length!==1 || types.length!==1 ||
            !buttons[0].contains(names[0]) || !buttons[0].contains(types[0]) ||
            !rendered(names[0]) || !rendered(types[0]) || types[0].textContent.trim().toUpperCase()!=="TXT") return null;
        name=names[0].textContent;
      }
      return name===descriptors[0].filename ? Object.freeze({text:bodyText(node,"user")}) : null;
    }
    function controls(context) {
      const c = currentContext(context);
      return c ? [...c.root.querySelectorAll("button")].filter(n => !n.closest(MESSAGE) && rendered(n)) : [];
    }
    function classify(context) {
      const c = currentContext(context);
      if (!c) return {kind:"unknown",button:null};
      const stops = [...document.querySelectorAll('button[data-testid="chat-input-stop"][aria-label="Остановить ответ"]')]
        .filter(n => !n.closest(MESSAGE) && rendered(n));
      if (stops.length) return {kind:stops.length === 1 ? "stop" : "unknown",
        button:stops.length === 1 && c.root.contains(stops[0]) ? stops[0] : null};
      // Busy was observed with a missing data-is-streaming attribute.
      // Only explicit false clears this signal; absence is not idle evidence.
      const assistantStates = [...document.querySelectorAll('[data-testid="assistant-message"]')].filter(rendered);
      if (assistantStates.some(n => n.getAttribute("data-is-streaming") === "true")) return {kind:"busy",button:null};
      if (assistantStates.some(n => n.getAttribute("data-is-streaming") !== "false")) return {kind:"unknown",button:null};
      if (c.root.querySelector('[role="progressbar"],[aria-busy="true"],[data-state="pending"],[data-cds="Skeleton"]')) return {kind:"busy",button:null};
      const staged=c.root.querySelectorAll(CARD).length>0;
      if (staged ? !stagedReadyCard(c) : inputContext(c)?.input.files?.length) return {kind:"unknown",button:null};
      const sends = controls(c).filter(n => n.matches('button[data-testid="chat-input-send"][aria-label="Отправить сообщение"]'));
      if (sends.length !== 1) return {kind:"unknown",button:null};
      const button = sends[0], disabled = button.disabled || button.matches(":disabled") ||
        button.getAttribute("aria-disabled") === "true" || button.hasAttribute("data-disabled");
      if (!staged && !readComposerText(c.composer).trim()) return {kind:"ready",button:null};
      return {kind:disabled ? "send_disabled" : "send_active",button};
    }
    function attachmentPreview(filename) {
      const c = composerContext();
      if (!c || !validName(filename)) return null;
      const list = cards(c.root);
      if (list.length !== 1) return null;
      const names = list[0].querySelectorAll('[data-cds="CardLink"][title]'),
        badges = list[0].querySelectorAll('[data-cds="Badge"]');
      return names.length === 1 && badges.length === 1 && names[0].getAttribute("title") === filename &&
        badges[0].textContent.trim() === "TXT" ? list[0] : null;
    }
    function attachmentSurface() {
      const c = composerContext();
      if (!c || !["ready","send_disabled"].includes(classify(c).kind) ||
          readComposerText(c.composer).trim() || cards(c.root).length) return null;
      const selected=inputContext(c), input=selected?.input;
      if (!(input instanceof HTMLInputElement) || !input.isConnected || !input.multiple ||
          input.disabled || input.matches(":disabled") || input.files?.length ||
          input.getAttribute("aria-disabled") === "true" || input.closest(EXCLUDED) ||
          !(input.getAttribute("accept") === "")) return null;
      return {kind:"file_input_v1",input,root:c.root,inputRoot:selected.root,locationHref:c.locationHref};
    }
    return Object.freeze({
      id:ID, label:"Claude", matchesLocation, composerContext,
      classifyComposerControl:classify, allComposerControls:controls,
      readComposerText(composer) { return composerContext()?.composer === composer ? readComposerText(composer) : ""; },
      setComposerText(composer,value) {
        const c = composerContext();
        if (!c || c.composer !== composer || !["ready","send_active","send_disabled"].includes(classify(c).kind))
          fail("COMPOSER_NOT_AVAILABLE");
        setComposerText(composer,value);
        if (!currentContext(c) || readComposerText(composer) !== String(value || "")) fail("COMPOSER_CONTEXT_CHANGED");
      },
      sendButtonCandidates(context) {
        const s = classify(context);
        return s.kind === "send_active" ? [{button:s.button,score:2000}] : [];
      },
      sendButton(context) { return this.sendButtonCandidates(context)[0]?.button || null; },
      sendButtonFingerprint(button) {
        const s = classify(composerContext());
        return s.button === button && button instanceof HTMLElement ?
          [button.tagName,button.getAttribute("data-testid") || "",button.getAttribute("aria-label") || "",button.type].join("|") : "";
      },
      isGenerating() { return ["stop","busy","unknown"].includes(classify(composerContext()).kind); },
      conversationRoot, userMessages, assistantMessages, messageId, messageText, messageObservationEpoch,
      findCodeBlocks:reader.findCodeBlocks, readCodeText:reader.readCodeText, geometryAnchor:reader.geometryAnchor,
      messageComplete(node) {
        return assistantMessages().includes(node) && Boolean(messageId(node)) &&
          node.getAttribute("data-is-streaming")==="false" &&
          ["ready","send_active","send_disabled"].includes(classify(composerContext()).kind) &&
          Boolean(messageText(node).trim());
      },
      deliveryCapabilities() { return globalThis.OzonAIDeliveryCapabilities?.profile?.("claude") || null; },
      attachmentSurface, attachmentPreview,
      attachFiles(surface,files) {
        const c = attachmentSurface();
        if (!c || c.input !== surface?.input || c.root !== surface?.root || c.inputRoot !== surface?.inputRoot ||
            c.locationHref !== surface?.locationHref || c.kind !== surface?.kind)
          fail("TARGET_AI_ATTACHMENT_SURFACE_UNAVAILABLE");
        if (!Array.isArray(files) || files.length !== 1 || !(files[0] instanceof File) ||
            !validName(files[0].name) || files[0].size > 1024 * 1024 || !["","text/plain"].includes(files[0].type))
          fail("TARGET_AI_FILE_TYPE_UNSUPPORTED");
        return globalThis.OzonWebFileAttachment.setInputFiles(c.input,files);
      },
      // Readiness and a new owned sent-card witness are separate checks.
      attachmentReady, sentAttachmentMessage,
      integrationStatus() {
        return Object.freeze({status:"implemented",message_identity:"document_scoped_native_witness",
          upload_end:"observed_pending_skeleton_transition",registry_activated:true});
      }
    });
  }
  globalThis.SellerAgentsClaudeAdapter = Object.freeze({create});
})();

;
/* Grok B02 DOM adapter: accepted S08 and 11:30-11:31 observations.
 * response-* is a local message witness, never a permanent chat ID.
 * Busy common ancestry was not captured; a visible native Stop excludes
 * sending even if outside the retained idle root. No click or authority here. */
(() => {
  "use strict";
  const ORIGIN = "https://grok.com";
  const ROOT = "div.flex.flex-col.gap-0.justify-center.w-full.relative.items-center";
  const EDITOR = '[data-testid="chat-input"] .tiptap.ProseMirror[role="textbox"][contenteditable="true"]';
  const MESSAGE = 'div[id^="response-"]';
  const ROLES = '[data-testid="user-message"],[data-testid="assistant-message"]';
  const LIST = '[role="list"][aria-label="Вложения в беседе"]';
  const STOP = "Остановить ответ модели";
  const EXCLUDED = '[hidden],[aria-hidden="true"],[inert],[role="dialog"]';
  const matchesLocation = () => location.origin === ORIGIN;
  const fail = code => { throw Object.assign(new Error(code), { code }); };
  function rendered(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected || node.closest(EXCLUDED)) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let p = node; p instanceof Element; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse" ||
          s.contentVisibility === "hidden" || Number(s.opacity) === 0) return false;
    }
    return true;
  }
  const txt = d => typeof d?.filename === "string" && d.filename.length > 4 && d.filename.length <= 255 &&
    !/[\\/\u0000-\u001f]/u.test(d.filename) && /\.txt$/i.test(d.filename) &&
    Number.isSafeInteger(d.byte_length) && d.byte_length >= 0 && d.byte_length <= 1024 * 1024;
  function create({ readComposerText, setComposerText }) {
    const reader = globalThis.SellerAgentsObservedAICodeReaders.readers.grok;
    function roleNode(node, role) {
      if (!matchesLocation() || !(node instanceof HTMLElement) || !node.matches(MESSAGE) ||
          !rendered(node) || node.isContentEditable || node.parentElement?.closest(MESSAGE) ||
          node.querySelector(MESSAGE) ||
          [...node.querySelectorAll("[contenteditable]")].some(n => n.isContentEditable)) return null;
      const roles = [...node.querySelectorAll(ROLES)];
      return roles.length === 1 && roles[0].parentElement === node &&
        roles[0].matches('div[role="article"][data-testid="'+role+'-message"]') && rendered(roles[0]) ? roles[0] : null;
    }
    const userMessages = () => [...document.querySelectorAll(MESSAGE)].filter(n => roleNode(n,"user"));
    const assistantMessages = () => {
      const eligible = new Set(reader.assistantMessages());
      return [...document.querySelectorAll(MESSAGE)].filter(n => eligible.has(roleNode(n,"assistant")));
    };
    function messageId(node) {
      if (!roleNode(node,"user") && !roleNode(node,"assistant")) return "";
      const id = node.id;
      return id.length > 9 && id.length <= 256 && !/[\s|\u0000-\u001f]/u.test(id) &&
        [...userMessages(),...assistantMessages()].filter(n => n.id === id).length === 1 ? id : "";
    }
    function messageText(node) {
      const role = roleNode(node,"user") || roleNode(node,"assistant");
      if (!role) return "";
      const markdown = [...role.querySelectorAll(".response-content-markdown")]
        .filter(n => n.closest(ROLES) === role && rendered(n));
      return markdown.length === 1 ? markdown[0].innerText || "" : "";
    }
    function composerContext() {
      if (!matchesLocation()) return null;
      const editors = [...document.querySelectorAll(EDITOR)].filter(n =>
        rendered(n) && n.isContentEditable && !n.closest(MESSAGE) && !n.closest('[aria-disabled="true"]'));
      if (editors.length !== 1) return null;
      const composer = editors[0], root = composer.closest(ROOT);
      if (!root || !rendered(root) || root.isContentEditable || root.closest(MESSAGE) ||
          root.parentElement?.closest(ROOT) || [...root.querySelectorAll(EDITOR)].filter(rendered).length !== 1 ||
          root.querySelectorAll('input[type="file"]').length !== 1) return null;
      return { root, composer, form: composer.closest("form"), locationHref: location.href };
    }
    function currentContext(context) {
      if (!context || context.locationHref !== location.href) return null;
      const fresh = composerContext();
      return fresh && fresh.composer === context.composer && fresh.root === context.root ? fresh : null;
    }
    const cards = root => [...root.querySelectorAll(LIST+' > [role="listitem"]')]
      .filter(n => !n.closest(MESSAGE) && rendered(n));
    const cardReady = card => rendered(card) && !card.querySelector('[role="status"],[role="progressbar"],.animate-spin,[aria-busy="true"]') &&
      !/Обработка/.test(card.innerText || "");
    function controls(context) {
      const c = currentContext(context);
      return c ? [...c.root.querySelectorAll("button")].filter(n => !n.closest(MESSAGE) && rendered(n)) : [];
    }
    function classify(context) {
      const c = currentContext(context);
      if (!c) return { kind:"unknown", button:null };
      const stops = [...document.querySelectorAll('button[aria-label="'+STOP+'"]')]
        .filter(n => !n.closest(MESSAGE) && rendered(n));
      if (stops.length) return { kind:stops.length === 1 ? "stop" : "unknown",
        button:stops.length === 1 && c.root.contains(stops[0]) ? stops[0] : null };
      const staged = cards(c.root);
      if (staged.length > 1 || staged.some(n => !cardReady(n))) return { kind:"busy", button:null };
      const all = controls(c), sends = all.filter(n => n.matches('button[type="submit"][data-testid="chat-submit"][aria-label="Отправить"]'));
      if (sends.length === 1) {
        const button = sends[0], disabled = button.disabled || button.matches(":disabled") || button.getAttribute("aria-disabled") === "true";
        if (disabled) return { kind:!readComposerText(c.composer).trim() && !staged.length ? "ready" : "send_disabled", button };
        return { kind:readComposerText(c.composer).trim() || staged.length ? "send_active" : "unknown", button };
      }
      if (sends.length) return { kind:"unknown", button:null };
      const voice = all.filter(n => n.getAttribute("aria-label") === "Перейти в голосовой режим (Ctrl+⇧O)");
      return voice.length === 1 && !readComposerText(c.composer).trim() && !staged.length ?
        { kind:"ready", button:null } : { kind:"unknown", button:null };
    }
    function attachmentPreview(filename) {
      const c = composerContext();
      if (!c || !txt({ filename, byte_length:0 })) return null;
      const list = cards(c.root);
      if (list.length !== 1) return null;
      const open = [...list[0].querySelectorAll('button[aria-label="Открыть вложение"]')].filter(rendered);
      return open.length === 1 && open[0].textContent.trim() === filename ? list[0] : null;
    }
    function attachmentSurface() {
      const c = composerContext();
      if (!c || classify(c).kind !== "ready" || readComposerText(c.composer).trim() || cards(c.root).length) return null;
      const input = c.root.querySelector('input[type="file"]');
      if (!(input instanceof HTMLInputElement) || !input.isConnected || !input.classList.contains("hidden") ||
          !input.multiple || input.hasAttribute("accept") || input.disabled || input.matches(":disabled") ||
          input.files?.length || input.getAttribute("aria-disabled") === "true" ||
          input.closest('[inert],[role="dialog"],[aria-hidden="true"]') || input.parentElement?.closest("[hidden]")) return null;
      return { kind:"file_input_v1", input, root:c.root, locationHref:c.locationHref };
    }
    return Object.freeze({
      id:"grok", label:"Grok", matchesLocation, userMessages, assistantMessages, messageId, messageText,
      findCodeBlocks(node) { const role = roleNode(node,"assistant"); return role ? reader.findCodeBlocks(role) : []; },
      readCodeText:reader.readCodeText, geometryAnchor:reader.geometryAnchor,
      composerContext,
      readComposerText(composer) { return composerContext()?.composer === composer ? readComposerText(composer) : ""; },
      setComposerText(composer,value) {
        const c = composerContext();
        if (!c || c.composer !== composer || !["ready","send_active","send_disabled"].includes(classify(c).kind)) fail("COMPOSER_NOT_AVAILABLE");
        setComposerText(composer,value);
        if (!currentContext(c) || readComposerText(composer) !== String(value || "")) fail("COMPOSER_CONTEXT_CHANGED");
      },
      classifyComposerControl:classify, allComposerControls:controls,
      sendButtonCandidates(context) { const s = classify(context); return s.kind === "send_active" ? [{button:s.button,score:2000}] : []; },
      sendButton(context) { return this.sendButtonCandidates(context)[0]?.button || null; },
      sendButtonFingerprint(button) {
        const s = classify(composerContext());
        return s.button === button && button instanceof HTMLButtonElement ?
          [button.tagName,button.getAttribute("data-testid"),button.getAttribute("aria-label")].join("|") : "";
      },
      isGenerating() { return ["stop","busy","unknown"].includes(classify(composerContext()).kind); },
      messageComplete(node) { return Boolean(roleNode(node,"assistant") && messageId(node) &&
        ["ready","send_active","send_disabled"].includes(classify(composerContext()).kind) && messageText(node)); },
      deliveryCapabilities() { return globalThis.OzonAIDeliveryCapabilities?.profile?.("grok") || null; },
      attachmentSurface, attachmentPreview,
      attachFiles(surface,files) {
        const c = attachmentSurface();
        if (!c || c.input !== surface?.input || c.root !== surface?.root || c.locationHref !== surface?.locationHref || c.kind !== surface?.kind)
          fail("TARGET_AI_ATTACHMENT_SURFACE_UNAVAILABLE");
        if (!Array.isArray(files) || files.length !== 1 || !(files[0] instanceof File) ||
            !txt({filename:files[0].name,byte_length:files[0].size}) || !["","text/plain"].includes(files[0].type))
          fail("TARGET_AI_FILE_TYPE_UNSUPPORTED");
        return globalThis.OzonWebFileAttachment.setInputFiles(c.input,files);
      },
      attachmentReady(descriptors) {
        return Boolean(Array.isArray(descriptors) && descriptors.length === 1 && txt(descriptors[0]) &&
          attachmentPreview(descriptors[0].filename) && cardReady(attachmentPreview(descriptors[0].filename)) &&
          ["send_active","send_disabled"].includes(classify(composerContext()).kind));
      },
      sentAttachmentMessage(node,descriptors) {
        if (!roleNode(node,"user") || !messageId(node) || !Array.isArray(descriptors) ||
            descriptors.length !== 1 || !txt(descriptors[0])) return null;
        const open = [...node.querySelectorAll('button[aria-label="Открыть вложение"]')]
          .filter(n => n.closest(MESSAGE) === node && rendered(n));
        const text = messageText(node);
        return open.length === 1 && open[0].textContent.trim() === descriptors[0].filename && text.trim() ?
          Object.freeze({text}) : null;
      }
    });
  }
  globalThis.SellerAgentsGrokAdapter = Object.freeze({create});
})();

;
/* Gemini B02 adapter from accepted 19 Oct DOM.
 * The paired container ID is a document-local turn witness, not a chat ID.
 * Native TXT input observed20Oct1442, mounted by the normal upload menu.
 * Menu preparation is bound to the current composer/delivery; no Send,
 * clipboard, execution or signed authority is created here. */
(() => {
  "use strict";
  const ORIGIN = "https://gemini.google.com";
  const ROOT = ".text-input-field";
  const EDITOR = 'rich-textarea > .ql-editor[contenteditable="true"][role="textbox"]';
  const MESSAGE = "user-query, model-response";
  const EXCLUDED = '[hidden],[aria-hidden="true"],[inert],[role="dialog"]';
  const SEND = "Отправить сообщение";
  const STOP = "Остановить генерацию ответа";
  const VOICE = "Начать голосовой ввод (^⇧D)";
  const matchesLocation = () => location.origin === ORIGIN;
  const fail = code => { throw Object.assign(new Error(code), { code }); };
  function rendered(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected || node.closest(EXCLUDED)) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let p = node; p instanceof Element; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse" ||
          s.contentVisibility === "hidden" || Number(s.opacity) === 0) return false;
    }
    return true;
  }
  const txt = d => typeof d?.filename === "string" && d.filename.length > 4 &&
    d.filename.length <= 255 && !/[\\/\u0000-\u001f]/u.test(d.filename) && /\.txt$/i.test(d.filename) &&
    Number.isSafeInteger(d.byte_length) && d.byte_length >= 0 && d.byte_length <= 1024 * 1024;
  function create({ readComposerText, setComposerText }) {
    const reader = globalThis.SellerAgentsObservedAICodeReaders.readers.gemini;
    function own(node, role) {
      if (!matchesLocation() || !(node instanceof HTMLElement) || !node.matches(role) ||
          !rendered(node) || node.isContentEditable || node.parentElement?.closest(MESSAGE) ||
          node.querySelector(MESSAGE) ||
          [...node.querySelectorAll("[contenteditable]")].some(n => n.isContentEditable)) return false;
      const parent = node.parentElement;
      return Boolean(parent?.matches(".conversation-container[id]") && parent.id &&
        parent.querySelectorAll(role).length === 1);
    }
    const userMessages = () => [...document.querySelectorAll("user-query")].filter(n => own(n, "user-query"));
    const assistantMessages = () => reader.assistantMessages().filter(n => own(n, "model-response"));
    function messageId(node) {
      const role = own(node, "user-query") ? "user" : own(node, "model-response") ? "assistant" : "";
      const id = node?.parentElement?.id || "";
      if (!role || id.length > 220 || /[\s|\u0000-\u001f]/u.test(id)) return "";
      const peers = role === "user" ? userMessages() : assistantMessages();
      return peers.filter(n => n.parentElement.id === id).length === 1 ? role + ":" + id : "";
    }
    function composerContext() {
      if (!matchesLocation()) return null;
      const editors = [...document.querySelectorAll(EDITOR)].filter(n =>
        rendered(n) && n.isContentEditable && !n.closest(MESSAGE) && !n.closest('[aria-disabled="true"]'));
      if (editors.length !== 1) return null;
      const composer = editors[0], root = composer.closest(ROOT);
      if (!root || !rendered(root) || root.isContentEditable || root.closest(MESSAGE) ||
          root.parentElement?.closest(ROOT) || [...root.querySelectorAll(EDITOR)].filter(rendered).length !== 1) return null;
      return { root, composer, form: composer.closest("form"), locationHref: location.href };
    }
    function currentContext(context) {
      if (!context || context.locationHref !== location.href) return null;
      const current = composerContext();
      return current && current.root === context.root && current.composer === context.composer ? current : null;
    }
    function controls(context) {
      const c = currentContext(context);
      return c ? [...c.root.querySelectorAll("button")].filter(n =>
        n.closest(ROOT) === c.root && !n.closest(MESSAGE) && rendered(n)) : [];
    }
    function classify(context) {
      const c = currentContext(context);
      if (!c) return { kind: "unknown", button: null };
      const all = controls(c), stops = all.filter(n => n.getAttribute("aria-label") === STOP);
      if (stops.length) return { kind: stops.length === 1 ? "stop" : "unknown", button: stops.length === 1 ? stops[0] : null };
      if (c.root.querySelector('[role="progressbar"], [aria-busy="true"]')) return { kind: "busy", button: null };
      const sends = all.filter(n => n.getAttribute("aria-label") === SEND);
      if (sends.length === 1) {
        const button = sends[0], disabled = button.disabled || button.matches(":disabled") || button.getAttribute("aria-disabled") === "true";
        return { kind: disabled ? "send_disabled" : "send_active", button };
      }
      if (sends.length) return { kind: "unknown", button: null };
      const voice = all.filter(n => n.getAttribute("aria-label") === VOICE);
      return voice.length === 1 && !readComposerText(c.composer).trim() &&
        !c.root.querySelector(".gem-attachment-content") ? { kind: "ready", button: null } : { kind: "unknown", button: null };
    }
    function visibleText(node) {
      const read = n => {
        if (n.nodeType === Node.TEXT_NODE) return n.nodeValue || "";
        if (!(n instanceof Element) || n.matches('h5.screen-reader-user-query-label,button,user-query-file-preview,[hidden],[aria-hidden="true"],[inert]')) return "";
        const s = getComputedStyle(n);
        if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse") return "";
        return [...n.childNodes].map(read).join("") + (/^(P|DIV|BR|LI|PRE)$/.test(n.tagName) ? "\n" : "");
      };
      return read(node);
    }
    function messageText(node) {
      if (own(node, "user-query")) {
        const parts = [...node.querySelectorAll(".query-text")].filter(n => n.closest("user-query") === node && rendered(n));
        return parts.length === 1 ? visibleText(parts[0]) : "";
      }
      return own(node, "model-response") ? node.innerText || "" : "";
    }
    function attachmentPreview(filename) {
      const c = composerContext();
      if (!c || !txt({ filename, byte_length: 0 })) return null;
      const cards = [...c.root.querySelectorAll(".gem-attachment-content")].filter(rendered);
      if (cards.length !== 1) return null;
      const names = cards[0].querySelectorAll(".gem-attachment-text");
      const ext = cards[0].querySelectorAll(".gem-attachment-extension-label");
      return names.length === 1 && ext.length === 1 &&
        names[0].textContent === filename.slice(0, -4) && ext[0].textContent.trim().toUpperCase() === "TXT" ? cards[0] : null;
    }
    // The menu's native input is mounted only after the observed upload
    // button is clicked. Bind a portal menu to that exact composer/request,
    // never to a document-wide "first file input".
    const UPLOADER = 'images-files-uploader[data-test-id="uploader-images-files-button-advanced"]';
    const INPUT = 'input.hidden-file-input[type="file"]';
    const LOCAL = 'button[data-test-id="local-images-files-uploader-button"]';
    let preparation = null;
    let prepared = null;
    function emptyForAttachment(c) {
      return Boolean(currentContext(c) && ["ready","send_disabled"].includes(classify(c).kind) &&
        !readComposerText(c.composer).trim() && !c.root.querySelector(".gem-attachment-content"));
    }
    function uploadButton(c) {
      const buttons = controls(c).filter(n => n.getAttribute("aria-label") === "Загрузка и инструменты");
      return buttons.length === 1 && !buttons[0].disabled && !buttons[0].matches(":disabled") &&
        buttons[0].getAttribute("aria-disabled") !== "true" ? buttons[0] : null;
    }
    function nativeMenu() {
      const menus = [...document.querySelectorAll(UPLOADER)].filter(n =>
        rendered(n) && !n.closest(MESSAGE) && !n.isContentEditable);
      if (menus.length !== 1) return null;
      const menu = menus[0];
      const inputs = [...menu.querySelectorAll(INPUT)].filter(n => n.parentElement === menu);
      const buttons = [...menu.querySelectorAll(LOCAL)].filter(n => n.parentElement === menu && rendered(n));
      if (inputs.length !== 1 || buttons.length !== 1) return null;
      const input = inputs[0], button = buttons[0];
      if (!(input instanceof HTMLInputElement) || !input.isConnected || !input.multiple ||
          input.disabled || input.matches(":disabled") || input.files?.length ||
          input.getAttribute("aria-disabled") === "true" || input.closest(EXCLUDED) ||
          button.disabled || button.matches(":disabled") || button.getAttribute("aria-disabled") === "true" ||
          !(input.accept || "").toLowerCase().split(",").map(s => s.trim()).includes(".txt")) return null;
      return { input, menu };
    }
    function attachmentSurface() {
      const c = composerContext();
      if (!c || !emptyForAttachment(c)) return null;
      const found = nativeMenu();
      if (!found) return null;
      const bound = prepared && currentContext(prepared.context) &&
        prepared.context.root === c.root && prepared.input === found.input && prepared.menu === found.menu &&
        uploadButton(c) === prepared.button;
      if (!c.root.contains(found.menu) && !bound) return null;
      return { kind:"file_input_v1", input:found.input, inputRoot:found.menu,
        root:c.root, composer:c.composer, locationHref:c.locationHref };
    }
    async function prepareAttachmentSurface(context, options = {}) {
      const { deliveryId, isCurrent } = options;
      if (typeof deliveryId !== "string" || !deliveryId || typeof isCurrent !== "function") return null;
      if (preparation?.deliveryId === deliveryId) {
        await preparation.promise;
        return isCurrent() && currentContext(context) ? attachmentSurface() : null;
      }
      if (preparation?.pending) return null;
      const valid = () => isCurrent() && emptyForAttachment(context);
      if (!valid()) return null;
      const existing = attachmentSurface();
      if (existing) return existing;
      const button = uploadButton(context);
      // An already-open unbound portal cannot be attributed to this request.
      if (!button || [...document.querySelectorAll(UPLOADER)].some(rendered)) return null;
      const attempt = { deliveryId, pending:true, promise:null };
      preparation = attempt;
      prepared = null;
      attempt.promise = (async () => {
        if (!valid() || uploadButton(context) !== button) return null;
        button.click(); // Ordinary menu only: no file chooser, upload or Send.
        const deadline = Date.now() + 1500;
        do {
          if (!valid() || uploadButton(context) !== button) return null;
          const found = nativeMenu();
          if (found) {
            prepared = { ...found, context, button };
            return attachmentSurface();
          }
          await new Promise(resolve => setTimeout(resolve, 50));
        } while (Date.now() < deadline);
        return null;
      })();
      try { return await attempt.promise; }
      finally { attempt.pending = false; }
    }
    return Object.freeze({
      id: "gemini", label: "Gemini", matchesLocation,
      userMessages, assistantMessages, messageId, messageText,
      findCodeBlocks: reader.findCodeBlocks, readCodeText: reader.readCodeText, geometryAnchor: reader.geometryAnchor,
      composerContext,
      readComposerText(composer) { return composerContext()?.composer === composer ? readComposerText(composer) : ""; },
      setComposerText(composer, value) {
        const c = composerContext();
        if (!c || c.composer !== composer || !["ready","send_active","send_disabled"].includes(classify(c).kind)) fail("COMPOSER_NOT_AVAILABLE");
        setComposerText(composer, value);
        if (!currentContext(c) || readComposerText(composer) !== String(value || "")) fail("COMPOSER_CONTEXT_CHANGED");
      },
      classifyComposerControl: classify,
      allComposerControls: controls,
      sendButtonCandidates(context) { const c = classify(context); return c.kind === "send_active" ? [{ button: c.button, score: 2000 }] : []; },
      sendButton(context) { return this.sendButtonCandidates(context)[0]?.button || null; },
      sendButtonFingerprint(button) {
        const c = classify(composerContext());
        return c.button === button && button instanceof HTMLButtonElement ?
          [button.tagName, button.getAttribute("aria-label") || ""].join("|") : "";
      },
      isGenerating() { return ["stop","busy","unknown"].includes(classify(composerContext()).kind); },
      messageComplete(node) {
        return own(node, "model-response") && Boolean(messageId(node)) &&
          ["ready","send_active","send_disabled"].includes(classify(composerContext()).kind) && Boolean(messageText(node));
      },
      deliveryCapabilities() { return globalThis.OzonAIDeliveryCapabilities?.profile?.("gemini") || null; },
      attachmentSurface, prepareAttachmentSurface,
      attachFiles(surface, files) {
        const current = attachmentSurface();
        if (!current || current.input !== surface?.input || current.root !== surface?.root ||
            current.inputRoot !== surface?.inputRoot || current.composer !== surface?.composer ||
            current.locationHref !== surface?.locationHref || current.kind !== surface?.kind)
          fail("TARGET_AI_ATTACHMENT_SURFACE_UNAVAILABLE");
        if (!Array.isArray(files) || files.length !== 1 || !(files[0] instanceof File) ||
            !txt({filename:files[0].name,byte_length:files[0].size}) ||
            !["","text/plain"].includes(files[0].type)) fail("TARGET_AI_FILE_TYPE_UNSUPPORTED");
        return globalThis.OzonWebFileAttachment.setInputFiles(current.input, files);
      },
      attachmentPreview,
      attachmentReady(descriptors) {
        const c = composerContext();
        return Boolean(c && Array.isArray(descriptors) && descriptors.length === 1 && txt(descriptors[0]) &&
          attachmentPreview(descriptors[0].filename) &&
          ["send_active","send_disabled"].includes(classify(c).kind) &&
          !c.root.querySelector('[role="progressbar"], [aria-busy="true"]'));
      },
      sentAttachmentMessage(node, descriptors) {
        if (!own(node, "user-query") || !messageId(node) || !Array.isArray(descriptors) ||
            descriptors.length !== 1 || !txt(descriptors[0])) return null;
        const cards = [...node.querySelectorAll("user-query-file-preview button.new-file-preview-file")].filter(rendered);
        if (cards.length !== 1 || cards[0].getAttribute("aria-label") !== descriptors[0].filename) return null;
        const ext = cards[0].querySelectorAll('[data-test-id="extension-label"]');
        const name = cards[0].querySelectorAll('[data-test-id="filename-label"]');
        if (ext.length !== 1 || name.length !== 1 || ext[0].textContent.trim().toUpperCase() !== "TXT" ||
            name[0].textContent !== descriptors[0].filename.slice(0, -4)) return null;
        const text = messageText(node);
        return text.trim() ? Object.freeze({ text }) : null;
      }
    });
  }
  globalThis.SellerAgentsGeminiAdapter = Object.freeze({ create });
})();

;
/* Kimi DOM adapter from accepted 19 Oct observations.
 * Loading is busy, not an observed Stop. Signed-profile/delivery authority
 * remains independent; this module never clicks Send or executes code. */
(() => {
  "use strict";
  const ORIGIN = "https://www.kimi.ai";
  const ROOT = '.chat-editor[data-testid="chat-editor"]';
  const EDITOR = '.chat-input-editor[contenteditable="true"][role="textbox"]';
  const MESSAGE = ".chat-content-item";
  const USER = ".chat-content-item-user";
  const ASSISTANT = ".chat-content-item-assistant";
  const REASONING = ".thinking-container, .toolcall-content-text";
  const EXCLUDED = '[hidden], [aria-hidden="true"], [inert], [role="dialog"]';
  const MAX_TXT_BYTES = 1024 * 1024;
  const fail = code => { throw Object.assign(new Error(code), { code }); };
  const matchesLocation = () => location.origin === ORIGIN;

  // Layout/CSS eligibility is not proof of an installed UI click or upload.
  function rendered(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected || node.closest(EXCLUDED)) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let p = node; p instanceof Element; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse" ||
          s.contentVisibility === "hidden" || Number(s.opacity) === 0) return false;
    }
    return true;
  }
  function ownMessage(node, role) {
    return matchesLocation() && node instanceof HTMLElement && node.matches(MESSAGE + role) &&
      !node.matches(role === USER ? ASSISTANT : USER) && !node.parentElement?.closest(MESSAGE) &&
      !node.closest(REASONING) && !node.isContentEditable && rendered(node) &&
      ![...node.querySelectorAll("[contenteditable]")].some(n => n.isContentEditable && n.closest(MESSAGE) === node);
  }
  function txtName(name) {
    return typeof name === "string" && name.length > 4 && name.length <= 255 &&
      !/[\\/\u0000-\u001f]/u.test(name) && /\.txt$/i.test(name);
  }
  function create({ readComposerText, setComposerText }) {
    const reader = globalThis.SellerAgentsKimiCodeReader;
    const composerContext = () => {
      if (!matchesLocation()) return null;
      const editors = [...document.querySelectorAll(EDITOR)]
        .filter(n => rendered(n) && n.isContentEditable && !n.closest(MESSAGE) && !n.closest('[aria-disabled="true"]'));
      if (editors.length !== 1) return null;
      const composer = editors[0], root = composer.closest(ROOT);
      if (!root || !rendered(root) || root.isContentEditable || root.parentElement?.closest(ROOT) ||
          root.closest(MESSAGE) || [...root.querySelectorAll(EDITOR)].filter(rendered).length !== 1) return null;
      return { composer, root, form: composer.closest("form"), locationHref: location.href };
    };
    const currentContext = context => {
      if (!context || context.locationHref !== location.href) return null;
      const fresh = composerContext();
      return fresh && fresh.root === context.root && fresh.composer === context.composer ? fresh : null;
    };
    const cards = root => [...root.querySelectorAll('[data-testid="input-attachment-list"] .file-card-container')]
      .filter(n => n.closest(ROOT) === root && !n.closest(MESSAGE));
    const cardReady = card => rendered(card) && card.classList.contains("success") &&
      !card.matches('.loading, .error, .failed, [aria-busy="true"]') &&
      !card.querySelector('[aria-busy="true"], [role="progressbar"], .loading-pure, .send-loading');
    const classify = context => {
      const current = currentContext(context);
      if (!current) return { kind: "unknown", button: null };
      const buttons = [...current.root.querySelectorAll(".send-button-container")]
        .filter(n => n.closest(ROOT) === current.root && !n.closest(MESSAGE) && rendered(n));
      if (buttons.length !== 1) return { kind: "unknown", button: null };
      const button = buttons[0];
      if (button.classList.contains("loading") || button.querySelector(".send-loading, .loading-pure"))
        return { kind: "busy", button: null };
      const attached = cards(current.root);
      if (attached.length > 1 || attached.some(card => !cardReady(card)))
        return { kind: "unknown", button: null };
      const disabled = button.classList.contains("disabled") || button.getAttribute("aria-disabled") === "true" ||
        button.hasAttribute("disabled") || getComputedStyle(button).pointerEvents === "none";
      const hasText = Boolean(readComposerText(current.composer).trim());
      if (disabled) return { kind: !hasText && !attached.length ? "ready" : "send_disabled", button };
      return { kind: hasText || attached.length ? "send_active" : "unknown", button };
    };
    const userMessages = () => [...document.querySelectorAll(MESSAGE + USER)].filter(n => ownMessage(n, USER));
    const assistantMessages = () => reader.assistantMessages();
    const messageId = node => {
      if (!ownMessage(node, USER) && !ownMessage(node, ASSISTANT)) return "";
      const id = node.getAttribute("data-archer-id") || "";
      if (!id || id.length > 256 || /[\s|\u0000-\u001f]/u.test(id)) return "";
      const turn = node.getAttribute("data-conversation-turn-id");
      // These are independently observed message/turn witnesses, not equal or stable chat IDs.
      if (node.matches(USER) && turn !== null && (!turn || turn.length > 256 || /[\s|\u0000-\u001f]/u.test(turn))) return "";
      const equal = [...document.querySelectorAll(MESSAGE + "[data-archer-id]")]
        .filter(n => (ownMessage(n, USER) || ownMessage(n, ASSISTANT)) && n.getAttribute("data-archer-id") === id);
      return equal.length === 1 ? id : "";
    };
    const messageText = node => {
      const user = ownMessage(node, USER), assistant = ownMessage(node, ASSISTANT);
      if ((!user && !assistant) || node.querySelector(MESSAGE)) return "";
      if (user) return String(node.innerText || "");
      return [...node.querySelectorAll(".toolcall-rollup__flat")]
        .filter(n => n.closest(MESSAGE) === node && !n.closest(REASONING) && rendered(n) &&
          !n.isContentEditable && !n.querySelector(REASONING + ", " + MESSAGE + ", [contenteditable]"))
        .map(n => n.innerText || "").join("\n");
    };
    const attachmentSurface = () => {
      const context = composerContext();
      if (!context || readComposerText(context.composer).trim() || cards(context.root).length ||
          classify(context).kind !== "ready") return null;
      const inputs = [...context.root.querySelectorAll('input[type="file"]')]
        .filter(n => n.closest(ROOT) === context.root && !n.closest(MESSAGE));
      if (inputs.length !== 1) return null;
      const input = inputs[0];
      if (!(input instanceof HTMLInputElement) || !input.isConnected || !input.classList.contains("hidden-input") || input.disabled || input.matches(":disabled") || !input.multiple ||
          input.getAttribute("aria-disabled") === "true" || input.closest('[inert], [role="dialog"], [aria-hidden="true"]') ||
          input.parentElement?.closest("[hidden]") || input.files?.length || input.accept !== "") return null;
      return { kind: "file_input_v1", input, root: context.root, locationHref: context.locationHref };
    };
    const attachmentPreview = filename => {
      const context = composerContext();
      if (!context || !txtName(filename)) return null;
      const found = cards(context.root);
      if (found.length !== 1 || !rendered(found[0])) return null;
      const card = found[0], names = [...card.querySelectorAll(".file-card-info-name")],
        extensions = [...card.querySelectorAll(".file-ext")];
      return names.length === 1 && extensions.length === 1 &&
        names[0].textContent === filename.slice(0, -4) && extensions[0].textContent.trim().toUpperCase() === "TXT"
        ? card : null;
    };
    const adapter = {
      id: "kimi", label: "Kimi", matchesLocation,
      userMessages, assistantMessages, messageId, messageText,
      findCodeBlocks: reader.findCodeBlocks, readCodeText: reader.readCodeText, geometryAnchor: reader.geometryAnchor,
      composerContext,
      readComposerText: composer => {
        const current = composerContext();
        return current?.composer === composer ? readComposerText(composer) : "";
      },
      setComposerText(composer, value) {
        const current = composerContext();
        if (current?.composer !== composer || !["ready", "send_active", "send_disabled"].includes(classify(current).kind)) fail("COMPOSER_NOT_AVAILABLE");
        setComposerText(composer, value);
        if (!currentContext(current) || readComposerText(composer) !== String(value || ""))
          fail("COMPOSER_CONTEXT_CHANGED");
      },
      classifyComposerControl: classify,
      allComposerControls(context) {
        const current = currentContext(context);
        return current ? [...current.root.querySelectorAll('.send-button-container, [role="button"], button')]
          .filter(n => n.closest(ROOT) === current.root && !n.closest(MESSAGE) && rendered(n)) : [];
      },
      sendButtonCandidates(context) {
        const state = classify(context);
        return state.kind === "send_active" ? [{ button: state.button, score: 2000 }] : [];
      },
      sendButton(context) { return this.sendButtonCandidates(context)[0]?.button || null; },
      sendButtonFingerprint(button) {
        const state = classify(composerContext());
        return state.button === button && button instanceof HTMLElement ?
          [button.tagName, "send-button-container", button.getAttribute("aria-label") || ""].join("|") : "";
      },
      isGenerating() { return classify(composerContext()).kind === "busy"; },
      messageComplete(message) {
        return ownMessage(message, ASSISTANT) &&
          ["ready", "send_active", "send_disabled"].includes(classify(composerContext()).kind) &&
          Boolean(messageText(message));
      },
      // S08: only an observed sent card inside this owned user message counts.
      // The card's UI text is excluded from the submitted text comparison.
      sentAttachmentMessage(node, descriptors) {
        if (!ownMessage(node, USER) || !messageId(node) ||
            !Array.isArray(descriptors) || descriptors.length !== 1) return null;
        const d = descriptors[0];
        if (!txtName(d?.filename) || !Number.isSafeInteger(d.byte_length) ||
            d.byte_length < 0 || d.byte_length > MAX_TXT_BYTES) return null;
        const bodies = [...node.querySelectorAll(".segment-user")]
          .filter(n => n.closest(MESSAGE) === node && rendered(n));
        if (bodies.length !== 1) return null;
        const body = bodies[0], lists = [...body.querySelectorAll(".attachment-list-file")]
          .filter(n => n.closest(MESSAGE) === node && rendered(n));
        if (lists.length !== 1) return null;
        const fileCards = [...lists[0].querySelectorAll(".file-card-container")]
          .filter(n => n.closest(MESSAGE) === node && rendered(n));
        if (fileCards.length !== 1) return null;
        const card = fileCards[0], names = [...card.querySelectorAll(".file-card-info-name")],
          extensions = [...card.querySelectorAll(".file-ext")];
        if (!card.classList.contains("success") || names.length !== 1 || extensions.length !== 1 ||
            names[0].textContent !== d.filename.slice(0, -4) ||
            extensions[0].textContent.trim().toUpperCase() !== "TXT") return null;
        const read = current => {
          if (current === lists[0]) return "";
          if (current.nodeType === Node.TEXT_NODE) return current.nodeValue || "";
          if (!(current instanceof Element) || current.matches('button,[role="button"],[hidden],[aria-hidden="true"],[inert]')) return "";
          const style = getComputedStyle(current);
          if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return "";
          return [...current.childNodes].map(read).join("") +
            (/^(P|DIV|BR|LI|PRE)$/.test(current.tagName) ? "\n" : "");
        };
        return Object.freeze({ text: read(body) });
      },
      deliveryCapabilities() { return globalThis.OzonAIDeliveryCapabilities?.profile?.("kimi") || null; },
      attachmentSurface, attachmentPreview,
      attachFiles(surface, files) {
        const current = attachmentSurface();
        if (!current || surface?.kind !== current.kind || surface.root !== current.root ||
            surface.input !== current.input || surface.locationHref !== current.locationHref)
          fail("TARGET_AI_ATTACHMENT_SURFACE_UNAVAILABLE");
        if (!Array.isArray(files) || files.length !== 1 || !(files[0] instanceof File) ||
            !txtName(files[0].name) || files[0].size > MAX_TXT_BYTES ||
            !["", "text/plain"].includes(files[0].type)) fail("TARGET_AI_FILE_TYPE_UNSUPPORTED");
        return globalThis.OzonWebFileAttachment.setInputFiles(current.input, files);
      },
      attachmentReady(descriptors) {
        if (!Array.isArray(descriptors) || descriptors.length !== 1 || !txtName(descriptors[0]?.filename) ||
            !Number.isSafeInteger(descriptors[0].byte_length) || descriptors[0].byte_length < 0 ||
            descriptors[0].byte_length > MAX_TXT_BYTES) return false;
        const preview = attachmentPreview(descriptors[0].filename);
        return Boolean(preview && cardReady(preview) &&
          ["send_active", "send_disabled"].includes(classify(composerContext()).kind));
      }
    };
    return Object.freeze(adapter);
  }
  globalThis.SellerAgentsKimiAdapter = Object.freeze({ create });
})();

;
/* Qwen guest/authorized DOM share an adapter, never an AI account identity.
 * The complete Markdown code is read only on an explicit command/review action.
 * Monaco's visible lines are deliberately not an executable-code fallback. */
(() => {
  "use strict";
  const MESSAGE = ".qwen-chat-message";
  const ASSISTANT = MESSAGE + ".qwen-chat-message-assistant";
  const USER = MESSAGE + ".qwen-chat-message-user";
  const CODE = "pre.qwen-markdown-code";
  const fail = code => { throw Object.assign(new Error(code), { code }); };
  function create({ visible, readComposerText, setComposerText }) {
    const messageId = node => {
      if (!(node instanceof Element) || !node.matches(MESSAGE)) return "";
      const ids = [...new Set([node, ...node.querySelectorAll("[data-msg-id]")]
        .filter(value => value.closest(MESSAGE) === node)
        .map(value => value.getAttribute("data-msg-id")).filter(Boolean))];
      return ids.length === 1 ? ids[0] : "";
    };
    const codeBlocks = message => message instanceof Element ?
      [...message.querySelectorAll(CODE)].filter(node => node.closest(MESSAGE) === message) : [];
    const composerContext = () => {
      const composers = [...document.querySelectorAll("textarea.message-input-textarea")].filter(visible);
      if (composers.length !== 1) return null;
      const composer = composers[0], root = composer.closest(".message-input-container");
      return root && visible(root) ? { composer, root } : null;
    };
    const classify = context => {
      if (!context?.root?.isConnected || !context.composer?.isConnected) return { kind: "unknown", button: null };
      // Qwen keeps distinct structural controls when accessible labels are localized.
      // A visible Stop always excludes sending; ambiguous controls stay closed.
      const stops = [...context.root.querySelectorAll('.chat-prompt-send-button > button.stop-button, button[aria-label="Stop"]')].filter(visible);
      if (stops.length) return { kind: stops.length === 1 ? "stop" : "unknown", button: stops.length === 1 ? stops[0] : null };
      const buttons = [...context.root.querySelectorAll('.chat-prompt-send-button > button.send-button, button[aria-label="Send"]')].filter(visible);
      if (buttons.length !== 1) return { kind: "unknown", button: null };
      const button = buttons[0], disabled = button.disabled || button.getAttribute("aria-disabled") === "true";
      return { kind: disabled ? (readComposerText(context.composer).trim() ? "send_disabled" : "ready") : "send_active", button };
    };
    const attachmentCards = root => [...root.querySelectorAll(".file-card-list .fileitem-btn")];
    const attachmentSurface = () => {
      const context = composerContext();
      if (!context?.root?.isConnected || !context.composer?.isConnected || readComposerText(context.composer).trim() || attachmentCards(context.root).length) return null;
      const inputs = [...context.root.querySelectorAll('input[type="file"]')];
      if (inputs.length !== 1) return null;
      const input = inputs[0];
      if (!(input instanceof HTMLInputElement) || !input.isConnected || input.disabled || input.files?.length) return null;
      // Qwen's hidden input installs its upload callback only after the native
      // file-dialog action. Its visible chat drop surface is independently ready.
      const target = context.root.closest(".chat-content");
      if (!target?.isConnected || !visible(target)) return null;
      return { kind: "drag_drop_v1", input, root: context.root, target };
    };
    const attachmentPreview = filename => {
      const context = composerContext();
      if (!context?.root?.isConnected || !context.composer?.isConnected || typeof filename !== "string" || !filename) return null;
      const cards = attachmentCards(context.root);
      if (cards.length !== 1) return null;
      const card = cards[0], names = [...card.querySelectorAll(".fileitem-file-name")];
      return card.isConnected && visible(card) && names.length === 1 && names[0].textContent === filename ? card : null;
    };
    const adapter = {
      id: "qwen", label: "Qwen",
      matchesLocation: () => location.origin === "https://chat.qwen.ai",
      assistantMessages: () => [...document.querySelectorAll(ASSISTANT)],
      userMessages: () => [...document.querySelectorAll(USER)],
      messageId,
      messageText(node) {
        if (!(node instanceof Element)) return "";
        const body = node.matches(USER) ? node.querySelector(".chat-user-message-container[data-msg-id]") : node;
        return String(body?.innerText || body?.textContent || "");
      },
      findCodeBlocks: codeBlocks,
      readCodeText() { return ""; },
      async readCodeTextAsync(block) {
        const section = block?.closest?.(ASSISTANT), id = messageId(section), ordinal = codeBlocks(section).indexOf(block);
        if (!block?.isConnected || !section?.isConnected || !id || ordinal < 0) fail("QWEN_CODE_IDENTITY_REQUIRED");
        const response = await chrome.runtime.sendMessage({ type: "OZ_QWEN_READ_CODE", messageId: id, blockOrdinal: ordinal });
        if (!block.isConnected || !section.isConnected || messageId(section) !== id || codeBlocks(section)[ordinal] !== block)
          fail("QWEN_CODE_CONTEXT_CHANGED");
        if (!response?.ok || typeof response.text !== "string" || !response.text.length || response.text.length > 524288)
          fail("QWEN_COMPLETE_CODE_UNAVAILABLE");
        return response.text;
      },
      geometryAnchor: block => block?.isConnected ? block : null,
      composerContext, readComposerText, setComposerText,
      classifyComposerControl: classify,
      sendButtonCandidates(context) { const state = classify(context); return state.kind === "send_active" ? [{ button: state.button, score: 2000 }] : []; },
      sendButton(context) { const state = classify(context); return state.kind === "send_active" ? state.button : null; },
      sendButtonFingerprint(button) {
        return button instanceof HTMLElement ? [button.tagName, button.getAttribute("aria-label") || "", button.getAttribute("type") || ""].join("|") : "";
      },
      isGenerating() { return classify(composerContext()).kind === "stop"; },
      messageComplete(message) { return Boolean(message?.isConnected && !this.isGenerating() && this.messageText(message)); },
      // Accepted S08 has sent-file cards and user text as separate siblings.
      sentAttachmentMessage(node, descriptors) {
        if (location.origin !== "https://chat.qwen.ai" || !(node instanceof Element) ||
            !node.matches(USER) || node.closest('[contenteditable="true"]') ||
            node.querySelector('[contenteditable="true"]') || !visible(node) ||
            !Array.isArray(descriptors) || descriptors.length !== 1) return null;
        const id = messageId(node), d = descriptors[0];
        if (!id || [...document.querySelectorAll(USER)].filter(n => messageId(n) === id).length !== 1 ||
            typeof d?.filename !== "string" || !/\.txt$/i.test(d.filename) ||
            !Number.isSafeInteger(d.byte_length) || d.byte_length < 0) return null;
        const bodies = [...node.querySelectorAll(".chat-user-message-container[data-msg-id]")]
          .filter(n => n.closest(MESSAGE) === node && visible(n));
        if (bodies.length !== 1 || bodies[0].getAttribute("data-msg-id") !== id) return null;
        const body = bodies[0], sentCards = [...body.querySelectorAll(".fileitem-btn")]
          .filter(n => n.closest(MESSAGE) === node && visible(n));
        if (sentCards.length !== 1) return null;
        const names = [...sentCards[0].querySelectorAll(".fileitem-file-name-text")],
          extensions = [...sentCards[0].querySelectorAll(".fileitem-file-name-ext")];
        if (names.length !== 1 || extensions.length !== 1 ||
            names[0].textContent + extensions[0].textContent !== d.filename) return null;
        const parts = [...body.querySelectorAll(".user-message-content")]
          .filter(n => n.closest(MESSAGE) === node && visible(n));
        if (!parts.length) return null;
        return Object.freeze({ text: parts.map(n => n.innerText || n.textContent || "").join("\n") });
      },
      deliveryCapabilities() { return globalThis.OzonAIDeliveryCapabilities?.profile?.("qwen") || null; },
      attachmentSurface,
      attachFiles(surface, files) {
        const current = attachmentSurface();
        if (!current || surface?.kind !== current.kind || surface.root !== current.root ||
            surface.input !== current.input || surface.target !== current.target)
          fail("TARGET_AI_ATTACHMENT_SURFACE_UNAVAILABLE");
        if (!Array.isArray(files) || files.length !== 1 || !/\.txt$/i.test(String(files[0]?.name || "")))
          fail("TARGET_AI_FILE_TYPE_UNSUPPORTED");
        return globalThis.OzonWebFileAttachment.dispatchFileDrop(current.target, files);
      },
      attachmentPreview,
      attachmentReady(descriptors) {
        if (!Array.isArray(descriptors) || descriptors.length !== 1 || !/\.txt$/i.test(String(descriptors[0]?.filename || ""))) return false;
        const context = composerContext(), preview = attachmentPreview(descriptors[0].filename);
        if (!context || !preview || preview.matches('[aria-busy="true"]') ||
            preview.querySelector('[aria-busy="true"]') || context.root.querySelector("svg.anticon-spin") ||
            !["ready", "send_active", "send_disabled"].includes(classify(context).kind)) return false;
        // The observed finished TXT icon replaces the upload spinner. A card/name alone is not readiness.
        const icons = [...preview.querySelectorAll(".fileitem-icon-wrapper .fileitem-icon use")];
        return icons.length === 1 && (icons[0].getAttribute("href") || icons[0].getAttribute("xlink:href")) === "#qwenFileicon-txt1";
      }
    };
    return Object.freeze(adapter);
  }
  globalThis.SellerAgentsQwenAdapter = Object.freeze({ create });
})();

;
(() => {
  "use strict";

  const AI_MODES = Object.freeze(["auto", "chatgpt", "alice", "qwen", "kimi", "grok", "gemini", "claude", "deepseek"]);

  function normalizeMode(value) {
    const mode = String(value || "auto").trim().toLowerCase();
    return AI_MODES.includes(mode) ? mode : "auto";
  }

  function host() {
    return String(globalThis.location?.hostname || "").toLowerCase();
  }

  function text(node) {
    return String(node?.innerText || node?.textContent || "").replace(/\u00a0/g, " ").trim();
  }

  function visible(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected) return false;
    const rect = node.getBoundingClientRect();
    const style = getComputedStyle(node);
    return rect.width >= 0 && rect.height >= 0 && style.display !== "none" && style.visibility !== "hidden";
  }

  function readComposerText(composer) {
    if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) return composer.value || "";
    return composer?.textContent || "";
  }

  function setComposerText(composer, value) {
    if (!(composer instanceof HTMLElement)) throw Object.assign(new Error("AI composer is unavailable."), { code: "COMPOSER_NOT_FOUND" });
    const next = String(value || "");
    composer.focus();
    if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) {
      const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(composer), "value");
      if (!descriptor?.set) throw Object.assign(new Error("Composer value setter unavailable."), { code: "COMPOSER_SETTER_UNAVAILABLE" });
      descriptor.set.call(composer, next);
    } else {
      composer.textContent = next;
    }
    composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: next }));
    composer.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function controlsWithin(context) {
    const root = context?.root || context?.form || null;
    if (!(root instanceof Element)) return [];
    return [...root.querySelectorAll('button, [role="button"], input[type="submit"]')];
  }

  // Visibility of observed composer surfaces, including hidden ancestors.
  function observedComposerVisible(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected ||
        node.closest('[hidden],[aria-hidden="true"],[inert],[role="dialog"],article,[role="article"],[data-turn],[data-message-role],[data-message-author-role],[data-writing-block],[data-writing-block-id]')) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let p = node; p instanceof Element; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse" ||
          s.contentVisibility === "hidden" || Number(s.opacity) === 0) return false;
    }
    return true;
  }
  function aliceComposerContext() {
    const candidates = [...document.querySelectorAll('textarea[data-testid="inputbase-textarea"], [data-highlight-id="alice-input"] textarea')]
      .filter(node => observedComposerVisible(node) && !node.disabled && node.getAttribute("aria-disabled") !== "true");
    if (candidates.length !== 1) return null;
    const composer = candidates[0];
    const root = composer.closest('[data-testid="standalone-input"]') ||
      composer.closest('[data-testid="standalone-input-field"]') || composer.closest('[data-highlight-id="alice-input"]');
    if (!(root instanceof HTMLElement) || !observedComposerVisible(root)) return null;
    return {composer,root,form:composer.closest("form"),locationHref:location.href};
  }

  const CHATGPT_ASSISTANT_EDITOR_DIRECT_SELECTOR = '[data-turn="assistant"], [data-message-author-role="assistant"], [data-message-role="assistant"], [data-writing-block], [data-writing-block-id], #code-block-viewer';
  const CHATGPT_ASSISTANT_CONTENT_SELECTOR = '[data-assistant-markdown], [data-assistant-stream-block], [data-message-content-controls], [data-assistant-content-started]';
  const CHATGPT_RESPONSE_ACTION_SELECTOR = '[data-assistant-message-actions], [data-message-actions][aria-label="Response actions"], [data-message-actions][aria-label="Действия с ответом"], [role="group"][aria-label="Response actions"], [role="group"][aria-label="Действия с ответом"]';
  const CHATGPT_USER_TURN_SELECTOR = '[data-turn="user"], [data-message-author-role="user"], [data-message-role="user"]';

  function chatgptDirectAssistantContext(node) {
    return Boolean(node?.closest?.(CHATGPT_ASSISTANT_EDITOR_DIRECT_SELECTOR));
  }

  function chatgptInsideAssistantEditor(node) {
    if (chatgptDirectAssistantContext(node)) return true;
    const content = node?.closest?.(CHATGPT_ASSISTANT_CONTENT_SELECTOR);
    if (!(content instanceof Element)) return false;
    let root = content;
    while (root && root !== document.body && root !== document.documentElement) {
      if (root.matches?.(CHATGPT_USER_TURN_SELECTOR)) return false;
      const structural = root.matches?.('article, li, section, [data-testid^="conversation-turn"]');
      if (structural && root.querySelectorAll(CHATGPT_RESPONSE_ACTION_SELECTOR).length === 1 && !root.querySelector(CHATGPT_USER_TURN_SELECTOR)) return true;
      root = root.parentElement;
    }
    return false;
  }

  // Observed 21 Oct Work/dot first UI. Input ancestry is not a control scope.
  function chatgptDotLocation() {
    return host() === "chatgpt.com" && location.pathname === "/dots/home";
  }

  function chatgptSurfaceObservation() {
    if (host() !== "chatgpt.com") return null;
    const isDot = chatgptDotLocation();
    const label = isDot ? "Сообщение" : "Работайте с ChatGPT";
    const editors = [...document.querySelectorAll('[contenteditable="true"][role="textbox"][data-composer-markdown]')].filter(observedComposerVisible);
    const candidates = editors.filter(n => n.getAttribute("aria-label") === label && n.classList.contains("ProseMirror"));
    if (editors.length !== 1 || candidates.length !== 1) return isDot ? {kind:"dot",composer:null,inputRoot:null,controlScope:null} : null;
    const composer = candidates[0], parent = composer.parentElement;
    const layout = isDot ? "single-line" : "multiline";
    if (!parent?.matches('[role="presentation"][data-composer-input-layout]') ||
        parent.getAttribute("data-composer-input-layout") !== layout ||
        parent.getAttribute("data-rich-text-layout") !== layout ||
        [...parent.querySelectorAll('[contenteditable="true"][role="textbox"]')].filter(observedComposerVisible).length !== 1)
      return isDot ? {kind:"dot",composer:null,inputRoot:null,controlScope:null} : null;
    const inputRoot = isDot ? parent.parentElement : parent;
    if (isDot && (!inputRoot?.matches('[data-composer-input][data-composer-layout="single-line"]') ||
        inputRoot.querySelectorAll('[contenteditable="true"][role="textbox"]').length !== 1))
      return {kind:"dot",composer:null,inputRoot:null,controlScope:null};
    return {kind:isDot ? "dot" : "work",composer,inputRoot,controlScope:null};
  }

  const CHATGPT_DOT_MESSAGE = 'article.message-row[data-message-id]';
  function chatgptDotMessageParts(node) {
    if (!chatgptDotLocation() || !(node instanceof HTMLElement) || !node.matches(CHATGPT_DOT_MESSAGE) ||
        !chatgptSentVisible(node) || node.classList.contains("pending") || node.parentElement?.closest(CHATGPT_DOT_MESSAGE) ||
        node.closest('[role="dialog"],[data-writing-block],[data-writing-block-id]') ||
        node.querySelector('article,[data-turn],[data-message-role],[data-message-author-role]')) return null;
    const id = node.getAttribute("data-message-id") || "";
    if (!id || id.length > 512 || /\s/.test(id)) return null;
    const peers = [...document.querySelectorAll(CHATGPT_DOT_MESSAGE)]
      .filter(n => n.getAttribute("data-message-id") === id && chatgptSentVisible(n));
    if (peers.length !== 1) return null;
    const bodies = [...node.querySelectorAll('.message-body[data-message-id]')];
    if (bodies.length !== 1 || bodies[0].getAttribute("data-message-id") !== id || !chatgptSentVisible(bodies[0])) return null;
    const texts = [...bodies[0].querySelectorAll('.message-text[data-content-search-unit-key]')];
    if (texts.length !== 1 || texts[0].getAttribute("data-content-search-unit-key") !== id + ":message" || !chatgptSentVisible(texts[0])) return null;
    const fitted = [...texts[0].querySelectorAll('[data-fitted-message-text="true"]')];
    const orbit = [...texts[0].querySelectorAll('[data-orbit-message-parts="true"]')];
    const role = node.classList.contains("self") ? "user" : "assistant";
    if (fitted.length === 1 && orbit.length === 0 && chatgptSentVisible(fitted[0]) &&
        !fitted[0].querySelector('button,input,textarea,[contenteditable],[data-markdown-copy="exclude"]'))
      return {node,id,role,body:bodies[0],text:fitted[0],contentKind:"fitted"};
    if (role !== "assistant" || fitted.length || orbit.length !== 1 || !chatgptSentVisible(orbit[0]) ||
        orbit[0].querySelector('input,textarea,[contenteditable="true"]')) return null;
    const blocks = [...orbit[0].children];
    if (!blocks.length || blocks.some(n => n.getAttribute('data-orbit-message-block') !== 'codeBlock')) return null;
    return {node,id,role,body:bodies[0],text:orbit[0],contentKind:"orbit"};
  }

  function chatgptDotMessages(role) {
    return [...document.querySelectorAll(CHATGPT_DOT_MESSAGE)]
      .filter(n => chatgptDotMessageParts(n)?.role === role);
  }

  function chatgptObservedControlContext(observation) {
    const composer = observation?.composer;
    if (!composer || !observedComposerVisible(composer)) return null;
    let root = null;
    if (observation.kind === "dot") root = composer.closest('[data-role="composer"]');
    else {
      const body = composer.closest('[data-composer-body]');
      for (let p = body, depth = 0; p && p !== document.body && depth < 5; p = p.parentElement, depth++) {
        if ([...p.children].some(n => n.matches('input[type="file"][aria-label="Прикрепить файлы"]'))) { root = p; break; }
      }
    }
    if (!root || !observedComposerVisible(root) ||
        [...root.querySelectorAll('[contenteditable="true"][role="textbox"]')].filter(observedComposerVisible).length !== 1) return null;
    const selector = observation.kind === "dot" ? 'input[type="file"][data-role="file-input"]' : 'input[type="file"][aria-label="Прикрепить файлы"]';
    const inputs = [...root.children].filter(n => n.matches(selector));
    const menu = [...root.querySelectorAll('button[data-composer-navigation-target="add-context"]')].filter(observedComposerVisible);
    if (inputs.length !== 1 || !inputs[0].multiple || menu.length !== 1) return null;
    return {composer,root,form:root,nativeForm:composer.closest('form'),locationHref:location.href,
      surfaceKind:observation.kind === "dot" ? "observed_dot" : "observed_work"};
  }

  function chatgptUploadPending(context) {
    return Boolean(context?.root?.querySelector('[role="progressbar"],[aria-busy="true"],[class~="motion-safe:animate-spin"]'));
  }

  function chatgptObservedStop(context) {
    return Boolean(context?.root && [...context.root.querySelectorAll('button[aria-label="Остановить"],[data-testid="stop-button"]')].some(observedComposerVisible));
  }

  const CHATGPT_WORK_MESSAGE = '[data-chatgpt-selection-conversation-id][data-chatgpt-selection-message-id]';
  function chatgptWorkMessageParts(node) {
    if (chatgptSurfaceObservation()?.kind !== "work" || !(node instanceof HTMLElement) ||
        !node.matches(CHATGPT_WORK_MESSAGE) || !chatgptSentVisible(node) ||
        node.parentElement?.closest(CHATGPT_WORK_MESSAGE) || node.querySelector(CHATGPT_WORK_MESSAGE) ||
        node.closest(CHATGPT_OBSERVED_USER_SELECTOR+', [data-message-role="user"], [data-message-author-role="user"], [data-turn="user"]') ||
        node.querySelector(CHATGPT_OBSERVED_USER_SELECTOR+', [data-message-role="user"], [data-message-author-role="user"], [data-turn="user"]')) return null;
    const route = location.pathname.match(/\/c\/([^/]+)\/?$/);
    const id = node.getAttribute('data-chatgpt-selection-message-id') || '';
    if (!route || node.getAttribute('data-chatgpt-selection-conversation-id') !== route[1] || !id || /\s/.test(id)) return null;
    const peers = [...document.querySelectorAll(CHATGPT_WORK_MESSAGE)].filter(n =>
      n.getAttribute('data-chatgpt-selection-message-id') === id && chatgptSentVisible(n));
    const bodies = [...node.children].filter(n => n.getAttribute('data-markdown-text-style') === 'assistant-message');
    if (peers.length !== 1 || bodies.length !== 1 || !chatgptSentVisible(bodies[0])) return null;
    return {node,id,body:bodies[0]};
  }

  function chatgptObservedCodeBlocks(message) {
    const dot = chatgptDotLocation() ? chatgptDotMessageParts(message) : null;
    const work = !dot ? chatgptWorkMessageParts(message) : null;
    const body = dot?.role === 'assistant' && dot.contentKind === 'orbit' ? dot.text : work?.body;
    if (!body) return [];
    const blocks = [...body.querySelectorAll('[data-code-block="true"][data-markdown-copy="code-block"]')];
    return blocks.filter(block => {
      if (!chatgptSentVisible(block) || block.parentElement?.closest('[data-code-block="true"]') || block.querySelector('[data-code-block="true"]')) return false;
      if (dot && block.parentElement?.getAttribute('data-orbit-message-block') !== 'codeBlock') return false;
      const sources = [...block.querySelectorAll('[data-code-block-source="true"]')];
      const copies = [...block.querySelectorAll('[data-code-block-controls="true"] button[aria-label="Копировать код"]')];
      if (sources.length !== 1 || sources[0].querySelectorAll('code').length !== 1 ||
          sources[0].children.length !== 1 || sources[0].firstElementChild?.tagName !== 'CODE' || copies.length !== 1) return false;
      CHATGPT_COPY_ANCHORS.set(block,copies[0]);
      return true;
    });
  }

  function chatgptDotContentText(parts) {
    if (!parts) return '';
    if (parts.contentKind === 'fitted') return text(parts.text);
    return chatgptObservedCodeBlocks(parts.node).map(block => block.querySelector('[data-code-block-source="true"] code').textContent || '').join('\n\n');
  }

  function chatgptDotSentAttachmentMessage(node, descriptors) {
    const parts = chatgptDotMessageParts(node), list = Array.isArray(descriptors) ? descriptors : [];
    if (!parts || parts.role !== 'user' || parts.contentKind !== 'fitted' || !list.length ||
        list.some(d => typeof d?.filename !== 'string' || !d.filename) ||
        new Set(list.map(d => d.filename)).size !== list.length ||
        node.querySelector('[role="progressbar"],[aria-busy="true"],[class~="motion-safe:animate-spin"]')) return null;
    const lists = [...node.querySelectorAll('.message-body > .attachment-list')];
    if (lists.length !== 1 || lists[0].parentElement !== parts.body || parts.text.contains(lists[0])) return null;
    const cards = [...lists[0].querySelectorAll('div[class~="group/resource-card"]')];
    if (cards.length !== list.length) return null;
    const filenames = [];
    for (const card of cards) {
      if (!chatgptSentVisible(card)) return null;
      const buttons = [...card.children].filter(n => n.matches('button[type="button"][class~="peer/resource-card"]'));
      const names = [...card.querySelectorAll('span.truncate[title]')].filter(chatgptSentVisible);
      if (buttons.length !== 1 || names.length !== 1 || !chatgptSentVisible(buttons[0]) ||
          buttons[0].disabled || buttons[0].getAttribute('aria-disabled') === 'true' || buttons[0].getAttribute('aria-busy') !== 'false') return null;
      const filename = names[0].getAttribute('title');
      if (!filename || names[0].textContent !== filename || !list.some(d => d.filename === filename) ||
          buttons[0].getAttribute('aria-label') !== 'Открыть '+filename || buttons[0].getAttribute('title') !== 'Открыть '+filename) return null;
      filenames.push(filename);
    }
    return new Set(filenames).size === filenames.length ? {text:chatgptDotContentText(parts),filenames} : null;
  }

  function chatgptWorkMessageComplete(message) {
    const parts = chatgptWorkMessageParts(message);
    if (!parts) return false;
    const turn = message.closest('[data-talvt-turn-state]');
    const finalSlot = message.closest('[data-local-conversation-final-assistant="true"]');
    if (!turn || turn.getAttribute('data-talvt-turn-state') !== 'complete' || !finalSlot ||
        finalSlot.closest('[data-talvt-turn-state]') !== turn || !turn.contains(finalSlot)) return false;
    const slots = [...turn.querySelectorAll('[data-local-conversation-final-assistant="true"]')]
      .filter(n => n.closest('[data-talvt-turn-state]') === turn);
    const finals = [...finalSlot.querySelectorAll(CHATGPT_WORK_MESSAGE)].filter(chatgptWorkMessageParts);
    const users = [...turn.querySelectorAll(CHATGPT_OBSERVED_USER_SELECTOR)]
      .filter(n => n.closest('[data-talvt-turn-state]') === turn && chatgptObservedUserParts(n));
    return slots.length === 1 && finals.length === 1 && finals[0] === message && users.length === 1 && Boolean(text(parts.body));
  }

  function chatgptComposerContext() {
    const observation = chatgptSurfaceObservation();
    if (observation) return chatgptObservedControlContext(observation);
    const modernSelector = '[data-composer-body] [contenteditable="true"][role="textbox"][data-composer-markdown]';
    const modern = [...document.querySelectorAll(modernSelector)].filter(observedComposerVisible);
    if (modern.length) {
      if (modern.length !== 1) return null;
      const composer = modern[0], body = composer.closest("[data-composer-body]");
      if (!body || !observedComposerVisible(body) || body.querySelectorAll('[data-composer-markdown][contenteditable="true"]').length !== 1) return null;
      const label = composer.getAttribute("aria-label");
      if (!["Спросить ChatGPT","Ask ChatGPT"].includes(label)) return null;
      let root = body;
      for (let p = body, depth = 0; p && p !== document.body && p !== document.documentElement && depth < 5; p = p.parentElement, depth++) {
        if ([...p.children].some(n => n.matches('input[type="file"][aria-label="Прикрепить файлы"]'))) { root = p; break; }
      }
      if (!observedComposerVisible(root) || root.querySelectorAll(modernSelector).length > 1 ||
          [...root.querySelectorAll('[contenteditable="true"][role="textbox"]')].filter(observedComposerVisible).length !== 1) return null;
      // "form" is the existing control-scope contract (Element), not a claim
      // that an HTML FORM was present in the captured DOM.
      return {composer,root,form:root,nativeForm:composer.closest("form"),locationHref:location.href,surfaceKind:"observed_standard"};
    }
    const selectors = ["#prompt-textarea",'[data-testid="prompt-textarea"]','textarea[id*="prompt" i]','textarea[data-testid*="prompt" i]','[contenteditable="true"][id*="prompt" i]','[contenteditable="true"][data-testid*="prompt" i]'];
    const candidates = [];
    for (const selector of selectors) for (const composer of document.querySelectorAll(selector)) {
      if (!observedComposerVisible(composer) || chatgptInsideAssistantEditor(composer)) continue;
      const form = composer.closest("form");
      if (!(form instanceof Element) || chatgptInsideAssistantEditor(form)) continue;
      let score = composer.id === "prompt-textarea" ? 1000 : composer.getAttribute("data-testid") === "prompt-textarea" ? 800 : 0;
      if (form.closest("#composer-background, [data-testid*='composer' i]")) score += 400;
      candidates.push({context:{composer,form,root:form,locationHref:location.href},score});
    }
    candidates.sort((a,b)=>b.score-a.score);
    if (candidates.length) return candidates[0].context;
    const observed = [...document.querySelectorAll('form [contenteditable="true"][role="textbox"][aria-label="Ask ChatGPT"]')].filter(observedComposerVisible);
    return observed.length === 1 ? {composer:observed[0],form:observed[0].closest("form"),root:observed[0].closest("form"),locationHref:location.href} : null;
  }

  function buttonToken(button) {
    return [
      button?.getAttribute?.("data-testid") || "",
      button?.getAttribute?.("aria-label") || "",
      button?.getAttribute?.("title") || "",
      button?.getAttribute?.("name") || "",
      button?.getAttribute?.("type") || "",
      button?.textContent || ""
    ].join(" ").toLowerCase();
  }

  function controlDisabled(button) {
    return Boolean(button instanceof HTMLButtonElement && button.disabled) || button?.getAttribute?.("aria-disabled") === "true";
  }

  function chatgptSendCandidates(context) {
    const live = chatgptComposerContext();
    if (!live || live.composer !== context?.composer || live.root !== context?.root || live.locationHref !== context?.locationHref || !context.form?.contains(context.composer)) return [];
    if (context.surfaceKind?.startsWith("observed_") && (chatgptUploadPending(context) || chatgptObservedStop(context))) return [];
    const exact = [...context.form.querySelectorAll('button#composer-submit-button[data-testid="send-button"], button[data-testid="send-button"]')]
      .filter((button) => button instanceof HTMLElement && visible(button) && !chatgptInsideAssistantEditor(button) && !controlDisabled(button));
    if (exact.length === 1) return [{ button: exact[0], score: 2000 }];
    return [...context.form.querySelectorAll('button, [role="button"], input[type="submit"]')]
      .filter((button) => button instanceof HTMLElement && visible(button) && !chatgptInsideAssistantEditor(button) && !controlDisabled(button))
      .filter((button) => !/stop|cancel|abort|останов|отмен/.test(buttonToken(button)))
      .map((button) => {
        const token = buttonToken(button);
        const testid = String(button.getAttribute("data-testid") || "").toLowerCase();
        let score = 0;
        if (testid === "send-button" || testid.includes("send-button")) score += 1000;
        if (/\bsend\b|отправ/u.test(token)) score += 600;
        if (String(button.getAttribute("type") || "").toLowerCase() === "submit") score += 300;
        return { button, score };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);
  }

  function chatgptSendButton(context) {
    const candidates = chatgptSendCandidates(context);
    const top = candidates[0];
    if (!top) return null;
    return candidates.filter((item) => item.score === top.score).length === 1 ? top.button : null;
  }

  const CHATGPT_OBSERVED_USER_SELECTOR = 'div[class~="group/user-message"][data-chatgpt-search-unit-key][data-chatgpt-search-message-ids]';
  function chatgptSentVisible(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected ||
        node.closest('[hidden],[aria-hidden="true"],[inert],[role="dialog"],[contenteditable="true"],[contenteditable="plaintext-only"],[data-composer-body],[data-composer-attachments]')) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let p = node; p instanceof Element; p = p.parentElement) {
      const style = getComputedStyle(p);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" ||
          style.contentVisibility === "hidden" || Number(style.opacity) === 0) return false;
    }
    return true;
  }

  function chatgptObservedUserParts(node) {
    if (!(node instanceof HTMLElement) || !node.matches(CHATGPT_OBSERVED_USER_SELECTOR) || !chatgptSentVisible(node) ||
        node.parentElement?.closest(CHATGPT_OBSERVED_USER_SELECTOR) || node.closest('[data-turn="assistant"],[data-message-role="assistant"],[data-message-author-role="assistant"]') ||
        node.querySelector(CHATGPT_OBSERVED_USER_SELECTOR+', [data-turn], [data-message-role], [data-message-author-role]')) return null;
    const unit = node.getAttribute("data-chatgpt-search-unit-key") || "";
    const id = node.getAttribute("data-chatgpt-search-message-ids") || "";
    // Values are read from this message, never a fixed snapshot or chat ID.
    if (!unit.endsWith(":user") || /\s/.test(unit) || !id || /[\s,]/.test(id)) return null;
    const bodies = [...node.children].filter(n => n.getAttribute("data-content-search-unit-key") === unit);
    if (bodies.length !== 1 || !chatgptSentVisible(bodies[0])) return null;
    const bubbles = [...bodies[0].querySelectorAll('[data-user-message-bubble="true"]')]
      .filter(n => n.closest(CHATGPT_OBSERVED_USER_SELECTOR) === node);
    if (bubbles.length !== 1 || !chatgptSentVisible(bubbles[0])) return null;
    const texts = [...bubbles[0].querySelectorAll('div.text-size-chat.whitespace-pre-wrap[dir="auto"]')]
      .filter(n => n.closest('[data-user-message-bubble="true"]') === bubbles[0]);
    if (texts.length !== 1 || !chatgptSentVisible(texts[0]) || texts[0].querySelector('button,input,textarea,[contenteditable], [class~="group/resource-card"]')) return null;
    return {node,unit,id,body:bodies[0],bubble:bubbles[0],text:texts[0]};
  }

  function chatgptObservedUserId(node) {
    const parts = chatgptObservedUserParts(node);
    if (!parts) return "";
    const same = [...document.querySelectorAll(CHATGPT_OBSERVED_USER_SELECTOR)]
      .filter(n => chatgptSentVisible(n) && n.getAttribute("data-chatgpt-search-message-ids") === parts.id);
    return same.length === 1 ? "chatgpt-observed-user:" + parts.id : "";
  }

  function chatgptUserMessages() {
    if (chatgptDotLocation()) return chatgptDotMessages("user");
    const observed = [...document.querySelectorAll(CHATGPT_OBSERVED_USER_SELECTOR)].filter(chatgptObservedUserParts);
    const roots = [...new Set([...chatgptMessages("user"), ...observed])];
    // A legacy role wrapper must not produce a second identity for this message.
    return roots.filter(n => !roots.some(other => other !== n && n.contains(other)))
      .sort((a,b) => a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1);
  }

  function chatgptSentAttachmentMessage(node, descriptors) {
    if (chatgptDotLocation()) return chatgptDotSentAttachmentMessage(node, descriptors);
    const parts = chatgptObservedUserParts(node), list = Array.isArray(descriptors) ? descriptors : [];
    if (!parts || !chatgptObservedUserId(node) || !list.length ||
        list.some(d => typeof d?.filename !== "string" || !d.filename) ||
        new Set(list.map(d=>d.filename)).size !== list.length ||
        node.querySelector('[role="progressbar"],[aria-busy="true"]')) return null;
    const cards = [...node.querySelectorAll('span[class~="group/resource-card"]')]
      .filter(card => card.closest(CHATGPT_OBSERVED_USER_SELECTOR) === node && chatgptSentVisible(card));
    if (cards.length !== list.length) return null;
    const filenames = [];
    for (const card of cards) {
      if (parts.body.contains(card)) return null;
      const buttons = [...card.children].filter(n => n.matches('button[type="button"][class~="peer/resource-card"]'));
      if (buttons.length !== 1 || !chatgptSentVisible(buttons[0]) || buttons[0].disabled ||
          buttons[0].getAttribute("aria-disabled") === "true" || buttons[0].getAttribute("aria-busy") !== "false") return null;
      const filename = buttons[0].getAttribute("aria-label") || "";
      const labels = [...card.querySelectorAll('span.truncate[title]')]
        .filter(n => n.closest('span[class~="group/resource-card"]') === card && chatgptSentVisible(n));
      if (!filename || labels.length !== 1 || labels[0].getAttribute("title") !== filename ||
          labels[0].textContent !== filename || !list.some(d => d.filename === filename)) return null;
      filenames.push(filename);
    }
    if (new Set(filenames).size !== filenames.length) return null;
    return {text:parts.text.textContent || "",filenames};
  }

  function chatgptFileInput() {
    const c = chatgptComposerContext();
    if (!c) return null;
    if (c.surfaceKind === "observed_dot") {
      const inputs = [...c.root.children].filter(n => n.matches('input[type="file"][data-role="file-input"]'));
      const input = inputs.length === 1 ? inputs[0] : null;
      return input instanceof HTMLInputElement && input.multiple && input.isConnected &&
        !input.disabled && !input.matches(':disabled') && input.getAttribute('aria-disabled') !== 'true' ? input : null;
    }
    const all = [...c.root.querySelectorAll('input[type="file"]')].filter(n =>
      n instanceof HTMLInputElement && n.isConnected && !n.disabled && !n.matches(":disabled") &&
      n.getAttribute("aria-disabled") !== "true" && !n.closest('[hidden],[inert],[aria-hidden="true"],[data-message-role],[data-turn],[data-message-author-role]'));
    const named = all.filter(n => n.getAttribute("aria-label") === "Прикрепить файлы");
    if (["observed_standard","observed_work"].includes(c.surfaceKind)) return named.length === 1 && named[0].multiple && named[0].parentElement === c.root ? named[0] : null;
    const legacy = all.filter(n => n.id === "upload-files");
    return legacy.length === 1 ? legacy[0] : all.length === 1 ? all[0] : null;
  }

  function chatgptAttachmentPreview(filename) {
    const target = String(filename || ""), c = chatgptComposerContext();
    if (!target || !c) return null;
    if (["observed_standard","observed_work","observed_dot"].includes(c.surfaceKind)) {
      const zones = [...c.root.querySelectorAll("[data-composer-attachments]")].filter(observedComposerVisible);
      if (zones.length !== 1) return null;
      const cards = [...zones[0].querySelectorAll('span[class~="group/composer-attachment"]')].filter(observedComposerVisible);
      const matching = cards.filter(card => {
        const names = [...card.querySelectorAll("span.truncate")].filter(n => n.textContent === target);
        const open = [...card.querySelectorAll("button.composer-attachment-surface")].filter(n => n.getAttribute("aria-label") === target);
        if (c.surfaceKind === "observed_dot") {
          const remove = [...card.children].filter(n => n.matches('button[type="button"]') && n.getAttribute('aria-label') === 'Удалить '+target);
          return names.length === 1 && remove.length === 1 && !remove[0].disabled && remove[0].getAttribute('aria-disabled') !== 'true';
        }
        return names.length === 1 && open.length === 1 && observedComposerVisible(open[0]);
      });
      return matching.length === 1 ? matching[0] : null;
    }
    const nodes = [...c.root.querySelectorAll('[role="group"][aria-label], [data-testid*="file" i][aria-label], [title]')]
      .filter(n => observedComposerVisible(n) && [n.getAttribute("aria-label"),n.getAttribute("title")].includes(target));
    return nodes.length === 1 ? nodes[0] : null;
  }

  function chatgptAttachmentSurface() {
    const c = chatgptComposerContext(), input = chatgptFileInput();
    if (!c || !input || input.files?.length || readComposerText(c.composer).trim() ||
        chatgptUploadPending(c) || chatgptObservedStop(c) ||
        [...c.root.querySelectorAll('[data-composer-attachments]')].some(observedComposerVisible)) return null;
    return {kind:"file_input_v1",input,root:c.root,composer:c.composer,locationHref:location.href};
  }

  function chatgptAttachmentReady(descriptors) {
    const c = chatgptComposerContext(), list = Array.isArray(descriptors) ? descriptors : [];
    if (!c || !list.length || list.some(d => typeof d?.filename !== "string" || !d.filename) ||
        new Set(list.map(d=>d.filename)).size !== list.length ||
        chatgptUploadPending(c) || chatgptObservedStop(c)) return false;
    const input = chatgptFileInput();
    if (input?.files?.length && (input.files.length !== list.length ||
        list.some(d => ![...input.files].some(f => f.name === d.filename && f.size === d.byte_length)))) return false;
    return list.every(d => {
      const preview = chatgptAttachmentPreview(d.filename);
      return Boolean(preview && !preview.querySelector('[role="progressbar"],[aria-busy="true"]'));
    });
  }

  function aliceComposerShell() {
    const context = aliceComposerContext();
    if (!context?.composer || !(context.root instanceof Element)) return null;
    const standaloneInput = context.composer.closest('.Standalone-Input') || context.root.closest?.('.Standalone-Input') || context.root;
    if (!(standaloneInput instanceof Element)) return null;
    const controls = standaloneInput.querySelector('[data-testid="input-controls-root"]') || context.root.querySelector?.('[data-testid="input-controls-root"]');
    if (!(controls instanceof Element) || !controls.isConnected) return null;
    // Alice exposes attachments through either the legacy Plus control or
    // the current More menu, inside the same composer controls.
    const markers = [...controls.querySelectorAll(
      'button[data-testid="InputControls-Plus-Button"][aria-label="Добавить файл"][aria-haspopup="dialog"], button[data-testid="InputControls-More-Button"]'
    )].filter((node) => node instanceof HTMLElement && node.isConnected && visible(node) && !controlDisabled(node));
    if (markers.length !== 1) return null;
    const plus = markers[0];
    if (!(document.body instanceof HTMLElement) || !document.body.isConnected) return null;
    return { context, standaloneInput, controls, plus };
  }

  function aliceAttachmentSurface() {
    const shell = aliceComposerShell();
    if (!shell || readComposerText(shell.context.composer).trim() ||
        shell.controls.getAttribute("aria-busy") === "true" ||
        shell.context.root.querySelector('[data-testid="oknyx"][aria-label="Алиса, стоп"],.InputFilesBlock .File[data-testid="file"]')) return null;
    return { kind: "drag_drop_v1", root: document.body, composer_root: shell.standaloneInput, controls_root: shell.controls, capability_marker: shell.plus, composer: shell.context.composer, locationHref: location.href };
  }

  function aliceAttachFiles(surface, files) {
    if (surface?.kind !== "drag_drop_v1" || surface.root !== document.body || !surface.root?.isConnected) {
      throw Object.assign(new Error("Alice drag-drop attachment surface is unavailable."), { code: "TARGET_AI_ATTACHMENT_SURFACE_UNAVAILABLE" });
    }
    const live = aliceAttachmentSurface();
    if (!live || live.root !== surface.root || !surface.capability_marker?.isConnected || live.capability_marker !== surface.capability_marker || live.composer !== surface.composer || live.composer_root !== surface.composer_root || live.controls_root !== surface.controls_root || live.locationHref !== surface.locationHref) {
      throw Object.assign(new Error("Alice drag-drop capability marker changed before attachment dispatch."), { code: "TARGET_AI_ATTACHMENT_SURFACE_CHANGED" });
    }
    const helper = globalThis.OzonWebFileAttachment;
    if (typeof helper?.dispatchFileDrop !== "function") throw Object.assign(new Error("Alice drag-drop browser primitive is unavailable."), { code: "TARGET_AI_ATTACHMENT_TRANSPORT_UNAVAILABLE" });
    return helper.dispatchFileDrop(live.root, files);
  }

  function aliceAttachmentScopes() {
    const shell = aliceComposerShell();
    if (!shell) return [];
    const scopes = [];
    const add = (node) => { if (node instanceof Element && node.isConnected && !scopes.includes(node)) scopes.push(node); };
    add(shell.standaloneInput);
    add(shell.context.root);
    const topControls = shell.standaloneInput.querySelector?.('.StandaloneInput-TopControls');
    add(topControls);
    return scopes;
  }

  // Observed Alice card states (21 Oct). Layout alone is not an upload receipt.
  const ALICE_OBSERVED_USER = 'div.Message.Message_from_user[data-message-role="user"]';
  function aliceFileVisible(node) {
    if (!(node instanceof HTMLElement) || !node.isConnected ||
        node.closest('[hidden],[aria-hidden="true"],[inert],[role="dialog"]')) return false;
    const rect = node.getBoundingClientRect();
    if (!node.getClientRects().length || rect.width <= 0 || rect.height <= 0) return false;
    for (let p = node; p instanceof Element; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse" ||
          s.contentVisibility === "hidden" || Number(s.opacity) === 0) return false;
    }
    return true;
  }
  function aliceFileNames(descriptors) {
    if (!Array.isArray(descriptors) || !descriptors.length) return null;
    const names = descriptors.map(d => typeof d?.filename === "string" ? d.filename.trim() : "");
    return names.every(Boolean) && new Set(names).size === names.length ? names : null;
  }
  function aliceFileName(card) {
    if (!aliceFileVisible(card) || !card.matches('.File[data-testid="file"]') ||
        card.matches('[aria-busy="true"]') || card.querySelector('[aria-busy="true"],[role="progressbar"]')) return "";
    const titles = [...card.querySelectorAll('.File-Title[data-testid="file-title"]')]
      .filter(n => n.closest('.File[data-testid="file"]') === card);
    if (titles.length !== 1 || !aliceFileVisible(titles[0])) return "";
    const title = titles[0], other = title.querySelectorAll(':scope > .File-TitleOther'), required = title.querySelectorAll(':scope > .File-TitleRequired');
    if (other.length !== 1 || required.length !== 1 || title.children.length !== 2 ||
        !aliceFileVisible(other[0]) || !aliceFileVisible(required[0])) return "";
    const name = (other[0].textContent + required[0].textContent).trim();
    if (!name || title.textContent.trim() !== name) return "";
    const descriptions = [...card.querySelectorAll('.File-Description')]
      .filter(n => n.closest('.File[data-testid="file"]') === card);
    // TXT + rounded display size is a ready-card witness, never byte identity.
    if (descriptions.length !== 1 || !aliceFileVisible(descriptions[0]) ||
        !/^TXT\s*·\s*\d+(?:[.,]\d+)?\s*(?:Б|КБ|МБ|ГБ)$/i.test(descriptions[0].textContent.replace(/\u00a0/g, " ").trim())) return "";
    return name;
  }
  function aliceObservedReadyCards() {
    const context = aliceComposerContext(), root = context?.root;
    if (!(root instanceof HTMLElement) || !root.matches('.AliceInput[data-highlight-id="alice-input"]')) return null;
    const shell = aliceComposerShell();
    if (!shell || shell.context.root !== root || shell.controls.getAttribute("aria-busy") === "true" ||
        root.querySelector('[aria-busy="true"],[role="progressbar"],.StandaloneOknyx_error,[data-testid="oknyx"][aria-label="Алиса, стоп"]')) return [];
    const blocks = [...root.querySelectorAll('.InputFilesBlock[data-testid="input-files-block"]')]
      .filter(n => n.closest('.AliceInput') === root);
    if (blocks.length !== 1 || !aliceFileVisible(blocks[0])) return [];
    const cards = [...blocks[0].querySelectorAll('.File[data-testid="file"]')];
    if (!cards.length || cards.some(card => card.closest('.AliceInput') !== root ||
        card.closest('.InputFilesBlock') !== blocks[0] || !card.matches('.File_view_secondary.InputFilesBlock-Item') || !aliceFileName(card))) return [];
    for (const card of cards) {
      const remove = [...card.querySelectorAll('button.File-Remove[data-testid="file-remove-button"][aria-label="Удалить"]')]
        .filter(n => n.closest('.File') === card);
      if (remove.length !== 1 || !aliceFileVisible(remove[0]) || controlDisabled(remove[0])) return [];
    }
    return cards;
  }
  function aliceObservedUserId(node) {
    if (!(node instanceof HTMLElement) || !node.matches(ALICE_OBSERVED_USER) || !aliceFileVisible(node) ||
        node.closest('.AliceInput,[contenteditable="true"],form') || node.parentElement?.closest('[data-message-role]')) return "";
    const id = node.getAttribute('data-request-id')?.trim() || "";
    if (!id || node.id !== id || /\s/.test(id)) return "";
    const peers = [...document.querySelectorAll(ALICE_OBSERVED_USER)]
      .filter(n => aliceFileVisible(n) && n.getAttribute('data-request-id')?.trim() === id);
    return peers.length === 1 ? 'alice-observed-user:' + id : "";
  }
  function aliceSentAttachmentMessage(node, descriptors) {
    const names = aliceFileNames(descriptors);
    if (!names || !aliceObservedUserId(node) || node.querySelector('[data-message-role],[aria-busy="true"],[role="progressbar"]')) return null;
    const fileGroups = [...node.querySelectorAll('.MessageBubble-Container_type_files.MessageBubble-Container_from-user')];
    const textGroups = [...node.querySelectorAll('.MessageBubble-Container_type_text.MessageBubble-Container_from-user')];
    if (fileGroups.length !== 1 || textGroups.length !== 1 ||
        fileGroups[0].parentElement !== node || textGroups[0].parentElement !== node ||
        !aliceFileVisible(fileGroups[0]) || !aliceFileVisible(textGroups[0])) return null;
    const texts = [...textGroups[0].querySelectorAll('.AliceTextBubble.AliceTextBubble_from_user')];
    if (texts.length !== 1 || !aliceFileVisible(texts[0]) ||
        texts[0].closest('[data-message-role]') !== node || texts[0].querySelector('button,input,textarea,[contenteditable="true"]')) return null;
    const cards = [...node.querySelectorAll('.File[data-testid="file"]')];
    if (cards.length !== names.length) return null;
    const found = [];
    for (const card of cards) {
      const row = card.closest('.MessageAttachedFiles-Row[data-testid="message-attached-files-row"]');
      const group = card.closest('.MessageAttachedFiles[data-testid="message-attached-files"]');
      const bubble = card.closest('.MessageBubble-UserRequest_fileUpload');
      if (!card.matches('.File_view_primary.MessageAttachedFiles-Item_file') || !row || !group || !bubble ||
          !group.contains(row) || !bubble.contains(group) || !fileGroups[0].contains(bubble) ||
          card.closest('[data-message-role]') !== node || card.querySelector('.File-Remove')) return null;
      const name = aliceFileName(card);
      if (!name || !names.includes(name) || found.includes(name)) return null;
      found.push(name);
    }
    const body = texts[0].textContent.replace(/\u00a0/g, " ").trim();
    return body ? {text:body,filenames:found} : null;
  }
  function aliceRequiresSentAttachmentMessage(node) {
    const context = aliceComposerContext();
    const legacy = context?.root?.matches('[data-testid="standalone-input"],[data-testid="standalone-input-field"]') &&
      !context.root.matches('.AliceInput[data-highlight-id="alice-input"]');
    return !legacy || Boolean(node?.matches?.(ALICE_OBSERVED_USER));
  }

  function aliceAttachmentPreview(filename) {
    const observed = aliceObservedReadyCards();
    if (observed !== null) {
      const matches = observed.filter(card => aliceFileName(card) === String(filename || "").trim());
      return matches.length === 1 ? matches[0] : null;
    }
    const target = String(filename || "").trim();
    if (!target) return null;
    const matches = [];
    for (const scope of aliceAttachmentScopes()) {
      for (const node of scope.querySelectorAll('*')) {
        if (!(node instanceof HTMLElement) || !node.isConnected) continue;
        const attrs = [
          node.getAttribute('data-filename') || '', node.getAttribute('data-file-name') || '',
          node.getAttribute('aria-label') || '', node.getAttribute('title') || ''
        ].map((value) => String(value).trim()).filter(Boolean);
        const exactAttr = attrs.some((value) => value === target || value.includes(target));
        const nodeText = String(node.textContent || '').replace(/\u00a0/g, ' ').trim();
        const exactText = nodeText === target;
        if (exactAttr || exactText) matches.push(node);
      }
      if (matches.length) break;
    }
    if (!matches.length) return null;
    const leaves = matches.filter((node) => !matches.some((other) => other !== node && node.contains(other)));
    const candidates = leaves.length ? leaves : matches;
    return candidates.length === 1 ? candidates[0] : null;
  }

  function aliceAttachmentStatusText(preview) {
    if (!(preview instanceof HTMLElement)) return "";
    const tokens = [];
    let node = preview;
    for (let depth = 0; node instanceof HTMLElement && depth < 4; depth += 1, node = node.parentElement) {
      tokens.push(node.getAttribute('data-status') || '', node.getAttribute('aria-label') || '', node.getAttribute('title') || '', node.textContent || '');
      if (node.classList?.contains('Standalone-Input')) break;
    }
    return tokens.join(' ').replace(/\u00a0/g, ' ').toLowerCase();
  }

  const CHATGPT_COPY_ANCHORS = new WeakMap();
  const ALICE_COPY_ANCHORS = new WeakMap();
  const CHATGPT_CODE_COPY_SELECTOR = 'button[data-code-copy-state], button[aria-label="Копировать"], button[aria-label="Copy"], button[aria-label="Copy code"], button[aria-label="Копировать код"], button[title="Copy code"], button[title="Копировать код"], button[title="Copy"], button[title="Копировать"]';
  const CHATGPT_CODE_COPY_TEXT = new Set(["copy", "copy code", "копировать", "копировать код"]);

  function chatgptInsideResponseActions(node) {
    return Boolean(node instanceof Element && node.closest(CHATGPT_RESPONSE_ACTION_SELECTOR));
  }

  function chatgptCodeCopyButtons(root) {
    if (!(root instanceof Element)) return [];
    return [...root.querySelectorAll("button")].filter((button) => {
      if (chatgptInsideResponseActions(button)) return false;
      if (button.matches(CHATGPT_CODE_COPY_SELECTOR)) return true;
      return CHATGPT_CODE_COPY_TEXT.has(text(button).replace(/\s+/g, " ").toLowerCase());
    });
  }

  function chatgptMessages(role) {
    if (chatgptDotLocation()) return chatgptDotMessages(role);
    const selector = `[data-turn="${role}"], [data-message-author-role="${role}"], [data-message-role="${role}"]`;
    const opposite = role === "assistant" ? "user" : "assistant";
    const excluded = `[data-turn="${opposite}"], [data-message-author-role="${opposite}"], [data-message-role="${opposite}"]` + (role === "assistant" ? ", " + CHATGPT_OBSERVED_USER_SELECTOR : "");
    const explicit = [...document.querySelectorAll(selector)].filter((node) =>
      !node.parentElement?.closest(selector) && !node.closest(excluded));
    if (role !== "assistant") return explicit;

    // Current authenticated/project ChatGPT can expose a response turn through its
    // response-actions group even when legacy data-turn/data-message role markers
    // are absent from the outer structural container.
    const actionSelector = [
      '[data-assistant-message-actions]',
      '[data-message-actions][aria-label="Response actions"]',
      '[data-message-actions][aria-label="Действия с ответом"]',
      '[role="group"][aria-label="Response actions"]',
      '[role="group"][aria-label="Действия с ответом"]'
    ].join(', ');
    const inferred = [];
    for (const actions of document.querySelectorAll(actionSelector)) {
      if (!(actions instanceof Element) || actions.closest(excluded) || chatgptDirectAssistantContext(actions)) continue;
      let node = actions.parentElement;
      while (node && node !== document.body && node !== document.documentElement) {
        if (node.matches(excluded)) break;
        if (node.matches(selector)) { inferred.push(node); break; }
        const structural = node.matches('article, li, section, [data-testid^="conversation-turn"]');
        const assistantContent = node.querySelector('[data-assistant-markdown], [data-assistant-stream-block], [data-message-content-controls], [data-assistant-content-started]');
        if (structural && assistantContent && node.querySelectorAll(actionSelector).length === 1 && !node.querySelector(excluded)) {
          inferred.push(node);
          break;
        }
        node = node.parentElement;
      }
    }
    const observedWork = [...document.querySelectorAll(CHATGPT_WORK_MESSAGE)].filter(chatgptWorkMessageParts);
    const roots = [...new Set([...explicit, ...inferred, ...observedWork])].filter((node) =>
      !node.parentElement?.closest(selector) && !node.closest(excluded) && !node.querySelector(excluded));
    // An inferred wrapper cannot duplicate an already proven nested response.
    const canonical = roots.filter((node) =>
      !roots.some((other) => other !== node && node.contains(other)));
    return canonical.sort((left, right) => {
      const position = left.compareDocumentPosition(right);
      return position & Node.DOCUMENT_POSITION_FOLLOWING ? -1
        : position & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
    });
  }

  function chatgptCopyOwnedBlock(copyButton, message) {
    if (!(copyButton instanceof Element) || !(message instanceof Element) || !message.contains(copyButton)) return null;
    if (chatgptInsideResponseActions(copyButton)) return null;
    let node = copyButton.parentElement;
    while (node && node !== message) {
      const copyControls = chatgptCodeCopyButtons(node);
      const rawSurfaces = [
        ...node.querySelectorAll('[data-writing-block-fullscreen-editor-region]'),
        ...node.querySelectorAll('.cm-content'),
        ...node.querySelectorAll('#code-block-viewer'),
        ...node.querySelectorAll('pre > code'),
        ...node.querySelectorAll('pre'),
        ...node.querySelectorAll('code')
      ];
      // A message-level Copy must never claim several independent code blocks.
      const surfaces = [...new Set(rawSurfaces)].filter((surface) =>
        !rawSurfaces.some((other) => other !== surface && other.contains(surface)));
      if (copyControls.length === 1 && surfaces.length === 1) return node;
      node = node.parentElement;
    }
    return null;
  }

  const CHATGPT = Object.freeze({
    id: "chatgpt",
    label: "ChatGPT",
    surfaceObservation: chatgptSurfaceObservation,
    matchesLocation() { return ["chatgpt.com", "chat.openai.com"].includes(host()); },
    assistantMessages() {
      return chatgptMessages("assistant");
    },
    userMessages: chatgptUserMessages,
    messageId(node) {
      if (!(node instanceof Element)) return "";
      if (chatgptDotLocation()) {
        const parts = chatgptDotMessageParts(node);
        return parts ? "dot-message:" + parts.id : "";
      }
      if (node.matches(CHATGPT_WORK_MESSAGE)) {
        const parts = chatgptWorkMessageParts(node);
        return parts ? "work-message:" + parts.id : "";
      }
      if (node.matches(CHATGPT_OBSERVED_USER_SELECTOR)) return chatgptObservedUserId(node);
      return node.getAttribute("data-turn-id") || node.querySelector('[data-message-author-role][data-message-id]')?.getAttribute("data-message-id") || node.getAttribute("data-message-id") || node.id || "";
    },
    messageText(node) {
      if (!(node instanceof Element)) return "";
      if (chatgptDotLocation()) {
        const parts = chatgptDotMessageParts(node);
        return chatgptDotContentText(parts);
      }
      if (node.matches(CHATGPT_OBSERVED_USER_SELECTOR)) return chatgptObservedUserParts(node)?.text.textContent || "";
      if (!node.matches('[data-message-role="user"], [data-message-author-role="user"], [data-turn="user"]')) return text(node);
      // A turn wrapper also contains attribution and response controls. Match
      // the semantic user body, never a translated label or a prompt substring.
      const bodies = [...node.querySelectorAll("[data-user-message-copy]")].filter(body =>
        body.closest('[data-message-role], [data-message-author-role], [data-turn]') === node);
      if (bodies.length === 1) return text(bodies[0]);
      if (bodies.length > 1) return "";
      return text(node);
    },
    findCodeBlocks(message) {
      if (!(message instanceof Element)) return [];
      if (chatgptDotLocation() || message.matches(CHATGPT_WORK_MESSAGE)) return chatgptObservedCodeBlocks(message);
      const roots = [];
      for (const copyButton of chatgptCodeCopyButtons(message)) {
        const root = chatgptCopyOwnedBlock(copyButton, message);
        if (!root) continue;
        CHATGPT_COPY_ANCHORS.set(root, copyButton);
        roots.push(root);
      }
      // Standard fenced code is authoritative inside a proven assistant message.
      // It remains discoverable when Copy is localized, icon-only or mounted later.
      for (const code of message.querySelectorAll("pre > code")) {
        const pre = code.parentElement;
        if (!roots.some((root) => root.contains(pre))) roots.push(pre);
      }
      return [...new Set(roots)];
    },
    readCodeText(block) {
      if (!(block instanceof Element)) return "";
      const writingBody = block.querySelector('[data-writing-block-fullscreen-editor-region]');
      if (writingBody) return String(writingBody.innerText || writingBody.textContent || "");
      const cm = block.querySelector('.cm-content');
      if (cm) return String(cm.textContent || "");
      const legacy = block.querySelector('#code-block-viewer');
      if (legacy) return String(legacy.innerText || legacy.textContent || "");
      const code = block.querySelector("pre > code") || block.querySelector("code");
      if (code) return String(code.textContent || "");
      const pre = block.querySelector("pre");
      return pre ? String(pre.textContent || "") : "";
    },
    geometryAnchor(block) {
      const copyButton = block instanceof Element ? CHATGPT_COPY_ANCHORS.get(block) : null;
      return copyButton?.isConnected ? copyButton : (block instanceof Element ? block : null);
    },
    isGenerating() { return Boolean(document.querySelector('[data-testid="stop-button"]') || document.querySelector('[aria-busy="true"]')); },
    messageComplete(message) {
      const observation = chatgptSurfaceObservation();
      if (observation?.kind === "work" || message?.matches?.(CHATGPT_WORK_MESSAGE)) return chatgptWorkMessageComplete(message);
      if (observation?.kind === "dot") return false; // No per-message dot completion witness yet.
      return Boolean(message?.isConnected && !this.isGenerating() && text(message));
    },
    composerContext: chatgptComposerContext,
    readComposerText,
    setComposerText,
    sendButtonCandidates: chatgptSendCandidates,
    sendButton: chatgptSendButton,
    sendButtonFingerprint(button) {
      if (!(button instanceof HTMLElement)) return "";
      return [button.tagName, button.getAttribute("data-testid") || "", button.getAttribute("aria-label") || "", button.getAttribute("title") || "", button.getAttribute("type") || "", button.getAttribute("name") || ""].join("|");
    },
    deliveryCapabilities() { return globalThis.OzonAIDeliveryCapabilities?.profile?.("chatgpt") || null; },
    attachmentSurface: chatgptAttachmentSurface,
    attachFiles(surface, files) {
      const live = chatgptAttachmentSurface();
      if (!live || live.input !== surface?.input || live.root !== surface?.root ||
          live.composer !== surface?.composer || live.locationHref !== surface?.locationHref || live.kind !== surface?.kind)
        throw Object.assign(new Error("ChatGPT attachment surface changed."), {code:"TARGET_AI_ATTACHMENT_SURFACE_UNAVAILABLE"});
      return globalThis.OzonWebFileAttachment.setInputFiles(live.input, files);
    },
    attachmentPreview: chatgptAttachmentPreview,
    attachmentReady: chatgptAttachmentReady,
    requiresSentAttachmentMessage(node) {
      // Only the known legacy composer keeps its prior text receipt route.
      const context = chatgptComposerContext();
      return !context || context.surfaceKind?.startsWith("observed_") ||
        node?.matches?.(CHATGPT_OBSERVED_USER_SELECTOR) === true;
    },
    sentAttachmentMessage: chatgptSentAttachmentMessage
  });

  const ALICE = Object.freeze({
    id: "alice",
    label: "Alice",
    matchesLocation() { return host() === "alice.yandex.ru"; },
    assistantMessages() { return [...document.querySelectorAll('[data-message-role="alice"]')]; },
    userMessages() { return [...document.querySelectorAll('[data-message-role="user"]')]; },
    messageId(node) {
      if (!(node instanceof Element)) return "";
      if (node.matches(ALICE_OBSERVED_USER)) return aliceObservedUserId(node);
      return node.id || node.getAttribute("data-message-id") || "";
    },
    messageText(node) {
      if (!(node instanceof Element)) return "";
      if (!node.matches('[data-message-role="user"]')) return text(node);
      // The role wrapper also contains the author and Expand controls. Only
      // the single owned text bubble can witness our exact submitted prompt.
      const bubbles = [...node.querySelectorAll('.AliceTextBubble.AliceTextBubble_from_user')]
        .filter((bubble) => bubble.closest('[data-message-role]') === node);
      if (bubbles.length !== 1 || !visible(bubbles[0]) || !bubbles[0].getClientRects().length ||
          bubbles[0].closest('[aria-hidden="true"], [hidden]')) return "";
      return String(bubbles[0].textContent || "").replace(/\u00a0/g, " ").trim();
    },
    findCodeBlocks(message) {
      if (!(message instanceof Element)) return [];
      const roots = [];
      for (const copyButton of message.querySelectorAll('[data-testid="codeblock-action-copy"]')) {
        const root = copyButton.closest('.CodeBlock');
        if (!(root instanceof Element) || !message.contains(root)) continue;
        ALICE_COPY_ANCHORS.set(root, copyButton);
        roots.push(root);
      }
      return [...new Set(roots)];
    },
    readCodeText(block) {
      if (!(block instanceof Element)) return "";
      const code = block.querySelector("pre.CodeBlock-ContentPre > code") || block.querySelector("pre > code");
      return code ? String(code.textContent || "") : "";
    },
    geometryAnchor(block) {
      if (!(block instanceof Element)) return null;
      const copyButton = ALICE_COPY_ANCHORS.get(block);
      return copyButton?.isConnected ? copyButton : (block.querySelector(":scope > .CodeBlock-StickyWrapper") || block);
    },
    composerContext: aliceComposerContext,
    readComposerText,
    setComposerText,
    classifyComposerControl(context, visibleFn = visible) {
      const root = context?.root;
      if (!(root instanceof Element)) return { kind: "unknown", button: null };
      const button = root.querySelector('[data-testid="oknyx"]');
      if (!(button instanceof HTMLElement) || !visibleFn(button)) return { kind: "unknown", button: null };
      const aria = String(button.getAttribute("aria-label") || "").trim().toLowerCase();
      if (aria === "алиса, стоп") return { kind: "stop", button };
      if (aria === "отправить") {
        // Alice's first-party StandaloneOknyx handler intentionally no-ops submit while
        // inputStore.status === "blocked". The current Alice bundle exposes that state as
        // the boolean BEM modifier StandaloneOknyx_error even when the native button is not
        // disabled and aria-label is still "Отправить". Treat it as send-disabled so the
        // delivery state machine waits before SEND_COMMIT instead of committing a no-op click.
        const aliceInputBlocked = button.classList?.contains?.("StandaloneOknyx_error") === true;
        return { kind: (controlDisabled(button) || aliceInputBlocked) ? "send_disabled" : "send_active", button };
      }
      if (aria === "алиса, начни слушать") return { kind: "ready", button };
      return { kind: "unknown", button };
    },
    sendButtonCandidates(context) {
      const classified = this.classifyComposerControl(context, visible);
      return classified.kind === "send_active" && classified.button ? [{ button: classified.button, score: 2000 }] : [];
    },
    sendButton(context) {
      const classified = this.classifyComposerControl(context, visible);
      return classified.kind === "send_active" ? classified.button : null;
    },
    sendButtonFingerprint(button) {
      if (!(button instanceof HTMLElement)) return "";
      return [button.tagName, button.getAttribute("data-testid") || "", button.getAttribute("aria-label") || "", button.getAttribute("title") || ""].join("|");
    },
    deliveryCapabilities() { return globalThis.OzonAIDeliveryCapabilities?.profile?.("alice") || null; },
    attachmentSurface() { return aliceAttachmentSurface(); },
    attachFiles(surface, files) { return aliceAttachFiles(surface, files); },
    attachmentPreview(filename) { return aliceAttachmentPreview(filename); },
    requiresSentAttachmentMessage: aliceRequiresSentAttachmentMessage,
    sentAttachmentMessage: aliceSentAttachmentMessage,
    attachmentReady(descriptors) {
      const observed = aliceObservedReadyCards();
      if (observed !== null) {
        const names = aliceFileNames(descriptors);
        return Boolean(names && observed.length === names.length &&
          names.every(name => observed.filter(card => aliceFileName(card) === name).length === 1));
      }
      const list = Array.isArray(descriptors) ? descriptors : [];
      if (!list.length) return false;
      return list.every((descriptor) => {
        const preview = aliceAttachmentPreview(descriptor.filename);
        if (!preview?.isConnected || !visible(preview) || preview.matches?.('[aria-busy="true"]') || preview.querySelector?.('[aria-busy="true"]')) return false;
        const status = aliceAttachmentStatusText(preview);
        return !/uploading|loading|загружа|обработ|ошиб|error|не поддерж|unsupported|failed|сбой/.test(status);
      });
    },
    isGenerating() {
      const button = document.querySelector('[data-testid="oknyx"]');
      return String(button?.getAttribute("aria-label") || "").trim().toLowerCase() === "алиса, стоп";
    },
    messageComplete(message) { return Boolean(message?.isConnected && !this.isGenerating() && text(message)); }
  });

  const QWEN = SellerAgentsQwenAdapter.create({ visible, readComposerText, setComposerText });
  const KIMI = SellerAgentsKimiAdapter.create({ readComposerText, setComposerText });
  const GROK = SellerAgentsGrokAdapter.create({ readComposerText, setComposerText });
  const GEMINI = SellerAgentsGeminiAdapter.create({ readComposerText, setComposerText });
  const CLAUDE = SellerAgentsClaudeAdapter.create({ readComposerText, setComposerText });
  const DEEPSEEK = SellerAgentsDeepSeekAdapter.create({ readComposerText, setComposerText });
  const ADAPTERS = Object.freeze({ chatgpt: CHATGPT, alice: ALICE, qwen: QWEN, kimi: KIMI, grok: GROK, gemini: GEMINI, claude: CLAUDE, deepseek: DEEPSEEK });

  function adapterForLocation(mode = "auto") {
    const normalized = normalizeMode(mode);
    // Kimi selection requires the reviewed local delivery profile.
    // Adapter presence never replaces signed profile, entitlement or Work authority.
    const available = adapter => ["gemini", "claude", "deepseek"].includes(adapter?.id) ? ["text_only", "implemented"].includes(adapter.deliveryCapabilities()?.status) : !["kimi", "grok"].includes(adapter?.id) || adapter.deliveryCapabilities()?.status === "implemented";
    if (normalized !== "auto") {
      const selected = ADAPTERS[normalized] || null;
      return selected?.matchesLocation() && available(selected) ? selected : null;
    }
    return Object.values(ADAPTERS).find((candidate) => candidate.matchesLocation() && available(candidate)) || null;
  }

  globalThis.OzonAIAdapters = Object.freeze({
    AI_MODES,
    ADAPTERS,
    normalizeMode,
    adapterForLocation,
    visible,
    readComposerText,
    setComposerText
  });
})();

;
/* One document-scoped observation shared by text and attachment delivery. */
(() => {
  "use strict";
  if (globalThis.SellerAgentsConversationSurface?.version === 1) return;
  const core = globalThis.SellerAgentsConversationIdentity;
  const tracker = core.createTracker({ newToken: () => crypto.randomUUID() });
  const text = (value) => String(value || "").replace(/\s+/g, " ").trim();
  let pending = null;
  let lastInput = null;
  let address = null;
  function locatorDigest() {
    const value = location.origin + location.pathname + (location.search || "") + (location.hash || "");
    if (address?.value === value) return address;
    const entry = { value, digest: null, promise: null };
    address = entry;
    entry.promise = crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))
      .then((bytes) => { entry.digest = [...new Uint8Array(bytes)].map((byte) => byte.toString(16).padStart(2, "0")).join(""); })
      .catch(() => { entry.failed = true; });
    return entry;
  }
  function capture(adapter) {
    const origin = String(location.origin).toLowerCase();
    const provider = globalThis.BB2ConversationIdentity.providerForOrigin(origin);
    if (!adapter || adapter.id !== provider) return { origin, provider: null };
    const pathname = location.pathname + (location.search || "") + (location.hash || "");
    // A retained empty Qwen frame may finish only the observed guest route
    // promotion. A different route ends that observation before any matching
    // historical text could be considered an owned-message witness.
    if (pending?.qwenRemountGap && (provider !== "qwen" ||
        !["/c/new-chat", "/c/guest"].includes(pathname))) {
      tracker.endStart(pending.intentId);
      pending = null;
    }
    const composer = adapter.composerContext?.() || null;
    const observedMessages = [...(adapter.userMessages?.() || []), ...(adapter.assistantMessages?.() || [])];
    const messages = observedMessages.filter((node) => node?.isConnected && (!node.getClientRects || node.getClientRects().length > 0) && !node.closest?.('[aria-hidden="true"], [hidden]'));
    const roots = new Set(messages.map((node) => node.closest?.("main, [role='main']") || document.body).filter(Boolean));
    const composerRoot = composer?.composer?.closest?.("main, [role='main']") || composer?.root || null;
    const allMainRoots = [...document.querySelectorAll("main, [role='main']")];
    const mainRoots = allMainRoots.filter((node) =>
      !node.getClientRects || node.getClientRects().length > 0);
    // Alice's guest chat can have no semantic main. Its empty editor uses a
    // nested composer root, but the first visible message is rooted at body.
    // Choose that same proven document root before the irreversible first
    // send; never generalize this fallback to another AI or ambiguous roots.
    const aliceNoMainRoot = provider === "alice" && mainRoots.length === 0 &&
      composer?.composer?.isConnected && document.body?.contains?.(composer.composer) &&
      (roots.size === 0 || (roots.size === 1 && roots.has(document.body)));
    // Qwen replaces its home-page main on the first guest send. Its observed
    // desktop content parent survives that transition. Use it only when one
    // visible main, the composer, and every visible message belong to it.
    // Exact owned-message witnessing and all navigation fences still apply.
    const allQwenRoots = provider === "qwen" ? [...document.querySelectorAll('.desktop-layout-content-inner')] : [];
    const qwenRoots = allQwenRoots.filter((node) => node.isConnected && node.getClientRects().length > 0 &&
        !node.closest('[aria-hidden="true"], [hidden]'));
    const qwenRoot = allMainRoots.length === 1 && qwenRoots.length === 1 && mainRoots.length === 1 && roots.size <= 1 &&
      composer?.composer?.isConnected && qwenRoots[0].contains(mainRoots[0]) &&
      qwenRoots[0].contains(composer.composer) && messages.every((node) => mainRoots[0].contains(node))
      ? qwenRoots[0] : null;
    // Qwen also keeps the SAME old main/composer briefly while that main has
    // no client rect. Retain only an already pending empty Start, with the
    // original nodes and exact prompt still present, on the observed route.
    // This and the fully empty remount frame suspend confirmation; neither
    // authorizes Send, retry, hidden history or a replacement surface.
    const qwenPartialGap = allMainRoots.length === 1 && mainRoots.length === 0 &&
      pending?.qwenInitialMain === allMainRoots[0] && allMainRoots[0].isConnected &&
      pending.qwenInitialComposer === composer?.composer && composer?.composer?.isConnected &&
      composerRoot === allMainRoots[0] && pending.root.contains(composer.composer) &&
      !allMainRoots[0].closest('[aria-hidden="true"], [hidden]') &&
      !composer.composer.closest('[aria-hidden="true"], [hidden]') &&
      text(composer.composer.value) === pending.text;
    const qwenGapRoot = pending?.emptySurface && pending.initialPath === "/" && pathname === "/c/new-chat" &&
      !pending.witnessId && pending.baseline.size === 0 &&
      allQwenRoots.length === 1 && qwenRoots.length === 1 && pending.root === qwenRoots[0] &&
      observedMessages.length === 0 &&
      ((allMainRoots.length === 0 && !composer) || qwenPartialGap) ? qwenRoots[0] : null;
    if (qwenGapRoot) pending.qwenRemountGap = true;
    const hasObservedRoot = ["claude", "deepseek"].includes(provider);
    const observedRoot = hasObservedRoot ? adapter.conversationRoot?.() || null : null;
    const observedRootValid = Boolean(observedRoot?.isConnected && composer?.composer?.isConnected &&
      observedRoot.contains(composer.composer) && messages.every(node => observedRoot.contains(node)));
    const root = hasObservedRoot ? (observedRootValid ? observedRoot : null) :
      aliceNoMainRoot ? document.body : qwenRoot || qwenGapRoot || (
      roots.size === 1 ? [...roots][0] :
      mainRoots.length === 1 ? mainRoots[0] : composerRoot);

    const inSurface = root ? messages.filter((node) => root.contains(node)) : [];
    const explicitIds = [];
    // Read only identifiers with a declared conversation meaning, on the
    // selected surface itself. A region id or arbitrary DOM UUID is not one.
    for (const attribute of ["data-conversation-id", "data-chat-id", "data-thread-id"]) {
      const id = root?.getAttribute?.(attribute);
      if (id) explicitIds.push(id);
    }
    if (provider === "alice") {
      const active = document.querySelector('button[data-testid="chatlist-item-active"][aria-current="page"]');
      const item = active?.closest?.(".ChatListItem[id]");
      if (item?.id) explicitIds.push(item.id);
    }
    const messageIds = inSurface.map((node) => adapter.messageId(node)).filter(Boolean);
    let startWitness = null, startWitnessMessageId = null, renamePreviousId = null;
    if (pending && roots.size <= 1 && (pending.root === root || pending.witnessId)) {
      for (const node of adapter.userMessages?.() || []) {
        // Never discover a new witness on another root, or in hidden history.
        if (!inSurface.includes(node)) continue;
        const id = adapter.messageId(node);
        if (!id || pending.baseline.has(id) || text(adapter.messageText(node)) !== pending.text) continue;
        if (!pending.witnessId || id === pending.witnessId) {
          if (pending.witnessNode && pending.witnessNode !== node) pending.renameUnavailable = true;
          pending.witnessNode ||= node;
          pending.witnessId = id;
          pending.witnessRoot = root; pending.witnessPath = pathname;
          startWitness = pending.intentId;
          startWitnessMessageId = id;
          break;
        }
        // Primary guest trace: the same owned node receives its server UUID
        // 571 ms after /c/guest. Never infer this continuity from text alone.
        if (provider === "qwen" && pending.emptySurface && pending.initialPath === "/" &&
            pending.baseline.size === 0 && !pending.renameUnavailable &&
            node === pending.witnessNode && root === pending.witnessRoot && root === qwenRoot &&
            pathname === "/c/guest" && pathname === pending.witnessPath &&
            explicitIds.length === 0 && messageIds.filter(value => value === id).length === 1) {
          renamePreviousId = pending.witnessId;
          startWitness = pending.intentId; startWitnessMessageId = id;
          break;
        }
      }
    }
    const canonicalHref = document.querySelector('link[rel="canonical"][href]')?.href || "";
    if (provider === "qwen" && pending?.witnessNode && !startWitness) pending.renameUnavailable = true;
    const surfaceConfirmed = Boolean(!qwenGapRoot && root && roots.size <= 1 &&
      (composer?.composer?.isConnected || inSurface.length));
    lastInput = { origin, provider, pathname, canonicalHref,
      explicitIds, requiresExplicitId: provider === "alice", root,
      qwenInitialMain: qwenRoot ? mainRoots[0] : null, qwenInitialComposer: qwenRoot ? composer.composer : null,
      surfaceConfirmed, hasMessages: inSurface.length > 0, messageIds, startWitness, startWitnessMessageId, renamePreviousId,
      conflict: roots.size > 1 ? "multiple_conversation_surfaces" : null };
    return lastInput;
  }
  function read(adapter) {
    const input = capture(adapter);
    if (input.renamePreviousId && tracker.renameStartMessage(input, input.renamePreviousId)) {
      pending.witnessId = input.startWitnessMessageId;
      pending.renameUnavailable = true;
    }
    const identity = tracker.observe(input);
    const digest = locatorDigest();
    if (!digest.digest) return { ...identity, conversation_id: null, status: "unknown", source: digest.failed ? "surface_proof_unavailable" : "surface_proof_pending" };
    return { ...identity, identity_evidence: { version: 1, locator_digest: digest.digest, message_ids: (input.messageIds || []).slice(-32) } };
  }
  async function ready(adapter) {
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const identity = read(adapter);
      if (identity.source !== "surface_proof_pending") return identity;
      await address.promise;
    }
    return read(adapter);
  }
  function adoptLocal(adapter, message) {
    const here = read(adapter);
    if (here.surface_id !== message.surface_id || !core.matchingProof(here.identity_evidence, message.identity_evidence)) return null;
    if (!tracker.adoptLocal(message.conversation_id, here.surface_id)) return null;
    return read(adapter);
  }
  function beginStart(adapter, intentId, prompt) {
    const identity = read(adapter);
    if (!lastInput?.root) throw Object.assign(new Error("Не найдено поле текущего диалога."), { code: "CONVERSATION_SURFACE_UNAVAILABLE" });
    tracker.beginStart(intentId);
    pending = { intentId: String(intentId), text: text(prompt), root: lastInput.root,
      emptySurface: lastInput.surfaceConfirmed && !lastInput.hasMessages, initialPath: lastInput.pathname,
      qwenInitialMain: lastInput.qwenInitialMain, qwenInitialComposer: lastInput.qwenInitialComposer,
      baseline: new Set((adapter.userMessages?.() || []).map((node) => adapter.messageId(node)).filter(Boolean)) };
    return identity;
  }
  function endStart(intentId, reason = "terminal") {
    const retainWitness = reason === "active_visible" &&
      pending?.intentId === String(intentId) && Boolean(pending.witnessId);
    tracker.endStart(intentId, { retainWitness });
    if (!retainWitness && pending?.intentId === String(intentId)) pending = null;
  }
  function confirmCurrent(adapter) {
    const input = capture(adapter);
    pending = null;
    return tracker.confirmSurface(input);
  }
  globalThis.SellerAgentsConversationSurface = Object.freeze({
    version: 1, read, ready, beginStart, endStart, confirmCurrent, adoptLocal
  });
})();

;
/* Content-side identity evidence only. The worker owns reservation and all permissions. */
(() => {
  "use strict";
  const PROTOCOL = 2, documentKey = crypto.randomUUID(), localMessages = new WeakMap();
  const fail = code => { throw Object.assign(new Error(code), { code }); };
  function messageIdentity(adapter, node) {
    const id = adapter?.messageId?.(node);
    if (typeof id === "string" && id.length && id.length <= 512 && !/[\u0000-\u001f]/.test(id))
      return { kind: "provider-message", id };
    if (!node || typeof node !== "object") fail("COMMAND_MESSAGE_IDENTITY_REQUIRED");
    if (!localMessages.has(node)) localMessages.set(node, crypto.randomUUID());
    return { kind: "document-local", id: localMessages.get(node), documentKey };
  }
  async function capture({ context, adapter, binding, conversationKey }) {
    if (context?.command_protocol !== PROTOCOL) fail("COMMAND_PROTOCOL_RELOAD_REQUIRED");
    if (!context.work_session_id || !context.binding_id || !context.work_active || !binding?.root?.isConnected || !binding?.section?.isConnected)
      fail("COMMAND_CONTEXT_CHANGED");
    const messages = adapter?.assistantMessages?.() || [];
    if (!messages.includes(binding.section)) fail("COMMAND_MESSAGE_IDENTITY_REQUIRED");
    const roots = adapter.findCodeBlocks(binding.section), ordinal = roots.indexOf(binding.root);
    if (ordinal < 0) fail("COMMAND_BLOCK_IDENTITY_REQUIRED");
    return Object.freeze({ protocol: PROTOCOL, documentKey, workSessionId: context.work_session_id,
      bindingId: context.binding_id, conversationKey, messageIdentity: messageIdentity(adapter, binding.section),
      blockOrdinal: ordinal });
  }
  function baselineId(identity) { return identity.kind === "provider-message" ? identity.id : "r3-local:" + identity.id; }
  function baselineIds(adapter, messages) {
    return ["r3-document:" + documentKey, ...messages.map(node => baselineId(messageIdentity(adapter, node)))];
  }
  async function readBlock({ context, adapter, source, conversationKey }) {
    if (!source?.messageIdentity || source.bindingId !== context?.binding_id || source.workSessionId !== context?.work_session_id ||
        source.conversationKey !== conversationKey) fail("COMMAND_CONTEXT_CHANGED");
    if (source.messageIdentity.kind === "document-local" && source.documentKey !== documentKey)
      fail("COMMAND_LOCAL_IDENTITY_UNCERTAIN_START_REQUIRED");
    const matches = (adapter?.assistantMessages?.() || []).filter(node => {
      const found = messageIdentity(adapter, node), expected = source.messageIdentity;
      return found.kind === expected.kind && found.id === expected.id &&
        (found.kind !== "document-local" || found.documentKey === expected.documentKey);
    });
    if (matches.length !== 1) fail("COMMAND_MESSAGE_IDENTITY_REQUIRED");
    const section = matches[0], root = adapter.findCodeBlocks(section)[source.blockOrdinal];
    if (!root) fail("COMMAND_BLOCK_IDENTITY_REQUIRED");
    const proof = await capture({ context, adapter, binding: { root, section }, conversationKey });
    const commandText = String((adapter.readCodeTextAsync ? await adapter.readCodeTextAsync(root) : adapter.readCodeText(root)) || "");
    const afterRead = await capture({ context, adapter, binding: { root, section }, conversationKey });
    if (JSON.stringify(afterRead) !== JSON.stringify(proof)) fail("COMMAND_CONTEXT_CHANGED");
    if (!commandText || commandText.length > 524288) fail("COMMAND_BLOCK_INVALID");
    return { ok: true, command_text: commandText, command_source: proof };
  }
  globalThis.SellerAgentsCommandSource = Object.freeze({ PROTOCOL, capture, readBlock, messageIdentity, baselineId, baselineIds });
})();
