(() => { const scope = Object.create(null); (function(globalThis) {
(() => {
  "use strict";
  const HOSTS = Object.freeze({
  "content": "https://content-api.wildberries.ru",
  "prices": "https://discounts-prices-api.wildberries.ru",
  "marketplace": "https://marketplace-api.wildberries.ru",
  "analytics": "https://seller-analytics-api.wildberries.ru",
  "statistics": "https://statistics-api.wildberries.ru",
  "finance": "https://finance-api.wildberries.ru",
  "documents": "https://documents-api.wildberries.ru",
  "common": "https://common-api.wildberries.ru",
  "supplies": "https://supplies-api.wildberries.ru",
  "advert": "https://advert-api.wildberries.ru",
  "advert_media": "https://advert-media-api.wildberries.ru",
  "calendar": "https://dp-calendar-api.wildberries.ru",
  "feedbacks": "https://feedbacks-api.wildberries.ru",
  "returns": "https://returns-api.wildberries.ru",
  "buyer_chat": "https://buyer-chat-api.wildberries.ru",
  "user_management": "https://user-management-api.wildberries.ru"
});
  const raw = [
  {
    "alias": "seller_info",
    "host": "common",
    "method": "GET",
    "path": "/api/v1/seller-info",
    "category": "any",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "01-general.yaml",
    "source_path": "/api/v1/seller-info",
    "source_readonly": true
  },
  {
    "alias": "subscriptions",
    "host": "common",
    "method": "GET",
    "path": "/api/common/v1/subscriptions",
    "category": "any",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "01-general.yaml",
    "source_path": "/api/common/v1/subscriptions",
    "source_readonly": true,
    "token_types": [
      "service"
    ],
    "blocked_reason": "SERVICE_TOKEN_ONLY_PERSONAL_BUILD"
  },
  {
    "alias": "tariff_commission",
    "host": "common",
    "method": "GET",
    "path": "/api/v1/tariffs/commission",
    "category": "any",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "10-rates.yaml",
    "source_path": "/api/v1/tariffs/commission",
    "source_readonly": true
  },
  {
    "alias": "tariff_box",
    "host": "common",
    "method": "GET",
    "path": "/api/v1/tariffs/box",
    "category": "any",
    "query_keys": [
      "date"
    ],
    "required_query_keys": [
      "date"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "10-rates.yaml",
    "source_path": "/api/v1/tariffs/box",
    "source_readonly": true
  },
  {
    "alias": "tariff_pallet",
    "host": "common",
    "method": "GET",
    "path": "/api/v1/tariffs/pallet",
    "category": "any",
    "query_keys": [
      "date"
    ],
    "required_query_keys": [
      "date"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "10-rates.yaml",
    "source_path": "/api/v1/tariffs/pallet",
    "source_readonly": true
  },
  {
    "alias": "tariff_acceptance",
    "host": "common",
    "method": "GET",
    "path": "/api/tariffs/v1/acceptance/coefficients",
    "category": "any",
    "query_keys": [
      "warehouseIDs"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "10-rates.yaml",
    "source_path": "/api/tariffs/v1/acceptance/coefficients",
    "source_readonly": true
  },
  {
    "alias": "tariff_return",
    "host": "common",
    "method": "GET",
    "path": "/api/v1/tariffs/return",
    "category": "any",
    "query_keys": [
      "date"
    ],
    "required_query_keys": [
      "date"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "10-rates.yaml",
    "source_path": "/api/v1/tariffs/return",
    "source_readonly": true
  },
  {
    "alias": "content_parent_categories",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/object/parent/all",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/object/parent/all",
    "source_readonly": true
  },
  {
    "alias": "content_subjects",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/object/all",
    "category": "content",
    "query_keys": [
      "locale",
      "name",
      "limit",
      "offset",
      "parentID"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/object/all",
    "source_readonly": true
  },
  {
    "alias": "content_subject_characteristics",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/object/charcs/{subjectId}",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/object/charcs/{subjectId}",
    "source_readonly": true
  },
  {
    "alias": "content_colors",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/directory/colors",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/directory/colors",
    "source_readonly": true
  },
  {
    "alias": "content_kinds",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/directory/kinds",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/directory/kinds",
    "source_readonly": true
  },
  {
    "alias": "content_countries",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/directory/countries",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/directory/countries",
    "source_readonly": true
  },
  {
    "alias": "content_seasons",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/directory/seasons",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/directory/seasons",
    "source_readonly": true
  },
  {
    "alias": "content_vat",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/directory/vat",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/directory/vat",
    "source_readonly": true
  },
  {
    "alias": "content_tnved",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/directory/tnved",
    "category": "content",
    "query_keys": [
      "subjectID",
      "search",
      "locale"
    ],
    "required_query_keys": [
      "subjectID"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/directory/tnved",
    "source_readonly": true
  },
  {
    "alias": "content_brands",
    "host": "content",
    "method": "GET",
    "path": "/api/content/v1/brands",
    "category": "content",
    "query_keys": [
      "subjectId",
      "next"
    ],
    "required_query_keys": [
      "subjectId"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/content/v1/brands",
    "source_readonly": true
  },
  {
    "alias": "content_card_limits",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/cards/limits",
    "category": "content",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/cards/limits",
    "source_readonly": true
  },
  {
    "alias": "cards_list",
    "host": "content",
    "method": "POST",
    "path": "/content/v2/get/cards/list",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/get/cards/list",
    "source_readonly": true
  },
  {
    "alias": "cards_trash",
    "host": "content",
    "method": "POST",
    "path": "/content/v2/get/cards/trash",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/get/cards/trash",
    "source_readonly": true
  },
  {
    "alias": "cards_errors",
    "host": "content",
    "method": "POST",
    "path": "/content/v2/cards/error/list",
    "category": "content",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/cards/error/list",
    "source_readonly": true
  },
  {
    "alias": "content_tags",
    "host": "content",
    "method": "GET",
    "path": "/content/v2/tags",
    "category": "content",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/tags",
    "source_readonly": true
  },
  {
    "alias": "prices_all",
    "host": "prices",
    "method": "GET",
    "path": "/api/v2/list/goods/filter",
    "category": "prices",
    "query_keys": [
      "limit",
      "offset",
      "filterNmID"
    ],
    "required_query_keys": [
      "limit"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v2/list/goods/filter",
    "source_readonly": true
  },
  {
    "alias": "prices_by_nm",
    "host": "prices",
    "method": "POST",
    "path": "/api/v2/list/goods/filter",
    "category": "prices",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v2/list/goods/filter",
    "source_readonly": true
  },
  {
    "alias": "size_prices",
    "host": "prices",
    "method": "GET",
    "path": "/api/v2/list/goods/size/nm",
    "category": "prices",
    "query_keys": [
      "limit",
      "offset",
      "nmID"
    ],
    "required_query_keys": [
      "limit",
      "nmID"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v2/list/goods/size/nm",
    "source_readonly": true
  },
  {
    "alias": "price_quarantine",
    "host": "prices",
    "method": "GET",
    "path": "/api/v2/quarantine/goods",
    "category": "prices",
    "query_keys": [
      "limit",
      "offset"
    ],
    "required_query_keys": [
      "limit"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v2/quarantine/goods",
    "source_readonly": true
  },
  {
    "alias": "calendar_promotions",
    "host": "calendar",
    "method": "GET",
    "path": "/api/v1/calendar/promotions",
    "category": "prices",
    "query_keys": [
      "startDateTime",
      "endDateTime",
      "allPromo",
      "limit",
      "offset"
    ],
    "required_query_keys": [
      "startDateTime",
      "endDateTime",
      "allPromo"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/api/v1/calendar/promotions",
    "source_readonly": true
  },
  {
    "alias": "calendar_promotion_details",
    "host": "calendar",
    "method": "GET",
    "path": "/api/v1/calendar/promotions/details",
    "category": "prices",
    "query_keys": [
      "promotionIDs"
    ],
    "required_query_keys": [
      "promotionIDs"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/api/v1/calendar/promotions/details",
    "source_readonly": true
  },
  {
    "alias": "calendar_promotion_nomenclatures",
    "host": "calendar",
    "method": "GET",
    "path": "/api/v1/calendar/promotions/nomenclatures",
    "category": "prices",
    "query_keys": [
      "promotionID",
      "inAction",
      "limit",
      "offset"
    ],
    "required_query_keys": [
      "promotionID",
      "inAction"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/api/v1/calendar/promotions/nomenclatures",
    "source_readonly": true
  },
  {
    "alias": "seller_warehouses",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/warehouses",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v3/warehouses",
    "source_readonly": true
  },
  {
    "alias": "marketplace_offices",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/offices",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v3/offices",
    "source_readonly": true
  },
  {
    "alias": "fbs_stocks",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/stocks/{warehouseId}",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v3/stocks/{warehouseId}",
    "source_readonly": true
  },
  {
    "alias": "pickup_orders_new",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/click-collect/orders/new",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "06-in-store-pickup.yaml",
    "source_path": "/api/v3/click-collect/orders/new",
    "source_readonly": true
  },
  {
    "alias": "pickup_orders",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/click-collect/orders",
    "category": "marketplace",
    "query_keys": [
      "limit",
      "next",
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "limit",
      "next",
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "06-in-store-pickup.yaml",
    "source_path": "/api/v3/click-collect/orders",
    "source_readonly": true
  },
  {
    "alias": "pickup_order_statuses",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/click-collect/orders/status/info",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "06-in-store-pickup.yaml",
    "source_path": "/api/marketplace/v3/click-collect/orders/status/info",
    "source_readonly": true
  },
  {
    "alias": "pickup_order_meta",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/click-collect/orders/meta/details",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "06-in-store-pickup.yaml",
    "source_path": "/api/marketplace/v3/click-collect/orders/meta/details",
    "source_readonly": true
  },
  {
    "alias": "fbs_orders_new",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/orders/new",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/orders/new",
    "source_readonly": true
  },
  {
    "alias": "fbs_orders",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/orders",
    "category": "marketplace",
    "query_keys": [
      "limit",
      "next",
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "limit",
      "next"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/orders",
    "source_readonly": true
  },
  {
    "alias": "fbs_order_statuses",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/orders/status",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/orders/status",
    "source_readonly": true
  },
  {
    "alias": "fbs_order_stickers",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/orders/stickers",
    "category": "marketplace",
    "query_keys": [
      "type",
      "width",
      "height"
    ],
    "required_query_keys": [
      "type",
      "width",
      "height"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/orders/stickers",
    "source_readonly": true
  },
  {
    "alias": "fbs_crossborder_stickers",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/orders/stickers/cross-border",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/orders/stickers/cross-border",
    "source_readonly": true
  },
  {
    "alias": "fbs_crossborder_status_history",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/orders/status/history",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/orders/status/history",
    "source_readonly": true
  },
  {
    "alias": "fbs_order_meta",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/orders/meta",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/marketplace/v3/orders/meta",
    "source_readonly": true
  },
  {
    "alias": "fbs_pass_offices",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/passes/offices",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/passes/offices",
    "source_readonly": true
  },
  {
    "alias": "fbs_supplies",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/supplies",
    "category": "marketplace",
    "query_keys": [
      "limit",
      "next"
    ],
    "required_query_keys": [
      "limit",
      "next"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/supplies",
    "source_readonly": true
  },
  {
    "alias": "fbs_supply",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/supplies/{supplyId}",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/supplies/{supplyId}",
    "source_readonly": true
  },
  {
    "alias": "fbs_supply_order_ids",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/marketplace/v3/supplies/{supplyId}/order-ids",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/marketplace/v3/supplies/{supplyId}/order-ids",
    "source_readonly": true
  },
  {
    "alias": "fbs_supply_barcode",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/supplies/{supplyId}/barcode",
    "category": "marketplace",
    "query_keys": [
      "type"
    ],
    "required_query_keys": [
      "type"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/supplies/{supplyId}/barcode",
    "source_readonly": true
  },
  {
    "alias": "fbs_supply_boxes",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/supplies/{supplyId}/trbx",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/supplies/{supplyId}/trbx",
    "source_readonly": true
  },
  {
    "alias": "fbs_supply_box_stickers",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/supplies/{supplyId}/trbx/stickers",
    "category": "marketplace",
    "query_keys": [
      "type"
    ],
    "required_query_keys": [
      "type"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/supplies/{supplyId}/trbx/stickers",
    "source_readonly": true
  },
  {
    "alias": "dbs_orders_new",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/dbs/orders/new",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "05-orders-dbs.yaml",
    "source_path": "/api/v3/dbs/orders/new",
    "source_readonly": true
  },
  {
    "alias": "dbs_orders",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/dbs/orders",
    "category": "marketplace",
    "query_keys": [
      "limit",
      "next",
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "limit",
      "next",
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "05-orders-dbs.yaml",
    "source_path": "/api/v3/dbs/orders",
    "source_readonly": true
  },
  {
    "alias": "dbs_order_statuses",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/dbs/orders/status/info",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "05-orders-dbs.yaml",
    "source_path": "/api/marketplace/v3/dbs/orders/status/info",
    "source_readonly": true
  },
  {
    "alias": "dbs_order_stickers",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/dbs/orders/stickers",
    "category": "marketplace",
    "query_keys": [
      "type",
      "width",
      "height"
    ],
    "required_query_keys": [
      "type",
      "width",
      "height"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "05-orders-dbs.yaml",
    "source_path": "/api/marketplace/v3/dbs/orders/stickers",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service",
      "base-with-secret"
    ]
  },
  {
    "alias": "dbs_order_meta",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/dbs/orders/meta/details",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "05-orders-dbs.yaml",
    "source_path": "/api/marketplace/v3/dbs/orders/meta/details",
    "source_readonly": true
  },
  {
    "alias": "dbs_delivery_date",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/dbs/orders/delivery-date",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "05-orders-dbs.yaml",
    "source_path": "/api/v3/dbs/orders/delivery-date",
    "source_readonly": true
  },
  {
    "alias": "dbs_paid_delivery_groups",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/dbs/groups/info",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "05-orders-dbs.yaml",
    "source_path": "/api/v3/dbs/groups/info",
    "source_readonly": true
  },
  {
    "alias": "dbw_orders_new",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/dbw/orders/new",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "04-orders-dbw.yaml",
    "source_path": "/api/v3/dbw/orders/new",
    "source_readonly": true
  },
  {
    "alias": "dbw_orders",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/dbw/orders",
    "category": "marketplace",
    "query_keys": [
      "limit",
      "next",
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "limit",
      "next",
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "04-orders-dbw.yaml",
    "source_path": "/api/v3/dbw/orders",
    "source_readonly": true
  },
  {
    "alias": "dbw_order_statuses",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/dbw/orders/status",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "04-orders-dbw.yaml",
    "source_path": "/api/v3/dbw/orders/status",
    "source_readonly": true
  },
  {
    "alias": "dbw_order_stickers",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/dbw/orders/stickers",
    "category": "marketplace",
    "query_keys": [
      "type",
      "width",
      "height"
    ],
    "required_query_keys": [
      "type",
      "width",
      "height"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "04-orders-dbw.yaml",
    "source_path": "/api/v3/dbw/orders/stickers",
    "source_readonly": true
  },
  {
    "alias": "dbw_delivery_date",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/dbw/orders/delivery-date",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "04-orders-dbw.yaml",
    "source_path": "/api/v3/dbw/orders/delivery-date",
    "source_readonly": true
  },
  {
    "alias": "dbw_order_meta",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/dbw/orders/meta/details",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "04-orders-dbw.yaml",
    "source_path": "/api/marketplace/v3/dbw/orders/meta/details",
    "source_readonly": true
  },
  {
    "alias": "statistics_orders",
    "host": "statistics",
    "method": "GET",
    "path": "/api/v1/supplier/orders",
    "category": "statistics",
    "query_keys": [
      "dateFrom",
      "flag"
    ],
    "required_query_keys": [
      "dateFrom"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/supplier/orders",
    "source_readonly": true
  },
  {
    "alias": "statistics_sales",
    "host": "statistics",
    "method": "GET",
    "path": "/api/v1/supplier/sales",
    "category": "statistics",
    "query_keys": [
      "dateFrom",
      "flag"
    ],
    "required_query_keys": [
      "dateFrom"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/supplier/sales",
    "source_readonly": true
  },
  {
    "alias": "stock_products",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/stocks-report/products/products",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/stocks-report/products/products",
    "source_readonly": true
  },
  {
    "alias": "stock_groups",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/stocks-report/products/groups",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/stocks-report/products/groups",
    "source_readonly": true
  },
  {
    "alias": "stock_sizes",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/stocks-report/products/sizes",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/stocks-report/products/sizes",
    "source_readonly": true
  },
  {
    "alias": "stock_offices",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/stocks-report/offices",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/stocks-report/offices",
    "source_readonly": true
  },
  {
    "alias": "wb_warehouse_stocks",
    "host": "analytics",
    "method": "POST",
    "path": "/api/analytics/v1/stocks-report/wb-warehouses",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/analytics/v1/stocks-report/wb-warehouses",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service",
      "base-with-secret"
    ]
  },
  {
    "alias": "sales_funnel_products",
    "host": "analytics",
    "method": "POST",
    "path": "/api/analytics/v3/sales-funnel/products",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/analytics/v3/sales-funnel/products",
    "source_readonly": true
  },
  {
    "alias": "sales_funnel_history",
    "host": "analytics",
    "method": "POST",
    "path": "/api/analytics/v3/sales-funnel/products/history",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/analytics/v3/sales-funnel/products/history",
    "source_readonly": true
  },
  {
    "alias": "sales_funnel_grouped_history",
    "host": "analytics",
    "method": "POST",
    "path": "/api/analytics/v3/sales-funnel/grouped/history",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/analytics/v3/sales-funnel/grouped/history",
    "source_readonly": true
  },
  {
    "alias": "search_report_groups",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/search-report/table/groups",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/search-report/table/groups",
    "source_readonly": true
  },
  {
    "alias": "search_report_details",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/search-report/table/details",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/search-report/table/details",
    "source_readonly": true
  },
  {
    "alias": "search_report_product",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/search-report/product/search-texts",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/search-report/product/search-texts",
    "source_readonly": true
  },
  {
    "alias": "search_report_search_texts",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/search-report/product/orders",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/search-report/product/orders",
    "source_readonly": true
  },
  {
    "alias": "analytics_report_create",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/nm-report/downloads",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "derived",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/nm-report/downloads",
    "source_readonly": true
  },
  {
    "alias": "analytics_report_list",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v2/nm-report/downloads",
    "category": "analytics",
    "query_keys": [
      "filter[downloadIds]"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/nm-report/downloads",
    "source_readonly": true
  },
  {
    "alias": "analytics_report_retry",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/nm-report/downloads/retry",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "derived",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/nm-report/downloads/retry",
    "source_readonly": true
  },
  {
    "alias": "analytics_report_download",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v2/nm-report/downloads/file/{downloadId}",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "binary",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/nm-report/downloads/file/{downloadId}",
    "source_readonly": true
  },
  {
    "alias": "warehouse_remains_create",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/warehouse_remains",
    "category": "analytics",
    "query_keys": [
      "locale",
      "groupByBrand",
      "groupBySubject",
      "groupBySa",
      "groupByNm",
      "groupByBarcode",
      "groupBySize",
      "filterPics",
      "filterVolume"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "derived",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/warehouse_remains",
    "source_readonly": true
  },
  {
    "alias": "warehouse_remains_status",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/warehouse_remains/tasks/{task_id}/status",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/warehouse_remains/tasks/{task_id}/status",
    "source_readonly": true
  },
  {
    "alias": "warehouse_remains_download",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/warehouse_remains/tasks/{task_id}/download",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/warehouse_remains/tasks/{task_id}/download",
    "source_readonly": true
  },
  {
    "alias": "excise_report",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v1/analytics/excise-report",
    "category": "analytics",
    "query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/excise-report",
    "source_readonly": true
  },
  {
    "alias": "measurement_penalties",
    "host": "analytics",
    "method": "GET",
    "path": "/api/analytics/v1/measurement-penalties",
    "category": "analytics",
    "query_keys": [
      "dateFrom",
      "dateTo",
      "limit",
      "offset"
    ],
    "required_query_keys": [
      "dateTo",
      "limit"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/analytics/v1/measurement-penalties",
    "source_readonly": true
  },
  {
    "alias": "warehouse_measurements",
    "host": "analytics",
    "method": "GET",
    "path": "/api/analytics/v1/warehouse-measurements",
    "category": "analytics",
    "query_keys": [
      "dateFrom",
      "dateTo",
      "limit",
      "offset"
    ],
    "required_query_keys": [
      "dateTo",
      "limit"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/analytics/v1/warehouse-measurements",
    "source_readonly": true
  },
  {
    "alias": "deductions",
    "host": "analytics",
    "method": "GET",
    "path": "/api/analytics/v1/deductions",
    "category": "analytics",
    "query_keys": [
      "dateFrom",
      "dateTo",
      "sort",
      "order",
      "limit",
      "offset"
    ],
    "required_query_keys": [
      "dateTo",
      "limit"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/analytics/v1/deductions",
    "source_readonly": true
  },
  {
    "alias": "antifraud_details",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/analytics/antifraud-details",
    "category": "analytics",
    "query_keys": [
      "date"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/antifraud-details",
    "source_readonly": true
  },
  {
    "alias": "goods_labeling",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/analytics/goods-labeling",
    "category": "analytics",
    "query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/goods-labeling",
    "source_readonly": true
  },
  {
    "alias": "acceptance_report_create",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/acceptance_report",
    "category": "analytics",
    "query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "derived",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/acceptance_report",
    "source_readonly": true
  },
  {
    "alias": "acceptance_report_status",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/acceptance_report/tasks/{task_id}/status",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/acceptance_report/tasks/{task_id}/status",
    "source_readonly": true
  },
  {
    "alias": "acceptance_report_download",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/acceptance_report/tasks/{task_id}/download",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/acceptance_report/tasks/{task_id}/download",
    "source_readonly": true
  },
  {
    "alias": "paid_storage_create",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/paid_storage",
    "category": "analytics",
    "query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "derived",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/paid_storage",
    "source_readonly": true
  },
  {
    "alias": "paid_storage_status",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/paid_storage/tasks/{task_id}/status",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/paid_storage/tasks/{task_id}/status",
    "source_readonly": true
  },
  {
    "alias": "paid_storage_download",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/paid_storage/tasks/{task_id}/download",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/paid_storage/tasks/{task_id}/download",
    "source_readonly": true
  },
  {
    "alias": "region_sales",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/analytics/region-sale",
    "category": "analytics",
    "query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/region-sale",
    "source_readonly": true
  },
  {
    "alias": "brand_share_brands",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/analytics/brand-share/brands",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/brand-share/brands",
    "source_readonly": true
  },
  {
    "alias": "brand_share_parent_subjects",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/analytics/brand-share/parent-subjects",
    "category": "analytics",
    "query_keys": [
      "locale",
      "brand",
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "brand",
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/brand-share/parent-subjects",
    "source_readonly": true
  },
  {
    "alias": "brand_share",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/analytics/brand-share",
    "category": "analytics",
    "query_keys": [
      "parentId",
      "brand",
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "parentId",
      "brand",
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/brand-share",
    "source_readonly": true
  },
  {
    "alias": "banned_products_blocked",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/analytics/banned-products/blocked",
    "category": "analytics",
    "query_keys": [
      "sort",
      "order"
    ],
    "required_query_keys": [
      "sort",
      "order"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/banned-products/blocked",
    "source_readonly": true
  },
  {
    "alias": "banned_products_shadowed",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/analytics/banned-products/shadowed",
    "category": "analytics",
    "query_keys": [
      "sort",
      "order"
    ],
    "required_query_keys": [
      "sort",
      "order"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/banned-products/shadowed",
    "source_readonly": true
  },
  {
    "alias": "goods_return",
    "host": "analytics",
    "method": "GET",
    "path": "/api/v1/analytics/goods-return",
    "category": "analytics",
    "query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "dateFrom",
      "dateTo"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "12-reports.yaml",
    "source_path": "/api/v1/analytics/goods-return",
    "source_readonly": true
  },
  {
    "alias": "finance_balance",
    "host": "finance",
    "method": "GET",
    "path": "/api/v1/account/balance",
    "category": "finance",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/v1/account/balance",
    "source_readonly": true
  },
  {
    "alias": "finance_sales_reports",
    "host": "finance",
    "method": "POST",
    "path": "/api/finance/v1/sales-reports/list",
    "category": "finance",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/finance/v1/sales-reports/list",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service"
    ]
  },
  {
    "alias": "finance_sales_detail_report",
    "host": "finance",
    "method": "POST",
    "path": "/api/finance/v1/sales-reports/detailed/{reportId}",
    "category": "finance",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/finance/v1/sales-reports/detailed/{reportId}",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service"
    ]
  },
  {
    "alias": "finance_sales_detail_period",
    "host": "finance",
    "method": "POST",
    "path": "/api/finance/v1/sales-reports/detailed",
    "category": "finance",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/finance/v1/sales-reports/detailed",
    "source_readonly": true
  },
  {
    "alias": "finance_acquiring_reports",
    "host": "finance",
    "method": "POST",
    "path": "/api/finance/v1/acquiring/list",
    "category": "finance",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/finance/v1/acquiring/list",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service"
    ]
  },
  {
    "alias": "finance_acquiring_detail_report",
    "host": "finance",
    "method": "POST",
    "path": "/api/finance/v1/acquiring/detailed/{reportId}",
    "category": "finance",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/finance/v1/acquiring/detailed/{reportId}",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service"
    ]
  },
  {
    "alias": "finance_acquiring_detail_period",
    "host": "finance",
    "method": "POST",
    "path": "/api/finance/v1/acquiring/detailed",
    "category": "finance",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/finance/v1/acquiring/detailed",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service"
    ]
  },
  {
    "alias": "document_categories",
    "host": "documents",
    "method": "GET",
    "path": "/api/v1/documents/categories",
    "category": "documents",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/v1/documents/categories",
    "source_readonly": true
  },
  {
    "alias": "documents_list",
    "host": "documents",
    "method": "GET",
    "path": "/api/v1/documents/list",
    "category": "documents",
    "query_keys": [
      "locale",
      "beginTime",
      "endTime",
      "sort",
      "order",
      "category",
      "serviceName",
      "limit",
      "offset"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/v1/documents/list",
    "source_readonly": true
  },
  {
    "alias": "document_download",
    "host": "documents",
    "method": "GET",
    "path": "/api/v1/documents/download",
    "category": "documents",
    "query_keys": [
      "serviceName",
      "extension"
    ],
    "required_query_keys": [
      "serviceName",
      "extension"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/v1/documents/download",
    "source_readonly": true
  },
  {
    "alias": "documents_download_all",
    "host": "documents",
    "method": "POST",
    "path": "/api/v1/documents/download/all",
    "category": "documents",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "13-finances.yaml",
    "source_path": "/api/v1/documents/download/all",
    "source_readonly": true
  },
  {
    "alias": "fbw_acceptance_options",
    "host": "supplies",
    "method": "POST",
    "path": "/api/v1/acceptance/options",
    "category": "supplies",
    "query_keys": [
      "warehouseID"
    ],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "07-orders-fbw.yaml",
    "source_path": "/api/v1/acceptance/options",
    "source_readonly": true
  },
  {
    "alias": "fbw_warehouses",
    "host": "supplies",
    "method": "GET",
    "path": "/api/v1/warehouses",
    "category": "supplies",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "07-orders-fbw.yaml",
    "source_path": "/api/v1/warehouses",
    "source_readonly": true
  },
  {
    "alias": "fbw_transit_tariffs",
    "host": "supplies",
    "method": "GET",
    "path": "/api/v1/transit-tariffs",
    "category": "supplies",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "07-orders-fbw.yaml",
    "source_path": "/api/v1/transit-tariffs",
    "source_readonly": true
  },
  {
    "alias": "fbw_supplies",
    "host": "supplies",
    "method": "POST",
    "path": "/api/v1/supplies",
    "category": "supplies",
    "query_keys": [
      "limit",
      "offset"
    ],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "07-orders-fbw.yaml",
    "source_path": "/api/v1/supplies",
    "source_readonly": true
  },
  {
    "alias": "fbw_supply",
    "host": "supplies",
    "method": "GET",
    "path": "/api/v1/supplies/{supplyId}",
    "category": "supplies",
    "query_keys": [
      "isPreorderID"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "07-orders-fbw.yaml",
    "source_path": "/api/v1/supplies/{ID}",
    "source_readonly": true
  },
  {
    "alias": "fbw_supply_goods",
    "host": "supplies",
    "method": "GET",
    "path": "/api/v1/supplies/{supplyId}/goods",
    "category": "supplies",
    "query_keys": [
      "limit",
      "offset",
      "isPreorderID"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "07-orders-fbw.yaml",
    "source_path": "/api/v1/supplies/{ID}/goods",
    "source_readonly": true
  },
  {
    "alias": "fbw_supply_package",
    "host": "supplies",
    "method": "GET",
    "path": "/api/v1/supplies/{supplyId}/package",
    "category": "supplies",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "07-orders-fbw.yaml",
    "source_path": "/api/v1/supplies/{ID}/package",
    "source_readonly": true
  },
  {
    "alias": "promo_campaign_count",
    "host": "advert",
    "method": "GET",
    "path": "/adv/v1/promotion/count",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/promotion/count",
    "source_readonly": true
  },
  {
    "alias": "promo_campaigns",
    "host": "advert",
    "method": "GET",
    "path": "/api/advert/v2/adverts",
    "category": "promotion",
    "query_keys": [
      "ids",
      "statuses",
      "payment_type"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/api/advert/v2/adverts",
    "source_readonly": true
  },
  {
    "alias": "promo_min_bids",
    "host": "advert",
    "method": "POST",
    "path": "/api/advert/v1/bids/min",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/api/advert/v1/bids/min",
    "source_readonly": true
  },
  {
    "alias": "promo_recommended_bids",
    "host": "advert",
    "method": "GET",
    "path": "/api/advert/v0/bids/recommendations",
    "category": "promotion",
    "query_keys": [
      "nmId",
      "advertId"
    ],
    "required_query_keys": [
      "nmId",
      "advertId"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/api/advert/v0/bids/recommendations",
    "source_readonly": true
  },
  {
    "alias": "promo_subjects",
    "host": "advert",
    "method": "GET",
    "path": "/adv/v1/supplier/subjects",
    "category": "promotion",
    "query_keys": [
      "payment_type"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/supplier/subjects",
    "source_readonly": true
  },
  {
    "alias": "promo_nms",
    "host": "advert",
    "method": "POST",
    "path": "/adv/v2/supplier/nms",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v2/supplier/nms",
    "source_readonly": true
  },
  {
    "alias": "promo_normquery_list",
    "host": "advert",
    "method": "POST",
    "path": "/adv/v0/normquery/list",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v0/normquery/list",
    "source_readonly": true
  },
  {
    "alias": "promo_normquery_bids",
    "host": "advert",
    "method": "POST",
    "path": "/adv/v0/normquery/get-bids",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v0/normquery/get-bids",
    "source_readonly": true
  },
  {
    "alias": "promo_normquery_minus",
    "host": "advert",
    "method": "POST",
    "path": "/adv/v0/normquery/get-minus",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v0/normquery/get-minus",
    "source_readonly": true
  },
  {
    "alias": "promo_normquery_stats_cpm",
    "host": "advert",
    "method": "POST",
    "path": "/adv/v0/normquery/stats",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v0/normquery/stats",
    "source_readonly": true
  },
  {
    "alias": "promo_normquery_stats_daily",
    "host": "advert",
    "method": "POST",
    "path": "/adv/v1/normquery/stats",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/normquery/stats",
    "source_readonly": true
  },
  {
    "alias": "promo_fullstats",
    "host": "advert",
    "method": "GET",
    "path": "/adv/v3/fullstats",
    "category": "promotion",
    "query_keys": [
      "ids",
      "beginDate",
      "endDate"
    ],
    "required_query_keys": [
      "ids",
      "beginDate",
      "endDate"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v3/fullstats",
    "source_readonly": true
  },
  {
    "alias": "promo_balance",
    "host": "advert",
    "method": "GET",
    "path": "/adv/v1/balance",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/balance",
    "source_readonly": true
  },
  {
    "alias": "promo_budget",
    "host": "advert",
    "method": "GET",
    "path": "/adv/v1/budget",
    "category": "promotion",
    "query_keys": [
      "id"
    ],
    "required_query_keys": [
      "id"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/budget",
    "source_readonly": true
  },
  {
    "alias": "promo_spend_history",
    "host": "advert",
    "method": "GET",
    "path": "/adv/v1/upd",
    "category": "promotion",
    "query_keys": [
      "from",
      "to"
    ],
    "required_query_keys": [
      "from",
      "to"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/upd",
    "source_readonly": true
  },
  {
    "alias": "promo_payment_history",
    "host": "advert",
    "method": "GET",
    "path": "/adv/v1/payments",
    "category": "promotion",
    "query_keys": [
      "from",
      "to"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/payments",
    "source_readonly": true
  },
  {
    "alias": "media_campaign_count",
    "host": "advert_media",
    "method": "GET",
    "path": "/adv/v1/count",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/count",
    "source_readonly": true
  },
  {
    "alias": "media_campaigns",
    "host": "advert_media",
    "method": "GET",
    "path": "/adv/v1/adverts",
    "category": "promotion",
    "query_keys": [
      "status",
      "type",
      "limit",
      "offset",
      "order",
      "direction"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/adverts",
    "source_readonly": true
  },
  {
    "alias": "media_campaign",
    "host": "advert_media",
    "method": "GET",
    "path": "/adv/v1/advert",
    "category": "promotion",
    "query_keys": [
      "id"
    ],
    "required_query_keys": [
      "id"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/advert",
    "source_readonly": true
  },
  {
    "alias": "media_stats",
    "host": "advert_media",
    "method": "POST",
    "path": "/adv/v1/stats",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/adv/v1/stats",
    "source_readonly": true
  },
  {
    "alias": "feedback_new_state",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/new-feedbacks-questions",
    "category": "feedbacks",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/new-feedbacks-questions",
    "source_readonly": true
  },
  {
    "alias": "questions_unanswered_count",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/questions/count-unanswered",
    "category": "feedbacks",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/questions/count-unanswered",
    "source_readonly": true
  },
  {
    "alias": "questions_count",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/questions/count",
    "category": "feedbacks",
    "query_keys": [
      "dateFrom",
      "dateTo",
      "isAnswered"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/questions/count",
    "source_readonly": true
  },
  {
    "alias": "questions_list",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/questions",
    "category": "feedbacks",
    "query_keys": [
      "isAnswered",
      "nmId",
      "take",
      "skip",
      "order",
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "isAnswered",
      "take",
      "skip"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/questions",
    "source_readonly": true
  },
  {
    "alias": "question_get",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/question",
    "category": "feedbacks",
    "query_keys": [
      "id"
    ],
    "required_query_keys": [
      "id"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/question",
    "source_readonly": true
  },
  {
    "alias": "feedbacks_unanswered_count",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/feedbacks/count-unanswered",
    "category": "feedbacks",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/feedbacks/count-unanswered",
    "source_readonly": true
  },
  {
    "alias": "feedbacks_count",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/feedbacks/count",
    "category": "feedbacks",
    "query_keys": [
      "dateFrom",
      "dateTo",
      "isAnswered"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/feedbacks/count",
    "source_readonly": true
  },
  {
    "alias": "feedbacks_list",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/feedbacks",
    "category": "feedbacks",
    "query_keys": [
      "isAnswered",
      "nmId",
      "take",
      "skip",
      "order",
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [
      "isAnswered",
      "take",
      "skip"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/feedbacks",
    "source_readonly": true
  },
  {
    "alias": "feedbacks_archive",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/feedbacks/archive",
    "category": "feedbacks",
    "query_keys": [
      "nmId",
      "take",
      "skip",
      "order"
    ],
    "required_query_keys": [
      "take",
      "skip"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/feedbacks/archive",
    "source_readonly": true
  },
  {
    "alias": "feedback_get",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/v1/feedback",
    "category": "feedbacks",
    "query_keys": [
      "id"
    ],
    "required_query_keys": [
      "id"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/feedback",
    "source_readonly": true
  },
  {
    "alias": "feedback_pins",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/feedbacks/v1/pins",
    "category": "feedbacks",
    "query_keys": [
      "state",
      "pinOn",
      "imtId",
      "nmId",
      "feedbackId",
      "dateFrom",
      "dateTo",
      "next",
      "limit"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/feedbacks/v1/pins",
    "source_readonly": true
  },
  {
    "alias": "feedback_pins_count",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/feedbacks/v1/pins/count",
    "category": "feedbacks",
    "query_keys": [
      "state",
      "pinOn",
      "imtId",
      "nmId",
      "feedbackId",
      "dateFrom",
      "dateTo"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/feedbacks/v1/pins/count",
    "source_readonly": true
  },
  {
    "alias": "feedback_pins_limits",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/feedbacks/v1/pins/limits",
    "category": "feedbacks",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/feedbacks/v1/pins/limits",
    "source_readonly": true
  },
  {
    "alias": "seller_rating",
    "host": "feedbacks",
    "method": "GET",
    "path": "/api/common/v1/rating",
    "category": "feedbacks",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "01-general.yaml",
    "source_path": "/api/common/v1/rating",
    "source_readonly": true,
    "token_types": [
      "service"
    ],
    "blocked_reason": "SERVICE_TOKEN_ONLY_PERSONAL_BUILD"
  },
  {
    "alias": "buyer_return_claims",
    "host": "returns",
    "method": "GET",
    "path": "/api/v1/claims",
    "category": "returns",
    "query_keys": [
      "is_archive",
      "id",
      "limit",
      "offset",
      "nm_id"
    ],
    "required_query_keys": [
      "is_archive"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/claims",
    "source_readonly": true
  },
  {
    "alias": "api_ping",
    "host": "common",
    "method": "GET",
    "path": "/ping",
    "category": "any",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "01-general.yaml",
    "source_path": "/ping",
    "source_readonly": true
  },
  {
    "alias": "seller_news",
    "host": "common",
    "method": "GET",
    "path": "/api/communications/v2/news",
    "category": "any",
    "query_keys": [
      "from",
      "fromID"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "01-general.yaml",
    "source_path": "/api/communications/v2/news",
    "source_readonly": true
  },
  {
    "alias": "tariff_constructor_options",
    "host": "common",
    "method": "GET",
    "path": "/api/common/v1/tariff-constructor/options",
    "category": "any",
    "query_keys": [
      "locale"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "01-general.yaml",
    "source_path": "/api/common/v1/tariff-constructor/options",
    "source_readonly": true,
    "token_types": [
      "service"
    ],
    "blocked_reason": "SERVICE_TOKEN_ONLY_PERSONAL_BUILD"
  },
  {
    "alias": "content_barcodes",
    "host": "content",
    "method": "POST",
    "path": "/content/v2/barcodes",
    "category": "content",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "derived",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/content/v2/barcodes",
    "source_readonly": false
  },
  {
    "alias": "content_recommendations",
    "host": "content",
    "method": "POST",
    "path": "/api/content/v1/recommendations/list",
    "category": "content",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/content/v1/recommendations/list",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service"
    ]
  },
  {
    "alias": "price_history_tasks",
    "host": "prices",
    "method": "GET",
    "path": "/api/v2/history/tasks",
    "category": "prices",
    "query_keys": [
      "uploadID"
    ],
    "required_query_keys": [
      "uploadID"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v2/history/tasks",
    "source_readonly": true
  },
  {
    "alias": "price_history_goods_task",
    "host": "prices",
    "method": "GET",
    "path": "/api/v2/history/goods/task",
    "category": "prices",
    "query_keys": [
      "limit",
      "offset",
      "uploadID"
    ],
    "required_query_keys": [
      "limit",
      "uploadID"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v2/history/goods/task",
    "source_readonly": true
  },
  {
    "alias": "price_buffer_tasks",
    "host": "prices",
    "method": "GET",
    "path": "/api/v2/buffer/tasks",
    "category": "prices",
    "query_keys": [
      "uploadID"
    ],
    "required_query_keys": [
      "uploadID"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v2/buffer/tasks",
    "source_readonly": true
  },
  {
    "alias": "price_buffer_goods_task",
    "host": "prices",
    "method": "GET",
    "path": "/api/v2/buffer/goods/task",
    "category": "prices",
    "query_keys": [
      "limit",
      "offset",
      "uploadID"
    ],
    "required_query_keys": [
      "limit",
      "uploadID"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v2/buffer/goods/task",
    "source_readonly": true
  },
  {
    "alias": "fbs_reshipment_orders",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/supplies/orders/reshipment",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/supplies/orders/reshipment",
    "source_readonly": true
  },
  {
    "alias": "fbs_orders_archive",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/marketplace/v3/fbs/orders/archive",
    "category": "marketplace",
    "query_keys": [
      "year",
      "month",
      "next",
      "limit"
    ],
    "required_query_keys": [
      "year",
      "month",
      "next",
      "limit"
    ],
    "body_required": false,
    "privacy": "customer_safe_v1",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/marketplace/v3/fbs/orders/archive",
    "source_readonly": true
  },
  {
    "alias": "fbs_autoreturns_settings",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/marketplace/v3/fbs/settings/autoreturns",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/marketplace/v3/fbs/settings/autoreturns",
    "source_readonly": true
  },
  {
    "alias": "fbs_autoreturns_items",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/fbs/settings/autoreturns/items",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/marketplace/v3/fbs/settings/autoreturns/items",
    "source_readonly": true
  },
  {
    "alias": "fbs_autoreturns_restricted_subjects",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/marketplace/v3/fbs/settings/autoreturns/subcategories/restricted",
    "category": "marketplace",
    "query_keys": [
      "next",
      "limit"
    ],
    "required_query_keys": [
      "next",
      "limit"
    ],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/marketplace/v3/fbs/settings/autoreturns/subcategories/restricted",
    "source_readonly": true
  },
  {
    "alias": "promo_config",
    "host": "advert",
    "method": "GET",
    "path": "/api/advert/v1/config",
    "category": "promotion",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "08-promotion.yaml",
    "source_path": "/api/advert/v1/config",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service"
    ]
  },
  {
    "alias": "search_report_main",
    "host": "analytics",
    "method": "POST",
    "path": "/api/v2/search-report/report",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/v2/search-report/report",
    "source_readonly": true
  },
  {
    "alias": "analytics_item_rating_v2",
    "host": "analytics",
    "method": "POST",
    "path": "/api/analytics/v2/item-rating",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/analytics/v2/item-rating",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service"
    ]
  },
  {
    "alias": "analytics_item_rating_v1",
    "host": "analytics",
    "method": "POST",
    "path": "/api/analytics/v1/item-rating",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/analytics/v1/item-rating",
    "source_readonly": true,
    "token_types": [
      "personal",
      "service"
    ]
  },
  {
    "alias": "analytics_order_feed",
    "host": "analytics",
    "method": "POST",
    "path": "/api/analytics/v1/order-feed",
    "category": "analytics",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "standard",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": true,
    "current": true,
    "source_openapi": "11-analytics.yaml",
    "source_path": "/api/analytics/v1/order-feed",
    "source_readonly": true
  },
  {
    "alias": "seller_users",
    "host": "user_management",
    "method": "GET",
    "path": "/api/v1/users",
    "category": "user_management",
    "query_keys": [
      "limit",
      "offset",
      "isInviteOnly"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "01-general.yaml",
    "source_path": "/api/v1/users",
    "source_readonly": true,
    "token_types": [
      "personal"
    ],
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "dbw_warehouse_contacts",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/dbw/warehouses/{warehouseId}/contacts",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "02-items.yaml",
    "source_path": "/api/v3/dbw/warehouses/{warehouseId}/contacts",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "fbs_passes",
    "host": "marketplace",
    "method": "GET",
    "path": "/api/v3/passes",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/passes",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "fbs_orders_client",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/orders/client",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "03-orders-fbs.yaml",
    "source_path": "/api/v3/orders/client",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "dbw_orders_client",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/dbw/orders/client",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "04-orders-dbw.yaml",
    "source_path": "/api/marketplace/v3/dbw/orders/client",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "dbw_orders_courier",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/dbw/orders/courier",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "04-orders-dbw.yaml",
    "source_path": "/api/v3/dbw/orders/courier",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "dbs_orders_client",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/dbs/orders/client",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "05-orders-dbs.yaml",
    "source_path": "/api/v3/dbs/orders/client",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "dbs_orders_b2b_info",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/marketplace/v3/dbs/orders/b2b/info",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "05-orders-dbs.yaml",
    "source_path": "/api/marketplace/v3/dbs/orders/b2b/info",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "pickup_orders_client",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/click-collect/orders/client",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "06-in-store-pickup.yaml",
    "source_path": "/api/v3/click-collect/orders/client",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "pickup_orders_client_identity",
    "host": "marketplace",
    "method": "POST",
    "path": "/api/v3/click-collect/orders/client/identity",
    "category": "marketplace",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": true,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "06-in-store-pickup.yaml",
    "source_path": "/api/v3/click-collect/orders/client/identity",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "buyer_chats",
    "host": "buyer_chat",
    "method": "GET",
    "path": "/api/v1/seller/chats",
    "category": "buyer_chat",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/seller/chats",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "buyer_chat_events",
    "host": "buyer_chat",
    "method": "GET",
    "path": "/api/v1/seller/events",
    "category": "buyer_chat",
    "query_keys": [
      "next"
    ],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "blocked_pii",
    "response_mode": "json",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/seller/events",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  },
  {
    "alias": "buyer_chat_download",
    "host": "buyer_chat",
    "method": "GET",
    "path": "/api/v1/seller/download/{id}",
    "category": "buyer_chat",
    "query_keys": [],
    "required_query_keys": [],
    "body_required": false,
    "privacy": "blocked_pii",
    "response_mode": "binary",
    "read_kind": "direct",
    "effect": "READ",
    "execution_enabled": false,
    "current": true,
    "source_openapi": "09-communications.yaml",
    "source_path": "/api/v1/seller/download/{id}",
    "source_readonly": true,
    "blocked_reason": "DIRECT_PII_SURFACE"
  }
];
  const OPERATIONS = Object.freeze(Object.fromEntries(raw.map((x)=>[
    x.alias,
    Object.freeze({
      ...x,
      query_keys:Object.freeze(x.query_keys||[]),
      required_query_keys:Object.freeze(x.required_query_keys||[]),
      token_types:Object.freeze(x.token_types||[])
    })
  ])));
  globalThis.WBOperations=Object.freeze({HOSTS,OPERATIONS});
})();

;
(() => {
  "use strict";
  const RETIREMENTS = Object.freeze([
    Object.freeze({
      alias: "banned_products_shadowed",
      method: "GET",
      path: "/api/v1/analytics/banned-products/shadowed",
    }),
    Object.freeze({
      alias: "analytics_item_rating_v1",
      method: "POST",
      path: "/api/analytics/v1/item-rating",
    }),
  ]);
  const ADDITION = Object.freeze({
    alias: "analytics_item_returns",
    host: "analytics",
    method: "GET",
    path: "/api/analytics/v1/item-returns",
    category: "analytics",
    query_keys: Object.freeze([
      "dateFrom",
      "dateTo",
      "status",
      "limit",
      "offset",
    ]),
    required_query_keys: Object.freeze([
      "dateFrom",
      "dateTo",
      "status",
      "limit",
      "offset",
    ]),
    body_required: false,
    privacy: "standard",
    response_mode: "json",
    read_kind: "direct",
    effect: "READ",
    execution_enabled: true,
    current: true,
    source_openapi: "12-reports.yaml",
    source_path: "/api/analytics/v1/item-returns",
    source_readonly: true,
  });
  const registry = globalThis.WBOperations;
  if (!registry?.OPERATIONS || !registry?.HOSTS)
    throw new Error(
      "WBOperations must load before the retired analytics registry overlay.",
    );

  const operations = { ...registry.OPERATIONS };
  const goodsReturn = operations.goods_return;
  if (
    !goodsReturn ||
    goodsReturn.method !== "GET" ||
    goodsReturn.path !== "/api/v1/analytics/goods-return" ||
    goodsReturn.current !== true ||
    goodsReturn.execution_enabled !== true
  )
    throw new Error("WB goods_return registry source drift.");
  if (
    Object.prototype.hasOwnProperty.call(operations, ADDITION.alias) ||
    Object.values(operations).some(
      (operation) => operation.path === ADDITION.path,
    )
  )
    throw new Error("WB item returns registry addition already exists.");
  for (const target of RETIREMENTS) {
    const source = operations[target.alias];
    if (
      !source ||
      source.method !== target.method ||
      source.path !== target.path ||
      source.current !== true ||
      source.execution_enabled !== true
    )
      throw new Error(
        `Retired WB analytics registry source drift: ${target.alias}`,
      );
    delete operations[target.alias];
  }
  operations[ADDITION.alias] = ADDITION;

  globalThis.WBOperations = Object.freeze({
    HOSTS: registry.HOSTS,
    OPERATIONS: Object.freeze(operations),
  });
})();

;
(() => {
  "use strict";
  const TARGET = "fbs_order_statuses";
  const registry = globalThis.WBOperations;
  if (!registry?.OPERATIONS || !registry?.HOSTS)
    throw new Error(
      "WBOperations must load before the FBS statuses registry overlay.",
    );
  const source = registry.OPERATIONS[TARGET];
  if (
    !source ||
    source.method !== "POST" ||
    source.path !== "/api/v3/orders/status"
  )
    throw new Error("FBS statuses registry source drift.");
  if (source.body_required !== false)
    throw new Error(
      "FBS statuses body_required baseline drift; retire or update the overlay.",
    );

  const patched = Object.freeze({ ...source, body_required: true });
  const operations = Object.freeze({
    ...registry.OPERATIONS,
    [TARGET]: patched,
  });
  globalThis.WBOperations = Object.freeze({
    HOSTS: registry.HOSTS,
    OPERATIONS: operations,
  });
})();

;
(() => {
  "use strict";
  function fail(code, message) { const e = new Error(message || code); e.code = code; throw e; }
  function ascii(value, name, { required=false, max=4096 }={}) {
    const text = String(value ?? "").trim();
    if (!text) { if (required) fail(`MISSING_${name.toUpperCase()}`, `${name} не сохранён.`); return ""; }
    if (text.length > max) fail(`INVALID_${name.toUpperCase()}`, `${name} слишком длинный.`);
    for (let i=0;i<text.length;i+=1) { const c=text.charCodeAt(i); if (c<0x21 || c>0x7e) fail(`INVALID_${name.toUpperCase()}`, `${name} содержит недопустимый символ.`); }
    return text;
  }
  function normalizeSellerCredentials(input={}, {required=false}={}) {
    const token = ascii(input.token ?? input.clientId, "token", {required, max:8192});
    const tokenTypeRaw = String(input.tokenType || "personal").trim().toLowerCase();
    if (tokenTypeRaw && tokenTypeRaw !== "personal") {
      fail("UNSUPPORTED_TOKEN_TYPE", "Эта сборка Wildberries Bridge работает только с Personal token.");
    }
    const clientSecret = ascii(input.clientSecret ?? input.apiKey, "client_secret", {required:false, max:4096});
    if (clientSecret) {
      fail("CLIENT_SECRET_UNSUPPORTED_PERSONAL_BUILD", "X-Client-Secret не используется в Personal-token сборке Wildberries Bridge.");
    }
    return Object.freeze({ token, tokenType:"personal", clientSecret:"", clientId:token, apiKey:"", present:Boolean(token) });
  }
  function sellerHeaders(credentials, {hasBody=false, accept="application/json"}={}) {
    const c=normalizeSellerCredentials(credentials,{required:true});
    const h={ Authorization:`Bearer ${c.token}`, Accept:String(accept||"application/json") };
    if (hasBody) h["Content-Type"]="application/json";
    return Object.freeze(h);
  }
  function publicCredentialState(credentials) {
    const c=normalizeSellerCredentials(credentials,{required:false});
    return Object.freeze({
      seller_token_present:Boolean(c.token),
      seller_token_type:"personal",
      seller_client_secret_present:false,
      seller_credentials_present:c.present
    });
  }
  globalThis.WBCredentials=Object.freeze({normalizeSellerCredentials,sellerHeaders,publicCredentialState});
})();

;
(() => {
  "use strict";
  const PREFIX="WB_API_V1", RESULT_PREFIX="WB_RESULT_V1", VERSION="0.3.0";
  const registry=globalThis.WBOperations;
  if(!registry) throw new Error("WBOperations must load before WBContract");
  const {HOSTS,OPERATIONS}=registry;
  const FORBIDDEN=new Set(["url","uri","host","hostname","method","headers","authorization","api-key","api_key","apikey","client-id","client_id","clientid","client-secret","client_secret","clientsecret","x-client-secret","token","access-token","access_token","bearer"]);
  const SECRET_KEYS=[/authorization/i,/api[_-]?key/i,/client[_-]?secret/i,/access[_-]?token/i,/^token$/i,/bearer/i];
  const PII_KEYS=[/phone/i,/e-?mail/i,/delivery[_-]?address/i,/^address$/i,/addressee/i,/recipient/i,/customer/i,/buyer/i,/client[_-]?info/i,/passport/i,/first[_-]?name/i,/last[_-]?name/i,/middle[_-]?name/i,/full[_-]?name/i,/^fio$/i,/^user(name)?$/i,/^latitude$/i,/^longitude$/i,/^lat$/i,/^lon$/i];
  function fail(code,message){const e=new Error(message||code);e.code=code;throw e;}
  function normKey(v){return String(v).toLowerCase().replace(/[^a-z0-9_-]/g,"");}
  function isPlain(v){if(!v||typeof v!=="object"||Array.isArray(v))return false; const p=Object.getPrototypeOf(v); return p===null||p===Object.prototype||Object.getPrototypeOf(p)===null;}
  function deepFreeze(v){if(!v||typeof v!=="object"||Object.isFrozen(v))return v;Object.freeze(v);for(const x of Object.values(v))deepFreeze(x);return v;}
  function cloneJson(v,path="params",depth=0,b={keys:0},{rejectTransport=true,maxDepth=16,maxItems=100000,maxKeys=300000}={}){
    if(depth>maxDepth)fail("PARAMS_TOO_DEEP",`${path}: превышена глубина JSON.`);
    if(v===null||typeof v==="boolean"||typeof v==="string")return v;
    if(typeof v==="number"){if(!Number.isFinite(v))fail("INVALID_NUMBER",`${path}: число должно быть конечным.`);return v;}
    if(Array.isArray(v)){if(v.length>maxItems)fail("TOO_MANY_ITEMS",`${path}: слишком много элементов.`);return v.map((x,i)=>cloneJson(x,`${path}[${i}]`,depth+1,b,{rejectTransport,maxDepth,maxItems,maxKeys}));}
    if(!isPlain(v))fail("INVALID_PARAMS_VALUE",`${path}: разрешены только JSON-значения.`);
    const out={};for(const [k,x] of Object.entries(v)){if(["__proto__","prototype","constructor"].includes(k))fail("UNSAFE_JSON_KEY",`${path}: unsafe object key.`);b.keys++;if(b.keys>maxKeys)fail("TOO_MANY_KEYS",`${path}: слишком много JSON-ключей.`);if(rejectTransport&&FORBIDDEN.has(normKey(k)))fail("TRANSPORT_INJECTION_REJECTED",`${path}.${k}: transport/auth поле запрещено.`);out[k]=cloneJson(x,`${path}.${k}`,depth+1,b,{rejectTransport,maxDepth,maxItems,maxKeys});}return out;
  }
  function resolveOperation(name){const m=OPERATIONS[String(name||"")];if(!m)fail("UNSUPPORTED_OPERATION",`Операция ${name||"<empty>"} не разрешена.`);if(m.effect!=="READ")fail("NON_READ_OPERATION_FORBIDDEN",`Операция ${name} не является READ.`);if(m.current!==true)fail("NON_CURRENT_OPERATION",`Операция ${name} не является current.`);if(m.execution_enabled!==true)fail("OPERATION_BLOCKED",`Операция ${name} заблокирована: ${m.blocked_reason||"policy"}.`);if(!/^(GET|POST)$/.test(m.method))fail("INVALID_REGISTRY_METHOD",`${name}: invalid method.`);if(!HOSTS[m.host])fail("INVALID_REGISTRY_HOST",`${name}: invalid host.`);return m;}
  // Public commands are NOT the normalized worker/provider representation.
  // Validate before resolving an alias: an extra transport field must never be ignored.
  function assertPublicCommand(raw) {
    if (!isPlain(raw)) fail("INVALID_JSON_ROOT", "Команда должна быть JSON-объектом.");
    for (const key of Object.keys(raw)) {
      if (key !== "operation" && key !== "params") fail("UNKNOWN_COMMAND_FIELD", "Разрешены только operation и params.");
    }
    if (typeof raw.operation !== "string" || !raw.operation.trim()) fail("MISSING_OPERATION", "Не указано строковое operation.");
    if (!Object.hasOwn(raw, "params") || !isPlain(raw.params)) fail("INVALID_OPERATION_PARAMS", "Обязателен JSON-объект params.");
  }
  function normalizeCommand(raw){
    assertPublicCommand(raw);
    const operation=raw.operation.trim();const meta=resolveOperation(operation);
    const supplied=raw.params===undefined?{}:cloneJson(raw.params,"params",0,{keys:0},{rejectTransport:true}); if(!isPlain(supplied))fail("INVALID_OPERATION_PARAMS","params должен быть JSON-объектом.");
    if (Object.hasOwn(supplied,"path") && !isPlain(supplied.path)) fail("INVALID_PATH_PARAMS", "params.path должен быть объектом.");
    if (Object.hasOwn(supplied,"query") && !isPlain(supplied.query)) fail("INVALID_QUERY_PARAMS", "params.query должен быть объектом.");
    const path=isPlain(supplied.path)?supplied.path:{}; const query=isPlain(supplied.query)?supplied.query:{};
    let body=supplied.body;
    // compatibility: for body-only methods, direct params are accepted when path/query/body wrappers are absent
    if(meta.body_required && body===undefined && !("path" in supplied)&&!("query" in supplied)&&!("body" in supplied)) body=supplied;
    const placeholders=[...String(meta.path).matchAll(/\{([A-Za-z0-9_]+)\}/g)].map(m=>m[1]);
    const pathOut={};for(const k of placeholders){const val=path[k]??supplied[k];if(val===undefined||val===null||String(val).trim()==="")fail("MISSING_PATH_PARAM",`${operation}: не указан path.${k}.`);const text=String(val).trim();if(!/^[A-Za-z0-9._:-]{1,180}$/.test(text))fail("INVALID_PATH_PARAM",`${operation}: ${k} имеет недопустимый формат.`);pathOut[k]=text;}
    const qOut={};for(const [k,v] of Object.entries(query)){if(!meta.query_keys.includes(k))fail("UNSUPPORTED_QUERY_PARAM",`${operation}: query.${k} не разрешён.`);qOut[k]=v;}
    // compatibility: declared query keys may be supplied directly in params
    for(const k of meta.query_keys){if(qOut[k]===undefined && supplied[k]!==undefined && !["path","query","body"].includes(k))qOut[k]=supplied[k];}
    for(const k of meta.required_query_keys){if(qOut[k]===undefined||qOut[k]===null||qOut[k]==="")fail("MISSING_QUERY_PARAM",`${operation}: обязателен query.${k}.`);}
    if(meta.body_required && (body===undefined||body===null))fail("MISSING_BODY",`${operation}: обязателен params.body.`);
    if(body!==undefined) body=cloneJson(body,"params.body",0,{keys:0},{rejectTransport:true});
    return deepFreeze({operation,path:pathOut,query:qOut,body});
  }
  // Internal callers may restore this representation from JSON storage. Re-validate
  // it through the public contract instead of trusting a marker, identity or old worker.
  function checkedCommand(command) {
    if (isPlain(command) && !Object.hasOwn(command,"params") && Object.hasOwn(command,"path") && Object.hasOwn(command,"query")) {
      for (const key of Object.keys(command)) {
        if (!["operation","path","query","body"].includes(key)) fail("UNKNOWN_COMMAND_FIELD", "Недопустимое поле внутренней команды.");
      }
      return normalizeCommand({operation:command.operation, params:{path:command.path, query:command.query, ...(command.body===undefined?{}:{body:command.body})}});
    }
    return normalizeCommand(command);
  }
  function parseCommand(text){let s=String(text||"").trim();if(!s.startsWith(PREFIX))fail("NOT_WB_COMMAND",`Команда должна начинаться с ${PREFIX}.`);s=s.slice(PREFIX.length).trim();if(!s)fail("MISSING_JSON",`После ${PREFIX} нужен JSON.`);let raw;try{raw=JSON.parse(s);}catch(e){fail("INVALID_JSON","Некорректный JSON команды.");}return normalizeCommand(raw);}
  function qs(query){const u=new URLSearchParams();for(const [k,v] of Object.entries(query||{})){if(v===undefined||v===null)continue;if(Array.isArray(v)){for(const x of v)u.append(k,String(x));}else if(isPlain(v))fail("INVALID_QUERY_PARAM",`${k}: query value cannot be object.`);else u.append(k,String(v));}const s=u.toString();return s?`?${s}`:"";}
  function buildRequest(command,headers={}){const c=checkedCommand(command),m=resolveOperation(c.operation);let path=m.path;for(const [k,v] of Object.entries(c.path))path=path.replaceAll(`{${k}}`,encodeURIComponent(v));if(path.includes("{")||path.includes(".."))fail("UNRESOLVED_PATH","Небезопасный или незаполненный path.");const origin=HOSTS[m.host];const url=`${origin}${path}${qs(c.query)}`;const request={url,host_alias:m.host,method:m.method,headers:Object.freeze({...headers}),body:m.method==="POST"&&c.body!==undefined?JSON.stringify(c.body):undefined,response_mode:m.response_mode||"json",privacy:m.privacy||"standard",effect:m.effect};return Object.freeze(request);}
  function redactText(s){return String(s).replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g,"[REDACTED_EMAIL]").replace(/(?:\+?\d[\d\s().-]{8,}\d)/g,"[REDACTED_PHONE]");}
  function sanitizeNode(v,privacy,depth=0,b={keys:0},maxKeys=300000){if(depth>64)fail("RESULT_DEPTH_EXCEEDED","Результат не обрезан; превышена безопасная глубина.");if(v===null||typeof v==="boolean")return v;if(typeof v==="number")return Number.isFinite(v)?v:null;if(typeof v==="string")return privacy==="customer_safe_v1"?redactText(v):v;if(Array.isArray(v))return v.map(x=>sanitizeNode(x,privacy,depth+1,b,maxKeys));if(!v||typeof v!=="object")return String(v);const out={};const entries=Object.entries(v);for(const [k,x] of entries){if(b.keys>=maxKeys-1){fail("RESULT_KEY_LIMIT","Результат не обрезан; превышено число полей.");}b.keys++;if(SECRET_KEYS.some(r=>r.test(k))||(privacy==="customer_safe_v1"&&PII_KEYS.some(r=>r.test(k))))out[k]="[REDACTED]";else out[k]=sanitizeNode(x,privacy,depth+1,b,maxKeys);}return out;}
  function sanitizeResult(command,raw){const c=checkedCommand(command),m=resolveOperation(c.operation);return sanitizeNode(raw,m.privacy||"standard");}
  function commandFingerprint(command){const s=JSON.stringify(checkedCommand(command));let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return(h>>>0).toString(16).padStart(8,"0");}
  function safeErrorPayload(status,raw,parsed){const src=parsed&&typeof parsed==="object"?sanitizeNode(parsed,"customer_safe_v1"):redactText(String(raw||"").slice(0,12000));return {code:"WB_API_ERROR",message:`Wildberries API вернул HTTP ${Number(status||0)}.`,http_status:Number(status||0),provider_error:src,automatic_retry:false};}
  function safeBridgeErrorPayload(error){return {code:String(error?.code||"WB_BRIDGE_ERROR"),message:redactText(String(error?.message||error||"Bridge error")).slice(0,4000),automatic_retry:false};}
  function formatResultReport({requestId,command,requestMeta,httpStatus,result,elapsedMs,pagination=null,rateLimit=null}){const c=checkedCommand(command);const env={bridge:"wildberries-llm-api-bridge",version:VERSION,request_id:String(requestId||""),operation:c.operation,command:{operation:c.operation,fingerprint:commandFingerprint(c)},request_meta:{provider:"wildberries",host_alias:String(requestMeta?.host_alias||""),http_method:String(requestMeta?.http_method||""),path_alias:String(requestMeta?.path_alias||c.operation)},http_status:Number(httpStatus||0),elapsed_ms:Number(elapsedMs||0),result:sanitizeNode(result,resolveOperation(c.operation).privacy||"standard"),pagination:pagination??{explicit_only:true,hidden_requests:0,automatic_retry:false}};if(rateLimit)env.rate_limit=rateLimit;return `${RESULT_PREFIX}\n${JSON.stringify(env,null,2)}`;}
  function isCommandText(text){return String(text||"").replace(/\u00a0/g," ").trim().startsWith(PREFIX);}
  function preflightExecution(command){const c=checkedCommand(command),m=resolveOperation(c.operation);return Object.freeze({operation:c.operation,effect:m.effect,execution_enabled:true,current:true});}
  const WBContract=Object.freeze({PREFIX,RESULT_PREFIX,VERSION,HOSTS,OPERATIONS,parseCommand,normalizeCommand,resolveOperation,preflightExecution,buildRequest,sanitizeResult,commandFingerprint,safeErrorPayload,safeBridgeErrorPayload,formatResultReport,isCommandText});
  function createWBContract({operations=null,prefix=PREFIX,resultPrefix=RESULT_PREFIX,version=VERSION,sellerApiBase="https://common-api.wildberries.ru"}={}) {
    if(!operations || operations===OPERATIONS) return WBContract;
    const reg=Object.freeze({...operations});
    function ro(name){const operation=String(name||"").trim(),meta=reg[operation];if(!meta)fail("UNSUPPORTED_OPERATION",`Операция ${operation} не разрешена.`);if(meta.effect!=="READ")fail("NON_READ_OPERATION_FORBIDDEN",operation);return {operation,meta};}
    function nc(raw){assertPublicCommand(raw);const {operation,meta}=ro(raw.operation);const params=cloneJson(raw.params===undefined?{}:raw.params,"params",0,{keys:0},{rejectTransport:true});const normalized=typeof meta.normalizeParams==="function"?meta.normalizeParams(params):params;return deepFreeze({operation,params:normalized});}
    function pc(text){const src=String(text||"").trim();if(!src.startsWith(prefix))fail("NOT_WB_COMMAND",`Команда должна начинаться с ${prefix}.`);let raw;try{raw=JSON.parse(src.slice(prefix.length).trim());}catch(e){fail("INVALID_JSON",e.message);}return nc(raw);}
    function pf(command){const c=nc(command),{meta}=ro(c.operation);if(meta.execution_enabled!==true)fail("OPERATION_BLOCKED",c.operation);return {command:c,meta};}
    function br(command,headers={}){const {command:c,meta}=pf(command);const url=`${sellerApiBase}${meta.path}`;return Object.freeze({url,host_alias:"common",method:meta.method,headers:Object.freeze({...headers}),body:meta.method==="POST"?JSON.stringify(c.params):undefined,response_mode:"json",effect:meta.effect});}
    function sr(command,raw){const {meta}=pf(command);return typeof meta.sanitizeResult==="function"?meta.sanitizeResult(raw):raw;}
    function fp(command){const x=JSON.stringify(nc(command));let h=2166136261;for(let i=0;i<x.length;i++){h^=x.charCodeAt(i);h=Math.imul(h,16777619);}return(h>>>0).toString(16).padStart(8,"0");}
    function fr({requestId,command,requestMeta,httpStatus,result,elapsedMs,pagination=null,rateLimit=null}){const c=nc(command);return `${resultPrefix}\n${JSON.stringify({bridge:"wildberries-llm-api-bridge",version,request_id:String(requestId||""),operation:c.operation,command:{operation:c.operation,fingerprint:fp(c)},request_meta:{provider:"wildberries",host_alias:String(requestMeta?.host_alias||"common"),http_method:String(requestMeta?.http_method||""),path_alias:String(requestMeta?.path_alias||c.operation)},http_status:Number(httpStatus||0),elapsed_ms:Number(elapsedMs||0),pagination,rate_limit:rateLimit,result},null,2)}`;}
    return Object.freeze({PREFIX:prefix,RESULT_PREFIX:resultPrefix,VERSION:version,HOSTS,OPERATIONS:reg,parseCommand:pc,normalizeCommand:nc,resolveOperation:(n)=>ro(n),preflightExecution:pf,buildRequest:br,sanitizeResult:sr,commandFingerprint:fp,safeErrorPayload,safeBridgeErrorPayload,formatResultReport:fr,isCommandText:(t)=>String(t||"").trim().startsWith(prefix)});
  }
  globalThis.WBContract=WBContract;
  globalThis.WBContractFactory=Object.freeze({createWBContract,OPERATIONS});
})();

;
(() => {
  "use strict";
  const TARGET = "fbs_order_statuses";
  const MAX_ORDERS = 1000;
  const base = globalThis.WBContract;
  if (!base || base.OPERATIONS?.[TARGET]?.body_required !== true)
    throw new Error(
      "Patched WBContract must load before the FBS statuses contract overlay.",
    );

  function fail(code, message) {
    const error = new Error(message || code);
    error.code = code;
    error.external_request_executed = false;
    throw error;
  }
  function validateNormalized(command) {
    if (command?.operation !== TARGET) return command;
    const body = command.body;
    if (!body || typeof body !== "object" || Array.isArray(body))
      fail(
        "FBS_ORDER_STATUSES_BODY_REQUIRED",
        "fbs_order_statuses requires an object body.",
      );
    if (!Object.hasOwn(body, "orders"))
      fail(
        "FBS_ORDER_STATUSES_ORDERS_REQUIRED",
        "fbs_order_statuses body must contain orders.",
      );
    const keys = Object.keys(body);
    if (keys.length !== 1)
      fail(
        "FBS_ORDER_STATUSES_BODY_INVALID",
        "fbs_order_statuses body must contain only orders.",
      );
    const orders = body.orders;
    if (!Array.isArray(orders) || orders.length === 0)
      fail(
        "FBS_ORDER_STATUSES_ORDERS_REQUIRED",
        "fbs_order_statuses orders must contain at least one ID.",
      );
    if (orders.length > MAX_ORDERS)
      fail(
        "FBS_ORDER_STATUSES_TOO_MANY_ORDERS",
        "fbs_order_statuses accepts at most 1000 IDs.",
      );
    if (orders.some((id) => !Number.isSafeInteger(id)))
      fail(
        "FBS_ORDER_STATUSES_ORDER_ID_INVALID",
        "fbs_order_statuses order IDs must be safe integers.",
      );
    return command;
  }
  function validateInput(command) {
    if (command?.operation !== TARGET) return command;
    if (Object.hasOwn(command, "params"))
      return validateNormalized(base.normalizeCommand(command));
    return validateNormalized(command);
  }
  function normalizeCommand(raw) {
    return validateNormalized(base.normalizeCommand(raw));
  }
  function parseCommand(text) {
    return validateNormalized(base.parseCommand(text));
  }
  function preflightExecution(command) {
    validateInput(command);
    return base.preflightExecution(command);
  }
  function buildRequest(command, headers = {}) {
    validateInput(command);
    return base.buildRequest(command, headers);
  }

  globalThis.WBContract = Object.freeze({
    ...base,
    normalizeCommand,
    parseCommand,
    preflightExecution,
    buildRequest,
  });
})();

;
(() => {
'use strict';
const C=globalThis.WBContract, groups={};
const OPERATIONS=Object.fromEntries(Object.entries(C.OPERATIONS).map(([alias,m])=>{
 const cluster=m.host,section=m.read_kind||'direct';
 const enabled=m.current===true&&m.effect==='READ'&&m.execution_enabled===true;
 const required=[...(m.required_query_keys||[]),...(m.path.match(/\{[^}]+\}/g)||[]),...(m.body_required?['body']:[])];
 const runnable=enabled&&required.length===0;
 (groups[cluster]||=( {description:cluster,clues:[cluster],sections:{}} )).sections[section]=section==='derived'?'Формирование отчёта отдельной явной командой':'Прямое чтение';
 return [alias,Object.freeze({...m,cluster,section,purpose:alias,required_parameters:required,template:runnable?{operation:alias,params:{}}:null,template_runnable:runnable,safety_class:enabled?'READ_SAFE':'BLOCKED',privacy_policy:m.privacy,policy_group:m.privacy==='standard'?'safe_projection':'personal_data_read',entitlement_key:null,workflow_role:section==='derived'?'explicit_report_step':'single_read'})];
}));
const canonicalClusterId=v=>typeof v==='string'&&Object.hasOwn(groups,v)?v:null;
const operationsForCluster=(id,section)=>Object.entries(OPERATIONS).filter(([a,m])=>m.cluster===id&&(!section||m.section===section)).map(([alias,meta])=>({alias,meta}));
const catalogValidation=()=>({ok:Object.keys(OPERATIONS).length===188,operation_count:Object.keys(OPERATIONS).length,enabled:Object.values(OPERATIONS).filter(m=>m.execution_enabled).length,authority:'PACKAGED_WB_REGISTRY_SNAPSHOT_NOT_LIVE_ACCOUNT_PROOF'});
globalThis.WBGuidanceRegistry=Object.freeze({CLUSTERS:Object.freeze(groups),OPERATIONS:Object.freeze(OPERATIONS),canonicalClusterId,operationsForCluster,catalogValidation});
})();

;
(() => {
  "use strict";

  const HELP_PREFIX = globalThis.WBRuntime?.RUNTIME?.helpPrefix || "WB_HELP_V1";
  const HELP_PREFIX_V2 = globalThis.WBRuntime?.RUNTIME?.helpPrefixV2 || "WB_HELP_V2";
  const GUIDANCE_PREFIX = globalThis.WBRuntime?.RUNTIME?.guidanceResultPrefix || "WB_GUIDANCE_RESULT_V1";
  const GUIDANCE_PREFIX_V2 = globalThis.WBRuntime?.RUNTIME?.guidanceResultPrefixV2 || "WB_GUIDANCE_RESULT_V2";
  const Registry = globalThis.WBGuidanceRegistry;
  const CLUSTERS = Registry?.CLUSTERS || Object.freeze({});
  const INTENT_FIELDS = new Set(["operation", "method", "path", "endpoint", "action"]);
  const SENSITIVE = new Set(["authorization", "api_key", "apikey", "client_id", "clientid", "client_secret", "clientsecret", "token", "access_token", "access-token"]);

  const norm = (value) => String(value || "").toLowerCase().slice(0, 240);
  const plain = (value) => Boolean(value && typeof value === "object" && !Array.isArray(value) && Object.prototype.toString.call(value) === "[object Object]");

  function descriptorFromObject(value, errorCode = "INVALID_COMMAND") {
    if (!plain(value)) return Object.freeze({ error_code: String(errorCode), top_level_keys: Object.freeze([]), intent: Object.freeze({}), parameter_keys: Object.freeze([]), sensitive: false });
    const top = Object.keys(value).slice(0, 24).map(norm);
    const intent = {};
    let sensitive = false;
    for (const rawKey of Object.keys(value).slice(0, 24)) {
      const key = norm(rawKey);
      if (SENSITIVE.has(key)) sensitive = true;
      if (INTENT_FIELDS.has(key) && typeof value[rawKey] === "string") intent[key] = Object.hasOwn(Registry?.OPERATIONS || {}, value[rawKey]) ? norm(value[rawKey]) : "[UNRECOGNIZED_INTENT]";
    }
    const params = plain(value.params) ? value.params : plain(value.args) ? value.args : {};
    const parameterKeys = Object.keys(params).slice(0, 32).map(norm);
    for (const key of parameterKeys) if (SENSITIVE.has(key)) sensitive = true;
    return Object.freeze({ error_code: String(errorCode || "INVALID_COMMAND").slice(0, 80), top_level_keys: Object.freeze(top), intent: Object.freeze(intent), parameter_keys: Object.freeze(parameterKeys), sensitive });
  }

  function descriptorFromJson(jsonText, errorCode) {
    try { return descriptorFromObject(JSON.parse(String(jsonText || "")), errorCode); }
    catch (_) { return descriptorFromObject(null, errorCode || "INVALID_JSON"); }
  }

  function clusterEntries(clusterId, section = null) {
    if (!Registry) return [];
    return Registry.operationsForCluster(clusterId, section, { includeConditional: true, includeHidden: false });
  }

  function scoreDescriptor(descriptor) {
    const scores = Object.fromEntries(Object.keys(CLUSTERS).map((id) => [id, 0]));
    const rules = [];
    const intents = Object.values(descriptor?.intent || {});
    const tokens = [...intents, ...(descriptor?.top_level_keys || []), ...(descriptor?.parameter_keys || [])].join(" ");

    for (const [alias, meta] of Object.entries(Registry?.OPERATIONS || {})) {
      if (intents.includes(alias.toLowerCase())) {
        scores[meta.cluster] = (scores[meta.cluster] || 0) + 120;
        rules.push(`${meta.cluster}:exact_alias:${alias}`);
      }
      const fixedPath = String(meta.path || "").toLowerCase();
      if (fixedPath && intents.some((value) => value.includes(fixedPath))) {
        scores[meta.cluster] = (scores[meta.cluster] || 0) + 100;
        rules.push(`${meta.cluster}:exact_path:${alias}`);
      }
    }

    for (const [id, cluster] of Object.entries(CLUSTERS)) {
      for (const clue of cluster.clues || []) {
        if (tokens.includes(String(clue).toLowerCase())) {
          scores[id] += String(clue).includes("/") ? 60 : 18;
          rules.push(`${id}:clue`);
        }
      }
    }

    return Object.freeze({ scores: Object.freeze(scores), rules: Object.freeze(rules) });
  }

  function classify(descriptor) {
    if (descriptor?.sensitive) return Object.freeze({ status: "guidance_error", cluster: null, section: null, version: 2, error: "SENSITIVE_ATTEMPT_REDACTED" });
    const scored = scoreDescriptor(descriptor);
    const ranked = Object.entries(scored.scores).sort((a, b) => b[1] - a[1]);
    if (!ranked.length || ranked[0][1] <= 0) return Object.freeze({ status: "cluster_required", cluster: null, section: null, version: 2, error: descriptor?.error_code || null, scores: scored.scores });
    if (ranked[1] && ranked[1][1] === ranked[0][1]) return Object.freeze({ status: "cluster_required", cluster: null, section: null, version: 2, error: "AMBIGUOUS_CLUSTER", scores: scored.scores });
    return Object.freeze({ status: "cluster_suggested", cluster: ranked[0][0], section: null, version: 2, error: descriptor?.error_code || null, scores: scored.scores });
  }

  function extractBalancedObject(source, start) {
    let depth = 0, string = false, escaped = false;
    for (let index = start; index < source.length; index += 1) {
      const char = source[index];
      if (string) {
        if (escaped) { escaped = false; continue; }
        if (char === "\\") { escaped = true; continue; }
        if (char === '"') string = false;
        continue;
      }
      if (char === '"') { string = true; continue; }
      if (char === "{") depth += 1;
      else if (char === "}") {
        depth -= 1;
        if (depth === 0) return source.slice(start, index + 1);
      }
    }
    return null;
  }

  function parseHelp(text) {
    const source = String(text || "").replace(/\u00a0/g, " ").trim();
    const v2 = source.startsWith(HELP_PREFIX_V2);
    const prefix = v2 ? HELP_PREFIX_V2 : HELP_PREFIX;
    if (!source.startsWith(prefix)) return Object.freeze({ ok: false, code: "NOT_HELP_COMMAND" });
    let cursor = prefix.length;
    while (/\s/.test(source[cursor] || "")) cursor += 1;
    if (source[cursor] !== "{") return Object.freeze({ ok: false, code: "HELP_JSON_REQUIRED" });
    const json = extractBalancedObject(source, cursor);
    if (!json || source.slice(cursor + json.length).trim()) return Object.freeze({ ok: false, code: "HELP_EXACT_OBJECT_REQUIRED" });
    let raw;
    try { raw = JSON.parse(json); } catch (_) { return Object.freeze({ ok: false, code: "HELP_INVALID_JSON" }); }
    if (!plain(raw)) return Object.freeze({ ok: false, code: "HELP_INVALID_OBJECT" });
    const allowedFields = v2 ? ["cluster", "section"] : ["cluster"];
    const extra = Object.keys(raw).filter((key) => !allowedFields.includes(key));
    if (extra.length) return Object.freeze({ ok: false, code: "HELP_UNKNOWN_FIELD" });
    const cluster = Registry?.canonicalClusterId(raw.cluster);
    if (!cluster || !CLUSTERS[cluster]) return Object.freeze({ ok: false, code: "HELP_UNKNOWN_CLUSTER" });
    let section = null;
    if (v2 && raw.section != null) {
      section = String(raw.section || "").trim();
      if (!section || !CLUSTERS[cluster]?.sections?.[section]) return Object.freeze({ ok: false, code: "HELP_UNKNOWN_SECTION" });
    }
    return Object.freeze({ ok: true, version: v2 ? 2 : 1, cluster, section });
  }

  function operationCard(alias, meta) {
    return Object.freeze({
      ...globalThis.WBParameterGuidance?.describe(alias),
      operation: alias,
      purpose: meta.purpose || "Read-only WB operation.",
      template: meta.template_runnable === false ? null : (meta.template || { operation: alias, params: {} }),
      template_runnable: meta.template_runnable !== false,
      required_parameters: Array.isArray(meta.required_parameters) ? Object.freeze([...meta.required_parameters]) : Object.freeze([]),
      section: meta.section || null,
      safety_class: meta.safety_class || "READ_SAFE",
      privacy_policy: meta.privacy_policy || "safe_projection",
      personal_data_setting_required_when_off: meta.policy_group === "personal_data_read",
      entitlement_key: meta.entitlement_key || null,
      workflow_role: meta.workflow_role || "single_read"
    });
  }

  function choicesFor(cluster = null, section = null, version = 1) {
    if (!cluster) {
      return Object.entries(CLUSTERS).map(([id, meta]) => Object.freeze({ cluster: id, description: meta.description || "" }));
    }
    const entries = clusterEntries(cluster, section);
    if (version >= 2 && !section) {
      const sections = [...new Set(entries.map(({ meta }) => meta.section).filter(Boolean))];
      if (sections.length > 1) {
        return sections.map((id) => Object.freeze({ section: id, description: CLUSTERS[cluster]?.sections?.[id] || "", operation_count: entries.filter(({ meta }) => meta.section === id).length }));
      }
    }
    return entries.map(({ alias, meta }) => operationCard(alias, meta));
  }

  function catalogValidation(contract = globalThis.WBContract) {
    return Registry?.catalogValidation(contract?.OPERATIONS || null) || Object.freeze({ ok: false, errors: ["operation_registry_missing"] });
  }

  function result({ status = "cluster_required", cluster = null, section = null, error = null, descriptor = null, version = 1 } = {}) {
    const normalizedCluster = cluster ? Registry?.canonicalClusterId(cluster) : null;
    return Object.freeze({
      bridge: "wildberries-llm-api-bridge",
      version: globalThis.WBRuntime?.RUNTIME?.version || "0.3.0",
      guidance_version: String(version >= 2 ? 2 : 1),
      status,
      cluster: normalizedCluster,
      section: section || null,
      external_request_executed: false,
      physical_business_request_count: 0,
      error: error || null,
      descriptor: descriptor ? { error_code: descriptor.error_code || null, intent: descriptor.intent || {}, parameter_keys: descriptor.parameter_keys || [] } : null,
      choices: choicesFor(normalizedCluster, section, version)
    });
  }

  function format(payload) {
    const prefix = String(payload?.guidance_version || "1") === "2" ? GUIDANCE_PREFIX_V2 : GUIDANCE_PREFIX;
    return `${prefix}\n${JSON.stringify(payload, null, 2)}`;
  }

  globalThis.WBGuidance = Object.freeze({
    HELP_PREFIX,
    HELP_PREFIX_V2,
    GUIDANCE_PREFIX,
    GUIDANCE_PREFIX_V2,
    CLUSTERS,
    descriptorFromObject,
    descriptorFromJson,
    scoreDescriptor,
    classify,
    parseHelp,
    catalogValidation,
    result,
    format
  });
})();

;
(() => {
  "use strict";
  function fail(code, message) {
    const error = new Error(message);
    error.code = code;
    throw error;
  }

  function headerValue(headers, name) {
    if (!headers) return null;
    if (typeof headers.get === "function") return headers.get(name);
    const target = String(name).toLowerCase();
    for (const [key, value] of Object.entries(headers)) {
      if (String(key).toLowerCase() === target) return String(value);
    }
    return null;
  }

  function safeResponseMeta(response) {
    return Object.freeze({
      content_type: headerValue(response?.headers, "content-type"),
      content_length: headerValue(response?.headers, "content-length"),
      request_id: headerValue(response?.headers, "x-request-id") || headerValue(response?.headers, "request-id"),
      retry_after: headerValue(response?.headers, "retry-after")
    });
  }

  function abortable(promise, signal, cancel = null) {
    if (!signal) return promise;
    return new Promise((resolve, reject) => {
      const abort = () => {
        reject(Object.assign(new Error('Provider response deadline exceeded.'), {code:'REQUEST_TIMEOUT'}));
        try { Promise.resolve(cancel?.()).catch(() => {}); } catch (_) {}
      };
      if (signal.aborted) { abort(); return; }
      signal.addEventListener('abort', abort, {once:true});
      Promise.resolve(promise).then(resolve, reject).finally(() => signal.removeEventListener('abort', abort));
    });
  }

  async function readResponseBounded(response, maxBytes = 1_500_000, signal = null) {
    if (!response) fail("EMPTY_RESPONSE", "Provider response отсутствует.");
    const limit = Number(maxBytes);
    if (!Number.isInteger(limit) || limit < 1) fail("INVALID_MAX_RESPONSE_BYTES", "maxBytes должен быть положительным целым числом.");
    const decoder = new TextDecoder();
    if (response.body && typeof response.body.getReader === "function") {
      const reader = response.body.getReader();
      const chunks = [];
      let total = 0;
      for (;;) {
        const { done, value } = await abortable(reader.read(), signal, () => reader.cancel());
        if (done) break;
        const bytes = value instanceof Uint8Array ? value : new Uint8Array(value || []);
        total += bytes.byteLength;
        if (total > limit) {
          try { await reader.cancel(); } catch (_) {}
          fail("RESPONSE_TOO_LARGE", `Provider response превышает ${limit} bytes.`);
        }
        chunks.push(bytes);
      }
      const merged = new Uint8Array(total);
      let offset = 0;
      for (const chunk of chunks) {
        merged.set(chunk, offset);
        offset += chunk.byteLength;
      }
      return Object.freeze({ rawText: decoder.decode(merged), byteLength: total });
    }
    const rawText = typeof response.text === "function" ? await abortable(response.text(), signal) : String(response.body ?? "");
    const byteLength = new TextEncoder().encode(rawText).byteLength;
    if (byteLength > limit) fail("RESPONSE_TOO_LARGE", `Provider response превышает ${limit} bytes.`);
    return Object.freeze({ rawText, byteLength });
  }

  async function executeJsonOnce({ fetchImpl, request, timeoutMs = 30_000, maxBytes = 1_500_000, now = () => Date.now() }) {
    if (typeof fetchImpl !== "function") fail("FETCH_IMPL_MISSING", "fetchImpl обязателен.");
    if (!request || typeof request !== "object") fail("INVALID_REQUEST", "Trusted request object обязателен.");
    const allowedHosts = new Set(["content-api.wildberries.ru","discounts-prices-api.wildberries.ru","marketplace-api.wildberries.ru","seller-analytics-api.wildberries.ru","statistics-api.wildberries.ru","finance-api.wildberries.ru","documents-api.wildberries.ru","common-api.wildberries.ru","supplies-api.wildberries.ru","advert-api.wildberries.ru","advert-media-api.wildberries.ru","dp-calendar-api.wildberries.ru","feedbacks-api.wildberries.ru","returns-api.wildberries.ru"]);
    let trustedUrl; try { trustedUrl = new URL(String(request.url || "")); } catch (_) { fail("UNTRUSTED_REQUEST_HOST", "Некорректный provider URL."); }
    if (trustedUrl.protocol !== "https:" || !allowedHosts.has(trustedUrl.hostname) || trustedUrl.username || trustedUrl.password || trustedUrl.port) fail("UNTRUSTED_REQUEST_HOST", "Разрешены только fixed official Wildberries API hosts.");
    if (!/^(GET|POST)$/.test(String(request.method || ""))) fail("UNTRUSTED_REQUEST_METHOD", "Разрешены только заранее зафиксированные GET/POST read methods.");

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), Math.max(1, Number(timeoutMs) || 30_000));
    const started = now();
    let response;
    try {
      response = await fetchImpl(request.url, {
        method: request.method,
        headers: request.headers,
        body: request.method === "GET" ? undefined : request.body,
        redirect: "error",
        signal: controller.signal
      });
    } catch (error) {
      clearTimeout(timer);
      if (error?.name === "AbortError" || controller.signal.aborted) fail("REQUEST_TIMEOUT", "Wildberries API request timeout.");
      const wrapped = new Error(String(error?.message || error || "Provider fetch failed"));
      wrapped.code = "PROVIDER_FETCH_FAILED";
      throw wrapped;
    }

    let bounded;
    try { bounded = await readResponseBounded(response, maxBytes, controller.signal); }
    finally { clearTimeout(timer); }
    let parsed = null;
    if (bounded.rawText.trim()) {
      try { parsed = JSON.parse(bounded.rawText); }
      catch (_) { parsed = null; }
    }
    return Object.freeze({
      httpStatus: Number(response.status || 0),
      ok: Boolean(response.ok),
      rawText: bounded.rawText,
      parsed,
      byteLength: bounded.byteLength,
      elapsedMs: Math.max(0, Number(now() - started) || 0),
      responseMeta: safeResponseMeta(response)
    });
  }

  async function readBinaryBounded(response, maxBytes = 8_000_000, signal = null) {
    if (!response) fail("EMPTY_RESPONSE", "Provider response отсутствует.");
    const limit = Number(maxBytes);
    if (!Number.isInteger(limit) || limit < 1) fail("INVALID_MAX_RESPONSE_BYTES", "maxBytes должен быть положительным целым числом.");
    let bytes;
    if (response.body && typeof response.body.getReader === "function") {
      const reader=response.body.getReader(), chunks=[]; let total=0;
      for (;;) { const {done,value}=await abortable(reader.read(),signal,()=>reader.cancel()); if(done) break; const b=value instanceof Uint8Array?value:new Uint8Array(value||[]); total+=b.byteLength; if(total>limit){try{await reader.cancel();}catch(_){} fail("RESPONSE_TOO_LARGE", `Provider response превышает ${limit} bytes.`);} chunks.push(b);}
      bytes=new Uint8Array(total); let off=0; for(const b of chunks){bytes.set(b,off);off+=b.byteLength;}
    } else { const ab=typeof response.arrayBuffer==="function"?await abortable(response.arrayBuffer(),signal):new TextEncoder().encode(String(response.body??"")).buffer; bytes=new Uint8Array(ab); if(bytes.byteLength>limit) fail("RESPONSE_TOO_LARGE", `Provider response превышает ${limit} bytes.`); }
    return Object.freeze({bytes, byteLength:bytes.byteLength});
  }
  async function executeBinaryOnce({ fetchImpl, request, timeoutMs=30_000, maxBytes=8_000_000, now=()=>Date.now() }) {
    if (typeof fetchImpl !== "function") fail("FETCH_IMPL_MISSING", "fetchImpl обязателен.");
    if (!request || typeof request !== "object") fail("INVALID_REQUEST", "Trusted request object обязателен.");
    const allowedHosts = new Set(["content-api.wildberries.ru","discounts-prices-api.wildberries.ru","marketplace-api.wildberries.ru","seller-analytics-api.wildberries.ru","statistics-api.wildberries.ru","finance-api.wildberries.ru","documents-api.wildberries.ru","common-api.wildberries.ru","supplies-api.wildberries.ru","advert-api.wildberries.ru","advert-media-api.wildberries.ru","dp-calendar-api.wildberries.ru","feedbacks-api.wildberries.ru","returns-api.wildberries.ru"]);
    let trustedUrl; try { trustedUrl=new URL(String(request.url||"")); } catch(_){ fail("UNTRUSTED_REQUEST_HOST","Некорректный provider URL."); }
    if(trustedUrl.protocol!=="https:"||!allowedHosts.has(trustedUrl.hostname)||trustedUrl.username||trustedUrl.password||trustedUrl.port) fail("UNTRUSTED_REQUEST_HOST","Разрешены только fixed official Wildberries API hosts.");
    if(!/^(GET|POST)$/.test(String(request.method||""))) fail("UNTRUSTED_REQUEST_METHOD","Разрешены только заранее зафиксированные GET/POST read methods.");
    const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),Math.max(1,Number(timeoutMs)||30_000)); const started=now(); let response;
    try{response=await fetchImpl(request.url,{method:request.method,headers:request.headers,body:request.method==="GET"?undefined:request.body,redirect:"error",signal:controller.signal});}
    catch(error){clearTimeout(timer);if(error?.name==="AbortError"||controller.signal.aborted) fail("REQUEST_TIMEOUT","Wildberries API request timeout."); const e=new Error(String(error?.message||error||"Provider fetch failed"));e.code="PROVIDER_FETCH_FAILED";throw e;}
    let bounded;try{bounded=await readBinaryBounded(response,maxBytes,controller.signal);}finally{clearTimeout(timer);}
    let binaryBase64=""; if (bounded.bytes.byteLength) { let s=""; for(let i=0;i<bounded.bytes.length;i+=0x8000) s+=String.fromCharCode(...bounded.bytes.subarray(i,i+0x8000)); binaryBase64=btoa(s); }
    return Object.freeze({httpStatus:Number(response.status||0),ok:Boolean(response.ok),binaryBase64,byteLength:bounded.byteLength,elapsedMs:Math.max(0,Number(now()-started)||0),responseMeta:safeResponseMeta(response)});
  }

  globalThis.ProviderTransportCore = Object.freeze({ readResponseBounded, readBinaryBounded, executeJsonOnce, executeBinaryOnce });
})();

})(scope); globalThis.SellerAgentsWBReference = Object.freeze({contract: scope.WBContract, credentials: scope.WBCredentials, guidance: scope.WBGuidance, transport: scope.ProviderTransportCore}); })();
(() => {
  "use strict";
  const { contract: C, credentials: Credentials, transport, guidance } = globalThis.SellerAgentsWBReference;
  const fail = (code) => { throw Object.assign(new Error(code), { code, external_request_executed: false }); };
  const codeOf = (error) => /^[A-Z0-9_]{1,100}$/.test(error?.code || "") ? error.code : "WB_BRIDGE_ERROR";
  const known = (operation) => Object.hasOwn(C.OPERATIONS, operation || "") ? operation : null;
  async function hash(value) {
    return [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)))]
      .map((x) => x.toString(16).padStart(2, "0")).join("");
  }
  async function credentialRevision(raw) {
    const value = Credentials.normalizeSellerCredentials(raw, { required: true });
    return hash(JSON.stringify(["seller-agents-wb-personal", value.token]));
  }
  async function createContext({ snapshot, readCurrent, credentials, quotaIdentity = null }) {
    const guard = globalThis.SellerAgentsExecutionContext.createGuard(snapshot, readCurrent);
    const saved = Credentials.normalizeSellerCredentials(structuredClone(credentials), { required: true });
    if (guard.snapshot.marketplace !== "wildberries") fail("MARKETPLACE_CONTEXT_MISMATCH");
    // Store credentialRevision is an opaque local fencing value. The execution
    // guard below compares that value with the current pinned store context;
    // never derive a server-visible revision from the credential secret. The
    // legacy adapter fixture format remains accepted only for old local
    // snapshots that explicitly carry the historical 64-hex revision.
    if (/^[0-9a-f]{64}$/.test(String(guard.snapshot.credentialRevision || "")) &&
        await credentialRevision(saved) !== guard.snapshot.credentialRevision)
      throw globalThis.SellerAgentsExecutionContext.error();
    await guard.assertCurrent();
    const identity = quotaIdentity?.state === "CONFIRMED" &&
      typeof quotaIdentity.providerAccountId === "string" && quotaIdentity.providerAccountId.length
      ? Object.freeze({ kind: "provider_account", value: quotaIdentity.providerAccountId })
      : Object.freeze({ kind: "store_local", value: guard.snapshot.storeId });
    return Object.freeze({ ...guard, quotaIdentity: identity,
      async credentials() { await guard.assertCurrent(); return saved; } });
  }
  function assertPolicy(command, context) {
    const meta = C.resolveOperation(command.operation);
    if (meta.privacy !== "standard" && context.snapshot.policyRevision !== "personal-enabled")
      fail("PERSONAL_DATA_DISABLED");
    C.preflightExecution(command);
    return meta;
  }
  function localError(error, operation = null, attempted = false, httpStatus = 0) {
    const code = codeOf(error);
    return { ok: false, bridge_error: true, external_request_executed: attempted,
      http_status: httpStatus, error: { code, message: code },
      report_text: "WB_RESULT_V1\n" + JSON.stringify({ operation: known(operation),
        provider: "wildberries", external_request_executed: attempted,
        physical_request_count: attempted ? 1 : 0, http_status: httpStatus,
        error: { code, automatic_retry: false }, result_omitted: true }) };
  }
  function parseHelp(text) {
    if (!text.startsWith("WB_HELP_V1")) return guidance.parseHelp(text);
    let raw;
    try { raw = JSON.parse(text.slice("WB_HELP_V1".length)); }
    catch { return { ok: false, code: "HELP_INVALID_JSON" }; }
    if (!raw || !Object.hasOwn(raw, "operation")) return guidance.parseHelp(text);
    try {
      if (Object.keys(raw).some((key) => !["operation", "params"].includes(key)) ||
        !raw.params || typeof raw.params !== "object" || Array.isArray(raw.params)) fail("HELP_UNKNOWN_FIELD");
      const allowed = raw.operation === "catalog" ? ["family", "offset", "limit"] :
        raw.operation === "describe" ? ["alias"] : null;
      if (!allowed || Object.keys(raw.params).some((key) => !allowed.includes(key))) fail("HELP_UNKNOWN_PARAM");
      const p = raw.params;
      if (raw.operation === "describe" && (typeof p.alias !== "string" || !/^[a-z0-9_]{1,120}$/.test(p.alias))) fail("HELP_INVALID_ALIAS");
      if (raw.operation === "catalog") {
        if (p.family !== undefined && !Object.hasOwn(C.HOSTS, p.family)) fail("HELP_UNKNOWN_FAMILY");
        if (!Number.isSafeInteger(p.offset ?? 0) || (p.offset ?? 0) < 0 ||
          !Number.isSafeInteger(p.limit ?? 25) || (p.limit ?? 25) < 1 || (p.limit ?? 25) > 50) fail("HELP_INVALID_PAGE");
      }
      return { ok: true, legacy: raw };
    } catch (error) { return { ok: false, code: codeOf(error) }; }
  }
  function discover(source) {
    const text = String(source || "");
    if (text.length > 262144) fail("COMMAND_SOURCE_TOO_LARGE");
    // Local file/recovery commands belong to application delivery, not the API adapter.
    // Reject them explicitly here; never silently drop them from an accepted block.
    if (/\bWB_FILE_V1\b/.test(text)) fail("LOCAL_FILE_APPLICATION_ROUTE_REQUIRED");
    if (/\bOZON_(?:API|HELP)_V[12]\b/.test(text)) fail("MIXED_MARKETPLACE_BLOCK");
    const rows = globalThis.SellerAgentsMixedBatchDiscovery.discover(text, {
      commandPrefix: "WB_API_V1", helpPrefixV1: "WB_HELP_V1", helpPrefixV2: "WB_HELP_V2",
      apiDiscover(commandText) {
        try {
          const command = C.parseCommand(commandText);
          C.buildRequest(command); // Serialization failures are local per-item results.
          return [{ ok: true, marker_index: 0, command, command_text: commandText }];
        } catch (error) { return [{ ok: false, marker_index: 0, code: codeOf(error) }]; }
      },
      parseHelp,
    });
    if (!rows.length) fail("NO_COMMAND_ENVELOPES");
    if (rows.length > 32) fail("TOO_MANY_COMMANDS");
    return rows.map((row, index) => {
      const item = row.kind === "api" ? row.discovery : row.help;
      if (!item.ok) return { index, kind: "pre_execution_error", status: "pending", error: { code: item.code } };
      if (row.kind === "help") return { index, kind: "guidance", status: "pending", guidance: item };
      return { index, kind: "command", status: "pending", command: item.command,
        operation: item.command.operation, command_text: item.command_text,
        command_fingerprint: C.commandFingerprint(item.command) };
    });
  }
  function localResult(entry) {
    if (entry.kind !== "guidance") return localError(entry.error);
    if (entry.guidance.legacy) {
      const { operation, params } = entry.guidance.legacy;
      const aliases = Object.keys(C.OPERATIONS).sort().filter((alias) => !params.family || C.OPERATIONS[alias].host === params.family);
      const card = (alias) => known(alias) ? { operation: alias, ...C.OPERATIONS[alias],
        authority: "PINNED_WB_REGISTRY_NOT_LIVE_ACCOUNT_PROOF" } : { operation: null, known: false };
      const offset = params.offset ?? 0, limit = params.limit ?? 25;
      const payload = operation === "describe" ? { operation_card: card(params.alias) } :
        { total: aliases.length, offset, limit, operations: aliases.slice(offset, offset + limit).map(card),
          next_offset: offset + limit < aliases.length ? offset + limit : null };
      return { ok: true, external_request_executed: false, http_status: 0,
        report_text: "WB_GUIDANCE_RESULT_V1\n" + JSON.stringify({ ...payload, local: true, physical_request_count: 0 }) };
    }
    const payload = guidance.result({ ...entry.guidance, status: "operations" });
    return { ok: true, external_request_executed: false, http_status: 0,
      report_text: guidance.format(payload) };
  }
  function safeTree(value, depth = 0, budget = { count: 0 }) {
    if (depth > 64) fail("RESPONSE_DEPTH_EXCEEDED");
    if (!value || typeof value !== "object") return;
    for (const [key, child] of Object.entries(value)) {
      if (++budget.count > 300000) fail("RESPONSE_KEY_LIMIT");
      if (["__proto__", "constructor", "prototype"].includes(key)) fail("UNSAFE_RESPONSE_KEY");
      safeTree(child, depth + 1, budget);
    }
  }
  function redactCredentialText(value, secrets) {
    return secrets.reduce((text, secret) => secret ? text.split(secret).join("[REDACTED_CREDENTIAL]") : text, value);
  }
  function redactSecrets(value, secrets, seen = new WeakSet()) {
    if (typeof value === "string") return redactCredentialText(value, secrets);
    if (!value || typeof value !== "object") return value;
    if (seen.has(value)) return undefined;
    seen.add(value);
    if (Array.isArray(value)) return value.map((item) => redactSecrets(item, secrets, seen));
    return Object.fromEntries(Object.entries(value).map(([key, child]) =>
      [redactCredentialText(key, secrets), redactSecrets(child, secrets, seen)]));
  }
  function originalName(response) {
    const header = response?.headers?.get?.("content-disposition") || "";
    const encoded = /filename\*=UTF-8''([^;]+)/i.exec(header);
    const plain = /filename="([^"]+)"|filename=([^;]+)/i.exec(header);
    let name = encoded?.[1] || plain?.[1] || plain?.[2] || "";
    if (encoded) { try { name = decodeURIComponent(name); } catch { return null; } }
    return name && name.length <= 240 && !/[\x00-\x1f\x7f/\\]/.test(name) && !/^\.+$/.test(name)
      ? name : null;
  }
  function preserveJsonNumberProperty(rawText, property) {
    const source = String(rawText);
    let output = "", index = 0;
    const number = /-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/y;
    while (index < source.length) {
      if (source[index] !== '"') { output += source[index++]; continue; }
      const start = index++;
      let escaped = false;
      while (index < source.length) {
        const char = source[index++];
        if (escaped) { escaped = false; continue; }
        if (char === "\\") { escaped = true; continue; }
        if (char === '"') break;
      }
      const token = source.slice(start, index);
      output += token;
      let key;
      try { key = JSON.parse(token); } catch { continue; }
      if (key !== property) continue;
      let cursor = index;
      while (/\s/.test(source[cursor] || "")) cursor++;
      if (source[cursor] !== ":") continue;
      cursor++;
      while (/\s/.test(source[cursor] || "")) cursor++;
      output += source.slice(index, cursor);
      index = cursor;
      number.lastIndex = index;
      const match = number.exec(source);
      if (!match) continue;
      const end = number.lastIndex;
      if (end < source.length && !/[\s,}\]]/.test(source[end])) continue;
      output += JSON.stringify(match[0]);
      index = end;
    }
    return output;
  }
  function createProvider({ fetchImpl = globalThis.fetch, timeoutMs = 30000, maxBytes = 3000000,
    maxBinaryBytes = 12000000, uuid = () => crypto.randomUUID() } = {}) {
    async function execute(commandText, { context, executionCommand = null, onProviderResponse = null, onProviderResult = null } = {}) {
      if (!context?.snapshot || typeof context.credentials !== "function") fail("EXECUTION_CONTEXT_MISSING");
      let attempted = false, httpStatus = 0, command, filename = null;
      try {
        await context.assertCurrent();
        if (context.snapshot.marketplace !== "wildberries") fail("MARKETPLACE_CONTEXT_MISMATCH");
        command = C.parseCommand(commandText);
        if (executionCommand && JSON.stringify(executionCommand) !== JSON.stringify(command))
          fail("WB_COMMAND_TRANSFORMATION_FORBIDDEN");
        const meta = assertPolicy(command, context), saved = await context.credentials();
        const request = C.buildRequest(command, Credentials.sellerHeaders(saved,
          { hasBody: meta.method === "POST" && command.body !== undefined }));
        const guardedFetch = async (url, init) => {
          if (typeof context.assertDispatchAuthority === "function")
            await context.assertDispatchAuthority();
          await context.assertCurrent(); // Last awaited step before actual fetch.
          if (attempted) fail("HIDDEN_PROVIDER_REQUEST_FORBIDDEN");
          attempted = true;
          const response = await fetchImpl(url, { ...init, credentials: "omit" });
          httpStatus = Number(response.status || 0);
          filename = originalName(response);
          // WB documents X-Ratelimit-Retry as the seconds until another
          // attempt is allowed. On 429 it takes precedence over generic
          // Retry-After; X-Ratelimit-Reset is a different deadline.
          if (httpStatus !== 429) return response;
          const retry = response.headers?.get?.("x-ratelimit-retry");
          if (retry == null || !/^\d+(?:\.\d+)?$/.test(String(retry).trim())) return response;
          const headers = new Proxy(response.headers, { get(target, property) {
            if (property === "get") return (name) => String(name).toLowerCase() === "retry-after"
              ? String(retry).trim() : target.get(name);
            const value = Reflect.get(target, property, target);
            return typeof value === "function" ? value.bind(target) : value;
          } });
          return new Proxy(response, { get(target, property) {
            if (property === "headers") return headers;
            const value = Reflect.get(target, property, target);
            return typeof value === "function" ? value.bind(target) : value;
          } });
        };
        const binary = request.response_mode === "binary";
        const response = await (binary ? transport.executeBinaryOnce : transport.executeJsonOnce)({
          fetchImpl: guardedFetch, request, timeoutMs, maxBytes: binary ? maxBinaryBytes : maxBytes });
        if (typeof onProviderResponse === "function")
          await onProviderResponse({ command, request, response });
        await context.assertCurrent();
        let result;
        if (!response.ok) result = { error: { code: "WB_API_ERROR", http_status: response.httpStatus, automatic_retry: false } };
        else if (binary) result = { content_base64: response.binaryBase64, byte_length: response.byteLength,
          content_type: response.responseMeta?.content_type || "application/octet-stream",
          original_filename: filename, delivery_status: "BYTES_RECEIVED_NOT_DELIVERED" };
        else {
          const declaredJson = /(?:^|[+/])json(?:;|$)/i.test(response.responseMeta?.content_type || "");
          const paidStorage = command.operation === "paid_storage_download";
          const nonEmptyBody = response.rawText.trim() !== "";
          if ((paidStorage && nonEmptyBody) ||
              (declaredJson && !(response.rawText.trim() === "" && [204, 205].includes(response.httpStatus)))) {
            const jsonText = paidStorage
              ? preserveJsonNumberProperty(response.rawText, "warehousePrice")
              : response.rawText;
            try { result = JSON.parse(jsonText); } catch { fail("PROVIDER_JSON_INVALID"); }
          } else result = response.parsed ?? response.rawText;
          safeTree(result);
          result = redactSecrets(C.sanitizeResult(command, result), [saved.token]);
        }
        const requestId = String(uuid());
        let report = C.formatResultReport({ requestId, command, httpStatus: response.httpStatus,
          requestMeta: { host_alias: request.host_alias, http_method: request.method, path_alias: command.operation },
          result, elapsedMs: response.elapsedMs, rateLimit: { retry_after: response.responseMeta?.retry_after || null } });
        // Never allow an echoed exact credential into a JSON/text result or diagnostics.
        if (!binary) report = report.split(saved.token).join("[REDACTED_CREDENTIAL]");
        const providerResult = { ok: response.ok, request_id: requestId, http_status: response.httpStatus,
          external_request_executed: true, report_text: report,
          result,
          executed_command_fingerprint: C.commandFingerprint(command),
          response_meta: { retry_after: response.responseMeta?.retry_after || null },
          verification: binary ? "BINARY_BYTES_CAPTURED" : "STRUCTURAL_ONLY_WB_SCHEMA_PENDING" };
        if (typeof onProviderResult === "function") await onProviderResult({ command, result, report_text: report, provider_result: providerResult });
        return providerResult;
      } catch (error) {
        if (error.execution_context_error) throw error;
        // The frozen transport normalizes fetch exceptions; recheck the guard so
        // cancellation cannot be downgraded to an ordinary provider error.
        await context.assertCurrent();
        return localError(error, command?.operation, attempted, httpStatus);
      }
    }
    return Object.freeze({ execute });
  }
  globalThis.SellerAgentsWBAdapter = Object.freeze({ hash, credentialRevision, createContext,
    discover, localResult, localError, assertPolicy, createProvider,
    operation: (command) => C.resolveOperation(command.operation) });
})();

;
(() => {
  "use strict";
  const A = globalThis.SellerAgentsWBAdapter;
  const changed = () => { throw globalThis.SellerAgentsExecutionContext.error(); };
  const forbiddenPlan = () => {
    throw Object.assign(new Error("WB cache/coalescing/prefetch policy is not enabled"), { code: "WB_UNREVIEWED_PLAN" });
  };
  function create({ records, quota, finalize, diagnostic, workerId, provider = A.createProvider() }) {
    if (!records?.get || !records?.mutate || !quota?.prepare || !quota?.observe ||
      typeof finalize !== "function" || typeof diagnostic !== "function" || !workerId)
      throw new TypeError("WB application record, quota, finalization and diagnostic ports are required");
    const flights = new Map();
    async function admit({ source, context }) {
      await context.assertCurrent();
      const { snapshot } = context;
      if (snapshot.marketplace !== "wildberries" || await A.hash(String(source)) !== snapshot.commandHash) changed();
      let entries;
      try { entries = A.discover(source); }
      catch (error) { entries = [{ kind: "pre_execution_error", status: "pending", error: { code: error.code } }]; }
      return records.mutate(snapshot.conversationKey, async (old) => {
        await context.assertCurrent();
        if (old?.operation_id === snapshot.requestId) {
          if (old.execution_context?.commandHash !== snapshot.commandHash) changed();
          return old; // Completed, dispatched and unknown requests are never readmitted.
        }
        if (old?.status === "collecting") throw Object.assign(new Error("Another batch owns this dialogue"), { code: "BATCH_BUSY" });
        return { operation_id: snapshot.requestId, conversation_key: snapshot.conversationKey,
          execution_context: snapshot, status: "collecting", batch: { entries,
            next_index: 0, request_state: "idle", request_worker_session_id: null } };
      });
    }
    async function process({ context }) {
      const { snapshot } = context, key = snapshot.conversationKey;
      if (snapshot.marketplace !== "wildberries") changed();
      const ownerMatches = (owner) => owner?.operation_id === snapshot.requestId &&
        globalThis.SellerAgentsExecutionContext.fields.every((field) => owner.execution_context?.[field] === snapshot[field]);
      const isCollecting = (owner) => owner?.status === "collecting";
      const options = {
        conversationKey: key, ownerKind: "wildberries", ownerId: snapshot.requestId,
        getOwner: () => records.get(key), mutateOwner: (fn) => records.mutate(key, fn), ownerMatches, isCollecting,
        failOwner: (code) => records.mutate(key, (owner) => ownerMatches(owner) ?
          { ...owner, status: "failed", last_error: { code } } : owner),
        async finalizeOwner(owner, entries) {
          await context.assertCurrent();
          const saved = await records.mutate(key, async (current) => {
            await context.assertCurrent();
            return ownerMatches(current) && isCollecting(current) ? { ...current, status: "ready" } : current;
          });
          if (!ownerMatches(saved) || saved.status !== "ready") changed();
          await context.assertCurrent();
          // Application delivery consumes the existing local reports, without refetching.
          return finalize(saved, entries, context);
        },
      };
      const ports = createPorts(context, { quota, diagnostic, workerId, provider, flights });
      return globalThis.SellerAgentsGuardedBatchQueue.run(options, { context, ports });
    }
    return Object.freeze({ admit, process });
  }
  function createPorts(context, { quota, diagnostic, workerId, provider = A.createProvider(), flights = new Map() }) {
    const { snapshot } = context;
  const scopes = async (command) => {
    const identity = context.quotaIdentity || { kind: "store_local", value: snapshot.storeId };
    const operation = A.operation(command);
    const group = operation.category === "marketplace" ? "category:marketplace" : `method:${command.operation}`;
    const identities = identity.kind === "provider_account"
      ? [identity, { kind: "store_local", value: snapshot.storeId }]
      : [identity];
    return Promise.all(identities.map((item) =>
      A.hash(JSON.stringify(["wildberries", item.kind, item.value, group]))));
  };
      const ports = {
        normalizeKey: (key) => key, workerId, flights,
        singleFlight: globalThis.SellerAgentsLocalOperations.singleFlight,
        async preparePolicy(o) {
          await o.mutateOwner((owner) => {
            if (!o.ownerMatches(owner) || !o.isCollecting(owner)) return owner;
            const entries = owner.batch.entries.map((entry) => {
              if (entry.kind !== "command" || entry.status !== "pending") return entry;
              try { A.assertPolicy(entry.command, context); return entry; }
              catch (error) { return { ...entry, kind: "pre_execution_error", error: { code: error.code } }; }
            });
            return { ...owner, batch: { ...owner.batch, entries } };
          });
          return { ok: true };
        },
        async prepareCapability() { return { ok: true, source: "PINNED_REGISTRY_ONLY_NO_ACCOUNT_PROBE" }; },
        async prepareQueries(o) {
          const owner = await o.getOwner();
          if (owner.batch.entries.some((entry) => entry.query_group_id || entry.execution_command || entry.planning)) forbiddenPlan();
          return { ok: true, source: "EXPLICIT_COMMANDS_ONLY" };
        },
        diagnostic,
        // WB keeps its accepted last-moment C3G fence inside guardedFetch.
        // The queue still commits intent before entering this provider boundary.
        beforeProviderDispatch: async () => {},
        guidanceResult: A.localResult,
        policyErrorResult: () => A.localError({ code: "PERSONAL_DATA_DISABLED" }),
        planningErrorResult: forbiddenPlan, findGroup: forbiddenPlan, projectGroup: forbiddenPlan,
        groupError: forbiddenPlan, groupPlanning: forbiddenPlan, cachedResult: forbiddenPlan,
        async readCache() { return { hit: false, reason: "WB_CACHE_POLICY_NOT_ENABLED" }; },
        storeCache: forbiddenPlan, projectSingle: forbiddenPlan,
        reviewedAcquisitionProfile: () => null, acquisitionPlanning: () => null,
        coalescedOperation: null, providerId: "wildberries", bridgeErrorCode: "WB_BRIDGE_ERROR",
        executionError: (command, fingerprint, error) => A.localError(error, command?.operation, error?.external_request_executed === true),
        prepareQuota: async (command) => {
          const decisions = await Promise.all((await scopes(command)).map((scope) => quota.prepare(scope)));
          return decisions.reduce((selected, current) =>
            Number(current?.quota?.next_allowed_at || 0) > Number(selected?.quota?.next_allowed_at || 0)
              ? current : selected);
        },
        quotaMetadata: (value) => value,
        async persistQuotaWait(o) {
          await o.mutateOwner((owner) => o.ownerMatches(owner) && o.isCollecting(owner) ?
            { ...owner, batch: { ...owner.batch, request_state: "quota_waiting", quota_wait: o.quota } } : owner);
        },
        async execute(text, { executionCommand, onProviderResponse, onProviderResult }) {
          const result = await provider.execute(text, { context, executionCommand, onProviderResponse, onProviderResult });
          await context.assertCurrent();
          try {
            for (const scope of await scopes(executionCommand))
              await quota.observe(scope, result.response_meta?.retry_after);
          }
          catch (error) {
            // Commit the received result first; then stop before any further dispatch.
            result.stop_after_result = "QUOTA_OBSERVATION_FAILED_NO_RETRY";
          }
          return result;
        },
      };
    return ports;
  }
  globalThis.SellerAgentsWBBatch = Object.freeze({ create, createPorts });
})();
