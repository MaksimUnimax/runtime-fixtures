(() => {
  "use strict";
  // Privileged local catalog. The account port is supplied by the application;
  // this module neither authenticates a user nor invents a server account.
  function create({
    read,
    write,
    currentAccount,
    assertTransferContext,
    assertBackupContext,
    normalizeCredentials,
    revision,
    uuid,
  }) {
    const lock = globalThis.SellerAgentsLocalOperations.createWriteQueue();
    const key = "seller_agents_stores_v1";
    const fail = (code) => {
      throw Object.assign(new Error(code), { code });
    };
    const canonicalJson = (value) => {
      if (Array.isArray(value))
        return `[${value.map(canonicalJson).join(",")}]`;
      if (value && typeof value === "object")
        return `{${Object.keys(value)
          .sort()
          .map(
            (name) => `${JSON.stringify(name)}:${canonicalJson(value[name])}`,
          )
          .join(",")}}`;
      return JSON.stringify(value);
    };
    function backupCredentials(incoming) {
      // Match the representation produced when a store is saved/imported.
      // Backup payloads deliberately omit derived credential presence fields.
      const input = incoming.credentials.type === "ozon"
        ? { seller: incoming.credentials.seller, performance: incoming.credentials.performance || {} }
        : { token: incoming.credentials.token };
      return normalizeCredentials(incoming.marketplace, input, {});
    }
    async function account() {
      const id = await currentAccount();
      if (!id || typeof id !== "string") fail("AUTH_REQUIRED");
      return id;
    }
    async function state() {
      const id = await account(),
        data = await read(key);
      if (id !== (await account())) fail("ACCOUNT_CHANGED");
      return { id, all: data[key] || { version: 1, accounts: {} } };
    }
    function publicStore(store) {
      const c = store.credentials || {};
      return {
        id: store.id,
        accountId: store.accountId,
        name: store.name,
        marketplace: store.marketplace,
        credentialRevision: store.credentialRevision,
        metadataRevision: store.metadataRevision || 0,
        lifecycleState: store.lifecycleState || "ACTIVE",
        providerAccountId: store.providerAccountId || null,
        providerIdentityState: store.providerIdentityState || "UNCONFIRMED",
        credentialsStale: store.credentialsStale === true,
        personalDataEnabled: store.personalDataEnabled,
        sellerPresent: Boolean(c.seller?.clientId && c.seller?.apiKey),
        performancePresent: Boolean(
          c.performance?.clientId && c.performance?.clientSecret,
        ),
        tokenPresent: Boolean(c.token),
        sellerClientId: c.seller?.clientId || "",
        performanceClientId: c.performance?.clientId || "",
        verification: store.verification || {},
      };
    }
    async function list() {
      const { id, all } = await state();
      return Object.values(all.accounts[id]?.stores || {})
        .filter(store => (store.lifecycleState || "ACTIVE") !== "TOMBSTONED")
        .map(publicStore);
    }
    async function get(storeId) {
      const { id, all } = await state();
      const store = all.accounts[id]?.stores?.[storeId];
      if (!store || store.accountId !== id || store.lifecycleState === "TOMBSTONED") fail("STORE_NOT_FOUND");
      return structuredClone(store);
    }
    function plainBackupContext(value) {
      if (!value || typeof value !== "object" || Array.isArray(value)) return false;
      try {
        // The caller creates this context inside the same service-worker realm.
        // Prototype equality alone can be spoofed by a Proxy. The native
        // structured clone rejects Proxies and other non-cloneable contexts.
        const prototype = Object.getPrototypeOf(value);
        if (prototype !== null && prototype !== Object.prototype) return false;
        const copied = structuredClone(value);
        return copied !== null && typeof copied === "object" && !Array.isArray(copied);
      } catch (_) { return false; }
    }
    async function mutate(fn, transferContext = null, backupContext = null, backupContextSupplied = false) {
      function assertCurrent() {
        if (transferContext) assertTransferContext?.(transferContext);
        if (backupContextSupplied) {
          // An explicit null/undefined is not the legacy two-argument call.
          if (!plainBackupContext(backupContext)) fail("BACKUP_CONTEXT_GUARD_INVALID");
          if (typeof assertBackupContext !== "function") fail("BACKUP_CONTEXT_GUARD_REQUIRED");
          if (assertBackupContext(backupContext) !== true) fail("BACKUP_CONTEXT_GUARD_INVALID");
        }
      }
      return lock.run(async () => {
        assertCurrent();
        const { id, all } = await state();
        if (transferContext && transferContext.accountId !== id) fail("ACCOUNT_CHANGED");
        const scope = structuredClone(
          all.accounts[id] || { stores: {}, next: { ozon: 1, wildberries: 1 } },
        );
        const result = await fn(scope, id);
        if (id !== (await account())) fail("ACCOUNT_CHANGED");
        const next = { ...all, accounts: { ...all.accounts, [id]: scope } };
        // Synchronous fence immediately before the storage call: no later
        // account/generation can be selected by this queued import.
        assertCurrent();
        await write({ [key]: next });
        const saved = (await read(key))[key];
        if (canonicalJson(saved) !== canonicalJson(next))
          fail("STORE_WRITE_NOT_CONFIRMED");
        if (id !== (await account())) fail("ACCOUNT_CHANGED");
        assertCurrent();
        return result;
      });
    }
    async function save(input) {
      if (!input || typeof input !== "object" || Array.isArray(input))
        fail("INVALID_STORE");
      return mutate(async (scope, id) => {
        const previous =
          input.id && Object.hasOwn(scope.stores, input.id)
            ? scope.stores[input.id]
            : null;
        if (input.id && !previous) fail("STORE_NOT_FOUND");
        if (previous?.lifecycleState === "TOMBSTONED") fail("STORE_TOMBSTONED");
        if (input.providerAccountId && input.providerAccountId !== previous?.providerAccountId) fail("PROVIDER_IDENTITY_CONFIRMATION_REQUIRED");
        const marketplace = previous?.marketplace || input.marketplace;
        if (
          !["ozon", "wildberries"].includes(marketplace) ||
          (input.marketplace && input.marketplace !== marketplace)
        )
          fail("INVALID_MARKETPLACE");
        const credentials = normalizeCredentials(
          marketplace,
          input.credentials || {},
          previous?.credentials,
        );
        const credentialsUnchanged = Boolean(
          previous && canonicalJson(previous.credentials || {}) === canonicalJson(credentials),
        );
        // A credential revision is an opaque fencing value. It is deliberately
        // not a digest or fingerprint of secret material.
        const credentialRevision = credentialsUnchanged
          ? previous.credentialRevision
          : await revision(marketplace, credentials);
        const serial = scope.next[marketplace] || 1;
        const name =
          String(input.name ?? previous?.name ?? "").trim() ||
          `${marketplace === "ozon" ? "Ozon" : "WB"} ${serial}`;
        if (name.length > 80 || /[\u0000-\u001f\u007f]/.test(name))
          fail("INVALID_STORE_NAME");
        const store = {
          id: previous?.id || `store-${uuid()}`,
          accountId: id,
          marketplace,
          name,
          credentials,
          credentialRevision,
          metadataRevision: (previous?.metadataRevision || 0) + 1,
          lifecycleState: "ACTIVE",
          providerAccountId: previous?.providerAccountId || null,
          providerIdentityState: previous?.providerIdentityState || "UNCONFIRMED",
          credentialsStale: false,
          personalDataEnabled:
            input.personalDataEnabled === undefined
              ? previous?.personalDataEnabled === true
              : input.personalDataEnabled === true,
          verification:
            previous?.credentialRevision === credentialRevision
              ? previous.verification
              : {},
          createdAt: previous?.createdAt || Date.now(),
        };
        scope.stores[store.id] = store;
        if (!previous) scope.next[marketplace] = serial + 1;
        return publicStore(store);
      });
    }
    async function importCredential(input, transferContext = null) {
      assertTransferContext?.(transferContext);
      if (!input || typeof input !== "object" || typeof input.id !== "string" || typeof input.credentialRevision !== "string") fail("TRANSFER_CONFLICT");
      return mutate(async (scope, id) => {
        const previous = scope.stores[input.id];
        if (previous?.lifecycleState === "TOMBSTONED" || previous && previous.marketplace !== input.marketplace) fail("TRANSFER_CONFLICT");
        if (previous?.providerIdentityState === "CONFIRMED" && input.providerIdentityState === "CONFIRMED" && previous.providerAccountId !== input.providerAccountId) fail("TRANSFER_CONFLICT");
        if (previous?.credentialRevision === input.credentialRevision && previous.credentialsStale !== true) return { kind: "SAME_CURRENT", store: publicStore(previous) };
        if (previous?.credentialRevision === input.credentialRevision && previous.credentialsStale === true) {
          previous.credentials = normalizeCredentials(input.marketplace, input.credentials, {});
          previous.credentialsStale = false;
          previous.verification = {};
          return { kind: "IMPORTED", store: publicStore(previous) };
        }
        if (previous?.credentialRevision) return { kind: "CONFLICT", store: publicStore(previous) };
        const credentials = normalizeCredentials(input.marketplace, input.credentials, {});
        const store = { id: input.id, accountId: id, marketplace: input.marketplace, name: String(input.name || input.id).slice(0, 80), credentials, credentialRevision: input.credentialRevision, metadataRevision: Number(input.metadataRevision || 0), lifecycleState: "ACTIVE", providerAccountId: input.providerIdentityState === "CONFIRMED" ? input.providerAccountId || null : null, providerIdentityState: input.providerIdentityState === "CONFIRMED" ? "CONFIRMED" : "UNCONFIRMED", credentialsStale: false, personalDataEnabled: false, verification: {}, createdAt: Date.now() };
        scope.stores[store.id] = store;
        return { kind: "IMPORTED", store: publicStore(store) };
      }, transferContext);
    }
    async function backupSnapshot() {
      const { id, all } = await state();
      return Object.values(all.accounts[id]?.stores || {})
        .filter((store) => (store.lifecycleState || "ACTIVE") === "ACTIVE")
        .map((store) => structuredClone(store));
    }
    async function planBackupImport(payload) {
      if (!payload?.accountBinding?.accountId) fail("BACKUP_ACCOUNT_MISMATCH");
      const { id, all } = await state();
      if (payload.accountBinding.accountId !== id) fail("BACKUP_ACCOUNT_MISMATCH");
      const current = all.accounts[id]?.stores || {};
      const classifications = payload.stores.map((incoming) => {
        const previous = current[incoming.storeId];
        if (!previous) return { storeId: incoming.storeId, kind: "IMPORT_NEW" };
        if (previous.lifecycleState === "TOMBSTONED") return { storeId: incoming.storeId, kind: "LOCAL_TOMBSTONED" };
        if (previous.marketplace !== incoming.marketplace) return { storeId: incoming.storeId, kind: "MARKETPLACE_MISMATCH" };
        if (previous.providerIdentityState === "CONFIRMED" && incoming.providerIdentityState === "CONFIRMED" && previous.providerAccountId !== incoming.providerAccountId) return { storeId: incoming.storeId, kind: "PROVIDER_ACCOUNT_MISMATCH" };
        const localCredentials = previous.credentials || {};
        const incomingCredentials = backupCredentials(incoming);
        if (previous.credentialRevision === incoming.credentialRevision && canonicalJson(localCredentials) === canonicalJson(incomingCredentials)) return { storeId: incoming.storeId, kind: "SAME_CURRENT" };
        return { storeId: incoming.storeId, kind: "LOCAL_NEWER" };
      });
      return { accountId: id, classifications, safeStoreIds: classifications.filter((row) => row.kind === "IMPORT_NEW").map((row) => row.storeId) };
    }
    async function applyBackupImport(payload, expectedPlan, backupContext) {
      const backupContextSupplied = arguments.length >= 3;
      return mutate(async (scope, id) => {
        if (payload?.accountBinding?.accountId !== id || expectedPlan?.accountId !== id) fail("ACCOUNT_CHANGED");
        const current = scope.stores || {};
        const actual = payload.stores.map((incoming) => {
          const previous = current[incoming.storeId];
          if (!previous) return { storeId: incoming.storeId, kind: "IMPORT_NEW" };
          if (previous.lifecycleState === "TOMBSTONED") return { storeId: incoming.storeId, kind: "LOCAL_TOMBSTONED" };
          if (previous.marketplace !== incoming.marketplace) return { storeId: incoming.storeId, kind: "MARKETPLACE_MISMATCH" };
          if (previous.providerIdentityState === "CONFIRMED" && incoming.providerIdentityState === "CONFIRMED" && previous.providerAccountId !== incoming.providerAccountId) return { storeId: incoming.storeId, kind: "PROVIDER_ACCOUNT_MISMATCH" };
          const localCredentials = previous.credentials || {};
          const incomingCredentials = backupCredentials(incoming);
          if (previous.credentialRevision === incoming.credentialRevision && canonicalJson(localCredentials) === canonicalJson(incomingCredentials)) return { storeId: incoming.storeId, kind: "SAME_CURRENT" };
          return { storeId: incoming.storeId, kind: "LOCAL_NEWER" };
        });
        if (canonicalJson(actual) !== canonicalJson(expectedPlan.classifications || [])) fail("IMPORT_PLAN_STALE");
        const safe = new Set((expectedPlan.safeStoreIds || []).filter((storeId) => actual.find((row) => row.storeId === storeId)?.kind === "IMPORT_NEW"));
        const imported = [];
        for (const incoming of payload.stores) {
          if (!safe.has(incoming.storeId)) continue;
          const credentials = backupCredentials(incoming);
          const store = {
            id: incoming.storeId, accountId: id, marketplace: incoming.marketplace, name: incoming.label,
            credentials, credentialRevision: incoming.credentialRevision, metadataRevision: incoming.metadataRevision,
            lifecycleState: "ACTIVE", providerAccountId: incoming.providerIdentityState === "CONFIRMED" ? incoming.providerAccountId : null,
            providerIdentityState: incoming.providerIdentityState, credentialsStale: false, personalDataEnabled: false,
            verification: {}, createdAt: Date.now(),
          };
          scope.stores[store.id] = store;
          imported.push(publicStore(store));
        }
        return { imported, classifications: actual };
      }, null, backupContext, backupContextSupplied);
    }
    async function remove(id) {
      return mutate((scope) => {
        if (!scope.stores[id]) fail("STORE_NOT_FOUND");
        const store = scope.stores[id];
        if (!store) fail("STORE_NOT_FOUND");
        store.lifecycleState = "TOMBSTONED";
        store.credentials = {};
        store.credentialsStale = true;
        store.verification = {};
        store.metadataRevision = (store.metadataRevision || 0) + 1;
        return { deleted: true, store: publicStore(store) };
      });
    }
    async function noteVerification(id, expectedRevision, part, result) {
      return mutate((scope) => {
        const store = scope.stores[id];
        if (!store || store.lifecycleState === "TOMBSTONED" || store.credentialRevision !== expectedRevision)
          fail("STORE_CHANGED");
        store.verification = {
          ...store.verification,
          [part]: {
            code: result.code,
            httpStatus: Number(result.httpStatus || 0),
            checkedAt: Date.now(),
          },
        };
        return publicStore(store);
      });
    }
    async function confirmProviderIdentity(id, expectedRevision, providerAccountId) {
      if (typeof providerAccountId !== "string" || !/^[A-Za-z0-9._:-]{1,128}$/.test(providerAccountId)) fail("PROVIDER_IDENTITY_UNCONFIRMED");
      return mutate(scope => {
        const store = scope.stores[id];
        if (!store || store.lifecycleState === "TOMBSTONED" || store.credentialRevision !== expectedRevision) fail("STORE_CHANGED");
        if (store.providerIdentityState === "CONFIRMED" && store.providerAccountId !== providerAccountId) fail("STORE_PROVIDER_IDENTITY_MISMATCH");
        store.providerAccountId = providerAccountId;
        store.providerIdentityState = "CONFIRMED";
        store.metadataRevision = (store.metadataRevision || 0) + 1;
        return publicStore(store);
      });
    }
    async function metadataForSync(id) {
      const store = await get(id);
      return {
        kind: "STORE_UPSERT",
        storeId: store.id,
        marketplace: store.marketplace,
        name: store.name,
        providerAccountId: store.providerIdentityState === "CONFIRMED" ? store.providerAccountId : null,
        providerIdentityState: store.providerIdentityState,
        credentialRevision: store.credentialRevision,
        metadataRevision: store.metadataRevision || 0,
        lifecycleState: "ACTIVE",
      };
    }
    async function applyRemoteMetadata(input) {
      if (!input || !input.storeId || !["STORE_UPSERT", "STORE_TOMBSTONE"].includes(input.kind)) fail("INVALID_STORE_METADATA");
      return mutate((scope, accountId) => {
        const previous = scope.stores[input.storeId];
        if (previous && previous.accountId !== accountId) fail("STORE_NOT_FOUND");
        const incomingRevision = Number.isSafeInteger(Number(input.metadataRevision)) && Number(input.metadataRevision) >= 0 ? Number(input.metadataRevision) : 0;
        if (previous?.lifecycleState === "TOMBSTONED") {
          if (input.kind === "STORE_TOMBSTONE" && incomingRevision > (previous.metadataRevision || 0)) previous.metadataRevision = incomingRevision;
          return publicStore(previous);
        }
        if (previous && incomingRevision < (previous.metadataRevision || 0)) return publicStore(previous);
        if (previous?.providerIdentityState === "CONFIRMED" && input.providerIdentityState === "CONFIRMED" && previous.providerAccountId !== input.providerAccountId) fail("STORE_PROVIDER_IDENTITY_MISMATCH");
        const store = previous || {
          id: input.storeId,
          accountId,
          marketplace: input.marketplace,
          credentials: {},
          personalDataEnabled: false,
          verification: {},
          createdAt: Date.now(),
        };
        const previousCredentialRevision = previous?.credentialRevision || null;
        store.name = String(input.name || "").trim();
        store.marketplace = input.marketplace;
        store.providerIdentityState = previous?.providerIdentityState === "CONFIRMED" ? "CONFIRMED" : input.providerIdentityState === "CONFIRMED" ? "CONFIRMED" : "UNCONFIRMED";
        store.providerAccountId = store.providerIdentityState === "CONFIRMED" ? (previous?.providerAccountId || input.providerAccountId || null) : null;
        store.credentialRevision = input.credentialRevision || previous?.credentialRevision || null;
        store.metadataRevision = incomingRevision;
        store.lifecycleState = input.kind === "STORE_TOMBSTONE" ? "TOMBSTONED" : "ACTIVE";
        store.credentials = input.kind === "STORE_TOMBSTONE" ? {} : (previous?.credentials || {});
        store.credentialsStale = input.kind === "STORE_TOMBSTONE" || !Object.keys(store.credentials || {}).length || Boolean(previous?.credentials && previousCredentialRevision !== store.credentialRevision);
        if (store.lifecycleState === "TOMBSTONED") store.verification = {};
        scope.stores[store.id] = store;
        return publicStore(store);
      });
    }
    return Object.freeze({ key, list, get, save, importCredential, backupSnapshot, planBackupImport, applyBackupImport, remove, noteVerification, confirmProviderIdentity, metadataForSync, applyRemoteMetadata });
  }
  globalThis.SellerAgentsStoreCatalog = Object.freeze({ create });
})();

;
(() => {
  "use strict";

  const CLASSES = Object.freeze({
    IN_SYNC: "IN_SYNC",
    SERVER_AHEAD_COMPATIBLE: "SERVER_AHEAD_COMPATIBLE",
    LOCAL_PENDING: "LOCAL_PENDING",
    SAME_BINDING_MERGEABLE: "SAME_BINDING_MERGEABLE",
    EXPLICIT_BINDING_CONFLICT: "EXPLICIT_BINDING_CONFLICT",
    LOCAL_FINISH_SUPERSEDED_BY_NEWER_EXPLICIT_BINDING: "LOCAL_FINISH_SUPERSEDED_BY_NEWER_EXPLICIT_BINDING",
    SERVER_FINISH_WINS_OVER_LATE_DELIVERY: "SERVER_FINISH_WINS_OVER_LATE_DELIVERY",
    STALE_DELIVERY_OBSOLETE: "STALE_DELIVERY_OBSOLETE",
    REQUIRES_EXPLICIT_USER_REBIND_RESOLUTION: "REQUIRES_EXPLICIT_USER_REBIND_RESOLUTION",
    UNKNOWN_REMOTE_INSTALLATION_STATE: "UNKNOWN_REMOTE_INSTALLATION_STATE",
  });
  const PREFERRED_STATES = Object.freeze({
    UNSET: "UNSET",
    VALID_CURRENT: "VALID_CURRENT",
    REPLACEMENT_REQUIRED: "REPLACEMENT_REQUIRED",
  });
  const PROVENANCE = Object.freeze({
    AI_ORDERED: "AI_ORDERED",
    CLIENT_APPROXIMATE: "CLIENT_APPROXIMATE",
    SERVER_RECEIVE_FALLBACK: "SERVER_RECEIVE_FALLBACK",
  });
  const EXPLICIT_KINDS = new Set(["BINDING_UPSERT", "FINISH"]);

  const string = (value, max = 320) => typeof value === "string" && value.length > 0 && value.length <= max ? value : null;
  const number = value => value === null || value === undefined || value === "" ? null : Number.isFinite(Number(value)) ? Number(value) : null;
  const integer = value => value === null || value === undefined || value === "" ? null : Number.isSafeInteger(Number(value)) && Number(value) >= 0 ? Number(value) : null;
  const compareText = (left, right) => String(left || "").localeCompare(String(right || ""), "en", { numeric: true });
  const compareNumber = (left, right) => (left === right ? 0 : left < right ? -1 : 1);

  function contextOf(value = {}) {
    return {
      accountId: string(value.accountId),
      entityId: string(value.entityId || value.conversationKeyDigest),
      conversationKeyDigest: string(value.conversationKeyDigest || value.entityId, 64),
      bindingId: string(value.bindingId),
      bindingRevision: integer(value.bindingRevision),
      storeId: string(value.storeId),
      marketplace: string(value.marketplace, 32),
      workGeneration: string(value.workGeneration, 160),
      bindingState: string(value.bindingState, 32) || (value.kind === "FINISH" ? "FINISHED" : "BOUND"),
    };
  }

  function effectiveIdentity(value = {}) {
    const c = contextOf(value);
    return [c.accountId, c.entityId || c.conversationKeyDigest, c.bindingId, c.bindingRevision, c.storeId, c.marketplace, c.workGeneration, c.bindingState].join("|");
  }

  function sameBinding(left, right, { includeState = true } = {}) {
    const a = contextOf(left), b = contextOf(right);
    const fields = ["accountId", "entityId", "conversationKeyDigest", "bindingId", "bindingRevision", "storeId", "marketplace", "workGeneration"];
    if (includeState) fields.push("bindingState");
    return fields.every(field => a[field] === b[field]);
  }

  function deliveryEligibility(marker, current, { accountId = null, entityId = null } = {}) {
    if (!marker || !current) return { eligible: false, reason: "MISSING_CONTEXT" };
    const expected = contextOf({ ...current, accountId: accountId || current.accountId, entityId: entityId || current.entityId });
    const actual = contextOf({ ...marker, accountId: accountId || marker.accountId, entityId: entityId || marker.entityId });
    for (const field of ["accountId", "entityId", "conversationKeyDigest", "bindingId", "bindingRevision", "storeId", "marketplace", "workGeneration"]) {
      if (expected[field] !== actual[field]) return { eligible: false, reason: `MISMATCH_${field.toUpperCase()}` };
    }
    if (expected.bindingState === "FINISHED") return { eligible: false, reason: "FINISHED_BINDING" };
    if (actual.bindingState === "FINISHED") return { eligible: false, reason: "FINISHED_MARKER" };
    return { eligible: true, reason: null };
  }

  function markerProvenance(marker = {}) {
    if (marker.orderProvenance === PROVENANCE.AI_ORDERED && string(marker.aiOrderId, 240)) return PROVENANCE.AI_ORDERED;
    if (string(marker.aiOrderId, 240)) return PROVENANCE.AI_ORDERED;
    if (number(marker.clientDeliveredAtMs) !== null || integer(marker.clientSequence) !== null) return PROVENANCE.CLIENT_APPROXIMATE;
    return PROVENANCE.SERVER_RECEIVE_FALLBACK;
  }

  function compareDeliveryMarkers(left, right) {
    const a = { ...left, orderProvenance: markerProvenance(left) };
    const b = { ...right, orderProvenance: markerProvenance(right) };
    if (a.orderProvenance === PROVENANCE.AI_ORDERED && b.orderProvenance !== PROVENANCE.AI_ORDERED) return 1;
    if (b.orderProvenance === PROVENANCE.AI_ORDERED && a.orderProvenance !== PROVENANCE.AI_ORDERED) return -1;
    if (a.orderProvenance === PROVENANCE.AI_ORDERED && b.orderProvenance === PROVENANCE.AI_ORDERED) {
      const order = compareText(a.aiOrderId, b.aiOrderId);
      if (order) return order;
    } else {
      const aTime = number(a.clientDeliveredAtMs), bTime = number(b.clientDeliveredAtMs);
      if (aTime !== null || bTime !== null) {
        const order = compareNumber(aTime ?? Number.NEGATIVE_INFINITY, bTime ?? Number.NEGATIVE_INFINITY);
        if (order) return order;
      }
      const sequence = compareNumber(integer(a.clientSequence) ?? -1, integer(b.clientSequence) ?? -1);
      if (sequence) return sequence;
      const receive = compareNumber(number(a.serverReceiveAtMs) ?? Number.NEGATIVE_INFINITY, number(b.serverReceiveAtMs) ?? Number.NEGATIVE_INFINITY);
      if (receive) return receive;
    }
    const installation = compareText(a.installationId, b.installationId);
    if (installation) return installation;
    return compareText(a.deliveryMarkerId, b.deliveryMarkerId);
  }

  function eligibleMarkers(candidates, current) {
    return (Array.isArray(candidates) ? candidates : []).filter(candidate => deliveryEligibility(candidate, current).eligible && candidate.revoked !== true);
  }

  function chooseDeliveryMarker(candidates, current) {
    const eligible = eligibleMarkers(candidates, current);
    if (!eligible.length) return null;
    return [...eligible].sort((a, b) => compareDeliveryMarkers(a, b)).at(-1) || null;
  }

  function preferredExecutorDecision({ currentPreferred = null, candidates = [], currentBinding = null, reason = "reconcile" } = {}) {
    const preferred = currentPreferred?.installationId ? currentPreferred : null;
    const preferredEligible = Boolean(preferred && preferred.revoked !== true && deliveryEligibility(preferred.context || currentBinding, currentBinding || preferred.context).eligible);
    if (preferred && preferredEligible) return { state: PREFERRED_STATES.VALID_CURRENT, installationId: preferred.installationId, changed: false, reason: "VALID_CURRENT", decisionReason: reason };
    const selected = chooseDeliveryMarker(candidates, currentBinding);
    if (selected) return { state: PREFERRED_STATES.VALID_CURRENT, installationId: selected.installationId || null, changed: selected.installationId !== preferred?.installationId, reason: preferred ? "REPLACEMENT_REQUIRED" : "INITIALIZE_UNSET", decisionReason: reason };
    return { state: preferred ? PREFERRED_STATES.REPLACEMENT_REQUIRED : PREFERRED_STATES.UNSET, installationId: preferred?.installationId || null, changed: false, reason: preferred ? "NO_ELIGIBLE_REPLACEMENT" : "NO_ELIGIBLE_CANDIDATE", decisionReason: reason };
  }

  function explicitConflict(local, server) {
    return Boolean(local && server && !sameBinding(local, server, { includeState: false }) && (local.storeId !== server.storeId || local.marketplace !== server.marketplace || local.bindingId !== server.bindingId));
  }

  function classifyComparison({ local = null, server = null, pending = null, delivery = null } = {}) {
    if (pending) {
      if (pending.kind === "DELIVERY_MARKER") {
        if (!server) return CLASSES.UNKNOWN_REMOTE_INSTALLATION_STATE;
        const eligibility = deliveryEligibility(pending, server);
        if (!eligibility.eligible) return server.bindingState === "FINISHED" ? CLASSES.SERVER_FINISH_WINS_OVER_LATE_DELIVERY : CLASSES.STALE_DELIVERY_OBSOLETE;
      } else if (!server) return CLASSES.LOCAL_PENDING;
    }
    if (!server) return CLASSES.UNKNOWN_REMOTE_INSTALLATION_STATE;
    if (delivery && !deliveryEligibility(delivery, server).eligible) return server.bindingState === "FINISHED" ? CLASSES.SERVER_FINISH_WINS_OVER_LATE_DELIVERY : CLASSES.STALE_DELIVERY_OBSOLETE;
    if (!local) return CLASSES.SERVER_AHEAD_COMPATIBLE;
    if (sameBinding(local, server)) return pending ? CLASSES.SAME_BINDING_MERGEABLE : CLASSES.IN_SYNC;
    if (explicitConflict(local, server)) return CLASSES.EXPLICIT_BINDING_CONFLICT;
    if (local.bindingState === "FINISHED" && server.bindingRevision > local.bindingRevision) return CLASSES.LOCAL_FINISH_SUPERSEDED_BY_NEWER_EXPLICIT_BINDING;
    if (server.bindingRevision > local.bindingRevision) return CLASSES.SERVER_AHEAD_COMPATIBLE;
    return CLASSES.REQUIRES_EXPLICIT_USER_REBIND_RESOLUTION;
  }

  function reconcile({ local = null, server = null, pending = null, delivery = null, currentPreferred = null, candidates = [] } = {}) {
    const current = server || local;
    const classification = classifyComparison({ local, server, pending, delivery });
    const preference = preferredExecutorDecision({ currentPreferred, candidates, currentBinding: current, reason: classification });
    return Object.freeze({ classification, preference, deliveryEligible: delivery ? deliveryEligibility(delivery, current) : null, current: current ? contextOf(current) : null });
  }

  function allowsFutureAction({ local = null, server = null } = {}) {
    if (!server) return { allowed: true, code: null };
    if (server.bindingState === "FINISHED" && local && local.bindingRevision <= server.bindingRevision) return { allowed: false, code: "SYNC_SERVER_FINISH_FENCE" };
    if (local && server.bindingRevision > local.bindingRevision && !sameBinding(local, server, { includeState: false })) return { allowed: false, code: "SYNC_NEWER_BINDING_FENCE" };
    return { allowed: true, code: null };
  }

  const STORE_RECONCILIATION_CLASSES = Object.freeze({
    IN_SYNC: "IN_SYNC",
    SERVER_AHEAD_COMPATIBLE: "SERVER_AHEAD_COMPATIBLE",
    STORE_TOMBSTONE_DOMINATES: "STORE_TOMBSTONE_DOMINATES",
    STORE_PROVIDER_IDENTITY_MISMATCH: "STORE_PROVIDER_IDENTITY_MISMATCH",
    STORE_STALE_REVISION: "STORE_STALE_REVISION",
    UNKNOWN_REMOTE_INSTALLATION_STATE: "UNKNOWN_REMOTE_INSTALLATION_STATE",
  });
  function storeState(entry) {
    const payload = entry.payload || entry;
    return {
      kind: entry.kind || payload.kind,
      storeId: payload.storeId,
      marketplace: payload.marketplace,
      name: payload.name,
      providerAccountId: payload.providerIdentityState === "CONFIRMED" ? payload.providerAccountId : null,
      providerIdentityState: payload.providerIdentityState === "CONFIRMED" ? "CONFIRMED" : "UNCONFIRMED",
      credentialRevision: payload.credentialRevision || null,
      metadataRevision: Number.isSafeInteger(Number(payload.metadataRevision)) && Number(payload.metadataRevision) >= 0 ? Number(payload.metadataRevision) : 0,
      lifecycleState: (entry.kind || payload.kind) === "STORE_TOMBSTONE" ? "TOMBSTONED" : "ACTIVE",
    };
  }
  function sameStoreState(left, right) {
    return Boolean(left && right && left.storeId === right.storeId && left.marketplace === right.marketplace && left.name === right.name && left.providerAccountId === right.providerAccountId && left.providerIdentityState === right.providerIdentityState && left.credentialRevision === right.credentialRevision && left.metadataRevision === right.metadataRevision && left.lifecycleState === right.lifecycleState);
  }
  function applyStoreMetadata({ current = null, serverRevision = 0, entry, receiveAtMs = 0 } = {}) {
    const desired = storeState(entry);
    if (!desired.storeId || !["ozon", "wildberries"].includes(desired.marketplace) || !desired.name) return { outcome: "CONFLICT", serverRevision, serverState: current, code: "STORE_METADATA_INVALID" };
    if (!current) return { outcome: "ACK", serverRevision: serverRevision + 1, serverState: desired, code: null };
    if (current.lifecycleState === "TOMBSTONED") return { outcome: desired.lifecycleState === "TOMBSTONED" ? "ACK" : "CONFLICT", serverRevision, serverState: current, code: desired.lifecycleState === "TOMBSTONED" ? STORE_RECONCILIATION_CLASSES.IN_SYNC : STORE_RECONCILIATION_CLASSES.STORE_TOMBSTONE_DOMINATES };
    if (entry.baseRevision !== serverRevision) {
      if (sameStoreState(desired, current)) return { outcome: "ACK", serverRevision, serverState: current, code: STORE_RECONCILIATION_CLASSES.IN_SYNC };
      return { outcome: "CONFLICT", serverRevision, serverState: current, code: "SYNC_CONFLICT" };
    }
    if (current.providerIdentityState === "CONFIRMED" && desired.providerIdentityState === "CONFIRMED" && current.providerAccountId !== desired.providerAccountId)
      return { outcome: "CONFLICT", serverRevision, serverState: current, code: STORE_RECONCILIATION_CLASSES.STORE_PROVIDER_IDENTITY_MISMATCH };
    if (desired.metadataRevision < Number(current.metadataRevision || 0)) return { outcome: "CONFLICT", serverRevision, serverState: current, code: STORE_RECONCILIATION_CLASSES.STORE_STALE_REVISION };
    if (current.providerIdentityState === "CONFIRMED") {
      desired.providerIdentityState = "CONFIRMED";
      desired.providerAccountId = current.providerAccountId;
    }
    return { outcome: "ACK", serverRevision: serverRevision + 1, serverState: desired, code: null };
  }

  globalThis.SellerAgentsReconciliation = Object.freeze({
    CLASSES,
    PREFERRED_STATES,
    PROVENANCE,
    contextOf,
    effectiveIdentity,
    sameBinding,
    deliveryEligibility,
    markerProvenance,
    compareDeliveryMarkers,
    chooseDeliveryMarker,
    preferredExecutorDecision,
    classifyComparison,
    reconcile,
    allowsFutureAction,
    STORE_RECONCILIATION_CLASSES,
    applyStoreMetadata,
  });
})();

;
/* C3E: compact installation-local metadata journal. It observes local truth;
 * it never owns Work authority and never replays a business operation. */
(() => {
  "use strict";

  const STORAGE_KEY = "seller_agents_sync_journal_v1";
  const BINDINGS_STORAGE_KEY = "ozmb_conversation_bindings";
  const VERSION = "seller_agents_sync_v1";
  const MAX_BATCH = 32;
  const MAX_ENTRIES = 256;
  const MAX_PAYLOAD_BYTES = 1800;
  const RETRY_MS = [5000, 15000, 30000, 60000, 120000, 300000];
  const MAX_RETRY_MS = 300000;
  const SNAPSHOT_READ_RETRY_MS = 60000;
  const SNAPSHOT_READ_SUCCESS_MS = 300000;
  let stateFlight = null;
  let mutationFlight = Promise.resolve();
  let syncFlight = null;
  const snapshotFlights = new Map();
  const snapshotNextAllowedAt = new Map();

  const text = (value, max = 256) => typeof value === "string" && value.length <= max ? value : null;
  const entityKey = value => typeof value === "string" && value.length > 0 && value.length <= 128;
  const mapKey = value => typeof value === "string" && value.length > 0 && value.length <= 320;
  const integer = (value, fallback = 0) => Number.isSafeInteger(Number(value)) && Number(value) >= 0 ? Number(value) : fallback;
  const clone = value => value === undefined ? undefined : structuredClone(value);
  const canonicalJson = value => {
    if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
    if (value && typeof value === "object") return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
    return JSON.stringify(value);
  };
  const bytes = value => new TextEncoder().encode(JSON.stringify(value)).byteLength;
  const digest = async value => [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(String(value))))].map(x => x.toString(16).padStart(2, "0")).join("");
  const normalizedConversationKey = value => {
    const key = typeof value === "string" ? value.trim().toLowerCase() : "";
    return key && key.length <= 320 && key.includes("|") ? key : null;
  };
  const conversationEntityId = async value => {
    const key = normalizedConversationKey(value);
    if (!key) throw Object.assign(new Error("SYNC_CONVERSATION_KEY_INVALID"), { code: "SYNC_CONVERSATION_KEY_INVALID" });
    return `conversation:${await digest(key)}`;
  };
  const stateSlot = (accountId, entityId) => `${String(accountId || "")}\u001f${String(entityId || "")}`;
  const stableJitter = (requestId, attempt) => {
    let hash = 2166136261;
    for (const char of `${requestId}:${attempt}`) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619);
    return 0.9 + (Math.abs(hash >>> 0) % 2001) / 10000;
  };
  const retryDelay = (requestId, attempt) => Math.min(MAX_RETRY_MS, Math.round((RETRY_MS[Math.min(Math.max(attempt - 1, 0), RETRY_MS.length - 1)] || MAX_RETRY_MS) * stableJitter(requestId, attempt)));

  function empty() {
    return { version: VERSION, sequence: 0, entries: {}, serverRevisions: {}, serverStates: {}, reconciliation: {}, snapshotAt: 0 };
  }
  function copyLegacyKnowledge(result, legacyKey, slot) {
    if (!legacyKey || legacyKey === slot) return false;
    let changed = false;
    const sourceRevision = Object.prototype.hasOwnProperty.call(result.serverRevisions, legacyKey) ? integer(result.serverRevisions[legacyKey]) : null;
    const targetRevision = Object.prototype.hasOwnProperty.call(result.serverRevisions, slot) ? integer(result.serverRevisions[slot]) : null;
    if (sourceRevision !== null && (targetRevision === null || sourceRevision > targetRevision)) {
      result.serverRevisions[slot] = sourceRevision;
      changed = true;
    }
    const sourceState = result.serverStates[legacyKey], sourceReconciliation = result.reconciliation[legacyKey];
    const sourceKnowledgeRevision = Math.max(sourceRevision ?? 0, integer(sourceReconciliation?.serverRevision));
    const targetKnowledgeRevision = Math.max(targetRevision ?? 0, integer(result.reconciliation[slot]?.serverRevision));
    if (sourceState && (!result.serverStates[slot] || sourceKnowledgeRevision >= targetKnowledgeRevision)) {
      result.serverStates[slot] = clone(sourceState);
      changed = true;
    }
    if (sourceReconciliation && (!result.reconciliation[slot] || sourceKnowledgeRevision >= targetKnowledgeRevision)) {
      result.reconciliation[slot] = clone(sourceReconciliation);
      changed = true;
    }
    return changed;
  }
  async function migrateLegacyKnowledgeFromBindings(result, bindings = {}) {
    let changed = false;
    for (const [storedKey, binding] of Object.entries(bindings || {})) {
      const accountId = text(binding?.store_context?.accountId, 128), bindingId = text(binding?.binding_id, 128);
      const conversationKey = normalizedConversationKey(binding?.conversation_key || storedKey);
      if (!accountId || !conversationKey || globalThis.BB2ConversationIdentity?.isLocal?.(conversationKey)) continue;
      const keyDigest = await digest(conversationKey), slot = stateSlot(accountId, `conversation:${keyDigest}`);
      for (const legacyKey of [bindingId, keyDigest]) changed = copyLegacyKnowledge(result, legacyKey, slot) || changed;
    }
    return changed;
  }
  function validEntry(entry) {
    return entry && typeof entry === "object" && text(entry.entryId, 320) && text(entry.requestId, 128) && text(entry.mutationId, 320) && text(entry.entityId, 128) && (!entry.wireEntityId || text(entry.wireEntityId, 128)) && text(entry.kind, 64) && ["PENDING", "RETRY_WAIT", "IN_FLIGHT", "CONFLICT", "FAILED"].includes(entry.status) && Number.isSafeInteger(entry.localSequence) && bytes(entry.payload) <= MAX_PAYLOAD_BYTES;
  }
  function normalize(raw) {
    if (!raw || raw.version !== VERSION || !raw.entries || typeof raw.entries !== "object" || !raw.serverRevisions || typeof raw.serverRevisions !== "object") throw Object.assign(new Error("SYNC_JOURNAL_CORRUPT"), { code: "SYNC_JOURNAL_CORRUPT" });
    const result = { version: VERSION, sequence: integer(raw.sequence), entries: {}, serverRevisions: {}, serverStates: {}, reconciliation: {}, snapshotAt: integer(raw.snapshotAt) };
    for (const [key, entry] of Object.entries(raw.entries)) {
      if (!validEntry(entry)) throw Object.assign(new Error("SYNC_JOURNAL_CORRUPT"), { code: "SYNC_JOURNAL_CORRUPT" });
      const normalizedEntry = clone(entry), keyDigest = text(entry.payload?.conversationKeyDigest, 64);
      if (["BINDING_UPSERT", "FINISH", "DELIVERY_MARKER"].includes(entry.kind) && /^[a-f0-9]{64}$/.test(keyDigest || "")) {
        normalizedEntry.wireEntityId = text(entry.wireEntityId, 128) || entry.entityId;
        normalizedEntry.entityId = `conversation:${keyDigest}`;
      }
      result.entries[key] = normalizedEntry;
    }
    for (const [key, value] of Object.entries(raw.serverRevisions)) if (mapKey(key) && Number.isSafeInteger(Number(value)) && Number(value) >= 0) result.serverRevisions[key] = Number(value);
    for (const [key, value] of Object.entries(raw.serverStates || {})) if (mapKey(key) && value && typeof value === "object" && bytes(value) <= 4096) result.serverStates[key] = clone(value);
    for (const [key, value] of Object.entries(raw.reconciliation || {})) if (mapKey(key) && value && typeof value === "object" && bytes(value) <= 4096) result.reconciliation[key] = clone(value);
    for (const entry of Object.values(result.entries)) {
      const accountId = text(entry.accountId, 128), keyDigest = text(entry.payload?.conversationKeyDigest, 64);
      if (!accountId || !/^[a-f0-9]{64}$/.test(keyDigest || "") || !["BINDING_UPSERT", "FINISH", "DELIVERY_MARKER"].includes(entry.kind)) continue;
      const slot = stateSlot(accountId, `conversation:${keyDigest}`);
      for (const legacyKey of [entry.wireEntityId, keyDigest]) copyLegacyKnowledge(result, legacyKey, slot);
    }
    if (Object.keys(result.entries).length > MAX_ENTRIES) throw Object.assign(new Error("SYNC_JOURNAL_CORRUPT"), { code: "SYNC_JOURNAL_CORRUPT" });
    return result;
  }
  async function read() {
    if (!stateFlight) stateFlight = (async () => {
      const data = await storageGet([STORAGE_KEY, BINDINGS_STORAGE_KEY]);
      const result = data[STORAGE_KEY] ? normalize(data[STORAGE_KEY]) : empty();
      const currentWorker = String(globalThis.WORKER_SESSION_ID || "worker-unknown");
      let changed = Boolean(data[STORAGE_KEY] && canonicalJson(data[STORAGE_KEY]) !== canonicalJson(result));
      changed = await migrateLegacyKnowledgeFromBindings(result, data[BINDINGS_STORAGE_KEY] || {}) || changed;
      for (const entry of Object.values(result.entries)) {
        if (entry.status !== "IN_FLIGHT" || entry.attempt_worker_id === currentWorker) continue;
        entry.status = "RETRY_WAIT";
        entry.nextAttemptAt = Math.max(Date.now() + 1000, Number(entry.nextAttemptAt || 0));
        entry.lastError = "WORKER_RESTART_RECOVERY";
        entry.attempt_worker_id = null;
        changed = true;
      }
      if (changed) await storageSet({ [STORAGE_KEY]: result });
      return result;
    })().finally(() => { stateFlight = null; });
    return stateFlight;
  }
  async function write(next) {
    const normalized = normalize(next);
    await storageSet({ [STORAGE_KEY]: normalized });
    const readback = (await storageGet(STORAGE_KEY))[STORAGE_KEY];
    if (!readback || canonicalJson(readback) !== canonicalJson(normalized)) throw Object.assign(new Error("SYNC_JOURNAL_WRITE_READBACK_FAILED"), { code: "SYNC_JOURNAL_WRITE_READBACK_FAILED" });
    stateFlight = null;
    return normalized;
  }
  function mutate(fn) {
    const run = mutationFlight.then(fn, fn);
    mutationFlight = run.catch(() => {});
    return run;
  }
  async function identity() {
    // C3E records local metadata only. Reading the cached continuation state
    // avoids a control-authority checkpoint/persist side effect while a popup
    // mutation is being returned to its caller.
    const cached = await SellerAgentsControlClient.getCachedContinuationState?.();
    const authority = cached?.authority || await SellerAgentsControlClient.getAuthority();
    const accountId = text(authority?.payload?.account?.id, 128), installationId = text(authority?.deviceId, 128);
    if (!accountId || !installationId) throw Object.assign(new Error("AUTH_REQUIRED"), { code: "AUTH_REQUIRED" });
    return { accountId, installationId };
  }
  async function metadata({ binding = null, store = null, conversationKey = "", kind, deliveryId = null, deliveryOrder = null, workGeneration = null }) {
    const auth = await identity();
    if (["STORE_UPSERT", "STORE_TOMBSTONE"].includes(kind)) {
      const storeId = text(store?.id || store?.storeId, 128);
      const marketplace = text(store?.marketplace, 32);
      const metadataRevision = integer(store?.metadataRevision);
      if (!storeId || !marketplace || !metadataRevision && metadataRevision !== 0) throw Object.assign(new Error("STORE_METADATA_INVALID"), { code: "STORE_METADATA_INVALID" });
      return {
        auth,
        entityId: `store:${storeId}`,
        payload: {
          kind,
          conversationKeyDigest: await digest(`store:${storeId}`),
          bindingId: null,
          bindingRevision: 0,
          storeId,
          marketplace,
          credentialRevision: text(store?.credentialRevision, 128),
          name: text(store?.name, 80),
          providerAccountId: store?.providerIdentityState === "CONFIRMED" ? text(store?.providerAccountId, 128) : null,
          providerIdentityState: store?.providerIdentityState === "CONFIRMED" ? "CONFIRMED" : "UNCONFIRMED",
          metadataRevision,
          lifecycleState: kind === "STORE_TOMBSTONE" ? "TOMBSTONED" : "ACTIVE",
        },
      };
    }
    const normalizedKey = normalizedConversationKey(conversationKey || binding?.conversation_key);
    if (globalThis.BB2ConversationIdentity?.isLocal?.(normalizedKey)) return null;
    if (!normalizedKey) throw Object.assign(new Error("SYNC_CONVERSATION_KEY_INVALID"), { code: "SYNC_CONVERSATION_KEY_INVALID" });
    const keyDigest = await digest(normalizedKey);
    const bindingId = text(binding?.binding_id, 128), baseBindingRevision = integer(binding?.revision) || 0;
    const bindingRevision = kind === "FINISH" ? baseBindingRevision + 1 : baseBindingRevision;
    const storeId = text(store?.id || binding?.store_context?.storeId, 128), marketplace = text(store?.marketplace || binding?.store_context?.marketplace, 32);
    const credentialRevision = text(store?.credentialRevision || binding?.store_context?.credentialRevision, 128);
    return {
      auth, entityId: `conversation:${keyDigest}`, wireEntityId: bindingId || keyDigest, payload: {
        kind, conversationKeyDigest: keyDigest, bindingId, bindingRevision,
        storeId, marketplace, credentialRevision,
        bindingState: kind === "FINISH" ? "FINISHED" : "BOUND",
        workGeneration: text(workGeneration, 160),
        ...(kind === "DELIVERY_MARKER" ? {
          deliveryMarkerId: text(deliveryId, 128),
          deliveryOrder: deliveryOrder && typeof deliveryOrder === "object" ? {
            aiOrderId: text(deliveryOrder.aiOrderId || deliveryOrder.messageId, 240),
            clientDeliveredAtMs: Number.isSafeInteger(Number(deliveryOrder.clientDeliveredAtMs || deliveryOrder.deliveredAtMs)) ? Number(deliveryOrder.clientDeliveredAtMs || deliveryOrder.deliveredAtMs) : null,
            clientSequence: Number.isSafeInteger(Number(deliveryOrder.clientSequence)) && Number(deliveryOrder.clientSequence) >= 0 ? Number(deliveryOrder.clientSequence) : null,
            orderProvenance: text(deliveryOrder.orderProvenance, 32) || undefined,
          } : undefined,
        } : {})
      }
    };
  }
  function compact(next, entityId, accountId) {
    const related = Object.values(next.entries).filter(entry => entry.entityId === entityId && (!accountId || entry.accountId === accountId));
    const replaceable = related.filter(entry => ["PENDING", "RETRY_WAIT"].includes(entry.status));
    for (const kind of ["BINDING_UPSERT", "FINISH", "DELIVERY_MARKER", "STORE_UPSERT", "STORE_TOMBSTONE"]) {
      const sameKind = replaceable.filter(entry => entry.kind === kind).sort((a, b) => a.localSequence - b.localSequence);
      for (const old of sameKind.slice(0, -1)) delete next.entries[old.entryId];
    }
    const storeEntries = replaceable.filter(entry => ["STORE_UPSERT", "STORE_TOMBSTONE"].includes(entry.kind)).sort((a, b) => a.localSequence - b.localSequence);
    const latestStore = storeEntries.at(-1);
    if (latestStore?.kind === "STORE_TOMBSTONE") for (const old of storeEntries) if (old.entryId !== latestStore.entryId) delete next.entries[old.entryId];
    const pendingExplicit = Object.values(next.entries).filter(entry => entry.entityId === entityId && (!accountId || entry.accountId === accountId) && ["BINDING_UPSERT", "FINISH"].includes(entry.kind) && ["PENDING", "RETRY_WAIT"].includes(entry.status)).sort((a, b) => a.localSequence - b.localSequence).at(-1);
    if (pendingExplicit) for (const marker of Object.values(next.entries)) if (marker.entityId === entityId && marker.accountId === pendingExplicit.accountId && marker.kind === "DELIVERY_MARKER" && ["PENDING", "RETRY_WAIT"].includes(marker.status) && marker.localSequence < pendingExplicit.localSequence) delete next.entries[marker.entryId];
    const keys = Object.keys(next.entries);
    if (keys.length > MAX_ENTRIES) {
      const removable = Object.values(next.entries).filter(entry => ["PENDING", "RETRY_WAIT", "FAILED"].includes(entry.status)).sort((a, b) => a.localSequence - b.localSequence);
      for (const old of removable) {
        if (Object.keys(next.entries).length <= MAX_ENTRIES) break;
        delete next.entries[old.entryId];
      }
    }
    if (Object.keys(next.entries).length > MAX_ENTRIES) throw Object.assign(new Error("SYNC_JOURNAL_FULL"), { code: "SYNC_JOURNAL_FULL" });
  }
  function latestExplicitEntry(next, accountId, entityId, afterSequence = -1) {
    return Object.values(next.entries)
      .filter(entry => entry.accountId === accountId && entry.entityId === entityId &&
        ["BINDING_UPSERT", "FINISH"].includes(entry.kind) &&
        ["PENDING", "RETRY_WAIT", "IN_FLIGHT", "CONFLICT", "FAILED"].includes(entry.status) &&
        entry.localSequence > afterSequence)
      .sort((a, b) => a.localSequence - b.localSequence)
      .at(-1) || null;
  }
  function entryFor(next, record, auth, payload) {
    next.sequence += 1;
    const requestId = crypto.randomUUID(), mutationId = `${auth.installationId}:${next.sequence}`;
    return {
      entryId: `${record.entityId}:${next.sequence}`, requestId, mutationId, entityId: record.entityId, wireEntityId: record.wireEntityId || null,
      accountId: auth.accountId, installationId: auth.installationId, baseRevision: integer(next.serverRevisions[stateSlot(auth.accountId, record.entityId)]),
      localSequence: next.sequence, mutationGeneration: `${auth.installationId}:${record.entityId}:${next.sequence}`,
      kind: payload.kind, payload: clone(payload), status: "PENDING", attempts: 0,
      nextAttemptAt: 0, lastAttemptAt: 0, lastError: null, conflict: null,
      createdAt: Date.now()
    };
  }
  async function record(kind, input = {}) {
    const entry = await mutate(async () => {
      const recordData = await metadata({ ...input, kind });
      if (!recordData) return null;
      const next = clone(await read());
      const entry = entryFor(next, recordData, recordData.auth, recordData.payload);
      next.entries[entry.entryId] = entry;
      compact(next, entry.entityId, entry.accountId);
      await write(next);
      return entry;
    });
    if (!entry) return null;
    await schedule();
    return clone(entry);
  }
  function wireEntry(entry) {
    return { requestId: entry.requestId, mutationId: entry.mutationId, entityId: entry.wireEntityId || entry.entityId,
      baseRevision: entry.baseRevision, localSequence: entry.localSequence, mutationGeneration: entry.mutationGeneration,
      kind: entry.kind, payload: clone(entry.payload) };
  }
  function retryable(error) {
    return ["CONTROL_TRANSPORT_UNAVAILABLE", "CONTROL_REQUEST_TIMEOUT", "SYNC_RESPONSE_CONTEXT_STALE"].includes(error?.code) ||
      [408, 425, 429, 500, 502, 503, 504].includes(Number(error?.status)) ||
      error?.code === "SERVICE_UNAVAILABLE";
  }
  function authDenied(error) {
    return [401, 403].includes(Number(error?.status)) || ["UNAUTHORIZED", "DEVICE_MISMATCH", "DEVICE_REVOKED", "AUTH_REFRESH_INVALID", "ACCOUNT_IDENTITY_MISMATCH"].includes(error?.code);
  }
  async function schedule() {
    const auth = await identity().catch(() => null);
    const next = await read(), due = Object.values(next.entries).filter(entry =>
      auth && entry.accountId === auth.accountId && entry.installationId === auth.installationId && ["PENDING", "RETRY_WAIT"].includes(entry.status) && entry.kind !== "DELIVERY_MARKER");
    const scheduler = globalThis.SellerAgentsTechnicalScheduler;
    if (!due.length) {
      await scheduler?.cancelKind?.(scheduler.KINDS.SYNC);
      return;
    }
    const first = due.sort((a, b) => (a.nextAttemptAt || 0) - (b.nextAttemptAt || 0) || a.localSequence - b.localSequence)[0];
    await scheduler?.schedule?.(scheduler.KINDS.SYNC, {
      taskId: "sync:pending",
      dueAt: first.nextAttemptAt || Date.now() + 5000,
      identity: { requestId: first.requestId, installationId: first.installationId, retryGeneration: first.attempts },
    });
  }
  async function markBatch(entries, patch) {
    return mutate(async () => {
      const next = clone(await read());
      for (const entry of entries) if (next.entries[entry.entryId]) Object.assign(next.entries[entry.entryId], patch(entry));
      return write(next);
    });
  }
  // The control service publishes a strict sync v1 response contract.
  // Validate all nested fields and the entire batch before any local/catalog
  // effects; partial checks on only the selected row are not sufficient.
  const syncPlain = value => value !== null && typeof value === "object" && !Array.isArray(value);
  const syncFields = (value, allowed, required) => syncPlain(value) &&
    Object.keys(value).every(key => allowed.includes(key)) &&
    required.every(key => Object.prototype.hasOwnProperty.call(value, key));
  const syncOptional = (value, key, valid) =>
    !Object.prototype.hasOwnProperty.call(value, key) || valid(value[key]);
  const syncInt = value => typeof value === "number" && Number.isSafeInteger(value);
  const syncNonnegative = value => syncInt(value) && value >= 0;
  const syncNullable = valid => value => value === null || valid(value);
  const syncString = max => value => typeof value === "string" && value.length >= 1 && value.length <= max;
  const syncNullableString = max => syncNullable(syncString(max));
  const syncEnum = values => value => values.includes(value);
  const syncArray = (valid, max) => value => Array.isArray(value) && value.length <= max && value.every(valid);
  const syncCode = value => typeof value === "string" && /^[A-Z][A-Z0-9_]{0,63}$/.test(value);
  const syncUuid = value => typeof value === "string" &&
    /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i.test(value);
  const syncOrigin = syncEnum(["ozon", "wildberries"]);
  const syncOrderProvenance = syncEnum(["AI_ORDERED", "CLIENT_APPROXIMATE", "SERVER_RECEIVE_FALLBACK"]);
  const syncKinds = ["BINDING_UPSERT", "FINISH", "DELIVERY_MARKER", "STORE_UPSERT", "STORE_TOMBSTONE"];
  const syncDeliveryOrder = value =>
    syncFields(value, ["aiOrderId", "clientDeliveredAtMs", "clientSequence", "orderProvenance", "serverReceiveAtMs"], []) &&
    syncOptional(value, "aiOrderId", syncNullableString(240)) &&
    syncOptional(value, "clientDeliveredAtMs", syncNullable(syncInt)) &&
    syncOptional(value, "clientSequence", syncNullable(syncNonnegative)) &&
    syncOptional(value, "orderProvenance", syncOrderProvenance) &&
    syncOptional(value, "serverReceiveAtMs", syncNullable(syncInt));
  const syncMarker = value =>
    syncFields(value, ["installationId", "deliveryMarkerId", "bindingId", "bindingRevision", "storeId",
      "marketplace", "workGeneration", "aiOrderId", "clientDeliveredAtMs", "clientSequence",
      "orderProvenance", "serverReceiveAtMs", "revoked"],
      ["installationId", "deliveryMarkerId", "bindingId", "bindingRevision", "storeId",
        "marketplace", "orderProvenance", "serverReceiveAtMs"]) &&
    syncUuid(value.installationId) && syncString(128)(value.deliveryMarkerId) &&
    syncNullableString(128)(value.bindingId) && syncNonnegative(value.bindingRevision) &&
    syncNullableString(128)(value.storeId) && syncNullable(syncOrigin)(value.marketplace) &&
    syncOptional(value, "workGeneration", syncNullableString(160)) &&
    syncOptional(value, "aiOrderId", syncNullableString(240)) &&
    syncOptional(value, "clientDeliveredAtMs", syncNullable(syncInt)) &&
    syncOptional(value, "clientSequence", syncNullable(syncNonnegative)) &&
    syncOrderProvenance(value.orderProvenance) && syncInt(value.serverReceiveAtMs) &&
    syncOptional(value, "revoked", item => typeof item === "boolean");
  const syncPreferred = value =>
    syncFields(value, ["state", "installationId", "reason"], ["state", "installationId"]) &&
    syncEnum(["UNSET", "VALID_CURRENT", "REPLACEMENT_REQUIRED"])(value.state) &&
    syncNullable(syncUuid)(value.installationId) &&
    syncOptional(value, "reason", syncNullable(syncCode));
  const syncReconciliation = value =>
    syncFields(value, ["classification", "preferred", "markers", "observedInstallationIds", "serverReceiveAtMs"],
      ["classification", "preferred", "markers", "observedInstallationIds"]) &&
    syncEnum(["IN_SYNC", "SERVER_AHEAD_COMPATIBLE", "LOCAL_PENDING", "SAME_BINDING_MERGEABLE",
      "EXPLICIT_BINDING_CONFLICT", "LOCAL_FINISH_SUPERSEDED_BY_NEWER_EXPLICIT_BINDING",
      "SERVER_FINISH_WINS_OVER_LATE_DELIVERY", "STALE_DELIVERY_OBSOLETE",
      "REQUIRES_EXPLICIT_USER_REBIND_RESOLUTION", "UNKNOWN_REMOTE_INSTALLATION_STATE"])(value.classification) &&
    syncPreferred(value.preferred) && syncArray(syncMarker, 8)(value.markers) &&
    syncArray(syncUuid, 16)(value.observedInstallationIds) &&
    syncOptional(value, "serverReceiveAtMs", syncNullable(syncInt));
  const syncState = value => value === null || (
    syncFields(value, ["kind", "conversationKeyDigest", "bindingId", "bindingRevision", "storeId",
      "marketplace", "credentialRevision", "deliveryMarkerId", "bindingState", "workGeneration",
      "deliveryOrder", "reconciliation", "name", "providerAccountId", "providerIdentityState",
      "metadataRevision", "lifecycleState"],
      ["kind", "conversationKeyDigest", "bindingId", "bindingRevision", "storeId",
        "marketplace", "credentialRevision"]) &&
    syncEnum(syncKinds)(value.kind) &&
    typeof value.conversationKeyDigest === "string" && /^[a-f0-9]{64}$/.test(value.conversationKeyDigest) &&
    syncNullableString(128)(value.bindingId) && syncNonnegative(value.bindingRevision) &&
    syncNullableString(128)(value.storeId) && syncNullable(syncOrigin)(value.marketplace) &&
    syncNullableString(128)(value.credentialRevision) &&
    syncOptional(value, "deliveryMarkerId", syncNullableString(128)) &&
    syncOptional(value, "bindingState", syncEnum(["BOUND", "FINISHED"])) &&
    syncOptional(value, "workGeneration", syncNullableString(160)) &&
    syncOptional(value, "deliveryOrder", syncDeliveryOrder) &&
    syncOptional(value, "reconciliation", syncReconciliation) &&
    syncOptional(value, "name", syncString(80)) &&
    syncOptional(value, "providerAccountId", syncNullableString(128)) &&
    syncOptional(value, "providerIdentityState", syncEnum(["CONFIRMED", "UNCONFIRMED"])) &&
    syncOptional(value, "metadataRevision", syncNonnegative) &&
    syncOptional(value, "lifecycleState", syncEnum(["ACTIVE", "TOMBSTONED"])) &&
    bytes(value) <= 4096
  );
  const syncResult = value =>
    syncFields(value, ["requestId", "mutationId", "entityId", "outcome", "serverRevision", "serverState", "code"],
      ["requestId", "mutationId", "entityId", "outcome", "serverRevision", "serverState", "code"]) &&
    syncUuid(value.requestId) && syncString(320)(value.mutationId) && syncString(128)(value.entityId) &&
    syncEnum(["ACK", "CONFLICT", "RETRY"])(value.outcome) &&
    syncNonnegative(value.serverRevision) && syncState(value.serverState) &&
    syncNullable(syncCode)(value.code);
  const syncSnapshot = value =>
    syncFields(value, ["entityId", "serverRevision", "serverState"], ["entityId", "serverRevision", "serverState"]) &&
    typeof value.entityId === "string" &&
    (/^conversation:[a-f0-9]{64}$/.test(value.entityId) ||
      (/^store:.{1,122}$/s.test(value.entityId) &&
        [...value.entityId.slice("store:".length)].every(char => char.charCodeAt(0) > 31 && char.charCodeAt(0) !== 127))) &&
    syncNonnegative(value.serverRevision) && syncState(value.serverState);
  const syncResponseValid = value =>
    syncFields(value, ["syncVersion", "results", "snapshots"], ["syncVersion", "results"]) &&
    value.syncVersion === VERSION && syncArray(syncResult, MAX_BATCH)(value.results) &&
    syncOptional(value, "snapshots", syncArray(syncSnapshot, MAX_BATCH)) &&
    (!value.snapshots || new Set(value.snapshots.map(row => row.entityId)).size === value.snapshots.length) &&
    bytes(value) <= 256 * 1024;
  async function syncNow(reason = "scheduled") {
    if (syncFlight) return syncFlight;
    syncFlight = (async () => {
      let auth;
      try { auth = await identity(); }
      catch (error) { return { ok: false, code: error?.code || "AUTH_REQUIRED", sent: 0, reason }; }
      const now = Date.now(), next = await read();
      const selected = Object.values(next.entries).filter(entry => entry.accountId === auth.accountId && entry.installationId === auth.installationId && ["PENDING", "RETRY_WAIT"].includes(entry.status) && (entry.nextAttemptAt || 0) <= now).sort((a, b) => a.localSequence - b.localSequence).slice(0, MAX_BATCH);
      if (!selected.length) { await schedule(); return { ok: true, sent: 0, reason }; }
      await markBatch(selected, entry => ({ status: "IN_FLIGHT", attempts: entry.attempts + 1, attempt_worker_id: String(globalThis.WORKER_SESSION_ID || "worker-unknown"), lastAttemptAt: now, lastError: null }));
      try {
        const result = await SellerAgentsControlClient.synchronizeMetadata({ syncVersion: VERSION, entries: selected.map(wireEntry) });
        if (!syncResponseValid(result) || result.results.length !== selected.length)
          throw Object.assign(new Error("SYNC_CONTRACT_INVALID"), { code: "SYNC_CONTRACT_INVALID" });
        const byRequest = new Map(result.results.map(row => [row.requestId, row]));
        if (byRequest.size !== result.results.length || selected.some(entry => !byRequest.has(entry.requestId)))
          throw Object.assign(new Error("SYNC_CONTRACT_INVALID"), { code: "SYNC_CONTRACT_INVALID" });
        const responseAuth = await identity().catch(() => null);
        if (!responseAuth || responseAuth.accountId !== auth.accountId || responseAuth.installationId !== auth.installationId) throw Object.assign(new Error("SYNC_RESPONSE_CONTEXT_STALE"), { code: "SYNC_RESPONSE_CONTEXT_STALE" });
        await mutate(async () => {
          const current = await read();
          // Validate the WHOLE response before any catalog or journal side
          // effects. An invalid later row must not partially apply an earlier
          // store ACK while the batch is ultimately reported as failed.
          const batch = selected.map(entry => {
            const row = byRequest.get(entry.requestId), live = current.entries[entry.entryId];
            if (!live || row.mutationId !== live.mutationId || row.entityId !== (live.wireEntityId || live.entityId) ||
                !["ACK", "CONFLICT", "RETRY"].includes(row.outcome) ||
                typeof row.serverRevision !== "number" ||
                !Number.isSafeInteger(row.serverRevision) || row.serverRevision < 0 ||
                (row.outcome === "ACK" && row.serverRevision < live.baseRevision) ||
                (row.serverState != null && (typeof row.serverState !== "object" ||
                  Array.isArray(row.serverState) || bytes(row.serverState) > 4096)) ||
                (row.code != null && (typeof row.code !== "string" || row.code.length > 128)))
              throw Object.assign(new Error("SYNC_CONTRACT_INVALID"), { code: "SYNC_CONTRACT_INVALID" });
            return { row, live };
          });
          for (const { row, live } of batch) {
            const slot = stateSlot(live.accountId, live.entityId);
            const priorRevision = integer(current.serverRevisions[slot]) || 0;
            if (row.serverRevision < priorRevision) {
              // A later snapshot/ACK already established newer server truth.
              // Do not overwrite it or leave the original intent stuck IN_FLIGHT:
              // retain the local desired mutation for explicit reconciliation.
              live.status = "CONFLICT";
              live.conflict = {
                serverRevision: priorRevision,
                serverState: clone(current.serverStates[slot] || null),
                classification: "SYNC_STALE_REPLY_SUPERSEDED",
              };
              live.nextAttemptAt = 0;
              live.lastError = "SYNC_STALE_REPLY_SUPERSEDED";
              continue;
            }
            if (row.outcome === "ACK") {
              // All ACK revisions were validated with the whole batch above.
              current.serverRevisions[slot] = row.serverRevision;
              const newerExplicit = Object.values(current.entries).some(entry => entry.accountId === live.accountId && entry.entityId === live.entityId && entry.localSequence > live.localSequence && ["BINDING_UPSERT", "FINISH"].includes(entry.kind));
              let lateDeliveryClass = null;
              if (live.kind === "DELIVERY_MARKER" && row.serverState && current.serverStates[slot]) {
                lateDeliveryClass = SellerAgentsReconciliation.classifyComparison({
                  server: { ...clone(current.serverStates[slot]), accountId: live.accountId, entityId: live.entityId },
                  delivery: { ...clone(row.serverState), accountId: live.accountId, entityId: live.entityId },
                });
                if (!["SERVER_FINISH_WINS_OVER_LATE_DELIVERY", "STALE_DELIVERY_OBSOLETE"].includes(lateDeliveryClass)) lateDeliveryClass = null;
              }
              const staleDelivery = live.kind === "DELIVERY_MARKER" && (newerExplicit || lateDeliveryClass);
              if (row.serverState && !staleDelivery) {
                if (["STORE_UPSERT", "STORE_TOMBSTONE"].includes(row.serverState.kind)) await globalThis.SellerAgentsActiveStoreCatalog?.applyRemoteMetadata?.(row.serverState);
                current.serverStates[slot] = clone(row.serverState);
                current.reconciliation[slot] = {
                  classification: row.code || row.serverState.reconciliation?.classification || (live.kind === "DELIVERY_MARKER" ? "IN_SYNC" : "SERVER_AHEAD_COMPATIBLE"),
                  preferred: row.serverState.reconciliation?.preferred || null,
                  serverRevision: Number(row.serverRevision),
                  serverState: clone(row.serverState),
                };
              } else if (live.kind === "DELIVERY_MARKER" && !staleDelivery) {
                current.reconciliation[slot] = { classification: "UNKNOWN_REMOTE_INSTALLATION_STATE", preferred: null, serverRevision: Number(row.serverRevision), serverState: null };
              } else if (staleDelivery && !current.reconciliation[slot]) {
                current.reconciliation[slot] = { classification: lateDeliveryClass || "STALE_DELIVERY_OBSOLETE", preferred: null, serverRevision: Number(row.serverRevision), serverState: null };
              }
              delete current.entries[live.entryId];
              for (const newer of Object.values(current.entries)) if (newer.accountId === live.accountId && newer.entityId === live.entityId && newer.localSequence > live.localSequence && ["PENDING", "RETRY_WAIT"].includes(newer.status) && newer.baseRevision <= Number(row.serverRevision)) newer.baseRevision = Number(row.serverRevision);
            } else if (row.outcome === "CONFLICT") {
              if (row.serverState && ["STORE_UPSERT", "STORE_TOMBSTONE"].includes(row.serverState.kind)) await globalThis.SellerAgentsActiveStoreCatalog?.applyRemoteMetadata?.(row.serverState);
              live.status = "CONFLICT"; live.conflict = { serverRevision: integer(row.serverRevision), serverState: row.serverState || null, classification: row.code || "EXPLICIT_BINDING_CONFLICT" }; live.lastError = text(row.code, 128) || "SYNC_CONFLICT";
              current.reconciliation[slot] = { classification: row.code || "EXPLICIT_BINDING_CONFLICT", preferred: row.serverState?.reconciliation?.preferred || null, serverRevision: integer(row.serverRevision), serverState: clone(row.serverState) };
            } else if (row.outcome === "RETRY") {
              live.status = "RETRY_WAIT"; live.nextAttemptAt = now + retryDelay(live.requestId, live.attempts); live.lastError = text(row.code, 128) || "SYNC_RETRY_WAIT";
            } else throw Object.assign(new Error("SYNC_CONTRACT_INVALID"), { code: "SYNC_CONTRACT_INVALID" });
          }
          await write(current);
        });
        await schedule(); return { ok: true, sent: selected.length, reason };
      } catch (error) {
        if (authDenied(error)) {
          await markBatch(selected, () => ({ status: "FAILED", nextAttemptAt: 0, lastError: text(error.code, 128) || "AUTH_REQUIRED" }));
        } else if (retryable(error)) {
          const retryAfterMs = Math.max(0, Number(error?.retryAfterMs) || 0);
          await markBatch(selected, entry => ({
            status: "RETRY_WAIT",
            nextAttemptAt: Date.now() + Math.min(MAX_RETRY_MS, Math.max(retryDelay(entry.requestId, entry.attempts), retryAfterMs)),
            lastError: text(error.code, 128) || "SYNC_RETRY_WAIT"
          }));
        } else {
          await markBatch(selected, () => ({ status: "FAILED", nextAttemptAt: 0, lastError: text(error.code, 128) || "SYNC_CONTRACT_INVALID" }));
        }
        await schedule(); return { ok: false, code: error?.code || "SYNC_FAILED", sent: 0, reason };
      }
    })().finally(() => { syncFlight = null; });
    return syncFlight;
  }
  function bindingContext(auth, entityId, keyDigest, binding = null, store = null, workGeneration = null) {
    return {
      accountId: auth.accountId,
      entityId,
      conversationKeyDigest: keyDigest,
      bindingId: text(binding?.binding_id, 128),
      bindingRevision: integer(binding?.revision) || 0,
      storeId: text(store?.id || binding?.store_context?.storeId, 128),
      marketplace: text(store?.marketplace || binding?.store_context?.marketplace, 32),
      workGeneration: text(workGeneration, 160),
      bindingState: "BOUND",
    };
  }
  const bindingFence = value => canonicalJson({
    accountId: value.accountId,
    entityId: value.entityId,
    bindingId: value.bindingId,
    bindingRevision: value.bindingRevision,
    storeId: value.storeId,
    marketplace: value.marketplace,
    workGeneration: value.workGeneration,
  });
  async function createSnapshotReadIntent(input = {}) {
    const auth = await identity();
    const conversationKey = normalizedConversationKey(input.conversationKey || input.binding?.conversation_key);
    if (!conversationKey) throw Object.assign(new Error("SYNC_CONVERSATION_KEY_INVALID"), { code: "SYNC_CONVERSATION_KEY_INVALID" });
    const keyDigest = await digest(conversationKey), entityId = `conversation:${keyDigest}`;
    const local = bindingContext(auth, entityId, keyDigest, input.binding, input.store, input.workGeneration);
    const journal = await read();
    return Object.freeze({
      version: "seller_agents_snapshot_intent_v1",
      accountId: auth.accountId,
      installationId: auth.installationId,
      conversationKey,
      conversationKeyDigest: keyDigest,
      entityIds: Object.freeze([entityId]),
      journalSequence: journal.sequence,
      localFence: bindingFence(local),
    });
  }
  async function applySnapshotRead(input = {}) {
    const intent = input.intent;
    if (!intent || intent.version !== "seller_agents_snapshot_intent_v1" || !Array.isArray(intent.entityIds) || intent.entityIds.length !== 1 || !Number.isSafeInteger(Number(intent.journalSequence)) || Number(intent.journalSequence) < 0) throw Object.assign(new Error("SYNC_SNAPSHOT_INTENT_INVALID"), { code: "SYNC_SNAPSHOT_INTENT_INVALID" });
    const auth = await identity();
    if (auth.accountId !== intent.accountId || auth.installationId !== intent.installationId) return { applied: false, code: "SYNC_SNAPSHOT_CONTEXT_STALE" };
    const currentConversationKey = normalizedConversationKey(input.currentConversationKey);
    if (!currentConversationKey || currentConversationKey !== intent.conversationKey) return { applied: false, code: "SYNC_SNAPSHOT_CONTEXT_STALE" };
    const entityId = await conversationEntityId(currentConversationKey);
    if (entityId !== intent.entityIds[0] || entityId !== `conversation:${intent.conversationKeyDigest}`) throw Object.assign(new Error("SYNC_SNAPSHOT_INTENT_INVALID"), { code: "SYNC_SNAPSHOT_INTENT_INVALID" });
    const local = bindingContext(auth, entityId, intent.conversationKeyDigest, input.binding, input.store, input.workGeneration);
    if (bindingFence(local) !== intent.localFence) return { applied: false, code: "SYNC_SNAPSHOT_CONTEXT_STALE" };
    if (!Array.isArray(input.snapshots) || input.snapshots.length !== 1) throw Object.assign(new Error("SYNC_SNAPSHOT_RESPONSE_INVALID"), { code: "SYNC_SNAPSHOT_RESPONSE_INVALID" });
    const snapshot = input.snapshots[0], serverRevision = Number(snapshot?.serverRevision), serverState = snapshot?.serverState ?? null;
    if (!snapshot || snapshot.entityId !== entityId || !Number.isSafeInteger(serverRevision) || serverRevision < 0 || (serverState === null ? serverRevision !== 0 : serverRevision < 1) || (serverState !== null && (typeof serverState !== "object" || bytes(serverState) > 4096))) throw Object.assign(new Error("SYNC_SNAPSHOT_RESPONSE_INVALID"), { code: "SYNC_SNAPSHOT_RESPONSE_INVALID" });
    if (serverState && ["BINDING_UPSERT", "FINISH", "DELIVERY_MARKER"].includes(serverState.kind) && serverState.conversationKeyDigest !== intent.conversationKeyDigest) throw Object.assign(new Error("SYNC_SNAPSHOT_RESPONSE_INVALID"), { code: "SYNC_SNAPSHOT_RESPONSE_INVALID" });
    return mutate(async () => {
      const current = clone(await read()), slot = stateSlot(auth.accountId, entityId), priorRevision = integer(current.serverRevisions[slot]) || 0;
      const newerExplicit = latestExplicitEntry(current, auth.accountId, entityId, Number(intent.journalSequence));
      if (newerExplicit) return { applied: false, code: "SYNC_SNAPSHOT_CONTEXT_STALE" };
      const unresolvedExplicit = latestExplicitEntry(current, auth.accountId, entityId);
      if (unresolvedExplicit && serverRevision <= integer(unresolvedExplicit.baseRevision))
        return { applied: false, code: "SYNC_SNAPSHOT_LOCAL_EXPLICIT_AHEAD", serverRevision };
      if (serverRevision < priorRevision) return { applied: false, code: "SYNC_SNAPSHOT_STALE", serverRevision: priorRevision };
      if (serverState?.kind === "DELIVERY_MARKER" && current.serverStates[slot]) {
        const classification = SellerAgentsReconciliation.classifyComparison({
          server: { ...clone(current.serverStates[slot]), accountId: auth.accountId, entityId },
          delivery: { ...clone(serverState), accountId: auth.accountId, entityId },
        });
        if (["SERVER_FINISH_WINS_OVER_LATE_DELIVERY", "STALE_DELIVERY_OBSOLETE"].includes(classification)) {
          current.serverRevisions[slot] = serverRevision;
          current.snapshotAt = Date.now();
          if (current.reconciliation[slot]) current.reconciliation[slot].serverRevision = serverRevision;
          await write(current);
          return { applied: true, code: "SYNC_SNAPSHOT_LATE_DELIVERY_OBSOLETE", serverRevision, classification };
        }
      }
      if (serverState?.kind === "DELIVERY_MARKER" && unresolvedExplicit) {
        current.serverRevisions[slot] = serverRevision;
        current.snapshotAt = Date.now();
        for (const entry of Object.values(current.entries)) {
          if (entry.accountId === auth.accountId && entry.entityId === entityId && ["PENDING", "RETRY_WAIT"].includes(entry.status) && entry.baseRevision <= serverRevision) entry.baseRevision = serverRevision;
        }
        await write(current);
        return { applied: true, code: "SYNC_SNAPSHOT_LATE_DELIVERY_OBSOLETE", serverRevision, classification: "STALE_DELIVERY_OBSOLETE" };
      }
      if (serverState === null) {
        current.serverRevisions[slot] = serverRevision;
        delete current.serverStates[slot];
        current.reconciliation[slot] = { classification: "UNKNOWN_REMOTE_INSTALLATION_STATE", preferred: null, serverRevision, serverState: null };
        current.snapshotAt = Date.now();
        await write(current);
        return { applied: true, code: "SYNC_SNAPSHOT_MISSING", serverRevision, classification: "UNKNOWN_REMOTE_INSTALLATION_STATE" };
      }
      const server = { ...clone(serverState), accountId: auth.accountId, entityId };
      const localForComparison = local.bindingId ? local : null;
      const classification = SellerAgentsReconciliation.classifyComparison({ local: localForComparison, server });
      let adoption = null;
      if (!local.bindingId && ["BOUND", "FINISHED"].includes(server.bindingState) && classification === "SERVER_AHEAD_COMPATIBLE") {
        adoption = await globalThis.SellerAgentsSyncSnapshotAdoption?.apply?.({ conversationKey: currentConversationKey, expectedAccountId: auth.accountId, serverState: clone(serverState) }) || { adopted: false, code: "SYNC_SNAPSHOT_ADOPTION_UNAVAILABLE" };
        if (adoption.code === "SYNC_SNAPSHOT_CONTEXT_STALE") return { applied: false, code: "SYNC_SNAPSHOT_CONTEXT_STALE" };
      }
      current.serverRevisions[slot] = serverRevision;
      current.serverStates[slot] = clone(serverState);
      current.reconciliation[slot] = { classification, preferred: serverState.reconciliation?.preferred || null, serverRevision, serverState: clone(serverState), adoption: adoption ? { adopted: adoption.adopted === true, code: adoption.code || null } : null };
      current.snapshotAt = Date.now();
      await write(current);
      return { applied: true, code: null, serverRevision, classification, adoption: adoption ? clone(adoption) : null };
    });
  }
  async function syncConversationSnapshot(input = {}) {
    if (globalThis.BB2ConversationIdentity?.isLocal?.(input.conversationKey || input.binding?.conversation_key)) return { applied: false, code: "LOCAL_CONVERSATION_SCOPE" };
    const intent = await createSnapshotReadIntent(input);
    const entityId = intent.entityIds[0], snapshotKey = stateSlot(intent.accountId, entityId);
    const reason = text(input.reason, 64) || "conversation_open";
    if (snapshotFlights.has(snapshotKey)) return snapshotFlights.get(snapshotKey);
    const now = Date.now(), nextAllowedAt = Number(snapshotNextAllowedAt.get(snapshotKey) || 0);
    if (nextAllowedAt > now) return { ok: true, read: 0, reason, code: "SYNC_SNAPSHOT_COOLDOWN", nextAllowedAt };
    snapshotNextAllowedAt.set(snapshotKey, now + SNAPSHOT_READ_RETRY_MS);
    const flight = (async () => {
      try {
        const result = await SellerAgentsControlClient.synchronizeMetadata({
          syncVersion: VERSION,
          entries: [],
          readEntityIds: [...intent.entityIds],
        });
        if (!result || result.syncVersion !== VERSION || !Array.isArray(result.results) || result.results.length !== 0 ||
          !Array.isArray(result.snapshots) || result.snapshots.length !== intent.entityIds.length)
          throw Object.assign(new Error("SYNC_SNAPSHOT_RESPONSE_INVALID"), { code: "SYNC_SNAPSHOT_RESPONSE_INVALID" });
        const applied = await applySnapshotRead({
          intent,
          currentConversationKey: intent.conversationKey,
          binding: input.binding || null,
          store: input.store || null,
          workGeneration: input.workGeneration || null,
          snapshots: result.snapshots,
        });
        snapshotNextAllowedAt.set(snapshotKey, Date.now() + SNAPSHOT_READ_SUCCESS_MS);
        return { ok: true, read: intent.entityIds.length, reason, ...applied };
      } catch (error) {
        return { ok: false, read: 0, reason, code: error?.code || "SYNC_SNAPSHOT_READ_FAILED" };
      }
    })().finally(() => snapshotFlights.delete(snapshotKey));
    snapshotFlights.set(snapshotKey, flight);
    return flight;
  }
  async function assertCurrentActionAllowed(input = {}) {
    const auth = await identity();
    const conversationKey = normalizedConversationKey(input.conversationKey || input.binding?.conversation_key);
    if (!conversationKey || globalThis.BB2ConversationIdentity?.isLocal?.(conversationKey)) return { allowed: true, code: null };
    const entityId = await conversationEntityId(conversationKey), keyDigest = entityId.slice("conversation:".length), slot = stateSlot(auth.accountId, entityId);
    const journal = await read(), local = bindingContext(auth, entityId, keyDigest, input.binding, input.store, input.workGeneration);
    // Pending local explicit changes are local truth until the server reconciles them.
    // They must not block already-permitted offline Resume/store work; only
    // server-known conflict/Finish may fence future actions here.
    const current = journal.reconciliation[slot];
    if (["EXPLICIT_BINDING_CONFLICT", "REQUIRES_EXPLICIT_USER_REBIND_RESOLUTION"].includes(current?.classification))
      return { allowed: false, code: "SYNC_EXPLICIT_BINDING_CONFLICT" };
    if (!current?.serverState) return { allowed: true, code: null };
    const server = { ...clone(current.serverState), accountId: auth.accountId, entityId };
    return SellerAgentsReconciliation.allowsFutureAction({ local, server });
  }
  globalThis.SellerAgentsSyncJournal = Object.freeze({
    recordBinding: input => record("BINDING_UPSERT", input),
    recordFinish: input => record("FINISH", input),
    recordDeliveryMarker: input => record("DELIVERY_MARKER", input),
    recordStoreMetadata: input => record("STORE_UPSERT", input),
    recordStoreTombstone: input => record("STORE_TOMBSTONE", input),
    read: async () => clone(await read()),
    entityIdForConversation: conversationEntityId,
    createSnapshotReadIntent,
    applySnapshotRead,
    syncConversationSnapshot,
    assertCurrentActionAllowed,
    syncNow,
    notifyNetworkRecovery: () => globalThis.SellerAgentsTechnicalScheduler?.wake?.("network_recovery") || syncNow("network_recovery")
  });
  queueMicrotask(() => { void globalThis.SellerAgentsTechnicalScheduler?.wake?.("worker_ready"); });
})();

;
/* Page availability is independent of conversation identity. Only an explicit
 * Start may install the already packaged receiver into an existing allowed tab. */
const saPageEntryFlights = new Map();
function saManifestMatches(pattern, value) {
  if (typeof pattern !== "string" || !/^(\*|https?):\/\//.test(pattern)) return false;
  const escaped = pattern.replace(/[.+?^{}$()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
  return new RegExp("^" + escaped + "$").test(value);
}
async function saBrowserPage(tabId) {
  let tab;
  try { tab = await chrome.tabs.get(normalizeTabId(tabId)); }
  catch (_) { throw saError("PAGE_TAB_UNAVAILABLE"); }
  let url;
  try { url = new URL(tab.url); }
  catch (_) { throw saError("WORK_START_UNSUPPORTED_PAGE"); }
  const aiFamily = BB2ConversationIdentity.providerForOrigin(url.origin);
  if (!aiFamily) throw saError("WORK_START_UNSUPPORTED_PAGE");
  return { tabId: tab.id, url: url.href, origin: url.origin, aiFamily };
}
async function saUnavailablePage(tabId, error) {
  let page = null;
  try { page = await saBrowserPage(tabId); } catch (_) {}
  return { supported: Boolean(page), aiFamily: page?.aiFamily || null,
    runtimeStatus: "unavailable", errorCode: saSupportCode(error?.code) || "IDENTITY_UNAVAILABLE",
    transportClass: safeTabMessageTransportClass(error?.transport_class) };
}
async function saPreparePageReceiver(tabId) {
  const tab = normalizeTabId(tabId);
  if (saPageEntryFlights.has(tab)) return saPageEntryFlights.get(tab);
  const flight = (async () => {
    const before = await saBrowserPage(tab);
    // Another Start or document_idle may have installed the receiver meanwhile.
    const observed = await tabMessage(tab, { type: "OZ_GET_IDENTITY" });
    if (observed?.ok && observed.identity) return;
    if (observed?.code !== "TAB_MESSAGE_ERROR" || observed.transport_class !== "NO_RECEIVER")
      throw Object.assign(saError(observed?.code || "IDENTITY_UNAVAILABLE"), {
        transport_class: safeTabMessageTransportClass(observed?.transport_class) });
    const documentUrl = new URL(before.url);
    documentUrl.hash = "";
    const scripts = chrome.runtime.getManifest().content_scripts || [];
    const files = [...new Set(scripts.filter(entry =>
      entry.matches?.some(pattern => saManifestMatches(pattern, documentUrl.href)) &&
      !entry.exclude_matches?.some(pattern => saManifestMatches(pattern, documentUrl.href))
    ).flatMap(entry => entry.js || []))];
    if (!files.length || files.some(file => typeof file !== "string" ||
        file.startsWith("/") || file.includes("..") || file.includes("://")))
      throw saError("PAGE_RUNTIME_NOT_PACKAGED");
    if (typeof chrome.scripting?.executeScript !== "function")
      throw saError("PAGE_RUNTIME_RECOVERY_UNAVAILABLE");
    if ((await saBrowserPage(tab)).url !== before.url) throw saError("POPUP_CONTEXT_STALE");
    try { await chrome.scripting.executeScript({ target: { tabId: tab, frameIds: [0] }, files }); }
    catch (_) { throw saError("PAGE_RUNTIME_INSTALL_FAILED"); }
    if ((await saBrowserPage(tab)).url !== before.url) throw saError("POPUP_CONTEXT_STALE");
  })();
  saPageEntryFlights.set(tab, flight);
  try { return await flight; }
  finally { if (saPageEntryFlights.get(tab) === flight) saPageEntryFlights.delete(tab); }
}
async function saStartPageIdentity(tabId) {
  const tab = normalizeTabId(tabId);
  try { return await tabIdentity(tab); }
  catch (error) {
    if (error?.code !== "TAB_MESSAGE_ERROR" || error.transport_class !== "NO_RECEIVER") throw error;
    await saPreparePageReceiver(tab);
    return tabIdentity(tab);
  }
}
/* End page entry. */


async function saResolveSurfaceIdentity(tabId, identity) {
  const model = globalThis.SellerAgentsConversationIdentity;
  const proof = model.normalizeProof(identity?.identity_evidence);
  if (!model.isLocal(identity?.conversation_id) || !proof || !await saEnabled()) return identity;
  const accountId = await SellerAgentsControlClient.currentAccount();
  if (!accountId) return identity;
  const bindings = await getConversationBindings();
  const matches = Object.values(bindings).filter((record) =>
    record?.store_context?.accountId === accountId && record.origin === identity.origin &&
    record.ai_id === identity.ai_id && model.isLocal(record.conversation_id) &&
    model.matchingProof(record.identity_evidence, proof));
  if (matches.length > 1) return { ...identity, conversation_id: null, status: "conflict", source: "local_identity_ambiguous" };
  if (matches.length !== 1 || matches[0].conversation_id === identity.conversation_id) return identity;
  if (await SellerAgentsControlClient.currentAccount() !== accountId) return { ...identity, conversation_id: null, status: "unknown", source: "account_changed" };
  const applied = await tabMessage(tabId, { type: "OZ_APPLY_SURFACE_IDENTITY",
    conversation_id: matches[0].conversation_id, surface_id: identity.surface_id, identity_evidence: proof });
  if (await SellerAgentsControlClient.currentAccount() !== accountId || !applied?.ok || !applied.identity)
    return { ...identity, conversation_id: null, status: "unknown", source: "surface_restore_unverified" };
  return normalizeIdentity(applied.identity);
}

/* Privileged application orchestration. Mature Ozon Work and delivery remain the implementation. */
const SA_PAYLOAD_TTL = 3600000;
let saCatalogEnabled = false;
const saStarts = new Map();
const saWorkFlights = new Map();
const saAdmissionEpochs = new Map();
const saCatalog = SellerAgentsStoreCatalog.create({
  read: storageGet, write: storageSet,
  currentAccount: () => SellerAgentsControlClient.currentAccount(),
  assertTransferContext: context => SellerAgentsControlClient.assertCredentialTransferContext(context),
  assertBackupContext: context => SellerAgentsControlClient.assertBackupContext(context),
  uuid: () => crypto.randomUUID(),
  normalizeCredentials(marketplace, input, previous = {}) {
    if (marketplace === "wildberries") return { token: SellerAgentsWBReference.credentials.normalizeSellerCredentials({ token: input.token || previous.token, tokenType: "personal" }, { required: true }).token };
    const seller = OzonCredentials.normalizeSellerCredentials({ clientId: input.seller?.clientId ?? previous.seller?.clientId,
      apiKey: input.seller?.apiKey || previous.seller?.apiKey }, { required: true });
    const performance = input.clearPerformance ? OzonCredentials.normalizePerformanceCredentials({}) :
      OzonCredentials.normalizePerformanceCredentials({ clientId: input.performance?.clientId ?? previous.performance?.clientId,
        clientSecret: input.performance?.clientSecret || previous.performance?.clientSecret });
    return { seller, performance };
  },
  revision: () => `credential-${crypto.randomUUID()}`
});
globalThis.SellerAgentsActiveStoreCatalog = saCatalog;
const saQuota = SellerAgentsObservedQuota.create({ read: storageGet, write: storageSet, namespace: "seller_agents_observed_quota_v1" });
const saReady = (async () => {
  await chrome.storage.local.setAccessLevel?.({ accessLevel: "TRUSTED_CONTEXTS" });
  await SellerAgentsControlClient.restore();
  saCatalogEnabled = true;
})();
function saError(code) { return Object.assign(new Error(code), { code }); }
function saPopupSender(sender) {
  // MessageSender.url is assigned by the browser, not supplied in the message.
  // The same privileged page may be hosted by the browser action or its own tab.
  return sender?.url === chrome.runtime.getURL("popup.html");
}
function saBackupImportSender(sender, type) {
  return ["SA_BACKUP_PREVIEW", "SA_BACKUP_IMPORT"].includes(type) &&
    sender?.url === chrome.runtime.getURL("popup.html") + "#backup-import";
}
async function saEnabled() { await saReady; return saCatalogEnabled; }
// Lifecycle admission only. Provider authorization is decided by
// saEvaluateDispatchAuthority at the provider boundary below.
async function saAssertLocalAuthorityAdmission() {
  await saReady;
  if (!await SellerAgentsControlClient.currentAccount() || !await SellerAgentsControlClient.canWork()) throw saError("WORK_POLICY_BLOCKED");
  return true;
}
async function saAssertReconciliationAction(binding, store, conversationKey, workGeneration = null) {
  if (!globalThis.SellerAgentsSyncJournal || !binding) return true;
  const decision = await SellerAgentsSyncJournal.assertCurrentActionAllowed({ binding, store, conversationKey, workGeneration });
  if (!decision.allowed) throw saError(decision.code || "SYNC_BINDING_FENCE");
  return true;
}
let saInitializeFlight = null;
async function saInitialize() {
  await saReady;
  if (saInitializeFlight) return saInitializeFlight;
  saInitializeFlight = saInitializeOnce().finally(() => { saInitializeFlight = null; });
  return saInitializeFlight;
}
async function saInitializeOnce() {
  /* Legacy global credentials remain isolated. Never assign them to the first real account. */
  if (!await SellerAgentsControlClient.currentAccount()) return;
  await saCatalog.list();
}
async function saTransferSourceSend(message) {
  const request = message.request;
  if (!request?.requestId || !request.recipientPublicKeySpki) throw saError("TRANSFER_INVALID");
  const accountId = await SellerAgentsControlClient.currentAccount(), authority = await SellerAgentsControlClient.getAuthority();
  const sourceDeviceId = authority?.deviceId;
  if (!accountId || !sourceDeviceId || request.accountId !== accountId) throw saError("TRANSFER_ACCOUNT_MISMATCH");
  await SellerAgentsControlClient.markCredentialTransferSourceSeen(request.requestId);
  // Empty selection is the recipient's explicit request for all locally
  // available stores (including on a fresh installation with no catalog).
  const selected = new Set((request.selectedStores || []).map(item => item.storeId));
  const stores = [];
  for (const store of await saCatalog.list()) {
    if (selected.size && !selected.has(store.id)) continue;
    const full = await saCatalog.get(store.id);
    if (full.accountId !== accountId) throw saError("TRANSFER_ACCOUNT_MISMATCH");
    const hasKeys = full.marketplace === "wildberries" ? Boolean(full.credentials?.token) : Boolean(full.credentials?.seller?.clientId && full.credentials?.seller?.apiKey);
    if (full.credentialsStale || !hasKeys) {
      if (selected.size) throw saError("TRANSFER_CREDENTIALS_MISSING");
      continue;
    }
    stores.push({ storeId: full.id, marketplace: full.marketplace, name: full.name, credentialRevision: full.credentialRevision, metadataRevision: full.metadataRevision || 0, providerAccountId: full.providerIdentityState === "CONFIRMED" ? full.providerAccountId : null, providerIdentityState: full.providerIdentityState, lifecycleState: full.lifecycleState, credentials: structuredClone(full.credentials) });
  }
  if (!stores.length || selected.size && stores.length !== selected.size) throw saError("TRANSFER_CREDENTIALS_MISSING");
  const packetId = crypto.randomUUID();
  const envelope = await SellerAgentsCredentialTransferCrypto.encrypt({ accountId, requestId: request.requestId, sourceDeviceId, recipientDeviceId: request.recipientDeviceId, packetId, recipientPublicKeySpki: request.recipientPublicKeySpki, payload: { transferPayloadVersion: "seller_agents_credential_payload_v1", stores } });
  await SellerAgentsControlClient.submitCredentialTransferPacket({ requestId: request.requestId, packetId, envelope });
  return { ok: true, requestId: request.requestId, packetId };
}
async function saTransferReceive(message) {
  const request = message.request;
  if (!request?.requestId || !request.sourceDeviceId) throw saError("TRANSFER_INVALID");
  const received = await SellerAgentsControlClient.receiveCredentialTransfer(request.requestId, request.sourceDeviceId);
  SellerAgentsControlClient.assertCredentialTransferContext(received.importContext);
  if (received.ackedResult) return { ok: true, ...received.result, recovered: true };
  if (received.pendingAck) {
    await SellerAgentsControlClient.acknowledgeCredentialTransfer({ requestId: request.requestId, packetId: received.packet.packetId, importDecision: "IMPORTED" });
    return { ok: true, ...received.result, recovered: true };
  }
  const payload = received.payload;
  if (!payload || payload.transferPayloadVersion !== "seller_agents_credential_payload_v1" || !Array.isArray(payload.stores)) throw saError("TRANSFER_INVALID");
  if (!payload.stores.length) throw saError("TRANSFER_CREDENTIALS_MISSING");
  const results = [];
  for (const store of payload.stores) {
    if (!store?.storeId || !["ozon", "wildberries"].includes(store.marketplace) || typeof store.credentialRevision !== "string" || store.lifecycleState !== "ACTIVE") { results.push({ storeId: store?.storeId || null, kind: "CONFLICT", code: "TRANSFER_INVALID" }); continue; }
    try { results.push({ storeId: store.storeId, ...(await saCatalog.importCredential({ ...store, id: store.storeId }, received.importContext)) }); }
    catch (error) {
      if (["AUTH_GENERATION_CHANGED", "ACCOUNT_CHANGED", "AUTH_REQUIRED"].includes(error?.code)) throw error;
      results.push({ storeId: store.storeId, kind: "CONFLICT", code: error?.code || "TRANSFER_CONFLICT" });
    }
  }
  SellerAgentsControlClient.assertCredentialTransferContext(received.importContext);
  const safe = results.map(({ storeId, kind, code, store }) => ({ storeId, kind, code, store: store ? { id: store.id, marketplace: store.marketplace, credentialRevision: store.credentialRevision } : null }));
  const hasConflict = safe.some(item => item.kind === "CONFLICT");
  if (hasConflict) return { ok: true, requestId: request.requestId, importState: "CONFLICT", results: safe };
  const durable = await SellerAgentsControlClient.recordCredentialTransferImported({ requestId: request.requestId, packetId: received.packet.packetId, results: safe, importContext: received.importContext });
  await SellerAgentsControlClient.acknowledgeCredentialTransfer({ requestId: request.requestId, packetId: received.packet.packetId, importDecision: "IMPORTED" });
  return { ok: true, ...durable };
}
async function saBackupAccount() {
  const accountId = await SellerAgentsControlClient.currentAccount();
  if (!accountId) throw saError("AUTH_REQUIRED");
  return accountId;
}
async function saBackupExport(message) {
  const accountId = await saBackupAccount();
  const password = String(message.password || ""), confirmation = String(message.passwordConfirmation || "");
  if (password !== confirmation) throw saError("BACKUP_PASSWORD_CONFIRMATION_MISMATCH");
  const snapshot = await saCatalog.backupSnapshot();
  if (accountId !== await saBackupAccount() || snapshot.some(store => store.accountId !== accountId)) throw saError("ACCOUNT_CHANGED");
  const payload = SellerAgentsStoreBackup.payloadFromStores(accountId, snapshot);
  const skippedStoreCount = snapshot.length - payload.stores.length;
  const backup = await SellerAgentsStoreBackup.encrypt(payload, password);
  if (accountId !== await saBackupAccount()) throw saError("ACCOUNT_CHANGED");
  return { ok: true, backup, fileName: "seller-agents-store-backup-v1.json", storeCount: payload.stores.length, skippedStoreCount };
}
async function saBackupDecodeAndPlan(message) {
  const backupContext = await SellerAgentsControlClient.captureBackupContext();
  const { accountId } = backupContext;
  const decoded = await SellerAgentsStoreBackup.decrypt(message.backup, String(message.password || ""), accountId);
  SellerAgentsControlClient.assertBackupContext(backupContext);
  const plan = await saCatalog.planBackupImport(decoded.payload);
  SellerAgentsControlClient.assertBackupContext(backupContext);
  return { accountId, decoded, plan, backupContext };
}
function saBackupPublicPlan(decoded, plan) {
  const result = SellerAgentsStoreBackup.summary(decoded.payload, plan.classifications);
  return { ...result, legacy: decoded.legacy, classifications: plan.classifications.map((row) => ({ storeId: row.storeId, kind: row.kind })) };
}
async function saBackupPreview(message) {
  const { decoded, plan } = await saBackupDecodeAndPlan(message);
  return { ok: true, preview: saBackupPublicPlan(decoded, plan) };
}
async function saBackupImport(message) {
  if (message.apply !== true) throw saError("BACKUP_EXPLICIT_ACTION_REQUIRED");
  const { decoded, plan, backupContext } = await saBackupDecodeAndPlan(message);
  const result = await saCatalog.applyBackupImport(decoded.payload, plan, backupContext);
  SellerAgentsControlClient.assertBackupContext(backupContext);
  for (const store of result.imported) void saRecordStoreMetadata(store);
  return { ok: true, preview: saBackupPublicPlan(decoded, plan), imported: result.imported.map((store) => ({ id: store.id, name: store.name, marketplace: store.marketplace, credentialRevision: store.credentialRevision })), classifications: result.classifications.map((row) => ({ storeId: row.storeId, kind: row.kind })) };
}
function saStoreContext(store) {
  return { accountId: store.accountId, storeId: store.id, marketplace: store.marketplace,
    credentialRevision: store.credentialRevision, policyRevision: store.personalDataEnabled ? "personal-enabled" : "personal-disabled" };
}
async function saAuthorityStoreContext(store) {
  return { ...saStoreContext(store), authGeneration: await SellerAgentsControlClient.generation() };
}
async function saAssertStore(pinned) {
  const accountId = await SellerAgentsControlClient.currentAccount();
  if (!accountId || !pinned || pinned.accountId !== accountId) throw SellerAgentsExecutionContext.error();
  let store;
  try { store = await saCatalog.get(pinned.storeId); } catch (_) { throw SellerAgentsExecutionContext.error(); }
  const live = { ...saStoreContext(store), ...(pinned.authGeneration === undefined ? {} : { authGeneration: await SellerAgentsControlClient.generation() }) };
  if (Object.keys(live).some(key => live[key] !== pinned[key])) throw SellerAgentsExecutionContext.error();
  return store;
}
async function saStoreForPending(tab, intent) {
  const pending = (await getPendingWorkStarts())[String(tab)];
  if (!pending || pending.intent_id !== intent) throw SellerAgentsExecutionContext.error();
  await saAssertStore(pending.store_context);
  return pending.store_context;
}
async function saVerifyCommittedWorkStart(message, sender) {
  // Recheck authority after composer readiness without issuing a second commit.
  return withBindingWrite(async () => {
    const { pending, identity } = await pendingWorkStartForMessage(message, sender);
    const actorId = String(message.actor_id || "").trim();
    if (!actorId || pending.send_commit_actor_id !== actorId || pending.send_outcome !== "committed_before_click")
      return { ok: false, valid: false, code: "WORK_START_COMMIT_VERIFICATION_FAILED" };
    if (pending.observed_conversation_id && identity.conversation_id !== pending.observed_conversation_id)
      return { ok: false, valid: false, code: "WORK_PENDING_CONVERSATION_CHANGED" };
    return { ok: true, valid: true };
  });
}
async function saPromptTreeForExchange(identity, cacheOnly = false) {
  if (typeof SellerAgentsControlClient.getPromptTree !== "function")
    return { available: false, pin: null, warning: "AI_TREE_CLIENT_UNAVAILABLE" };
  // Explicit Start checks the latest publication; command execution remains cache-only.
  return SellerAgentsControlClient.getPromptTree(identity, { cacheOnly, refresh: !cacheOnly });
}
async function saPendingPrompt(pending) {
  await saPendingGuard(pending);
  let tree = null;
  if (pending.prompt_tree) {
    tree = await SellerAgentsControlClient.validatePromptTreePin(pending.ai_id, pending.prompt_tree);
    await saPendingGuard(pending);
  }
  return saPrompt(pending.store_context, tree);
}
async function saPendingGuard(pending) {
  await saAssertLocalAuthorityAdmission();
  if (pending?.store_context) await saAssertStore(pending.store_context);
  else throw SellerAgentsExecutionContext.error();

  const provenance = pending?.admission_provenance;
  if (!provenance) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
  const captured = await saSignedProfileSnapshot(pending.ai_id || provenance.aiFamily).catch(() => null);
  const profile = captured?.authority?.payload?.ai?.profile || null;
  const detected = captured?.authority?.payload?.ai?.detected || null;
  if (!captured || !profile || !detected ||
      provenance.accountGeneration !== captured.generation ||
      provenance.bootstrapSnapshotSha256 !== captured.snapshot.bootstrapSnapshotSha256 ||
      provenance.aiFamily !== detected.family ||
      provenance.aiSurface !== detected.surface ||
      (provenance.aiVariant ?? null) !== (detected.variant ?? null) ||
      provenance.aiProfileKey !== profile.profileKey ||
      provenance.aiProfileRevision !== profile.revision ||
      (provenance.aiProfileScopeVariant ?? null) !== (profile.scopeVariant ?? null) ||
      provenance.aiProfileContentSha256 !== profile.contentSha256)
    throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
}
function saAdmissionError(code, deniedGates = []) {
  const error = saError(code);
  error.deniedGates = [...deniedGates];
  return error;
}
async function saRecordBindingMutation(binding, conversationKey, store = null) {
  if (!globalThis.SellerAgentsSyncJournal || !binding) return null;
  return SellerAgentsSyncJournal.recordBinding({ binding, conversationKey, store }).catch(() => null);
}
async function saRecordFinishMutation(conversationKey, binding = null, store = null) {
  if (!globalThis.SellerAgentsSyncJournal) return null;
  return SellerAgentsSyncJournal.recordFinish({ binding, conversationKey, store }).catch(() => null);
}
async function saRecordDeliveryMarker(conversationKey, binding = null, store = null, deliveryId = "", deliveryOrder = null) {
  if (!globalThis.SellerAgentsSyncJournal) return null;
  const workGeneration = deliveryOrder?.workGeneration || null;
  const order = deliveryOrder && typeof deliveryOrder === "object" ? { ...deliveryOrder } : deliveryOrder;
  if (order && typeof order === "object") delete order.workGeneration;
  return SellerAgentsSyncJournal.recordDeliveryMarker({ binding, conversationKey, store, deliveryId, deliveryOrder: order, workGeneration }).catch(() => null);
}
async function saRecordStoreMetadata(store) {
  if (!globalThis.SellerAgentsSyncJournal || !store) return null;
  return SellerAgentsSyncJournal.recordStoreMetadata({ store }).catch(() => null);
}
async function saRecordStoreTombstone(store) {
  if (!globalThis.SellerAgentsSyncJournal || !store) return null;
  return SellerAgentsSyncJournal.recordStoreTombstone({ store }).catch(() => null);
}
async function saAdoptRemoteBindingSnapshot({ conversationKey, expectedAccountId, serverState } = {}) {
  await saReady;
  const accountId = await SellerAgentsControlClient.currentAccount();
  if (!accountId || accountId !== expectedAccountId) return { adopted: false, code: "SYNC_SNAPSHOT_CONTEXT_STALE" };
  const key = normalizeConversationKey(conversationKey).toLowerCase();
  const separator = key.indexOf("|"), origin = separator > 0 ? key.slice(0, separator) : "", conversationId = separator > 0 ? key.slice(separator + 1) : "";
  const bindingId = typeof serverState?.bindingId === "string" && serverState.bindingId.length <= 128 ? serverState.bindingId : null;
  const bindingRevision = Number(serverState?.bindingRevision);
  const storeId = typeof serverState?.storeId === "string" && serverState.storeId.length <= 128 ? serverState.storeId : null;
  const marketplace = ["ozon", "wildberries"].includes(serverState?.marketplace) ? serverState.marketplace : null;
  if (!origin || !conversationId || conversationKeyFromIdentity({ origin, conversation_id: conversationId, status: "confirmed" }) !== key || !bindingId || !Number.isSafeInteger(bindingRevision) || bindingRevision < 1 || !storeId || !marketplace) return { adopted: false, code: "SYNC_SNAPSHOT_REMOTE_BINDING_INVALID" };
  let store;
  try { store = await saCatalog.get(storeId); } catch (_) { return { adopted: false, code: "SYNC_SNAPSHOT_LOCAL_CREDENTIALS_REQUIRED" }; }
  if (store.accountId !== accountId || store.marketplace !== marketplace) return { adopted: false, code: "SYNC_SNAPSHOT_STORE_CONFLICT" };
  return withBindingWrite(async () => {
    if (await SellerAgentsControlClient.currentAccount() !== accountId) return { adopted: false, code: "SYNC_SNAPSHOT_CONTEXT_STALE" };
    const bindings = await getConversationBindings(), existing = normalizeBindingRecord(bindings[key], key);
    if (existing) return { adopted: false, code: "SYNC_SNAPSHOT_CONTEXT_STALE" };
    const now = new Date().toISOString();
    const record = {
      binding_id: bindingId,
      revision: bindingRevision,
      origin,
      ai_id: BB2ConversationIdentity.providerForOrigin(origin),
      conversation_id: conversationId,
      conversation_key: key,
      bound_at: now,
      updated_at: now,
      store_context: await saAuthorityStoreContext(store),
      assistant_baseline_ids: [],
    };
    bindings[key] = record;
    await storageSet({ [KEYS.CONVERSATION_BINDINGS]: bindings });
    const readback = normalizeBindingRecord((await getConversationBindings())[key], key);
    if (!readback || readback.binding_id !== bindingId || Number(readback.revision) !== bindingRevision || readback.store_context?.storeId !== storeId) throw saError("SYNC_SNAPSHOT_ADOPTION_READBACK_FAILED");
    return { adopted: true, code: null, binding: readback };
  });
}
globalThis.SellerAgentsSyncSnapshotAdoption = Object.freeze({ apply: saAdoptRemoteBindingSnapshot });
function saAdmissionKey(tabId, conversationKey = null) {
  return `${Number(tabId)}:${conversationKey || "pending"}`;
}
function saBeginAdmission(key, { operation, tabId, conversationKey, store, intentId }) {
  const token = { id: crypto.randomUUID(), key, operation, tabId: Number(tabId), conversationKey: conversationKey || null, store, intentId: String(intentId || ""), cancelled: false, admitted: false, fence: null, rebindPlan: null, rebindPhase: "planned" };
  saAdmissionEpochs.set(key, token);
  return token;
}
function saCancelAdmission(tabId, conversationKey = null) {
  const tab = Number(tabId);
  const key = conversationKey ? normalizeConversationKey(conversationKey) : null;
  const waits = [];
  for (const token of saAdmissionEpochs.values()) {
    if (token.tabId === tab || key && token.conversationKey === key) {
      token.cancelled = true;
      if (token.mutationFlight) waits.push(token.mutationFlight);
    }
  }
  return waits;
}
function saCancelAdmissionsForStore(storeId) {
  const waits = [];
  for (const token of saAdmissionEpochs.values()) if (token.store?.id === storeId) {
    token.cancelled = true;
    if (token.mutationFlight) waits.push(token.mutationFlight);
  }
  return waits;
}
function saAdmissionCurrent(token) {
  return token && token.cancelled !== true && saAdmissionEpochs.get(token.key) === token;
}
function saAuthorityIdentity(authority) {
  return JSON.stringify({
    generation: authority?.generation,
    deviceId: authority?.deviceId,
    sessionId: authority?.sessionId,
    requestedAi: authority?.requestedAi,
    accountId: authority?.payload?.account?.id || null,
    envelope: authority?.envelope || null,
    cacheBinding: authority?.cacheBinding || null
  });
}
function saBase64UrlBytes(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value)) return null;
  try {
    const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
    const bytes = Uint8Array.from(atob(padded), char => char.charCodeAt(0));
    const encoded = btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    return encoded === value ? bytes : null;
  } catch (_) { return null; }
}
async function saSnapshotDigest(envelope) {
  const bytes = saBase64UrlBytes(envelope?.payload);
  if (!bytes) throw saAdmissionError("BOOTSTRAP_SNAPSHOT_INVALID");
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map(value => value.toString(16).padStart(2, "0")).join("");
}
async function saAdmissionFence({ operation, tabId, identity, key, binding, work, store, bindingStore = null, intentId, authority, admissionEpoch = "" }) {
  const currentAuthority = authority || await SellerAgentsControlClient.getAuthority(identity);
  const currentGeneration = await SellerAgentsControlClient.generation();
  const profile = currentAuthority?.payload?.ai?.profile || {};
  return Object.freeze({
    operation: String(operation || ""),
    admissionEpoch: String(admissionEpoch || ""),
    accountId: currentAuthority?.payload?.account?.id || null,
    generation: currentGeneration,
    deviceId: currentAuthority?.deviceId || null,
    sessionId: currentAuthority?.sessionId || null,
    authorityIdentity: saAuthorityIdentity(currentAuthority),
    bootstrapSnapshotSha256: await saSnapshotDigest(currentAuthority?.envelope),
    tabId: Number(tabId),
    origin: identity?.origin || null,
    pageSource: identity?.source || null,
    chatPath: identity?.chat_path || null,
    aiId: identity?.ai_id || null,
    aiSurface: currentAuthority?.payload?.ai?.detected?.surface || null,
    aiVariant: currentAuthority?.payload?.ai?.detected?.variant || null,
    aiProfileKey: profile.profileKey || null,
    aiProfileRevision: profile.revision || null,
    aiProfileScopeVariant: profile.scopeVariant ?? null,
    aiProfileContentSha256: profile.contentSha256 || null,
    conversationKey: key || null,
    conversationId: identity?.conversation_id || null,
    pendingIdentityState: identity?.conversation_id ? "confirmed" : identity?.status || "unknown",
    bindingId: binding?.binding_id || null,
    bindingIdentity: JSON.stringify(binding ? { bindingId: binding.binding_id, accountId: binding.store_context?.accountId || null, storeId: binding.store_context?.storeId || null, marketplace: binding.store_context?.marketplace || null, credentialRevision: binding.store_context?.credentialRevision || null, authGeneration: binding.store_context?.authGeneration ?? null } : null),
    bindingStoreId: bindingStore?.id || null,
    bindingStoreMarketplace: bindingStore?.marketplace || null,
    bindingStoreCredentialRevision: bindingStore?.credentialRevision || null,
    storeId: store?.id || null,
    selectedStoreId: store?.id || null,
    marketplace: store?.marketplace || null,
    credentialRevision: store?.credentialRevision || null,
    bindingRevision: Number(binding?.revision || 0),
    workState: work?.state || "inactive",
    workRevision: Number(work?.revision || 0),
    workIntentId: work?.start_intent_id || null,
    intentId: String(intentId || "")
  });
}
function saSameFence(left, right) {
  return left && right && ["operation", "admissionEpoch", "accountId", "generation", "deviceId", "sessionId", "authorityIdentity", "bootstrapSnapshotSha256", "tabId", "origin", "pageSource", "chatPath", "aiId", "aiSurface", "aiVariant", "aiProfileKey", "aiProfileRevision", "aiProfileScopeVariant", "aiProfileContentSha256", "conversationKey", "conversationId", "pendingIdentityState", "bindingId", "bindingIdentity", "bindingStoreId", "bindingStoreMarketplace", "bindingStoreCredentialRevision", "storeId", "selectedStoreId", "marketplace", "credentialRevision", "bindingRevision", "workState", "workRevision", "workIntentId", "intentId"].every(field => left[field] === right[field]);
}
async function saAdmissionInput({ operation, tabId, identity, key, binding, work, store }) {
  const authority = await SellerAgentsControlClient.getAuthority(identity);
  const cached = await SellerAgentsControlClient.getCachedContinuationState(identity);
  const effectiveTimeMs = await SellerAgentsControlClient.getVerifiedAuthorityTime(identity);
  const payload = authority?.payload;
  const generation = await SellerAgentsControlClient.generation();
  const bootstrapSnapshotSha256 = await saSnapshotDigest(authority?.envelope);
  const provider = identity.ai_id;
  const profile = payload?.ai?.profile || {};
  const identityValue = {
    key: key || null,
    origin: identity.origin,
    conversationId: identity.conversation_id || null,
    provider,
    status: identity.conversation_id ? "confirmed" : "unknown"
  };
  const bindingValue = binding ? {
    bound: true,
    bindingId: binding.binding_id,
    revision: Number(binding.revision),
    expectedRevision: Number(binding.revision),
    conversationKey: key,
    origin: binding.origin,
    conversationId: binding.conversation_id,
    provider: binding.ai_id || provider,
    accountId: binding.store_context?.accountId || payload?.account?.id,
    storeId: binding.store_context?.storeId || store.id,
    marketplace: binding.store_context?.marketplace || store.marketplace,
    credentialRevision: binding.store_context?.credentialRevision || store.credentialRevision,
    authGeneration: binding.store_context?.authGeneration ?? null
  } : null;
  const expiresAt = Date.parse(payload?.expiresAt || ""), grace = Date.parse(payload?.offlineGraceUntil || "");
  const freshness = effectiveTimeMs < expiresAt ? "FRESH" : effectiveTimeMs < grace ? "STALE_BUT_OFFLINE_GRACE_ELIGIBLE" : "CACHE_EXPIRED";
  return {
    account: { authenticated: true, accountId: payload?.account?.id, expectedAccountId: payload?.account?.id },
    session: { generation, expectedGeneration: generation, deviceId: authority?.deviceId, expectedDeviceId: authority?.deviceId, sessionId: authority?.sessionId, expectedSessionId: authority?.sessionId, revoked: false, obsolete: false },
    compatibility: {
      extension: { version: SellerAgentsControlConfig.extensionVersion, status: payload?.compatibility?.extension?.status, minimumVersion: payload?.compatibility?.extension?.minimumVersion ?? null },
      browser: { status: payload?.compatibility?.browser?.status },
      contractVersion: payload?.contractVersion,
      expectedContractVersion: SellerAgentsControlConfig.contractVersion
    },
    bootstrap: { verified: true, source: "CACHE", freshness, accountId: payload?.account?.id, generation, deviceId: authority?.deviceId, sessionId: authority?.sessionId, contractVersion: payload?.contractVersion, configVersion: payload?.configVersion, bootstrapSnapshotSha256, aiProvider: payload?.ai?.detected?.family },
    ai: { provider, surface: payload?.ai?.detected?.surface, variant: payload?.ai?.detected?.variant, profile: { verified: true, provider: payload?.ai?.detected?.family, profileKey: profile.profileKey, revision: profile.revision, scopeVariant: profile.scopeVariant, contentSha256: profile.contentSha256 } },
    dialogue: { key: key || null, trusted: true, tabId: Number(tabId), expectedTabId: Number(tabId), identity: identityValue, binding: bindingValue },
    store: { accountId: store.accountId, storeId: store.id, marketplace: store.marketplace, credentialRevision: store.credentialRevision, selectedStoreId: store.id, expectedStoreId: store.id, expectedCredentialRevision: store.credentialRevision, authGeneration: generation, accountGeneration: generation },
    work: { operation, state: work?.state || "inactive", startIntentId: work?.start_intent_id || null, expectedStartIntentId: work?.start_intent_id || null },
    capabilityIntersection: null,
    cachedAuthority: cached.authority || authority,
    cacheClock: cached.cacheClock,
    effectiveTimeMs,
    source: "CACHE",
    current: {
      accountId: payload?.account?.id,
      expectedAccountId: payload?.account?.id,
      generation,
      expectedGeneration: generation,
      deviceId: authority?.deviceId,
      expectedDeviceId: authority?.deviceId,
      sessionId: authority?.sessionId,
      expectedSessionId: authority?.sessionId,
      aiFamily: provider,
      aiSurface: payload?.ai?.detected?.surface,
      aiVariant: payload?.ai?.detected?.variant,
      aiProfile: { profileKey: profile.profileKey, revision: profile.revision, scopeVariant: profile.scopeVariant, contentSha256: profile.contentSha256 },
      origin: identity.origin,
      conversationId: identity.conversation_id || null,
      conversationKey: key || null,
      storeId: store.id,
      marketplace: store.marketplace,
      credentialRevision: store.credentialRevision,
      expectedCredentialRevision: store.credentialRevision,
      bindingId: binding?.binding_id || null,
      bindingRevision: binding?.revision ?? null,
      workStartIntentId: work?.start_intent_id || null,
      expectedWorkStartIntentId: work?.start_intent_id || null,
    }
  };
}
function saRebindPlan({ tabId, identity, key, binding, work, sourceStore, targetStore, intentId, authority }) {
  return Object.freeze({
    version: "store_rebind_plan_v1",
    accountId: sourceStore?.accountId || targetStore.accountId,
    tabId: Number(tabId),
    origin: identity.origin,
    pageSource: identity.source || null,
    chatPath: identity.chat_path || null,
    aiId: identity.ai_id,
    aiSurface: authority?.payload?.ai?.detected?.surface || null,
    aiVariant: authority?.payload?.ai?.detected?.variant || null,
    aiProfileKey: authority?.payload?.ai?.profile?.profileKey || null,
    aiProfileRevision: authority?.payload?.ai?.profile?.revision ?? null,
    aiProfileScopeVariant: authority?.payload?.ai?.profile?.scopeVariant ?? null,
    aiProfileContentSha256: authority?.payload?.ai?.profile?.contentSha256 || null,
    conversationKey: key,
    conversationId: identity.conversation_id,
    bindingId: binding.binding_id,
    bindingRevision: Number(binding.revision),
    sourceStoreId: binding.store_context.storeId,
    sourceMarketplace: binding.store_context.marketplace,
    sourceCredentialRevision: binding.store_context.credentialRevision,
    sourceWorkState: work.state,
    sourceWorkRevision: Number(work.revision || 0),
    sourceWorkIntentId: work.start_intent_id || null,
    targetStoreId: targetStore.id,
    targetMarketplace: targetStore.marketplace,
    targetCredentialRevision: targetStore.credentialRevision,
    generation: authority?.generation,
    deviceId: authority?.deviceId,
    sessionId: authority?.sessionId,
    startIntentId: String(intentId || ""),
    authorityIdentity: saAuthorityIdentity(authority)
  });
}
function saRebindProjection(plan) {
  return { binding: null, work: { state: OzonWorkSessionModel.STATES.INACTIVE, revision: 0, start_intent_id: null }, plan };
}
function saValidateRebindPlan(plan, initial) {
  if (!plan) return null;
  const fence = initial?.fence;
  const expected = {
    accountId: fence?.accountId,
    tabId: fence?.tabId,
    origin: fence?.origin,
    pageSource: fence?.pageSource,
    chatPath: fence?.chatPath,
    aiId: fence?.aiId,
    aiSurface: fence?.aiSurface,
    aiVariant: fence?.aiVariant,
    aiProfileKey: fence?.aiProfileKey,
    aiProfileRevision: fence?.aiProfileRevision,
    aiProfileScopeVariant: fence?.aiProfileScopeVariant,
    aiProfileContentSha256: fence?.aiProfileContentSha256,
    authorityIdentity: fence?.authorityIdentity,
    conversationKey: fence?.conversationKey,
    conversationId: fence?.conversationId,
    bindingId: fence?.bindingId,
    bindingRevision: fence?.bindingRevision,
    sourceStoreId: fence?.bindingStoreId,
    sourceMarketplace: fence?.bindingStoreMarketplace,
    sourceCredentialRevision: fence?.bindingStoreCredentialRevision,
    sourceWorkState: fence?.workState,
    sourceWorkRevision: fence?.workRevision,
    sourceWorkIntentId: fence?.workIntentId,
    targetStoreId: fence?.selectedStoreId,
    targetMarketplace: fence?.marketplace,
    targetCredentialRevision: fence?.credentialRevision,
    generation: fence?.generation,
    deviceId: fence?.deviceId,
    sessionId: fence?.sessionId,
    startIntentId: fence?.intentId
  };
  const fields = Object.keys(expected);
  if (fields.some(field => plan[field] !== expected[field])) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
  return Object.freeze({ ...plan, sourceWorkState: fence.workState, sourceWorkRevision: fence.workRevision, sourceWorkIntentId: fence.workIntentId });
}
async function saReadAdmissionSnapshot({ operation, tabId, store, intentId, conversationKey = null, admissionEpoch = "" }) {
  const identity = await tabIdentity(normalizeTabId(tabId));
  const key = identity.conversation_id ? conversationKeyFromIdentity(identity) : null;
  if (conversationKey && key !== normalizeConversationKey(conversationKey)) throw saAdmissionError("CONVERSATION_MISMATCH");
  const binding = key ? await bindingForConversationKey(key) : null;
  const work = key ? await workSessionFor(key) : { state: OzonWorkSessionModel.STATES.INACTIVE, revision: 0 };
  // A new Start on the same inactive dialogue uses the current account grant.
  // The old binding remains in the fence as history; it is never resumed here.
  const newInactiveStart = operation === "start" &&
    work?.state === OzonWorkSessionModel.STATES.INACTIVE &&
    binding?.store_context?.storeId === store?.id;
  const bindingContext = newInactiveStart && binding.store_context.authGeneration !== undefined
    ? { ...binding.store_context, authGeneration: await SellerAgentsControlClient.generation() }
    : binding?.store_context;
  const bindingStore = bindingContext ? await saAssertStore(bindingContext) : null;
  const liveStore = store ? await saAssertStore(saStoreContext(store)) : (binding?.store_context ? await saAssertStore(binding.store_context) : null);
  if (!liveStore) throw saAdmissionError("STORE_NOT_FOUND");
  const authority = await SellerAgentsControlClient.getAuthority(identity);
  return { identity, key, binding, work, store: liveStore, bindingStore, authority, fence: await saAdmissionFence({ operation, tabId, identity, key, binding, work, store: liveStore, bindingStore, intentId, authority, admissionEpoch }) };
}
async function saAdmissionMutationGuard({ operation, tabId, conversationKey = null, intentId = "" }) {
  const key = saAdmissionKey(tabId, conversationKey);
  const token = saAdmissionEpochs.get(key);
  if (!saAdmissionCurrent(token) || token.operation !== operation || intentId && token.intentId !== String(intentId)) throw saAdmissionError("WORK_ADMISSION_CANCELLED");
  let current;
  try {
    current = await saReadAdmissionSnapshot({ operation, tabId, store: token.store, intentId: token.intentId, conversationKey: token.conversationKey, admissionEpoch: token.id });
  } catch (_) {
    token.cancelled = true;
    throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
  }
  if (!saAdmissionCurrent(token)) throw saAdmissionError("WORK_ADMISSION_CANCELLED");
  if (!saSameFence(token.fence, current.fence)) {
    token.cancelled = true;
    throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
  }
  return token;
}
async function saAdmissionMutationGuardIfActive({ operation, tabId, conversationKey = null, intentId = "" }) {
  const token = saAdmissionEpochs.get(saAdmissionKey(tabId, conversationKey));
  if (!token?.rebindPlan || token.cancelled === true) return null;
  return saAdmissionMutationGuard({ operation, tabId, conversationKey, intentId });
}
async function saRebindAfterFinishGuard(token) {
  if (!saAdmissionCurrent(token) || !token.rebindPlan) throw saAdmissionError("WORK_ADMISSION_CANCELLED");
  const current = await saReadAdmissionSnapshot({ operation: "start", tabId: token.tabId, store: token.store, intentId: token.intentId, conversationKey: token.conversationKey, admissionEpoch: token.id });
  const plan = token.rebindPlan;
  const unchanged = ["accountId", "generation", "deviceId", "sessionId", "authorityIdentity", "bootstrapSnapshotSha256", "tabId", "origin", "pageSource", "chatPath", "aiId", "aiProfileKey", "aiProfileRevision", "aiProfileScopeVariant", "aiProfileContentSha256", "conversationKey", "conversationId", "pendingIdentityState", "bindingId", "bindingIdentity", "bindingStoreId", "bindingStoreMarketplace", "bindingStoreCredentialRevision", "storeId", "selectedStoreId", "marketplace", "credentialRevision", "bindingRevision"].every(field => token.fence[field] === current.fence[field]);
  // R3 retains the finished Work identity as a durable denial marker.
  const sourceFinished = current.work?.terminal_state_known === true && current.work?.finished === true &&
    current.fence.workIntentId === plan.sourceWorkIntentId && current.work?.work_session_id === plan.sourceWorkIntentId;
  if (!unchanged || current.fence.workState !== OzonWorkSessionModel.STATES.INACTIVE || !sourceFinished || current.fence.workRevision !== token.sourceRevisionAtAdmission + 2) {
    token.cancelled = true;
    throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
  }
  token.fence = current.fence;
  token.rebindPhase = "source_finished";
  return token;
}
function saIsHealthTransportUnavailable(error) {
  return error?.code === "CONTROL_TRANSPORT_UNAVAILABLE" ||
    error?.status === 503 && ["PRODUCER_UNAVAILABLE", "BOOTSTRAP_UNAVAILABLE"].includes(error?.code);
}
async function saObserveHealth(initial) {
  try {
    const health = await SellerAgentsControlClient.acquireSignedHealthAuthority({
      detectedAi: { family: initial.identity.ai_id, surface: initial.authority.payload.ai.detected.surface, variant: initial.authority.payload.ai.detected.variant },
      context: { generation: initial.fence.generation, deviceId: initial.fence.deviceId, sessionId: initial.fence.sessionId }
    });
    if (health?.payload?.status === "DENY") throw saAdmissionError("WORK_AUTHORITY_DENIED", ["healthObservation"]);
    return health;
  } catch (error) {
    if (saIsHealthTransportUnavailable(error)) return null;
    throw error;
  }
}
async function saAdmitWork({ operation, tabId, store, intentId, conversationKey = null, rebindPlan = null, entryToken = null }) {
  try { await saAssertLocalAuthorityAdmission(); }
  catch (error) { if (rebindPlan) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED"); throw error; }
  let initialRead;
  try { initialRead = await saReadAdmissionSnapshot({ operation, tabId, store, intentId, conversationKey }); }
  catch (error) { if (rebindPlan) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED"); throw error; }
  if (entryToken && !saAdmissionCurrent(entryToken)) throw saAdmissionError("WORK_ADMISSION_CANCELLED");
  if (entryToken && entryToken.generation !== initialRead.fence.generation) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
  const validatedPlan = saValidateRebindPlan(rebindPlan, initialRead);
  const admissionKey = saAdmissionKey(tabId, initialRead.key);
  const token = saBeginAdmission(admissionKey, { operation, tabId, conversationKey: initialRead.key, store: initialRead.store, intentId });
  token.rebindPlan = validatedPlan;
  token.sourceRevisionAtAdmission = initialRead.fence.workRevision;
  const initial = { ...initialRead, fence: Object.freeze({ ...initialRead.fence, admissionEpoch: token.id }) };
  token.fence = initial.fence;
  try {
    /* Health is an optional online observation. It can report a verified denial,
     * but its successful acquisition is never the lifecycle authority. */
    await saObserveHealth(initial);
    if (!saAdmissionCurrent(token)) throw saAdmissionError("WORK_ADMISSION_CANCELLED");
    const afterHealth = await saReadAdmissionSnapshot({ operation, tabId, store, intentId, conversationKey, admissionEpoch: token.id });
    if (!saSameFence(initial.fence, afterHealth.fence)) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
    const inputSnapshot = await saReadAdmissionSnapshot({ operation, tabId, store, intentId, conversationKey, admissionEpoch: token.id });
    if (!saSameFence(afterHealth.fence, inputSnapshot.fence)) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
    const projection = validatedPlan ? saRebindProjection(validatedPlan) : null;
    const input = await saAdmissionInput({ operation, tabId, identity: inputSnapshot.identity, key: inputSnapshot.key, binding: projection ? projection.binding : inputSnapshot.binding, work: projection ? projection.work : inputSnapshot.work, store: inputSnapshot.store });
    const decision = await SellerAgentsAutonomousWorkAuthority.evaluate(input);
    if (!saAdmissionCurrent(token)) throw saAdmissionError("WORK_ADMISSION_CANCELLED");
    const beforeMutation = await saReadAdmissionSnapshot({ operation, tabId, store, intentId, conversationKey, admissionEpoch: token.id });
    if (!saSameFence(inputSnapshot.fence, beforeMutation.fence)) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
    if (decision.executionAuthority !== false || decision.allowed !== true) throw saAdmissionError("WORK_AUTHORITY_DENIED", decision.deniedGates);
    token.fence = beforeMutation.fence;
    token.admitted = true;
    return { token, snapshot: beforeMutation, decision };
  } finally {
    if (!token.admitted && saAdmissionEpochs.get(admissionKey) === token) saAdmissionEpochs.delete(admissionKey);
  }
}
function saReleaseAdmission(token) {
  if (token && saAdmissionEpochs.get(token.key) === token) saAdmissionEpochs.delete(token.key);
}
async function saAdmissionProvenanceSeed(admission, operation, intentId) {
  const authority = admission.snapshot.authority, payload = authority?.payload, profile = payload?.ai?.profile || {};
  return SellerAgentsOfflineWorkAuthority.createProvenance({
    provenanceSchema: "seller_agents_local_admission_provenance_v1",
    mode: "LOCAL_SIGNED_AUTHORITY",
    accountId: payload?.account?.id || null,
    accountGeneration: admission.snapshot.fence.generation,
    deviceId: admission.snapshot.fence.deviceId,
    sessionId: admission.snapshot.fence.sessionId,
    bootstrapSnapshotSha256: admission.snapshot.fence.bootstrapSnapshotSha256,
    bootstrapConfigVersion: payload?.configVersion ?? null,
    bootstrapContractVersion: payload?.contractVersion || null,
    aiFamily: payload?.ai?.detected?.family || null,
    aiSurface: payload?.ai?.detected?.surface || null,
    aiVariant: payload?.ai?.detected?.variant ?? null,
    aiProfileKey: profile.profileKey || null,
    aiProfileRevision: profile.revision ?? null,
    aiProfileScopeVariant: profile.scopeVariant ?? null,
    aiProfileContentSha256: profile.contentSha256 || null,
    marketplace: admission.snapshot.store.marketplace,
    storeId: admission.snapshot.store.id,
    credentialRevision: admission.snapshot.store.credentialRevision,
    conversationKey: admission.snapshot.key || null,
    conversationId: admission.snapshot.identity.conversation_id || null,
    bindingId: admission.snapshot.binding?.binding_id || null,
    bindingRevision: admission.snapshot.binding?.revision || null,
    workStartIntentId: String(intentId || ""),
    operation: String(operation || "").toUpperCase(),
    admissionSafeTimeMs: await SellerAgentsControlClient.getVerifiedAuthorityTime(admission.snapshot.identity),
    executionAuthority: false,
    bearer: false,
  });
}
async function saRunAdmissionMutation(token, fn) {
  if (!saAdmissionCurrent(token)) throw saAdmissionError("WORK_ADMISSION_CANCELLED");
  const flight = Promise.resolve().then(fn);
  token.mutationFlight = flight;
  try { return await flight; }
  finally { if (token.mutationFlight === flight) token.mutationFlight = null; }
}
async function saReadContext(key, immutable, ownerIdentity) {
  OzonWorkSessionModel.assertStorageAvailable();
  const data = await storageGet([KEYS.CONVERSATION_BINDINGS, KEYS.WORK_SESSIONS]);
  const binding = normalizeBindingRecord(data[KEYS.CONVERSATION_BINDINGS]?.[key], key);
  const work = OzonWorkSessionModel.normalize(data[KEYS.WORK_SESSIONS]?.[key], key);
  const p = binding?.store_context;
  let store = null;
  try { store = await saAssertStore(p); } catch (_) {}
  // The in-memory mirror is only an optimization for the legacy standalone
  // carrier. A service-worker restart must validate the durable manual owner
  // record, otherwise a buffered known result is incorrectly fenced before it
  // can be materialized locally.
  let current = manualContextOwners.get(key);
  if (ownerIdentity && !current) {
    // Hydrate the payload-free mirror once after a worker restart. Subsequent
    // guard checkpoints stay on the mirror and do not reread report payloads.
    current = await getManualOperation(key);
    if (current) manualContextOwners.set(key, manualContextOwnerSummary(current));
  }
  // Read-only inside the existing command writer: no nested auth mutation or Finish callback.
  const workAllowed = SellerAgentsControlClient.canContinueCached(binding?.ai_id);
  const grant = (await SellerAgentsControlClient.getCachedContinuationState(binding?.ai_id)).authority;
  const ownerActive = !ownerIdentity || current?.operation_id === ownerIdentity.operation_id && manualOperationActive(current) &&
    [...SellerAgentsExecutionContext.fields, ...SellerAgentsExecutionContext.authorityFields].every(field => current.execution_context?.[field] === ownerIdentity.execution_context[field]);
  return { ...immutable, ...(store ? await saAuthorityStoreContext(store) : p), accountId: store?.accountId || "unavailable",
    scopeKey: grant?.scopeKey || "unavailable", principalEpoch: grant?.principalEpoch ?? -1,
    accessEpoch: grant?.accessEpoch ?? -1, grantEpoch: grant?.grantEpoch ?? -1,
    workGeneration: work.work_generation, aiFamily: binding?.ai_id || "unavailable",
    conversationKey: key, bindingId: binding?.binding_id || "unbound", bindingRevision: binding?.revision || 0,
    workSessionId: work.start_intent_id || "inactive", active: Boolean(workAllowed && store && ownerActive &&
      [OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN, OzonWorkSessionModel.STATES.RECOVERING].includes(work.state)) };
}
function saDispatchAuthorityError(code, deniedGates = []) {
  const error = saAdmissionError(code, deniedGates);
  error.external_request_executed = false;
  return error;
}
function saDispatchFence(snapshot) {
  return Object.freeze({
    accountId: snapshot.accountId,
    generation: snapshot.generation,
    deviceId: snapshot.deviceId,
    sessionId: snapshot.sessionId,
    authorityIdentity: snapshot.authorityIdentity,
    bootstrapSnapshotSha256: snapshot.bootstrapSnapshotSha256,
    tabId: snapshot.tabId,
    origin: snapshot.origin,
    conversationKey: snapshot.conversationKey,
    conversationId: snapshot.conversationId,
    aiFamily: snapshot.aiFamily,
    aiSurface: snapshot.aiSurface,
    aiVariant: snapshot.aiVariant,
    aiProfileKey: snapshot.aiProfileKey,
    aiProfileRevision: snapshot.aiProfileRevision,
    aiProfileScopeVariant: snapshot.aiProfileScopeVariant,
    aiProfileContentSha256: snapshot.aiProfileContentSha256,
    bindingId: snapshot.bindingId,
    bindingRevision: snapshot.bindingRevision,
    marketplace: snapshot.marketplace,
    storeId: snapshot.storeId,
    credentialRevision: snapshot.credentialRevision,
    // Visibility revisions do not revoke an already admitted packet.
    workGeneration: snapshot.workGeneration,
    workStartIntentId: snapshot.workStartIntentId,
    admissionProvenance: snapshot.admissionProvenance,
    localInvalidation: snapshot.localInvalidation,
  });
}
function saSameDispatchFence(left, right) {
  return Boolean(left && right && JSON.stringify(left) === JSON.stringify(right));
}
async function saReadDispatchSnapshot(owner) {
  const key = normalizeConversationKey(owner?.conversation_key);
  const pinned = owner?.execution_context;
  if (!key || !pinned || !owner?.tab_id) throw SellerAgentsExecutionContext.error("EXECUTION_CONTEXT_MISSING");
  if (SellerAgentsExecutionContext.authorityFields.some(field => pinned[field] === undefined))
    throw SellerAgentsExecutionContext.error("EXECUTION_CONTEXT_LEGACY_UNRESOLVED");
  const currentOwner = await getManualOperation(key);
  if (!currentOwner || currentOwner.operation_id !== owner.operation_id || !currentOwner.execution_context ||
      [...SellerAgentsExecutionContext.fields, ...SellerAgentsExecutionContext.authorityFields].some(field => currentOwner.execution_context[field] !== pinned[field]))
    throw SellerAgentsExecutionContext.error();
  const tab = Number(owner.tab_id);
  const identity = await tabIdentity(tab);
  if (!identity?.conversation_id || conversationKeyFromIdentity(identity) !== key)
    throw saDispatchAuthorityError("CONVERSATION_MISMATCH", ["conversation"]);
  const binding = await bindingForConversationKey(key);
  if (!binding?.store_context) throw saDispatchAuthorityError("CONVERSATION_NOT_BOUND", ["binding"]);
  const store = await saAssertStore(binding.store_context);
  const work = await workSessionFor(key);
  OzonWorkSessionModel.assertStorageAvailable();
  if (work.finished || ![OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN].includes(work.state))
    throw saDispatchAuthorityError("WORK_SESSION_NOT_ACTIVE", ["workState"]);
  const cached = await SellerAgentsControlClient.getCachedContinuationState(identity);
  const authority = cached.authority;
  const live = {
    scopeKey: authority?.scopeKey, principalEpoch: authority?.principalEpoch, accessEpoch: authority?.accessEpoch,
    grantEpoch: authority?.grantEpoch, workGeneration: work.work_generation, aiFamily: identity.ai_id,
    accountId: store.accountId, storeId: store.id, marketplace: store.marketplace,
    credentialRevision: store.credentialRevision, conversationKey: key,
    bindingId: binding.binding_id, bindingRevision: Number(binding.revision),
    workSessionId: work.start_intent_id || "inactive",
    policyRevision: store.personalDataEnabled ? "personal-enabled" : "personal-disabled",
    commandHash: pinned.commandHash, requestId: pinned.requestId,
    ...(pinned.authGeneration === undefined ? {} : { authGeneration: await SellerAgentsControlClient.generation() }),
    active: true,
  };
  try { SellerAgentsExecutionContext.assertSame(pinned, live); }
  catch (_) { throw SellerAgentsExecutionContext.error(); }
  const safeTimeMs = await SellerAgentsControlClient.getVerifiedAuthorityTime(identity);
  const payload = authority?.payload || {};
  const profile = payload.ai?.profile || {};
  const accountId = payload.account?.id || null;
  const snapshot = {
    accountId, generation: cached.generation, deviceId: authority?.deviceId || null,
    sessionId: authority?.sessionId || null, authorityIdentity: saAuthorityIdentity(authority),
    bootstrapSnapshotSha256: await saSnapshotDigest(authority?.envelope), tabId: tab,
    origin: identity.origin, conversationKey: key, conversationId: identity.conversation_id,
    aiFamily: identity.ai_id, aiSurface: payload.ai?.detected?.surface || null,
    aiVariant: payload.ai?.detected?.variant ?? null, aiProfileKey: profile.profileKey || null,
    aiProfileRevision: profile.revision ?? null, aiProfileScopeVariant: profile.scopeVariant ?? null,
    aiProfileContentSha256: profile.contentSha256 || null, bindingId: binding.binding_id,
    bindingRevision: Number(binding.revision), marketplace: store.marketplace, storeId: store.id,
    credentialRevision: store.credentialRevision, workState: work.state,
    workGeneration: work.work_generation, workStartIntentId: work.start_intent_id || null,
    admissionProvenance: JSON.stringify(work.admission_provenance || null),
    localInvalidation: JSON.stringify(cached.localInvalidation || {}), safeTimeMs,
    authorityExpiresAt: payload.expiresAt || null,
  };
  return { key, identity, binding, store, work, authority, cacheClock: cached.cacheClock,
    safeTimeMs, current: { accountId, generation: cached.generation, deviceId: snapshot.deviceId,
      sessionId: snapshot.sessionId, aiFamily: identity.ai_id, aiSurface: snapshot.aiSurface,
      aiVariant: snapshot.aiVariant, aiProfileKey: snapshot.aiProfileKey,
      aiProfileRevision: snapshot.aiProfileRevision, aiProfileScopeVariant: snapshot.aiProfileScopeVariant,
      aiProfileContentSha256: snapshot.aiProfileContentSha256, origin: identity.origin,
      conversationId: identity.conversation_id, conversationKey: key, bindingId: binding.binding_id,
      bindingRevision: Number(binding.revision), storeId: store.id, marketplace: store.marketplace,
      credentialRevision: store.credentialRevision, workStartIntentId: work.start_intent_id || null,
      aiProfile: { profileKey: snapshot.aiProfileKey, revision: snapshot.aiProfileRevision, scopeVariant: snapshot.aiProfileScopeVariant, contentSha256: snapshot.aiProfileContentSha256 },
      revoked: cached.localInvalidation?.revoked === true, loggedOut: cached.localInvalidation?.loggedOut === true,
      authReset: cached.localInvalidation?.authReset === true, obsolete: cached.localInvalidation?.obsolete === true,
      storeDeleted: cached.localInvalidation?.storeDeleted === true },
    fence: saDispatchFence(snapshot) };
}
async function saEvaluateDispatchAuthority(owner) {
  let initial;
  try { initial = await saReadDispatchSnapshot(owner); }
  catch (error) {
    if (error?.external_request_executed === false) throw error;
    throw saDispatchAuthorityError("WORK_AUTHORITY_REFRESH_REQUIRED", ["cachedAuthority"]);
  }
  const binding = initial.binding, store = initial.store, work = initial.work;
  const identity = initial.identity, authority = initial.authority;
  await saAssertReconciliationAction(binding, store, initial.key, work.start_intent_id);
  const input = {
    operation: "CONTINUE", work,
    cachedAuthority: authority, cacheClock: initial.cacheClock, safeTimeMs: initial.safeTimeMs,
    identity: { origin: identity.origin, conversationId: identity.conversation_id },
    binding: { binding_id: binding.binding_id, revision: Number(binding.revision), origin: binding.origin,
      ai_id: binding.ai_id, conversation_id: binding.conversation_id, conversation_key: binding.conversation_key,
      store_context: binding.store_context },
    store: { accountId: store.accountId, id: store.id, marketplace: store.marketplace, credentialRevision: store.credentialRevision },
    current: initial.current,
  };
  let decision;
  try { decision = await SellerAgentsAutonomousWorkAuthority.evaluate(input); }
  catch (_) { throw saDispatchAuthorityError("WORK_AUTHORITY_REFRESH_REQUIRED", ["cachedAuthority"]); }
  if (decision.allowed !== true || decision.executionAuthority !== false)
    throw saDispatchAuthorityError(decision.deniedGates?.includes("DENY_CACHE_EXPIRED") ? "WORK_AUTHORITY_REFRESH_REQUIRED" : "WORK_AUTHORITY_DENIED", decision.deniedGates);
  let after;
  try { after = await saReadDispatchSnapshot(owner); }
  catch (error) { if (error?.external_request_executed === false) throw error; throw SellerAgentsExecutionContext.error(); }
  await saAssertReconciliationAction(after.binding, after.store, after.key, after.work.start_intent_id);
  if (!saSameDispatchFence(initial.fence, after.fence))
    throw saDispatchAuthorityError("WORK_AUTHORITY_CONTEXT_CHANGED", ["contextFence"]);
  return decision;
}
async function saSettings(pinned) {
  const store = await saAssertStore(pinned);
  if (store.marketplace !== "ozon") throw saError("WRONG_SETTINGS_PROVIDER");
  return { sellerCredentials: store.credentials.seller, performanceCredentials: store.credentials.performance,
    autoSend: true, personalDataEnabled: store.personalDataEnabled,
    sellerApiMetadata: OzonEntitlements.normalizeSnapshot(null), lastStatus: null };
}
async function saGuard(owner) {
  const p = owner?.execution_context;
  if (!p) throw SellerAgentsExecutionContext.error("EXECUTION_CONTEXT_MISSING");
  // This checkpoint only lets the control client persist a local expiry/invalidation.
  // Its boolean is deliberately ignored; saEvaluateDispatchAuthority is the sole
  // provider predispatch decision and runs again at the provider fetch boundary.
  const binding = await bindingForConversationKey(owner.conversation_key);
  await SellerAgentsControlClient.canWork(binding?.ai_id);
  const readCurrent = () => saReadContext(owner.conversation_key, { commandHash: p.commandHash, requestId: p.requestId }, owner);
  if (owner.payload_expires_at_ms && owner.payload_expires_at_ms <= Date.now()) throw saError("RESULT_EXPIRED");
  const guard = SellerAgentsExecutionContext.createGuard(p, readCurrent);
  await guard.assertCurrent();
  const store = await saAssertStore(p);
  if (p.marketplace === "wildberries") {
    const context = await SellerAgentsWBAdapter.createContext({ snapshot: p, readCurrent, credentials: store.credentials,
      quotaIdentity: { state: store.providerIdentityState, providerAccountId: store.providerAccountId } });
    return Object.freeze({ ...context, async assertDispatchAuthority() { return saEvaluateDispatchAuthority(owner); } });
  }
  const settings = await saSettings(p);
  await guard.assertCurrent();
  return Object.freeze({ ...guard, async assertDispatchAuthority() { return saEvaluateDispatchAuthority(owner); }, async settings() { await guard.assertCurrent(); return settings; } });
}
const SA_SIGNED_PROFILE_ORIGINS = Object.freeze({
  chatgpt: Object.freeze(["https://chatgpt.com", "https://chat.openai.com"]),
  alice: Object.freeze(["https://alice.yandex.ru"]),
  qwen: Object.freeze(["https://chat.qwen.ai"]),
  kimi: Object.freeze(["https://www.kimi.ai"]),
  grok: Object.freeze(["https://grok.com"]),
  gemini: Object.freeze(["https://gemini.google.com"]),
  claude: Object.freeze(["https://claude.ai"]),
  deepseek: Object.freeze(["https://chat.deepseek.com"])
});
function saSignedProfileOriginAllowed(family, origin) {
  const allowed = SA_SIGNED_PROFILE_ORIGINS[family];
  return Array.isArray(allowed) && allowed.includes(origin);
}
function saProfileClone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
function saSignedProfileUnavailable(request, reason) {
  return {
    messageType: "OZ_SIGNED_AI_PROFILE",
    protocolVersion: SellerAgentsSignedAiProfileConsumer.PROTOCOL_VERSION,
    requestId: request.requestId,
    ai: saProfileClone(request.ai),
    status: "UNAVAILABLE",
    reason
  };
}
function saSignedProfileSender(sender, family) {
  if (sender?.id !== chrome.runtime.id || sender?.frameId !== 0 || !Number.isSafeInteger(sender?.tab?.id)) return null;
  if (typeof sender.documentId !== "string" || !/^[A-Za-z0-9._:-]{1,256}$/.test(sender.documentId)) return null;
  try {
    const url = new URL(sender.url || sender.tab.url || "");
    const origin = url.origin.toLowerCase();
    if (!saSignedProfileOriginAllowed(family, origin)) return null;
    return { tabId: Number(sender.tab.id), documentId: sender.documentId, origin };
  } catch (_) { return null; }
}
function saSignedProfileIdentity(profile) {
  return {
    profileKey: profile?.profileKey || null,
    revision: profile?.revision ?? null,
    scopeVariant: profile?.scopeVariant ?? null,
    contentSha256: profile?.contentSha256 || null
  };
}
function saSignedProfileAuthorityIdentity(generation, authority) {
  return {
    authGeneration: generation,
    bootstrapSnapshotSha256: null,
    authorityIdentity: saAuthorityIdentity(authority)
  };
}
function saSameSignedProfileAuthority(left, right) {
  return Boolean(left && right &&
    left.authGeneration === right.authGeneration &&
    left.bootstrapSnapshotSha256 === right.bootstrapSnapshotSha256);
}
function saSameSignedProfileIdentity(left, right) {
  return Boolean(left && right &&
    left.profileKey === right.profileKey &&
    left.revision === right.revision &&
    left.scopeVariant === right.scopeVariant &&
    left.contentSha256 === right.contentSha256);
}
async function saSignedProfileSnapshot(identity) {
  const generation = await SellerAgentsControlClient.generation();
  const authority = await SellerAgentsControlClient.getAuthority(identity);
  if (!authority) return null;
  const snapshot = saSignedProfileAuthorityIdentity(generation, authority);
  snapshot.bootstrapSnapshotSha256 = await saSnapshotDigest(authority.envelope);
  return { generation, authority, snapshot };
}
async function saSignedProfileSnapshotStillCurrent(captured) {
  if (!captured) return false;
  const current = await saSignedProfileSnapshot(captured.authority?.requestedAi).catch(() => null);
  return Boolean(current &&
    current.generation === captured.generation &&
    current.snapshot.authorityIdentity === captured.snapshot.authorityIdentity &&
    current.snapshot.bootstrapSnapshotSha256 === captured.snapshot.bootstrapSnapshotSha256);
}
async function saSignedProfileRequest(message, sender) {
  const consumer = globalThis.SellerAgentsSignedAiProfileConsumer;
  if (!consumer?.validRequest?.(message)) throw saError("SIGNED_PROFILE_REQUEST_INVALID");
  const trusted = saSignedProfileSender(sender, message.ai.family);
  if (!trusted) throw saError("SIGNED_PROFILE_SENDER_UNTRUSTED");

  let identity;
  try { identity = await tabIdentity(trusted.tabId); }
  catch (_) { return saSignedProfileUnavailable(message, "AI_SCOPE_MISMATCH"); }
  if (identity?.ai_id !== message.ai.family || String(identity.origin || "").toLowerCase() !== trusted.origin)
    return saSignedProfileUnavailable(message, "AI_SCOPE_MISMATCH");

  const captured = await saSignedProfileSnapshot(identity).catch(() => null);
  if (!captured) return saSignedProfileUnavailable(message, "NO_VERIFIED_AUTHORITY");
  if (!await SellerAgentsControlClient.canWork(identity)) return saSignedProfileUnavailable(message, "WORK_NOT_ALLOWED");

  const payload = captured.authority?.payload;
  const detected = payload?.ai?.detected;
  const profile = payload?.ai?.profile;
  if (payload?.ai?.status !== "RESOLVED" || !detected || !profile)
    return saSignedProfileUnavailable(message, "NO_VERIFIED_AUTHORITY");
  if (captured.authority?.requestedAi !== message.ai.family ||
      detected.family !== message.ai.family || detected.surface !== "web" || detected.variant !== null ||
      message.ai.surface !== detected.surface || message.ai.variant !== detected.variant)
    return saSignedProfileUnavailable(message, "AI_SCOPE_MISMATCH");
  if (!await consumer.validMaterial(profile)) return saSignedProfileUnavailable(message, "PROFILE_UNSUPPORTED");
  if (!await saSignedProfileSnapshotStillCurrent(captured))
    return saSignedProfileUnavailable(message, "AUTHORITY_CHANGED");

  const response = {
    messageType: "OZ_SIGNED_AI_PROFILE",
    protocolVersion: consumer.PROTOCOL_VERSION,
    requestId: message.requestId,
    ai: saProfileClone(message.ai),
    status: "AVAILABLE",
    authority: {
      authGeneration: captured.generation,
      bootstrapSnapshotSha256: captured.snapshot.bootstrapSnapshotSha256
    },
    profile: saProfileClone(profile)
  };
  if (!await consumer.validResponse(response)) return saSignedProfileUnavailable(message, "PROFILE_UNSUPPORTED");
  if (!await SellerAgentsControlClient.canWork(identity) || !await saSignedProfileSnapshotStillCurrent(captured))
    return saSignedProfileUnavailable(message, "AUTHORITY_CHANGED");
  return response;
}
async function saSignedProfileReceipt(message, sender) {
  const consumer = globalThis.SellerAgentsSignedAiProfileConsumer;
  if (!consumer?.validReceipt?.(message)) throw saError("SIGNED_PROFILE_RECEIPT_INVALID");
  const trusted = saSignedProfileSender(sender, message.ai.family);
  if (!trusted) throw saError("SIGNED_PROFILE_SENDER_UNTRUSTED");
  let identity;
  try { identity = await tabIdentity(trusted.tabId); }
  catch (_) { return { ok: false, accepted: false, code: "AI_SCOPE_MISMATCH" }; }
  if (identity?.ai_id !== message.ai.family || String(identity.origin || "").toLowerCase() !== trusted.origin)
    return { ok: false, accepted: false, code: "AI_SCOPE_MISMATCH" };

  if (message.status === "REJECTED") return { ok: true, accepted: true };
  const captured = await saSignedProfileSnapshot(identity).catch(() => null);
  const canWork = captured ? await SellerAgentsControlClient.canWork(identity) : false;
  const payload = captured?.authority?.payload;
  const detected = payload?.ai?.detected;
  const profile = payload?.ai?.profile;
  const scopeMatches = Boolean(detected &&
    detected.family === message.ai.family && detected.surface === message.ai.surface && detected.variant === message.ai.variant &&
    captured?.authority?.requestedAi === message.ai.family);

  if (message.status === "CLEARED") {
    const latest = await saSignedProfileSnapshot(identity).catch(() => null);
    if (!latest) return { ok: true, accepted: true };
    const latestCanWork = await SellerAgentsControlClient.canWork(identity);
    const latestPayload = latest.authority?.payload;
    const latestDetected = latestPayload?.ai?.detected;
    const latestProfile = latestPayload?.ai?.profile;
    const latestScopeMatches = Boolean(latestDetected &&
      latestDetected.family === message.ai.family && latestDetected.surface === message.ai.surface &&
      latestDetected.variant === message.ai.variant && latest.authority?.requestedAi === message.ai.family);
    const latestMaterialValid = Boolean(latestCanWork && latestScopeMatches &&
      latestPayload?.ai?.status === "RESOLVED" && latestProfile && await consumer.validMaterial(latestProfile));
    if (!await saSignedProfileSnapshotStillCurrent(latest))
      return { ok: false, accepted: false, code: "STALE_REQUEST" };
    if (latestMaterialValid) return { ok: false, accepted: false, code: "STALE_REQUEST" };
    return { ok: true, accepted: true };
  }
  if (!captured || !canWork || !scopeMatches || payload?.ai?.status !== "RESOLVED" || !profile ||
      !await consumer.validMaterial(profile)) return { ok: false, accepted: false, code: "STALE_REQUEST" };
  if (!await SellerAgentsControlClient.canWork(identity) || !await saSignedProfileSnapshotStillCurrent(captured))
    return { ok: false, accepted: false, code: "STALE_REQUEST" };

  const currentAuthority = {
    authGeneration: captured.generation,
    bootstrapSnapshotSha256: captured.snapshot.bootstrapSnapshotSha256
  };
  if (!saSameSignedProfileAuthority(message.authority, currentAuthority) ||
      !saSameSignedProfileIdentity(message.profile, saSignedProfileIdentity(profile)))
    return { ok: false, accepted: false, code: "STALE_REQUEST" };
  return { ok: true, accepted: true };
}
async function saBroadcastSignedProfileRefresh(reason = "authority_changed") {
  const boundedReason = reason === "profile_changed" ? "profile_changed" : "authority_changed";
  const tabs = await chrome.tabs.query({
    url: ["https://chatgpt.com/*", "https://chat.openai.com/*", "https://alice.yandex.ru/*", "https://chat.qwen.ai/*", "https://www.kimi.ai/*", "https://grok.com/*", "https://gemini.google.com/*", "https://claude.ai/*", "https://chat.deepseek.com/*"]
  }).catch(() => []);
  await Promise.allSettled(tabs.filter(tab => Number.isSafeInteger(tab?.id))
    .map(tab => tabMessage(tab.id, { type: "OZ_SIGNED_AI_PROFILE_REFRESH", reason: boundedReason })));
}

async function saEnsureTabSignedProfile(tabId, fence) {
  if (!Object.hasOwn(SA_SIGNED_PROFILE_ORIGINS, fence?.aiId))
    throw saAdmissionError("SIGNED_PROFILE_NOT_APPLIED");
  const expected = {
    authority: {
      authGeneration: fence.generation,
      bootstrapSnapshotSha256: fence.bootstrapSnapshotSha256
    },
    profile: {
      profileKey: fence.aiProfileKey,
      revision: fence.aiProfileRevision,
      scopeVariant: fence.aiProfileScopeVariant,
      contentSha256: fence.aiProfileContentSha256
    }
  };
  const response = await tabMessage(normalizeTabId(tabId), {
    type: "OZ_SIGNED_AI_PROFILE_ENSURE",
    expected
  }).catch(() => null);
  if (!response?.ok || response.applied !== true ||
      !saSameSignedProfileAuthority(response.authority, expected.authority) ||
      !saSameSignedProfileIdentity(response.profile, expected.profile))
    throw saAdmissionError("SIGNED_PROFILE_NOT_APPLIED");
  return true;
}

async function saPublicContext(key) {
  const binding = key ? await bindingForConversationKey(key) : null;
  const work = key ? await workSessionFor(key) : null;
  const allowed = await SellerAgentsControlClient.canWork(binding?.ai_id);
  return { command_protocol: 2, binding_id: binding?.binding_id || null,
    marketplace: binding?.store_context?.marketplace || "ozon", store_id: binding?.store_context?.storeId || null,
    work_session_id: allowed ? work?.start_intent_id || null : null, work_active: Boolean(allowed && work && ["active_visible", "active_hidden", "recovering"].includes(work.state)),
    button_visible: Boolean(allowed && work?.state === "active_visible"), assistant_baseline_ids: allowed ? binding?.assistant_baseline_ids || [] : [] };
}
async function saInvalidateStore(id) {
  await Promise.allSettled(saCancelAdmissionsForStore(id));
  const bindings = await getConversationBindings();
  for (const [key, raw] of Object.entries(bindings)) {
    if (raw.store_context?.storeId !== id) continue;
    const work = await workSessionFor(key);
    if (["active_visible", "active_hidden", "error"].includes(work.state))
      await saLegacyMessage({ type: "OZ_WORK_FINISH", conversation_key: key, tab_id: work.tab_id }, {});
  }
  const pending = await getPendingWorkStarts();
  for (const [tab, start] of Object.entries(pending)) if (start.store_context?.storeId === id)
    await clearPendingWorkStart(Number(tab), start.intent_id, start.revision, "store_changed");
}
async function saInvalidateAuthority(nextAuthority = null, reason = null, scopeNotice = null) {
  const waits = [];
  for (const token of saAdmissionEpochs.values()) {
    if (scopeNotice?.requestedAi && (token.expectedAi || token.requestedAi) !== scopeNotice.requestedAi) continue;
    // Preparation owns an intent, not an admitted profile. Resolving the AI
    // within the same verified account/session must not cancel its own Start.
    // Existing admitted work always loses its old authority.
    const samePreparingAccount = token.operation === "prepare_start"
      && nextAuthority?.verified === true && nextAuthority?.workAllowed === true
      && token.accountId && token.accountId === nextAuthority.payload?.account?.id
      && token.deviceId && token.deviceId === nextAuthority.deviceId
      && token.sessionId && token.sessionId === nextAuthority.sessionId;
    // A new grant never upgrades an already captured command/admission generation.
    if (!samePreparingAccount || token.generation !== nextAuthority.generation) {
      token.cancelled = true;
    }
    if (token.mutationFlight) waits.push(token.mutationFlight);
  }
  await Promise.allSettled(waits);
  const bindings = await getConversationBindings();
  for (const [key, raw] of Object.entries(bindings)) {
    if (scopeNotice?.requestedAi && raw.ai_id !== scopeNotice.requestedAi) continue;
    const work = await workSessionFor(key);
    if (["active_visible", "active_hidden", "recovering", "error"].includes(work.state)) {
      try { await saLegacyMessage({ type: "OZ_WORK_FINISH", conversation_key: key, tab_id: work.tab_id }, {}); } catch (_) { /* the context guard remains closed */ }
    }
  }
  const pending = await getPendingWorkStarts();
  for (const [tab, start] of Object.entries(pending)) {
    if (scopeNotice?.requestedAi && start.ai_id !== scopeNotice.requestedAi) continue;
    try { await clearPendingWorkStart(Number(tab), start.intent_id, start.revision, "authority_changed"); } catch (_) { /* stale pending state is harmless */ }
  }
}
SellerAgentsControlClient.onAuthorityChanged(async (authority, reason, generation, scopeNotice) => {
  if (reason !== "profile_changed") await saInvalidateAuthority(authority, reason, scopeNotice);
  queueMicrotask(() => { void saBroadcastSignedProfileRefresh(reason); });
});
function saSupportCode(value) {
  const code = typeof value === "string" ? value : "";
  return /^[A-Z][A-Z0-9_]{0,79}$/.test(code) ? code : null;
}
function saSupportToken(value) {
  const token = typeof value === "string" ? value : "";
  return /^[a-z][a-z0-9_]{0,39}$/.test(token) ? token : null;
}
const SA_SUPPORT_TRANSPORT_CLASSES = new Set([
  "NO_RECEIVER",
  "PORT_CLOSED",
  "TAB_GONE",
  "CONTEXT_INVALIDATED",
  "SYNC_SEND_EXCEPTION",
  "OTHER_TAB_MESSAGE_ERROR",
  "RESPONSE_TIMEOUT"
]);
function saSupportTransportClass(value) {
  const transportClass = typeof value === "string" ? value : "";
  return SA_SUPPORT_TRANSPORT_CLASSES.has(transportClass) ? transportClass : null;
}
// Only known lifecycle reasons are translated; never expose arbitrary reason text.
function saPendingStartDiagnostic(row) {
  if (row.reason === "bound_after_first_response") return { stage: "active", code: null, outcome: "active" };
  if (row.reason === "operator_finish") return { stage: "finished", code: null, outcome: "finished" };
  const reasons = {
    response_timeout: ["failed", "WORK_PENDING_TIMEOUT"],
    identity_mismatch: ["failed", "WORK_PENDING_IDENTITY_MISMATCH"],
    surface_changed: ["cancelled", "WORK_PENDING_SURFACE_CHANGED"],
    conversation_changed: ["cancelled", "WORK_PENDING_CONVERSATION_CHANGED"],
    store_changed: ["cancelled", "WORK_PENDING_STORE_CHANGED"],
    authority_changed: ["cancelled", "WORK_PENDING_AUTHORITY_CHANGED"],
    content_cancelled: ["cancelled", "WORK_PENDING_CONTENT_CANCELLED"],
    tab_closed: ["cancelled", "WORK_PENDING_TAB_CLOSED"],
    binding_failed: ["failed", "WORK_PENDING_BIND_FAILED"],
    send_failed_before_commit: ["failed", "WORK_START_SEND_FAILED"],
    send_failed_before_irreversible_click: ["failed", "WORK_START_SEND_FAILED"],
  };
  const known = Object.hasOwn(reasons, row.reason) ? reasons[row.reason] : null;
  return {
    stage: "terminal",
    code: known?.[1] || saSupportCode(row.code) || saSupportCode(row.reason) || "WORK_PENDING_TERMINATED",
    outcome: known?.[0] || "failed",
  };
}
async function saLastStartDiagnostic(tabId = null) {
  const requestedTab = tabId == null ? null : Number(tabId);
  const targetTab = Number.isInteger(requestedTab) && requestedTab > 0 ? requestedTab : null;
  if (tabId != null && targetTab == null) return null;
  let rows = [];
  try {
    const data = await storageGet(KEYS.DIAGNOSTICS);
    rows = Array.isArray(data[KEYS.DIAGNOSTICS]) ? data[KEYS.DIAGNOSTICS] : [];
  } catch (_) { return null; }
  for (let index = rows.length - 1; index >= 0; index -= 1) {
    const row = rows[index] || {};
    if (targetTab != null && Number(row.tab_id) !== targetTab) continue;
    const event = String(row.event || "");
    if (event === "WORK_PENDING_START_TERMINAL") return saPendingStartDiagnostic(row);
    if (event === "WORK_PENDING_START_CANCELLED_TAB_CLOSED") {
      return saPendingStartDiagnostic({ reason: "tab_closed" });
    }
    if (event === "WORK_START_ACTIVE_VISIBLE") return { stage: "active", code: null, outcome: "active" };
    if (event === "WORK_START_ACTION_RESULT") {
      return {
        stage: saSupportToken(row.stage) || "request",
        code: saSupportCode(row.code),
        outcome: saSupportToken(row.outcome) || "unknown",
      };
    }
    if (event === "WORK_START_ASYNC_DISPATCH_FAILED" || event === "WORK_START_SEND_FAILED") {
      return { stage: event === "WORK_START_SEND_FAILED" ? "send" : "dispatch", code: saSupportCode(row.code), outcome: "failed" };
    }
    if (event === "WORK_START_CONTENT_RESPONSE_LOST_NO_RETRY") {
      return {
        stage: "send",
        code: saSupportCode(row.code),
        outcome: "unknown_no_retry",
        transportClass: saSupportTransportClass(row.transport_class),
      };
    }
    if (event === "WORK_START_SEND_OUTCOME" && saSupportToken(row.send_outcome)) {
      return { stage: "send", code: saSupportCode(row.code), outcome: saSupportToken(row.send_outcome) };
    }
    if (event === "WORK_START_CORRELATION_ACCEPTED") return { stage: "correlation", code: null, outcome: "pending" };
    if (event === "WORK_START_BINDING") return { stage: "binding", code: null, outcome: "pending" };
    if (event === "WORK_START_PENDING_CREATED") return { stage: "pending", code: null, outcome: "pending" };
    if (event === "WORK_START_REQUESTED") return { stage: "requested", code: null, outcome: "pending" };
  }
  return null;
}
// Only a stage/booleans projection for the exact currently pending attempt.
// No prompt, response body, conversation, account, session, or intent identifiers.
async function saStartDispatchProgress(tabId, pending) {
  if (!pending?.intent_id || !Number.isInteger(Number(tabId))) return null;
  let rows;
  try {
    const data = await storageGet(KEYS.DIAGNOSTICS);
    rows = Array.isArray(data[KEYS.DIAGNOSTICS]) ? data[KEYS.DIAGNOSTICS] : [];
  } catch (_) { return null; }
  for (let index = rows.length - 1; index >= 0; index -= 1) {
    const row = rows[index];
    if (Number(row?.tab_id) !== Number(tabId) || row.intent_id !== pending.intent_id ||
        Number(row.revision) !== Number(pending.revision)) continue;
    const stage = row.event === "WORK_START_CONTENT_DISPATCHED" ? "content_requested" :
      row.event === "WORK_START_DISPATCH_PROGRESS" ? row.stage : null;
    if (!["guard_enter", "guard_passed", "content_requested", "content_response"].includes(stage)) continue;
    return {
      stage,
      pendingGuardPassed: stage !== "guard_enter",
      promptReady: ["content_requested", "content_response"].includes(stage),
      responseReceived: stage === "content_response",
      responseOk: stage === "content_response" ? row.response_ok === true : null,
      responseSent: stage === "content_response" ? row.response_sent === true : null,
      recordedAt: typeof row.at === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(row.at) ? row.at : null,
    };
  }
  return null;
}
async function saSupportSnapshot(tabId) {
  const popup = await saPopupState(tabId);
  const observed = globalThis.SellerAgentsBrowserIdentity?.current?.() || {};
  const stores = Array.isArray(popup.stores) ? popup.stores : [];
  const consent = await globalThis.SellerAgentsTechnicalDataConsent?.consent?.().catch(() => ({ applicable: true, granted: false }));
  const includeTechnical = !consent?.applicable || consent.granted === true;
  const family = globalThis.SellerAgentsBrowserIdentity?.families?.includes(observed.family) ? observed.family : null;
  const version = typeof observed.version === "string" && /^\d+(?:\.\d+){0,3}$/.test(observed.version) ? observed.version : null;
  const workState = saSupportToken(popup.work?.state);
  const detectedAiFamily = popup.identity?.ai_id || popup.page?.aiFamily;
  const aiFamily = ["chatgpt", "alice", "qwen", "kimi", "grok", "gemini", "claude", "deepseek"].includes(detectedAiFamily) ? detectedAiFamily : null;
  const lastStart = popup.lastStart || null;
  return Object.freeze({
    snapshotVersion: "seller_agents_support_snapshot_v1",
    generatedAt: new Date().toISOString(),
    extension: includeTechnical ? {
      version: String(globalThis.SellerAgentsControlConfig?.extensionVersion || ""),
      environment: String(globalThis.SellerAgentsControlConfig?.environment || ""),
    } : { environment: String(globalThis.SellerAgentsControlConfig?.environment || "") },
    ...(includeTechnical ? { browser: { family, version, evidence: "OBSERVED_RUNTIME_ONLY" } } : {}),
    auth: {
      authenticated: popup.auth?.authenticated === true,
      workAllowed: popup.auth?.workAllowed === true,
      lastErrorCode: saSupportCode(popup.auth?.lastError?.code),
      bootstrapRejection: popup.auth?.lastError?.bootstrapDiagnostic || null,
      bootstrapRetryAvailable: popup.auth?.bootstrapRetryAvailable === true,
      aiStatus: saSupportToken(popup.auth?.authority?.aiStatus),
      compatibility: popup.auth?.compatibility ? {
        extensionStatus: saSupportCode(popup.auth.compatibility.extension?.status),
        minimumExtensionVersion: typeof popup.auth.compatibility.extension?.minimumVersion === "string" && /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.test(popup.auth.compatibility.extension.minimumVersion) ? popup.auth.compatibility.extension.minimumVersion : null,
        browserStatus: saSupportCode(popup.auth.compatibility.browser?.status),
      } : null,
    },
    page: { aiFamily, identityStatus: saSupportToken(popup.identity?.status),
      runtimeStatus: saSupportToken(popup.page?.runtimeStatus),
      lastErrorCode: saSupportCode(popup.page?.errorCode),
      transportClass: safeTabMessageTransportClass(popup.page?.transportClass) },
    work: {
      state: workState,
      pending: Boolean(popup.pending),
      pendingOutcome: saSupportToken(popup.pending?.send_outcome),
      lastStart,
      dispatchProgress: popup.dispatchProgress || null,
    },
    stores: {
      total: stores.length,
      ozon: stores.filter(store => store?.marketplace === "ozon").length,
      wildberries: stores.filter(store => store?.marketplace === "wildberries").length,
    },
    privacy: {
      accountIdentifiersIncluded: false,
      deviceSessionIdentifiersIncluded: false,
      storeIdentifiersIncluded: false,
      credentialsIncluded: false,
      conversationIdentifiersIncluded: false,
      marketplacePayloadIncluded: false,
    },
  });
}
async function saRefreshConversationSnapshot(conversationKey) {
  if (!conversationKey || !globalThis.SellerAgentsSyncJournal?.syncConversationSnapshot) return null;
  try {
    const binding = await bindingForConversationKey(conversationKey);
    let store = null;
    if (binding?.store_context?.storeId) {
      try { store = await saCatalog.get(binding.store_context.storeId); } catch (_) {}
    }
    const work = await workSessionFor(conversationKey);
    return await SellerAgentsSyncJournal.syncConversationSnapshot({
      conversationKey,
      binding,
      store,
      workGeneration: work?.start_intent_id || null,
      reason: "popup_open",
    });
  } catch (_) { return null; }
}
async function saPopupState(tabId) {
  void globalThis.SellerAgentsTechnicalScheduler?.wake?.("popup_open");
  let live = { ai_id: null, origin: null, conversation_id: null, status: "unavailable", source: "none", chat_path: "" };
  let usableIdentity = false, page = null;
  try {
    live = await tabIdentity(normalizeTabId(tabId));
    usableIdentity = true;
    page = { supported: true, aiFamily: live.ai_id, runtimeStatus: "ready", errorCode: null, transportClass: null };
  } catch (error) { page = await saUnavailablePage(tabId, error); }
  const key = usableIdentity && live.conversation_id ? conversationKeyFromIdentity(live) : null;
  const pending = usableIdentity ? (await getPendingWorkStarts())[String(tabId)] || null : null;
  const lastStart = await saLastStartDiagnostic(tabId);
  const dispatchProgress = await saStartDispatchProgress(tabId, pending);
  const auth = await SellerAgentsControlClient.status(usableIdentity ? live : null);
  const work = key ? await workSessionFor(key) : null;
  if (auth.authenticated && key) void saRefreshConversationSnapshot(key);
  const context = await saPublicContext(key);
  const publicWork = work ? { ...work,
    can_resume: auth.workAllowed && OzonWorkSessionModel.canResume(work),
    state: auth.workAllowed ? work.state : OzonWorkSessionModel.STATES.INACTIVE,
  } : null;
  let stores = [];
  if (auth.authenticated) stores = await saCatalog.list();
  return { ok: true, auth, pending: pending ? { intent_id: pending.intent_id, send_outcome: pending.send_outcome, expires_at: pending.expires_at } : null, stores,
    account: auth.account || { kind: "signed_out", label: "Вход не выполнен" },
    identity: live, page, conversation_key: key, context, work: publicWork, lastStart, dispatchProgress,
    recovery: key ? await saR3RecoverySummary(key, work) : [],
    operation: key ? publicManualOperation(await getManualOperation(key)) : null };
}
async function saWorkStart(message, sender) {
  OzonWorkSessionModel.assertStorageAvailable();
  try {
    const result = await singleFlight(saWorkFlights, String(message.tab_id), async () => {
    const entry = saBeginAdmission(saAdmissionKey(message.tab_id, null), {
      operation: "prepare_start", tabId: message.tab_id, conversationKey: null,
      store: { id: message.store_id }, intentId: "page-entry"
    });
    try {
    entry.generation = await SellerAgentsControlClient.generation();
    const entryAuthority = await SellerAgentsControlClient.getAuthority();
    entry.accountId = entryAuthority?.payload?.account?.id || null;
    entry.deviceId = entryAuthority?.deviceId || null;
    entry.sessionId = entryAuthority?.sessionId || null;
    entry.requestedAi = entryAuthority?.requestedAi ?? null;
    let identity = await saStartPageIdentity(normalizeTabId(message.tab_id));
    if (identity.source === "history_continuity_unverified") {
      const confirmed = await tabMessage(message.tab_id, { type: "OZ_CONFIRM_CURRENT_SURFACE" });
      if (!confirmed?.ok) throw saError("CONVERSATION_SURFACE_UNAVAILABLE");
      identity = await tabIdentity(normalizeTabId(message.tab_id));
    }
    if (entry.generation !== await SellerAgentsControlClient.generation()) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
    if (!saAdmissionCurrent(entry)) throw saAdmissionError("WORK_ADMISSION_CANCELLED");
    entry.expectedAi = identity.ai_id;
    entry.resolvingIdentity = true;
    try { await SellerAgentsControlClient.ensureForIdentity(identity); }
    finally { entry.resolvingIdentity = false; }
    if (!await SellerAgentsControlClient.canWork(identity)) throw saError("WORK_POLICY_BLOCKED");
    const store = await saCatalog.get(message.store_id);
    const live = await tabIdentity(normalizeTabId(message.tab_id));
    const key = live.conversation_id ? conversationKeyFromIdentity(live) : null;
    const binding = key ? await bindingForConversationKey(key) : null;
    const work = key ? await workSessionFor(key) : null;
    const pending = (await getPendingWorkStarts())[String(message.tab_id)];
    if (pending && String(pending.expires_at || "") > new Date().toISOString())
      return { ok: true, accepted: false, code: "WORK_START_ALREADY_PENDING", pending_start: pending };
    if (binding?.store_context?.storeId === store.id && ["active_visible", "active_hidden"].includes(work?.state))
      return { ok: true, accepted: false, code: "WORK_SESSION_ALREADY_ACTIVE" };
    const changingStore = Boolean(binding?.store_context && binding.store_context.storeId !== store.id);
    if (changingStore && message.confirm_change !== true) throw saError("STORE_CHANGE_CONFIRMATION_REQUIRED");
    const rebindStates = [OzonWorkSessionModel.STATES.INACTIVE, OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN, OzonWorkSessionModel.STATES.ERROR];
    if (changingStore && (!key || !rebindStates.includes(work?.state))) throw saError("WORK_START_ALREADY_IN_PROGRESS");
    if (changingStore && await getManualOperation(key).then(manualOperationActive)) throw saError("WORK_START_ALREADY_IN_PROGRESS");
    const intentId = String(message.start_intent_id || "").trim() || `work-start-${crypto.randomUUID()}`;
    const authority = await SellerAgentsControlClient.getAuthority(live);
    const sourceStore = changingStore ? await saAssertStore(binding.store_context) : null;
    await saAssertReconciliationAction(binding, sourceStore || store, key);
    const plan = changingStore ? saRebindPlan({ tabId: message.tab_id, identity: live, key, binding, work, sourceStore, targetStore: store, intentId, authority }) : null;
    if (key && !changingStore && ![OzonWorkSessionModel.STATES.INACTIVE, OzonWorkSessionModel.STATES.ERROR].includes(work?.state))
      throw saError("WORK_START_ALREADY_IN_PROGRESS");
    if (entry.generation !== await SellerAgentsControlClient.generation()) throw saAdmissionError("WORK_ADMISSION_CONTEXT_CHANGED");
    if (!saAdmissionCurrent(entry)) throw saAdmissionError("WORK_ADMISSION_CANCELLED");
    const promptTree = await saPromptTreeForExchange(live);
    const admission = await saAdmitWork({ operation: "start", tabId: message.tab_id, store, intentId, rebindPlan: plan, entryToken: entry });
    const provenance = await saAdmissionProvenanceSeed(admission, "start", intentId);
    saStarts.set(Number(message.tab_id), await saAuthorityStoreContext(store));
    try {
      return await saRunAdmissionMutation(admission.token, async () => {
        const sourceWorkState = admission.token.fence.workState;
        if (plan && [OzonWorkSessionModel.STATES.ACTIVE_VISIBLE, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN, OzonWorkSessionModel.STATES.ERROR].includes(sourceWorkState)) {
          await saAdmissionMutationGuard({ operation: "start", tabId: message.tab_id, conversationKey: admission.snapshot.key, intentId });
          const finished = await saLegacyMessage({ type: "OZ_WORK_FINISH", tab_id: message.tab_id, conversation_key: key }, sender);
          if (!finished?.ok) throw saAdmissionError(finished?.code || "WORK_REBIND_FINISH_FAILED");
          await saRebindAfterFinishGuard(admission.token);
        }
        await saAdmissionMutationGuard({ operation: "start", tabId: message.tab_id, conversationKey: admission.snapshot.key, intentId });
        await saEnsureTabSignedProfile(message.tab_id, admission.snapshot.fence);
        await saAdmissionMutationGuard({ operation: "start", tabId: message.tab_id, conversationKey: admission.snapshot.key, intentId });
        const started = await saLegacyMessage({ type: "OZ_WORK_START", tab_id: message.tab_id, start_intent_id: intentId, admission_provenance: provenance, prompt_tree: promptTree.pin }, sender);
        return { ...started, prompt_tree_available: promptTree.available, prompt_tree_warning: promptTree.warning };
      });
    } finally { saReleaseAdmission(admission.token); saStarts.delete(Number(message.tab_id)); }
    } finally { saReleaseAdmission(entry); }
    });
    const accepted = result?.accepted === true;
    const code = saSupportCode(result?.code);
    await diagnostic("WORK_START_ACTION_RESULT", {
      tab_id: Number(message.tab_id),
      stage: accepted ? "accepted" : result?.accepted === false ? "not_accepted" : "request",
      code,
      outcome: accepted ? "pending" : result?.accepted === false ? "blocked" : result?.ok === false ? "failed" : "unknown",
      external_request_executed: false,
    });
    return result;
  } catch (error) {
    await diagnostic("WORK_START_ACTION_RESULT", {
      tab_id: Number.isInteger(Number(message?.tab_id)) ? Number(message.tab_id) : null,
      stage: "rejected",
      code: saSupportCode(error?.code) || "WORK_START_FAILED",
      outcome: "failed",
      external_request_executed: false,
    });
    throw error;
  }
}
async function saWorkResume(message, sender) {
  OzonWorkSessionModel.assertStorageAvailable();
  return singleFlight(saWorkFlights, String(message.tab_id), async () => {
    const tab = normalizeTabId(message.tab_id);
    const identity = await tabIdentity(tab);
    const key = identity.conversation_id ? conversationKeyFromIdentity(identity) : null;
    if (!key || key !== normalizeConversationKey(message.conversation_key)) throw saAdmissionError("CONVERSATION_MISMATCH");
    const resumableWork = await workSessionFor(key);
    if (!OzonWorkSessionModel.canResume(resumableWork)) throw saError(
      resumableWork.finished ? "WORK_SESSION_FINISHED" : "WORK_RESUME_UNPROVEN");
    await SellerAgentsControlClient.ensureForIdentity(identity);
    const binding = await bindingForConversationKey(key);
    if (!binding?.store_context) throw saAdmissionError("CONVERSATION_NOT_BOUND");
    const store = await saAssertStore(binding.store_context);
    await saAssertReconciliationAction(binding, store, key);
    const work = await workSessionFor(key);
    if (!OzonWorkSessionModel.canResume(work)) throw saError(work.finished ? "WORK_SESSION_FINISHED" : "WORK_RESUME_UNPROVEN");
    if (await getManualOperation(key).then(manualOperationActive)) throw saError("WORK_RESUME_OPERATION_ACTIVE");
    const intentId = `resume-${crypto.randomUUID()}`;
    const admission = await saAdmitWork({ operation: "resume", tabId: tab, store, intentId, conversationKey: key });
    const provenance = await saAdmissionProvenanceSeed(admission, "resume", intentId);
    try {
      await saAdmissionMutationGuard({ operation: "resume", tabId: tab, conversationKey: key });
      await saEnsureTabSignedProfile(tab, admission.snapshot.fence);
      await saAdmissionMutationGuard({ operation: "resume", tabId: tab, conversationKey: key });
      return await saRunAdmissionMutation(admission.token, () => saLegacyMessage({ type: "OZ_WORK_RESUME", tab_id: tab, conversation_key: key, admission_provenance: provenance }, sender));
    } finally { saReleaseAdmission(admission.token); }
  });
}
async function saHandleMessage(message, sender) {
  if (message?.type === "OZ_QWEN_READ_CODE") return saReadQwenCode(message, sender);
  const enabled = await saEnabled();
  if (enabled && message?.type === "OZ_CONTENT_READY" && sender?.tab?.id && message.identity) {
    const identity = await saResolveSurfaceIdentity(Number(sender.tab.id), normalizeIdentity(message.identity));
    if (identity.status !== "confirmed") return { ok: false, code: "CONVERSATION_NOT_CONFIRMED" };
    message = { ...message, identity };
  }
  if (message?.messageType === "OZ_REQUEST_SIGNED_AI_PROFILE") return saSignedProfileRequest(message, sender);
  if (message?.messageType === "OZ_SIGNED_AI_PROFILE_RECEIPT") return saSignedProfileReceipt(message, sender);
  if (enabled && ["OZ_WORK_RESUME", "OZ_WORK_START"].includes(message?.type)) throw saError("LEGACY_ACTION_DISABLED");
  if (/^OZ_(?:SAVE_|RESET_|CLEAR_|SET_|GET_SETTINGS_STATE|GET_GLOBAL_SETTINGS_STATE|GET_DIAGNOSTICS|BIND_CONVERSATION|TEST_CONNECTION|REFRESH_SELLER_API_METADATA|WORK_START$|WORK_SHOW$|WORK_HIDE$|WORK_FINISH$|WORK_REFRESH$|WORK_RESUME$)/.test(message?.type || "") && !saPopupSender(sender)) throw saError("POPUP_SENDER_REQUIRED");
  if (/^OZ_AUTO_/.test(message?.type || "")) throw saError("LEGACY_ACTION_DISABLED");
  if (message?.type?.startsWith("SA_")) {
    if (!saPopupSender(sender) && !saBackupImportSender(sender, message.type)) throw saError("POPUP_SENDER_REQUIRED");
    if (message.type === "SA_AUTH_STATE") return { ok: true, auth: await SellerAgentsControlClient.status() };
    if (message.type === "SA_AUTH_START") return { ok: true, auth: await SellerAgentsControlClient.startActivation() };
    if (message.type === "SA_AUTH_OPEN_PORTAL") return { ok: true, portalUrl: await SellerAgentsControlClient.openPortal() };
    if (message.type === "SA_AUTH_CANCEL") return { ok: true, auth: await SellerAgentsControlClient.cancelActivation() };
    if (message.type === "SA_AUTH_RESET") return { ok: true, auth: await SellerAgentsControlClient.localReset() };
    await saInitialize();
    switch (message.type) {
      case "SA_POPUP_STATE": return saPopupState(message.tab_id);
      case "SA_SUPPORT_SNAPSHOT": return { ok: true, snapshot: await saSupportSnapshot(message.tab_id) };
      case "SA_STORE_SAVE": {
        const old = message.store?.id ? await saCatalog.get(message.store.id) : null;
        const saved = await saCatalog.save(message.store);
        if (old && (old.credentialRevision !== saved.credentialRevision || old.personalDataEnabled !== saved.personalDataEnabled)) await saInvalidateStore(saved.id);
        void saRecordStoreMetadata(saved);
        return { ok: true, store: saved };
      }
      case "SA_STORE_DELETE":
        if (message.confirm !== true) throw saError("DELETE_CONFIRMATION_REQUIRED");
        const deletedStore = await saCatalog.get(message.store_id);
        await saCatalog.remove(message.store_id);
        await saInvalidateStore(message.store_id);
        void saRecordStoreTombstone({ ...deletedStore, lifecycleState: "TOMBSTONED", credentials: {}, credentialsStale: true, metadataRevision: (deletedStore.metadataRevision || 0) + 1 });
        return { ok: true };
      case "SA_BACKUP_EXPORT": return saBackupExport(message);
      case "SA_BACKUP_PREVIEW": return saBackupPreview(message);
      case "SA_BACKUP_IMPORT": return saBackupImport(message);
      case "SA_WORK_START": return saWorkStart(message, sender);
      case "SA_WORK_RESUME": return saWorkResume(message, sender);
      case "SA_R3_RETRY_REVIEW": return saR3RetryReview(message);
      case "SA_R3_RETRY_PREVIEW": return saR3RetryPreview(message);
      case "SA_R3_RETRY_CONFIRM": return saR3RetryConfirm(message);
      case "SA_R3_COPY_PREVIEW": return saR3CopyPreview(message);
      case "SA_R3_COPY_CONFIRM": return saR3CopyConfirm(message);
      case "SA_STORE_CHECK": return saCheckStore(message);
      case "SA_TRANSFER_CREATE": {
        const request = await SellerAgentsControlClient.createCredentialTransfer({ consent: message.consent === true, sourceDeviceId: message.sourceDeviceId || null, selectedStoreIds: message.selectedStoreIds || [], expiresInSeconds: message.expiresInSeconds || 300 });
        return { ok: true, request };
      }
      case "SA_TRANSFER_SOURCE_DISCOVER": {
        const requests = await SellerAgentsControlClient.listCredentialTransfers();
        const sent = [];
        for (const transferRequest of requests) {
          try { sent.push(await saTransferSourceSend({ request: transferRequest })); }
          catch (error) { sent.push({ ok: false, requestId: transferRequest.requestId, code: error?.code || "TRANSFER_INVALID" }); }
        }
        return { ok: true, requests, sent };
      }
      case "SA_TRANSFER_SOURCE_SEND": return saTransferSourceSend(message);
      case "SA_TRANSFER_RECEIVE": return saTransferReceive(message);
      case "SA_TRANSFER_RECEIVE_PENDING": {
        let pending = null;
        for (const local of await SellerAgentsControlClient.listCredentialTransferRecipients()) {
          try {
            if (local.phase === "ACKED_RESULT" && local.result) { pending = { ok: true, ...local.result, recovered: true }; break; }
            if (local.phase === "IMPORTED_PENDING_ACK" && local.packetId && local.result) {
              await SellerAgentsControlClient.acknowledgeCredentialTransfer({ requestId: local.requestId, packetId: local.packetId, importDecision: "IMPORTED" });
              pending = { ok: true, ...local.result, recovered: true }; break;
            }
            const request = await SellerAgentsControlClient.readCredentialTransfer(local.requestId);
            if (["EXPIRED", "CANCELLED"].includes(request?.state)) { await SellerAgentsControlClient.discardCredentialTransfer(local.requestId); continue; }
            if (request?.state === "COMPLETED") { await SellerAgentsControlClient.discardCredentialTransfer(local.requestId); continue; }
            if (request?.state === "PACKET_AVAILABLE_EPHEMERAL" || request?.state === "DELIVERED_TO_RECIPIENT") { pending = await saTransferReceive({ request }); break; }
          } catch (error) {
            if (local.phase === "IMPORTED_PENDING_ACK" && local.packetId &&
                local.result?.requestId === local.requestId) {
              if (error?.code === "TRANSFER_ACK_TERMINAL" &&
                  ["CANCELLED", "EXPIRED"].includes(error?.detail?.state)) {
                // Only the client can certify a terminal readback bound to
                // the same account, device, request, key and store selection.
                await SellerAgentsControlClient.discardCredentialTransfer(local.requestId);
                pending = { ok: false, code: error.detail.state === "EXPIRED" ? "TRANSFER_EXPIRED" : "TRANSFER_REPLAY",
                            importState: error.detail.state, ackConfirmed: false };
                break;
              }
              if (["TRANSFER_ACK_UNCONFIRMED", "TRANSFER_REQUEST_MISMATCH"].includes(error?.code)) {
                // The imported result stays private and durable. No ACK and
                // no second import are inferred from a lost relay response.
                pending = { ok: false, code: error.code, importState: "IMPORTED_PENDING_ACK",
                            requestId: local.requestId, recovered: true, ackConfirmed: false };
                if (error.code === "TRANSFER_ACK_UNCONFIRMED") pending.result = local.result;
                break;
              }
              // All other ACK failures lack an identity-bound terminal
              // verdict. Keep the durable local import until exact confirmed
              // completion/cancellation/expiry or an owner-authorized reset.
              // Hide even sanitized store results on auth or transport errors.
              pending = { ok: false, code: typeof error?.code === "string" ? error.code : "TRANSFER_ACK_UNCONFIRMED",
                          importState: "PENDING", ackConfirmed: false };
              break;
            }
            if (["TRANSFER_EXPIRED", "TRANSFER_REPLAY", "TRANSFER_ACCOUNT_MISMATCH"].includes(error?.code)) await SellerAgentsControlClient.discardCredentialTransfer(local.requestId).catch(() => null);
            else if (error?.code === "SOURCE_OFFLINE") pending = { ok: false, code: error.code, importState: "SOURCE_OFFLINE" };
            else if (error?.code === "TRANSFER_CREDENTIALS_MISSING") pending = { ok: false, code: error.code, importState: "EMPTY_TRANSFER" };
          }
        }
        return pending || { ok: false, importState: "PENDING" };
      }
      case "SA_TRANSFER_RESULT_CONSUME": {
        const result = await SellerAgentsControlClient.consumeCredentialTransferResult(message.requestId);
        return { ok: true, requestId: result.requestId };
      }
      case "SA_RESUME_QUOTA": {
        await saAssertLocalAuthorityAdmission();
        const state = await saPopupState(message.tab_id), key = state.conversation_key;
        const owner = await getManualOperation(key);
        if (!owner || owner.batch?.request_state !== "quota_waiting") throw saError("NO_QUOTA_WAIT");
        await assertManualBatchContext(key, owner.operation_id);
        launchBatchProcessor("manual", key, owner.operation_id, "explicit_quota_resume");
        return { ok: true };
      }
      default: throw saError("UNKNOWN_MESSAGE");
    }
  }
  if (enabled) {
    const workMessage = message?.type === "OZ_EXECUTE_COMMAND" || message?.type === "OZ_WORK_START" || message?.type?.startsWith("OZ_WORK_START_") || message?.type === "OZ_WORK_PENDING_IDENTITY" || message?.type === "OZ_BATCH_DELIVERY_RESUME";
    if (workMessage) await saAssertLocalAuthorityAdmission();
    if (/^OZ_(?:GET_SETTINGS_STATE|GET_GLOBAL_SETTINGS_STATE|GET_DIAGNOSTICS)/.test(message.type) && !saPopupSender(sender)) throw saError("POPUP_SENDER_REQUIRED");
    if (/^OZ_(?:AUTO_|BIND_CONVERSATION|SAVE_.*SETTINGS|TEST_CONNECTION|SET_MANUAL_MODE|SAVE_REPORT_PREFIX|SAVE_.*START_PROMPT|RESET_.*START_PROMPT|REFRESH_SELLER_API_METADATA)/.test(message?.type || "")) throw saError("LEGACY_ACTION_DISABLED");
    if (["OZ_WORK_DELIVERY_ASSERT", "OZ_WORK_SEND_COMMIT"].includes(message.type)) {
      const key = normalizeConversationKey(message.conversation_key), id = String(message.owner_id || "");
      await assertTabConversation(sender?.tab?.id, key);
      const current = await getManualOperation(key);
      if (current?.operation_id !== id || current.delivery?.delivery_id !== message.delivery_id || Number(current.tab_id) !== Number(sender?.tab?.id)) throw saError("DELIVERY_OWNER_MISMATCH");
      await saAssertDeliveryOwner(current);
      if (message.type === "OZ_WORK_DELIVERY_ASSERT") return { ok: true };
      if (!message.actor_id) throw saError("DELIVERY_ACTOR_REQUIRED");
      let granted = false, committedDelivery = null;
      await mutateManualOperation(key, async owner => {
        if (owner?.operation_id !== id || owner.delivery?.delivery_id !== message.delivery_id) throw saError("DELIVERY_OWNER_MISMATCH");
        await saAssertDeliveryOwner(owner);
        if (owner.delivery.sa_send_actor) { committedDelivery = owner.delivery; return owner; }
        if (owner.delivery.phase !== "inserted") throw saError("DELIVERY_NOT_INSERTED");
        const baseline = message.chatgpt_user_baseline;
        if (baseline !== undefined && (!Array.isArray(baseline) || baseline.length > 4096 ||
          !Array.from(baseline).every(id => typeof id === "string" && id.length > 0 && id.length <= 512))) throw saError("DELIVERY_BASELINE_INVALID");
        const observationEpoch = message.user_observation_epoch;
        if (observationEpoch !== undefined && (typeof observationEpoch !== "string" ||
          !/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(observationEpoch))) throw saError("DELIVERY_BASELINE_INVALID");
        granted = true;
        committedDelivery = { ...owner.delivery, sa_send_actor: message.actor_id, sa_send_committed_at: Date.now(),
          sa_chatgpt_user_baseline: Array.isArray(baseline) ? [...new Set(baseline)] : null,
          sa_user_observation_epoch: observationEpoch || null };
        return { ...owner, delivery: committedDelivery };
      });
      return { ok: true, click_allowed: granted, code: granted ? "SEND_COMMITTED" : "SEND_OUTCOME_UNKNOWN_NO_RETRY",
        send_click_committed: Boolean(committedDelivery?.sa_send_actor),
        chatgpt_user_baseline: Array.isArray(committedDelivery?.sa_chatgpt_user_baseline) ? committedDelivery.sa_chatgpt_user_baseline : null,
        user_observation_epoch: typeof committedDelivery?.sa_user_observation_epoch === "string" ? committedDelivery.sa_user_observation_epoch : null };
    }
    if (message.type === "OZ_WORK_START") throw saError("STORE_SELECTION_REQUIRED");
    if (["OZ_WORK_SHOW", "OZ_WORK_HIDE", "OZ_WORK_FINISH", "OZ_WORK_REFRESH"].includes(message.type) && !saPopupSender(sender)) throw saError("POPUP_SENDER_REQUIRED");
    if (message.type.startsWith("OZ_WORK_START_") || message.type === "OZ_WORK_PENDING_IDENTITY") {
      const pending = (await getPendingWorkStarts())[String(sender?.tab?.id || message.tab_id)];
      await saPendingGuard(pending);
    }
    if (message.type === "OZ_WORK_FINISH") {
      if (message.surface_id) {
        const live = await tabIdentity(normalizeTabId(message.tab_id));
        if (live.surface_id !== message.surface_id) throw saError("WORK_PENDING_SURFACE_CHANGED");
        // The empty dialogue may have become bound after the popup rendered.
        // Finish follows that same observed surface, never a replacement tab.
        message = { ...message, conversation_key: live.conversation_id ? conversationKeyFromIdentity(live) : null };
      }
      await Promise.allSettled(saCancelAdmission(message.tab_id, typeof message.conversation_key === "string" ? message.conversation_key : null));
      const pending = (await getPendingWorkStarts())[String(message.tab_id)];
      if (pending) {
        await clearPendingWorkStart(message.tab_id, pending.intent_id, pending.revision, "operator_finish");
        if (pending.conversation_key) await tabMessage(message.tab_id, { type: "OZ_WORK_APPLY_VISIBILITY", visible: false, conversation_key: pending.conversation_key });
        if (pending.conversation_key) {
          const binding = await bindingForConversationKey(pending.conversation_key);
          const store = binding?.store_context ? await saAssertStore(binding.store_context).catch(() => null) : null;
          await saRecordFinishMutation(pending.conversation_key, binding, store);
        }
        return { ok: true, pending_cancelled: true };
      }
    }
    if (message.type === "OZ_WORK_HIDE") {
      const key = normalizeConversationKey(message.conversation_key), work = await workSessionFor(key);
      await assertTabConversation(message.tab_id, key);
      if (work.state !== "active_visible") throw saError("WORK_SESSION_NOT_VISIBLE");
      await mutateWorkSession(key, work.revision, OzonWorkSessionModel.STATES.ACTIVE_HIDDEN);
      await tabMessage(message.tab_id, { type: "OZ_WORK_APPLY_VISIBILITY", visible: false, conversation_key: key, work_active: true });
      return { ok: true };
    }
    if (message.type === "OZ_EXECUTE_COMMAND") {
      await saAssertLocalAuthorityAdmission();
      await assertTabConversation(sender?.tab?.id, message.conversation_key);
      const binding = await bindingForConversationKey(message.conversation_key);
      const store = await saAssertStore(binding?.store_context);
      const work = await workSessionFor(message.conversation_key);
      if (work.state !== "active_visible") throw saError("WORK_SESSION_NOT_VISIBLE");
      if (message.work_session_id !== work.start_intent_id) throw saError("WORK_SESSION_CHANGED");
      await saAssertReconciliationAction(binding, store, message.conversation_key, message.work_session_id);
    }
    if (message.type.startsWith("OZ_BATCH_DELIVERY_")) {
      saR3AssertCopyPermit(await getManualOperation(message.conversation_key));
      await assertManualBatchContext(message.conversation_key, message.owner_id || message.operation_id);
    if (message.type === "OZ_BATCH_DELIVERY_COMPLETE") {
        const current = await getManualOperation(message.conversation_key);
        if (!current?.delivery?.sa_send_actor) throw saError("SEND_NOT_COMMITTED");
      }
    }
  }
  const result = await saLegacyMessage(message, sender);
  if (enabled && result?.ok && message.type === "OZ_WORK_PENDING_IDENTITY" && result.binding) {
    const store = result.binding.store_context ? await saAssertStore(result.binding.store_context) : null;
    await saRecordBindingMutation(result.binding, result.binding.conversation_key || message.conversation_key, store);
  }
  if (enabled && result?.ok && message.type === "OZ_WORK_FINISH") {
    const key = normalizeConversationKey(message.conversation_key), binding = await bindingForConversationKey(key);
    const store = binding?.store_context ? await saAssertStore(binding.store_context).catch(() => null) : null;
    await saRecordFinishMutation(key, binding, store);
  }
  if (enabled && result?.ok && ["OZ_BATCH_DELIVERY_COMPLETE", "OZ_REPORT_DELIVERY_CONFIRMED"].includes(message.type)) {
    const copyOwner = await getManualOperation(message.conversation_key);
    if (copyOwner?.r3_copy_delivery_id === message.delivery_id && copyOwner.status === MANUAL_OPERATION_STATUSES.COMPLETED &&
        copyOwner.delivery_confirmed === true && copyOwner.last_confirmed_delivery_id === message.delivery_id) {
      await saR3Ledger().recordCopyOutcome({ conversationKey: copyOwner.conversation_key, context: copyOwner.execution_context,
        deliveryId: message.delivery_id, outcome: "CONFIRMED" });
      saR3CopyPermits.delete(message.delivery_id);
    }
    const key = normalizeConversationKey(message.conversation_key), binding = await bindingForConversationKey(key);
    const store = binding?.store_context ? await saAssertStore(binding.store_context).catch(() => null) : null;
    await saRecordDeliveryMarker(key, binding, store, message.delivery_id || message.owner_id || "", {
      aiOrderId: message.ai_order_id || message.message_id || null,
      clientDeliveredAtMs: message.delivered_at_ms,
      clientSequence: message.client_sequence,
      orderProvenance: message.order_provenance,
      workGeneration: message.work_generation || message.work_session_id || null,
    });
  }
  if (enabled && ["OZ_CONTENT_READY", "OZ_CONTENT_SYNC", "OZ_GET_MANUAL_STATE"].includes(message.type) && result?.ok) {
    const key = result.conversation_key || message.conversation_key;
    result.store_context = await saPublicContext(key);
    result.auto_watch = null;
  }
  return result;
}
async function saCheckStore(message) {
  const store = await saCatalog.get(message.store_id), pinned = saStoreContext(store);
  let result;
  try {
    if (store.marketplace === "wildberries") {
      const snapshot = SellerAgentsExecutionContext.snapshot({ ...pinned, conversationKey: "credential-check", bindingId: "credential-check",
        bindingRevision: 1, workSessionId: "credential-check", commandHash: "credential-check", requestId: crypto.randomUUID() });
      const context = await SellerAgentsWBAdapter.createContext({ snapshot, credentials: store.credentials,
        readCurrent: async () => ({ ...snapshot, ...saStoreContext(await saAssertStore(pinned)), active: true }) });
      result = await SellerAgentsWBAdapter.createProvider().execute('WB_API_V1 {"operation":"seller_info","params":{}}', { context });
    } else if (message.part === "performance") result = await OzonProvider.testPerformanceConnection(store.credentials.performance);
    else result = await OzonProvider.testConnection(store.credentials.seller);
  } catch (error) { result = { ok: false, http_status: error.http_status || 0 }; }
  await saAssertStore(pinned);
  const httpStatus = Number(result.http_status || 0);
  const code = result.ok ? "ACCESS_CONFIRMED" : httpStatus === 401 ? "CREDENTIAL_REJECTED" : httpStatus === 403 ? "ACCESS_DENIED" : "CHECK_FAILED";
  let saved = await saCatalog.noteVerification(store.id, store.credentialRevision,
    store.marketplace === "wildberries" ? "token" : message.part === "performance" ? "performance" : "seller", { code, httpStatus });
  // Provider identity is authoritative only when the provider path explicitly
  // returns a confirmed account identifier. Labels, token shape, and failures
  // never bind or erase provider identity.
  if (result.provider_account_id) saved = await saCatalog.confirmProviderIdentity(store.id, store.credentialRevision, result.provider_account_id);
  void saRecordStoreMetadata(saved);
  return { ok: true, store: saved };
}
function saPrunePayload(owner, now = Date.now()) {
  if (!owner) return owner;
  // No report bytes remain. Preserve the first provider/delivery replay fence.
  if (owner.outgoing_text == null && owner.batch == null && owner.delivery == null) return owner;
  const expires = owner.payload_expires_at_ms || Date.parse(owner.created_at || "") + SA_PAYLOAD_TTL;
  if (Number.isFinite(expires) && expires > now) return { ...owner, payload_expires_at_ms: expires };
  const entries = Array.isArray(owner.batch?.entries) ? owner.batch.entries : [];
  const replayFence = {
    schema_version: SellerAgentsResultRecovery?.SCHEMA_VERSION || 1,
    kind: "RESULT_BUFFER_EXPIRED",
    expired_at_ms: now,
    provider_replay_forbidden: true,
    delivery_replay_forbidden: true,
    execution_id: owner.operation_id || null,
    context: owner.execution_context ? {
      accountId: owner.execution_context.accountId,
      conversationKey: owner.execution_context.conversationKey,
      marketplace: owner.execution_context.marketplace,
      storeId: owner.execution_context.storeId,
      bindingId: owner.execution_context.bindingId,
      bindingRevision: owner.execution_context.bindingRevision,
      workGeneration: owner.execution_context.workSessionId,
    } : null,
    attempts: entries.map((entry) => entry?.provider_attempt).filter(Boolean).map((attempt) => ({
      logical_execution_id: attempt.logical_execution_id || null,
      provider_attempt_id: attempt.provider_attempt_id || null,
      state: attempt.state || null,
      outcome: attempt.outcome || null,
    })).slice(-32),
    delivery_id: owner.delivery?.delivery_id || owner.delivery_id || null,
  };
  return { ...owner, status: "failed", batch: null, outgoing_text: null, delivery: null,
    completed_at: owner.completed_at || new Date(now).toISOString(), recovery_fence: replayFence,
    last_error: { code: "RESULT_BUFFER_EXPIRED" } };
}
async function saAssertDeliveryOwner(owner) {
  if (!owner?.execution_context) throw SellerAgentsExecutionContext.error("EXECUTION_CONTEXT_MISSING");
  await saAssertLocalAuthorityAdmission();
  saR3AssertCopyPermit(owner);
  if (owner.payload_expires_at_ms <= Date.now()) throw saError("RESULT_EXPIRED");
  const guard = await saGuard(owner);
  await guard.assertCurrent();
}

async function saCleanupExpiredPayloads() {
  const data = await storageGet(KEYS.MANUAL_OPERATIONS);
  const now = Date.now();
  let earliest = null;
  for (const [key, owner] of Object.entries(data[KEYS.MANUAL_OPERATIONS] || {})) {
    if (!owner || (owner.outgoing_text == null && owner.batch == null && owner.delivery == null)) continue;
    const expiry = owner.payload_expires_at_ms || Date.parse(owner.created_at || "") + SA_PAYLOAD_TTL;
    if (!Number.isFinite(expiry) || expiry <= now) await mutateManualOperation(key, current => saPrunePayload(current));
    else earliest = earliest === null ? expiry : Math.min(earliest, expiry);
  }
  await OzonFileDeliveryWorker.cleanupExpiredArtifacts();
  const scheduler = globalThis.SellerAgentsTechnicalScheduler;
  if (earliest !== null) await scheduler?.schedule?.(scheduler.KINDS.EXPIRY, { taskId: "expiry:buffers", dueAt: earliest, identity: { retryGeneration: "payload" } });
}

async function resumeKnownResultRecoveries() {
  if (!await saEnabled()) throw saError("AUTH_REQUIRED");
  const data = await storageGet(KEYS.MANUAL_OPERATIONS);
  const flights = [];
  for (const [conversationKey, owner] of Object.entries(data[KEYS.MANUAL_OPERATIONS] || {})) {
    if (owner?.status !== MANUAL_OPERATION_STATUSES.REQUESTING || !owner.batch) continue;
    const buffered = (owner.batch.entries || []).some((entry) =>
      entry?.status === "requesting" &&
      entry?.result_buffer?.phase === SellerAgentsResultRecovery.RESULT_PHASES.BUFFERED &&
      entry?.provider_attempt?.state !== SellerAgentsProviderOutcome.STATES.OUTCOME_UNKNOWN);
    if (buffered) flights.push(launchBatchProcessor("manual", conversationKey, owner.operation_id, "technical_known_result_recovery"));
  }
  await Promise.allSettled(flights);
}
const saFileOwners = SellerAgentsLocalOperations.createRecordStore({ read: keys => chrome.storage.session.get(keys),
  write: values => chrome.storage.session.set(values), namespace: "seller_agents_file_owners_v1" });
async function saCheckOzonFileRef(command, context) {
  if (command.operation !== "report_file_get") return;
  const owner = await saFileOwners.get(command.params.file_ref), pinned = context?.snapshot;
  if (!pinned || !owner || owner.expires_at_ms <= Date.now() ||
    ["accountId", "storeId", "credentialRevision"].some(field => owner[field] !== pinned[field]))
    throw saError("REPORT_FILE_STORE_MISMATCH");
  await context.assertCurrent();
}
async function saRememberOzonFileRefs(response, context) {
  if (!context) return;
  let envelope;
  try { envelope = JSON.parse(String(response.report_text).slice(String(response.report_text).indexOf("\n") + 1)); } catch (_) { return; }
  for (const ref of [envelope?.result?.report_file_ref, envelope?.result?.generated_file_ref]) {
    if (!/^rpf_[sp]_[A-Za-z0-9_-]+$/.test(ref || "")) continue;
    await context.assertCurrent();
    await saFileOwners.mutate(ref, async old => {
      await context.assertCurrent();
      const p = context.snapshot;
      if (old && ["accountId", "storeId", "credentialRevision"].some(field => old[field] !== p[field])) throw saError("REPORT_FILE_STORE_MISMATCH");
      return old || { accountId: p.accountId, storeId: p.storeId, credentialRevision: p.credentialRevision, expires_at_ms: Date.now() + SA_PAYLOAD_TTL };
    });
  }
}

// R3 receipts extend the existing manual record writer; they do not schedule another queue.
let saR3CommandLedger = null;
const saR3RetryPermits = new WeakSet();
const saR3CopyPermits = new Set();
function saR3ReadOnly(item) {
  try {
    const meta = item.marketplace === "ozon" ? OzonContract.OPERATIONS[item.operation] :
      item.marketplace === "wildberries" ? SellerAgentsWBAdapter.operation({ operation: item.operation }) : null;
    return Boolean(meta && meta.effect === "READ" && meta.execution_enabled === true &&
      (meta.current === true || meta.currentness === "current"));
  } catch (_) { return false; }
}
function saR3Ledger() {
  if (!saR3CommandLedger) saR3CommandLedger = SellerAgentsCommandLedger.createCommandLedger({
    store: manualOperationRecords, canonicalJson: SellerAgentsBootstrapVerifier.canonicalJson, sha256: sha256Hex,
    assertContext: async context => {
      const live = await saReadContext(context.conversationKey, { commandHash: context.commandHash, requestId: context.requestId });
      try { SellerAgentsExecutionContext.assertSame(context, live); return true; } catch (_) { return false; }
    },
    classifyReadOnly: saR3ReadOnly,
    readBuffer: saR3ReadBuffer,
  });
  return saR3CommandLedger;
}
async function saR3PrepareCommandSource(source, sender, identity, binding, work, key, text) {
  if (source?.protocol !== 2) throw saError("COMMAND_PROTOCOL_RELOAD_REQUIRED");
  const message = source.messageIdentity;
  if (!message || !["provider-message", "document-local"].includes(message.kind) ||
      typeof message.id !== "string" || !message.id || message.id.length > 512 || /[\u0000-\u001f]/.test(message.id) ||
      typeof source.documentKey !== "string" || !source.documentKey || source.documentKey.length > 128 ||
      !Number.isSafeInteger(source.blockOrdinal) || source.blockOrdinal < 0 || source.blockOrdinal > 10000)
    throw saError("BLOCK_IDENTITY_REQUIRED");
  if (source.workSessionId !== work.start_intent_id || source.bindingId !== binding.binding_id ||
      normalizeConversationKey(source.conversationKey) !== key || identity.ai_id !== binding.ai_id)
    throw saError("EXECUTION_CONTEXT_CHANGED");
  const baseline = binding.assistant_baseline_ids || [];
  const baselineId = message.kind === "provider-message" ? message.id : "r3-local:" + message.id;
  if (baseline.includes(baselineId)) throw saError("COMMAND_PRECEDES_WORK_START");
  if (message.kind === "document-local" && (message.documentKey !== source.documentKey ||
      !baseline.includes("r3-document:" + source.documentKey)))
    throw saError("COMMAND_LOCAL_IDENTITY_UNCERTAIN_START_REQUIRED");
  const accountId = await SellerAgentsControlClient.currentAccount();
  if (!accountId || accountId !== binding.store_context?.accountId) throw saError("EXECUTION_CONTEXT_CHANGED");
  const keys = await saR3Ledger().blockKeys({ accountId, conversationBindingId: binding.binding_id,
    workSessionId: work.start_intent_id, messageIdentity: message, blockOrdinal: source.blockOrdinal, blockText: text });
  const requestToken = await sha256Hex(SellerAgentsBootstrapVerifier.canonicalJson({
    blockOriginKey: keys.blockOriginKey, blockVersion: keys.blockVersion, approvalRevision: 0 }));
  return { ...keys, requestToken, source: { messageAnchorKey: keys.messageAnchorKey,
    documentKey: source.documentKey, messageKind: message.kind, messageIdentity: structuredClone(message), blockOrdinal: source.blockOrdinal,
    browserDocumentId: typeof sender.documentId === "string" ? sender.documentId : null } };
}
async function saR3ReserveCommand(prepared, context, entries, ingressRequestToken) {
  const current = await getManualOperation(context.conversationKey);
  if (current?.execution_context?.workSessionId === context.workSessionId &&
      current.seen_request_ids?.includes(ingressRequestToken)) throw saError("MANUAL_REQUEST_DUPLICATE");
  if (current?.operation_id && !current.r3_execution_id && current.execution_context?.workSessionId === context.workSessionId)
    throw saError("COMMAND_HISTORY_UNKNOWN_START_REQUIRED");
  const items = await Promise.all(entries.map(async (entry, ordinal) => ({ ordinal,
    inputHash: await sha256Hex(SellerAgentsBootstrapVerifier.canonicalJson({
      kind: entry.kind, command_text: entry.command_text || null, operation: entry.operation || null,
      guidance: entry.guidance || null, error: entry.error || null })) })));
  const reserved = await saR3Ledger().reserveCommand({ conversationKey: context.conversationKey, context,
    blockOriginKey: prepared.blockOriginKey, blockVersion: prepared.blockVersion, source: prepared.source, items });
  if (reserved.duplicate) {
    const latest = await getManualOperation(context.conversationKey);
    const receipt = latest?.r3_commands?.receipts?.[reserved.executionId];
    // Durable RESERVED without an owner or provider intent proves this new protocol made no API call.
    const recoverable = receipt?.items.every(item => item.state === "RESERVED") &&
      latest?.r3_execution_id !== reserved.executionId && !manualOperationActive(latest) &&
      receipt.payloadExpiresAt > Date.now();
    if (!recoverable) throw saError(reserved.unknown ? "COMMAND_OUTCOME_UNKNOWN_EXPLICIT_RETRY_REQUIRED" : "MANUAL_REQUEST_DUPLICATE");
  }
  return reserved;
}
function saR3ProviderResultJson(value) {
  const text = JSON.stringify(value, (_key, item) => {
    if (typeof item === "number" && !Number.isFinite(item))
      throw saError("RESULT_RECEIPT_NON_FINITE_NUMBER");
    return item && typeof item === "object" && !Array.isArray(item)
      ? Object.fromEntries(Object.keys(item).sort().map(key => [key, item[key]])) : item;
  });
  if (typeof text !== "string") throw saError("RESULT_RECEIPT_JSON_INVALID");
  return text;
}
const saR3BaseGuardedQueue = globalThis.SellerAgentsGuardedBatchQueue;
globalThis.SellerAgentsGuardedBatchQueue = Object.freeze({ ...saR3BaseGuardedQueue,
  async run(options, { context, ports }) {
    if (options.ownerKind !== "manual" || !await saEnabled()) return saR3BaseGuardedQueue.run(options, { context, ports });
    const initial = await options.getOwner();
    if (!initial?.r3_execution_id) throw SellerAgentsExecutionContext.error("COMMAND_HISTORY_UNKNOWN_START_REQUIRED");
    let pending = null;
    const record = async (outcome, result = null) => {
      if (!pending || pending.recorded) return;
      const digest = result === null ? null : await sha256Hex(saR3ProviderResultJson(result));
      for (const item of pending.items) await saR3Ledger().recordProviderOutcome({
        conversationKey: initial.conversation_key, context: initial.execution_context,
        executionId: initial.r3_execution_id, ordinal: item.ordinal,
        providerAttemptId: item.providerAttemptId, outcome, bufferDigest: digest });
      pending.recorded = true;
    };
    const wrapped = { ...ports,
      beforeProviderDispatch: async (...args) => {
        await ports.beforeProviderDispatch?.(...args);
        const owner = await options.getOwner();
        if (owner?.r3_execution_id !== initial.r3_execution_id) throw SellerAgentsExecutionContext.error();
        const indexes = (owner.batch?.entries || []).flatMap((entry, ordinal) => entry.kind === "command" && entry.status === "requesting" ? [entry.r3_original_ordinal ?? ordinal] : []);
        if (!indexes.length) throw SellerAgentsExecutionContext.error("COMMAND_ITEM_MISSING");
        pending = { items: [], recorded: false };
        for (const ordinal of indexes) {
          const permit = await saR3Ledger().beginProviderAttempt({ conversationKey: owner.conversation_key,
            context: owner.execution_context, executionId: owner.r3_execution_id, ordinal });
          if (permit.dispatch !== true) throw SellerAgentsExecutionContext.error("COMMAND_OUTCOME_UNKNOWN_EXPLICIT_RETRY_REQUIRED");
          pending.items.push({ ordinal, providerAttemptId: permit.providerAttemptId });
        }
      },
      execute: async (text, input) => {
        if (!pending) throw SellerAgentsExecutionContext.error("PROVIDER_INTENT_REQUIRED");
        try {
          const result = await ports.execute(text, { ...input, onProviderResult: async value => {
            await input.onProviderResult?.(value);
            await record("RESULT", value?.provider_result || value);
          } });
          if (!pending.recorded) {
            const uncertain = result?.external_request_executed === true && !(Number(result.http_status) > 0);
            await record(uncertain ? "UNKNOWN" : "RESULT", uncertain ? null : result);
          }
          return result;
        } catch (failure) {
          try { await record("UNKNOWN"); } catch (_) { /* A retained PROVIDER_INTENT is still UNKNOWN, never permission to retry. */ }
          throw failure;
        } finally { pending = null; }
      },
    };
    return saR3BaseGuardedQueue.run(options, { context, ports: wrapped });
  },
});

async function saR3RecoverySummary(key, work) {
  const owner = await getManualOperation(key);
  return Object.values(owner?.r3_commands?.receipts || {}).filter(receipt =>
    receipt.context?.workSessionId === work?.start_intent_id &&
    (receipt.items?.some(item => ["UNKNOWN", "PROVIDER_INTENT"].includes(item.state)) ||
      receipt.executionId === owner.r3_execution_id && saR3CopyCandidate(owner))).map(receipt => ({
      executionId: receipt.executionId, predecessor: receipt.predecessor || null,
      approvalRevision: receipt.approvalRevision, retryAvailable: Boolean(receipt.source?.messageIdentity) && receipt.items.some(item => ["UNKNOWN", "PROVIDER_INTENT"].includes(item.state)),
      copyAvailable: receipt.executionId === owner.r3_execution_id && saR3CopyCandidate(owner),
      state: receipt.items.some(item => ["UNKNOWN", "PROVIDER_INTENT"].includes(item.state)) ? "UNKNOWN" : "RESULT",
    }));
}
async function saR3RecoveryInput(message, expectedContext = null) {
  const tabId = normalizeTabId(message.tab_id), identity = await tabIdentity(tabId);
  const key = conversationKeyFromIdentity(identity), binding = await strictBindingForIdentity(identity);
  const work = await workSessionFor(key), owner = await getManualOperation(key);
  const receipt = owner?.r3_commands?.receipts?.[message.execution_id];
  if (!receipt?.source?.messageIdentity) throw saError("RETRY_PROVENANCE_UNAVAILABLE");
  if (work.finished || work.state !== OzonWorkSessionModel.STATES.ACTIVE_VISIBLE ||
      receipt.context.workSessionId !== work.start_intent_id) throw saError("WORK_SESSION_NOT_VISIBLE");
  if (manualOperationActive(owner)) throw saError("RECOVERY_PREVIOUS_DELIVERY_PENDING");
  if (!await SellerAgentsControlClient.canWork(identity)) throw saError("WORK_POLICY_BLOCKED");
  const source = { protocol: 2, ...receipt.source, messageIdentity: receipt.source.messageIdentity,
    workSessionId: work.start_intent_id, bindingId: binding.binding_id, conversationKey: key };
  const block = await tabMessage(tabId, { type: "OZ_R3_READ_BLOCK", source });
  if (!block?.ok) throw saError(block?.error?.code || "COMMAND_BLOCK_UNAVAILABLE");
  const sender = { tab: { id: tabId } };
  const prepared = await saR3PrepareCommandSource(block.command_source, sender, identity, binding, work, key, block.command_text);
  if (prepared.blockOriginKey !== receipt.blockOriginKey) throw saError("COMMAND_CONTEXT_CHANGED");
  if (message.block_version && message.block_version !== prepared.blockVersion) throw saError("RETRY_PREVIEW_CHANGED");
  const entries = binding.store_context.marketplace === "wildberries"
    ? SellerAgentsWBAdapter.discover(block.command_text) : discoverBatchEntries(block.command_text);
  if (binding.store_context.marketplace === "ozon" && /\bWB_(?:API|HELP|FILE)_V[12]\b/.test(block.command_text))
    throw saError("MIXED_MARKETPLACE_BLOCK");
  const context = await captureBatchContext(key, block.command_text, expectedContext?.requestId || crypto.randomUUID());
  if (expectedContext) SellerAgentsExecutionContext.assertSame(expectedContext, await saReadContext(key, { commandHash: context.commandHash, requestId: context.requestId }));
  const parserContract = "r3-retry-parser-1:" + context.marketplace + ":" + chrome.runtime.getManifest().version;
  const items = await Promise.all(entries.map(async (entry, ordinal) => {
    const operation = typeof entry.operation === "string" ? entry.operation : entry.operation?.operation;
    const candidate = { ordinal, operation, marketplace: context.marketplace,
      inputHash: await sha256Hex(SellerAgentsBootstrapVerifier.canonicalJson({
        kind: entry.kind, command_text: entry.command_text || null, operation: entry.operation || null,
        guidance: entry.guidance || null, error: entry.error || null })) };
    return { ...candidate, supported: entry.kind === "command" && saR3ReadOnly(candidate) &&
      receipt.items.some(item => item.ordinal === ordinal),
      parameters: SellerAgentsBootstrapVerifier.canonicalJson({ operation: entry.operation || null, command_text: entry.command_text || null }) };
  }));
  return { tabId, key, identity, binding, work, owner, receipt, block, prepared, context, entries, items, parserContract };
}
function saR3Selected(input, ordinals) {
  if (!Array.isArray(ordinals) || !ordinals.length || new Set(ordinals).size !== ordinals.length)
    throw saError("RETRY_SELECTION_REQUIRED");
  return ordinals.map(ordinal => {
    const item = input.items.find(candidate => candidate.ordinal === ordinal);
    if (!item?.supported) throw saError("RETRY_READ_ONLY_REQUIRED");
    return item;
  });
}
async function saR3RetryReview(message) {
  const input = await saR3RecoveryInput(message);
  return { ok: true, execution_id: input.receipt.executionId, block_version: input.prepared.blockVersion,
    items: input.items, warning: "Предыдущий запрос мог выполниться. Новый запуск может повторить действие и расход квоты" };
}
async function saR3RetryPreview(message) {
  const input = await saR3RecoveryInput(message), selection = saR3Selected(input, message.ordinals);
  const preview = await saR3Ledger().previewRetry({ conversationKey: input.key, context: input.context,
    executionId: input.receipt.executionId, blockVersion: input.prepared.blockVersion, selection,
    parserContract: input.parserContract, credentialRevision: input.context.credentialRevision });
  return { ok: true, ...preview, execution_id: input.receipt.executionId, block_version: input.prepared.blockVersion,
    items: selection, target: { conversationKey: input.key, storeId: input.context.storeId },
    ordinals: selection.map(item => item.ordinal) };
}
async function saR3RetryConfirm(message) {
  const identity = await tabIdentity(normalizeTabId(message.tab_id)), key = conversationKeyFromIdentity(identity);
  const owner = await getManualOperation(key), approval = owner?.r3_commands?.approvals?.[message.confirmation_id];
  if (message.confirmed !== true || !approval || approval.kind !== "RETRY") throw saError("RETRY_EXPLICIT_CONFIRMATION_REQUIRED");
  if (approval.predecessor !== message.execution_id) throw saError("RETRY_PREVIEW_CHANGED");
  if (approval.consumedBy) {
    SellerAgentsExecutionContext.assertSame(approval.context, await saReadContext(key, approval.context));
    return { ok: true, accepted: false, duplicate: true, execution_id: approval.consumedBy };
  }
  const input = await saR3RecoveryInput(message, approval.context), selection = saR3Selected(input, message.ordinals);
  const reservation = await saR3Ledger().confirmRetry({ conversationKey: key, context: input.context,
    confirmationId: message.confirmation_id, confirmed: true, selection, blockVersion: input.prepared.blockVersion,
    parserContract: input.parserContract, credentialRevision: input.context.credentialRevision });
  if (reservation.duplicate) return { ok: true, accepted: false, duplicate: true, execution_id: reservation.executionId };
  const permit = { context: input.context, reservation, blockVersion: input.prepared.blockVersion,
    blockOriginKey: input.prepared.blockOriginKey, ordinals: selection.map(item => item.ordinal) };
  saR3RetryPermits.add(permit);
  const result = await executeManualCommand(input.block.command_text, key, { tab: { id: input.tabId } },
    "r3-retry:" + message.confirmation_id, input.block.command_source, permit);
  return { ...result, execution_id: reservation.executionId, predecessor: reservation.predecessor };
}

function saR3CopyCandidate(owner) {
  return Boolean(owner?.r3_execution_id && owner.outgoing_text && owner.payload_expires_at_ms > Date.now() &&
    ["batch_watch_v1", "attachment_watch_v1"].includes(owner.delivery?.mode) &&
    (owner.status === MANUAL_OPERATION_STATUSES.COMPLETED || owner.delivery?.sa_send_actor || owner.delivery?.attachment_send_actor_id ||
      owner.delivery?.phase === BridgeAutorunModel.ATTACHMENT_PHASES.ATTACH_COMMITTED ||
      owner.delivery?.phase === BridgeAutorunModel.DELIVERY_PHASES.INSERT_COMMITTED ||
      owner.r3_copy_delivery_id && !saR3CopyPermits.has(owner.r3_copy_delivery_id) &&
      owner.r3_commands?.deliveries?.[owner.r3_copy_delivery_id]?.state === "DELIVERY_INTENT"));
}
function saR3AssertCopyPermit(owner) {
  if (owner?.r3_copy_delivery_id && !saR3CopyPermits.has(owner.r3_copy_delivery_id))
    throw SellerAgentsExecutionContext.error("COPY_OUTCOME_UNKNOWN_NO_RETRY");
}
async function saR3CopyInput(message) {
  const tabId = normalizeTabId(message.tab_id), identity = await tabIdentity(tabId);
  const key = conversationKeyFromIdentity(identity), owner = await getManualOperation(key);
  if (!saR3CopyCandidate(owner) || owner.r3_execution_id !== message.execution_id) throw saError("COPY_BUFFER_UNAVAILABLE");
  if (!await SellerAgentsControlClient.canWork(identity)) throw saError("WORK_POLICY_BLOCKED");
  SellerAgentsExecutionContext.assertSame(owner.execution_context, await saReadContext(key, owner.execution_context));
  return { tabId, identity, key, owner };
}
async function saR3CopyPreview(message) {
  const input = await saR3CopyInput(message), owner = input.owner;
  const buffer = await saR3ReadBuffer(owner.r3_execution_id, owner.execution_context), digest = buffer.digest;
  await saR3Ledger().recordDeliveryBuffer({ conversationKey: input.key, context: owner.execution_context,
    executionId: owner.r3_execution_id, bufferDigest: digest, expiresAt: owner.payload_expires_at_ms,
    previousDelivery: { deliveryId: owner.delivery.delivery_id,
      state: owner.delivery_confirmed === true || owner.status === MANUAL_OPERATION_STATUSES.COMPLETED ? "CONFIRMED" : "UNKNOWN" } });
  const preview = await saR3Ledger().previewCopy({ conversationKey: input.key, context: owner.execution_context,
    executionId: owner.r3_execution_id });
  return { ok: true, ...preview, execution_id: owner.r3_execution_id, buffer: owner.outgoing_text, attachments: buffer.attachments,
    target: { conversationKey: input.key, storeId: owner.execution_context.storeId },
    warning: "Предыдущая отправка могла состояться. В диалоге может появиться дубликат сообщения" };
}
async function saR3CopyConfirm(message) {
  if (message.confirmed !== true) throw saError("COPY_EXPLICIT_CONFIRMATION_REQUIRED");
  const identity = await tabIdentity(normalizeTabId(message.tab_id)), initialKey = conversationKeyFromIdentity(identity);
  const initialOwner = await getManualOperation(initialKey), previous = initialOwner?.r3_commands?.approvals?.[message.confirmation_id];
  if (previous?.kind === "COPY" && previous.executionId === message.execution_id && previous.consumedBy) {
    if (!await SellerAgentsControlClient.canWork(identity)) throw saError("WORK_POLICY_BLOCKED");
    SellerAgentsExecutionContext.assertSame(previous.context, await saReadContext(initialKey, previous.context));
    return { ok: true, accepted: false, duplicate: true, delivery_id: previous.consumedBy };
  }
  const input = await saR3CopyInput(message), { key, owner } = input;
  const approval = owner.r3_commands?.approvals?.[message.confirmation_id];
  if (!approval || approval.kind !== "COPY" || approval.executionId !== message.execution_id)
    throw saError("COPY_PREVIEW_MISSING");
  const reservation = await saR3Ledger().confirmCopy({ conversationKey: key, context: owner.execution_context,
    confirmationId: message.confirmation_id, confirmed: true });
  if (reservation.duplicate) return { ok: true, accepted: false, duplicate: true, delivery_id: reservation.deliveryId };
  const permit = await saR3Ledger().beginCopyDelivery({ conversationKey: key, context: owner.execution_context,
    deliveryId: reservation.deliveryId });
  if (!permit.send) throw saError("COPY_OUTCOME_UNKNOWN_NO_RETRY");
  saR3CopyPermits.add(reservation.deliveryId);
  try {
    await mutateManualOperation(key, async current => {
      SellerAgentsExecutionContext.assertSame(owner.execution_context, await saReadContext(key, owner.execution_context));
      if (current?.operation_id !== owner.operation_id || current.r3_execution_id !== owner.r3_execution_id ||
          current.delivery?.delivery_id !== owner.delivery.delivery_id ||
          current.outgoing_text !== owner.outgoing_text || current.payload_expires_at_ms !== owner.payload_expires_at_ms)
        throw saError("COPY_BUFFER_CHANGED");
      const next = BridgeAutorunModel.claimDelivery(current, { deliveryId: reservation.deliveryId, requestId: "",
        outgoingText: current.outgoing_text, outgoingHash: permit.bufferDigest,
        reportPrefixApplied: current.report_prefix_applied === true, mode: "batch_watch_v1" });
      if (current.delivery.mode === "attachment_watch_v1") {
        next.delivery = { ...current.delivery, delivery_id: reservation.deliveryId,
          phase: BridgeAutorunModel.ATTACHMENT_PHASES.CLAIMED, commit_actor_id: null,
          attachment_send_actor_id: null, attachment_send_committed_at: null,
          attachment_committed_at: null, attachment_ready_at: null, attached_filenames: [],
          baseline_user_turn_ids: [], baseline_assistant_turn_ids: [], claimed_at: new Date().toISOString() };
      }
      next.delivery.payload_expires_at_ms = current.payload_expires_at_ms;
      next.delivery.marketplace = current.execution_context.marketplace;
      return { ...next, tab_id: input.tabId, r3_copy_delivery_id: reservation.deliveryId,
        delivery_id: reservation.deliveryId, delivery_confirmed: false, completed_at: null };
    });
    void attemptManualBatchDelivery(key, owner.operation_id);
    return { ok: true, accepted: true, delivery_id: reservation.deliveryId, api_request: false };
  } catch (error) {
    saR3CopyPermits.delete(reservation.deliveryId);
    throw error;
  }
}

async function saR3ReadBuffer(executionId, context) {
  const owner = await getManualOperation(context.conversationKey);
  if (owner?.r3_execution_id !== executionId || !owner.outgoing_text || !owner.execution_context) return null;
  const attachments = owner.delivery?.mode === "attachment_watch_v1"
    ? await OzonFileDeliveryWorker.copyManifest(owner.delivery) : [];
  const payload = attachments.length ? SellerAgentsBootstrapVerifier.canonicalJson({ text: owner.outgoing_text, attachments }) : owner.outgoing_text;
  return { payload, digest: await sha256Hex(payload), attachments,
    expiresAt: owner.payload_expires_at_ms, context: owner.execution_context };
}
async function saR3RecordCopyConfirmation(key, deliveryId) {
  const owner = await getManualOperation(key);
  if (owner?.r3_copy_delivery_id !== deliveryId || owner.status !== MANUAL_OPERATION_STATUSES.COMPLETED ||
      !owner.delivery_confirmed || owner.last_confirmed_delivery_id !== deliveryId) return;
  await saR3Ledger().recordCopyOutcome({ conversationKey: key, context: owner.execution_context, deliveryId, outcome: "CONFIRMED" });
  saR3CopyPermits.delete(deliveryId);
}

;
async function saPrompt(pinned, tree = null) {
  const store = await saAssertStore(pinned);
  const header = `Октопорт. Источник: ${store.marketplace === "ozon" ? "Ozon" : "Wildberries"}. Магазин: ${JSON.stringify(store.name)}. Store ID: ${store.id}. Новая рабочая сессия: прежние данные диалога могут относиться к другому магазину. Не смешивай источники.\n`;
  const hints = tree ? `\n\nПодсказки Октопорта для выбранного ИИ, опубликованная версия ${tree.version}:\n${OctoportPromptTrees.render(tree.body)}` : "";
  if (store.marketplace === "ozon") return header + DEFAULT_AUTO_START_TEXT + hints;
  return header + [
    "Ты работаешь с разрешёнными данными Wildberries через расширение пользователя. Секреты хранит расширение: никогда не проси ключ в чате.",
    "Пользователь разрешает один блок кнопкой «Октопорт». Выводи все явные независимые команды шага в одном fenced text code block. Выполняются последовательно; одна API-команда — максимум один запрос, HELP — локально.",
    'Начинай с локальной справки WB_HELP_V1 {"operation":"catalog","params":{"offset":0,"limit":25}}. Следующие страницы справки запроси явно.',
    'Перед незнакомой операцией: WB_HELP_V1 {"operation":"describe","params":{"alias":"seller_info"}}. Не придумывай операции, поля, права или схемы.',
    'API envelope: WB_API_V1 {"operation":"seller_info","params":{}}. Для иных операций params содержит path, query, body только по локальной карточке.',
    "Справка основана на закреплённой версии API. Подтверждением доступа служит ответ конкретной операции, а не наличие alias в справке.",
    "Не строй скрытые пагинации, опросы, повторы или зависимые запросы до получения ответа. После промежуточного ответа формируй следующий явный блок.",
    "Полученные WB_RESULT_V1 и WB_BATCH_RESULT_V1 относятся только к указанному магазину. Ошибки, UNKNOWN и отсутствие загруженного файла не являются успехом.",
    "Большие результаты и оригинальные файлы расширение прикрепляет к сообщению; читай их полностью. Локальный технический буфер живёт не более часа, архива нет.",
    `Передача персональных данных: ${store.personalDataEnabled ? "разрешена пользователем для этого магазина" : "выключена; соответствующие операции блокирует код"}. Только чтение; изменение цен, рекламы и карточек запрещено.`,
    "Ответь кратко, что подключён к указанному источнику и магазину; уточни задачу пользователя."
  ].join("\n") + hints;
}
function saCombinedReport(entries, owner) {
  const p = owner.execution_context;
  const header = { source: p.marketplace, store_id: p.storeId, binding_id: p.bindingId,
    work_session_id: p.workSessionId, result_count: entries.length, created_at: owner.created_at,
    expires_at: new Date(owner.payload_expires_at_ms).toISOString() };
  return `${p.marketplace === "wildberries" ? "WB" : "OZON"}_BATCH_RESULT_V1\n${JSON.stringify(header)}\n\n` +
    entries.map((entry, i) => `===== RESULT ${i + 1}/${entries.length} =====\n${entry.report_text || ""}`).join("\n\n");
}
async function saPrepareDelivery(entries, owner) {
  if (!await saEnabled() || owner?.execution_context?.marketplace !== "wildberries") return entries;
  const guard = await saGuard(owner), result = [];
  for (const [entryIndex, entry] of entries.entries()) {
    await guard.assertCurrent();
    if (!entry.report_text?.startsWith("WB_RESULT_V1\n") || !(entry.http_status >= 200 && entry.http_status < 300)) { result.push(entry); continue; }
    const envelope = JSON.parse(entry.report_text.slice(entry.report_text.indexOf("\n") + 1));
    const data = envelope.result;
    if (typeof data?.content_base64 !== "string") { result.push(entry); continue; }
    const bytes = ProviderTransportCore.reportBase64ToBytes(data.content_base64);
    if (bytes.byteLength !== data.byte_length) throw saError("FILE_BYTE_LENGTH_MISMATCH");
    // The artifact identity is tied to the logical result, not to a worker
    // invocation. Re-finalizing after a restart therefore reuses the same
    // bounded artifact key instead of orphaning a second local file.
    const artifactIdentity = String(entry.provider_attempt?.provider_attempt_id || entry.request_id || `${owner.operation_id}:${entryIndex}`)
      .replace(/[^A-Za-z0-9_-]/g, "-").slice(0, 180);
    const ref = `sa_file_${artifactIdentity || `result-${entryIndex}`}`;
    const filename = data.original_filename || `wb-report-${entry.operation || "result"}.${/pdf/i.test(data.content_type) ? "pdf" : /csv/i.test(data.content_type) ? "csv" : /spreadsheetml/i.test(data.content_type) ? "xlsx" : "bin"}`;
    await guard.assertCurrent();
    const descriptor = await OzonFileDeliveryWorker.storeApplicationArtifact({ artifact_key: `provider:${ref}`,
      source_kind: "original_provider_file", filename, mime_type: data.content_type,
      extension: OzonAIDeliveryCapabilities.extensionFromFilename(filename), bytes,
      created_at_ms: Date.now(), expires_at_ms: owner.payload_expires_at_ms });
    await guard.assertCurrent();
    envelope.result = { filename: descriptor.filename, byte_length: descriptor.byte_length,
      sha256: descriptor.sha256, delivery_status: "SAVED_FOR_ATTACHMENT_NOT_YET_SENT" };
    result.push({ ...entry, provider_file_ref: ref, report_text: `WB_RESULT_V1\n${JSON.stringify(envelope)}` });
  }
  return result;
}
