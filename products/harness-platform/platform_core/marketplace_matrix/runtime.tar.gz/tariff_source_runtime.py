"""Current tariff pages and verified SKU mapping in the parent's existing job.

The parent owns the report, queue and publication fence. This leaf grants no
permission, creates no second job and never calls a provider outside Worker.
Only AEAD source packets, not previous coefficient values, survive recovery.
"""
from copy import deepcopy
from platform_core.marketplace_matrix import tariff_cohort
from hashlib import sha256
from pathlib import Path
import base64, secrets
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from semantics import Rejected, canonical_json, strict_json, fingerprint
from protected_reads import key as encryption_key
from parameter_support import economics_tariffs as source
import read_surface

OPERATIONS=(source.CATALOG['price_operation'],source.CATALOG['product_operation'])
PIN=fingerprint({'code':sha256(Path(__file__).read_bytes()).hexdigest(),
    'normalizer':sha256(Path(source.__file__).read_bytes()).hexdigest(),
    'catalog':source.HASH,'read_surface':read_surface.PIN,
    'wire_encoder':sha256(Path(__import__('period_cost_source_runtime').__file__).read_bytes()).hexdigest(),
    'cohort_source':sha256(Path(tariff_cohort.__file__).read_bytes()).hexdigest()})

def need(ok,code):
    if not ok:raise Rejected(code)

def descriptor(root,store_id):
    stores=[s for s in root['stores']if s['id']==store_id]
    need(len(stores)==1 and stores[0]['platform']=='ozon','TARIFF_SOURCE_SCOPE')
    return {'id':'tariffs:'+fingerprint([root['tenant'],store_id]),'pin':PIN,
        'store_id':store_id,'scope':{'tenant_id':root['tenant'],'store_id':store_id,
                                  'provider':'OZON','currency':'RUB'}}

def _guard(worker,row,root,desc,authorize):
    need(callable(authorize),'TARIFF_REPORT_AUTHORITY_REQUIRED')
    need(worker.engine.authorized(root)and authorize()is True,'TARIFF_REPORT_REVOKED')
    need(row['tenant']==root['tenant']and desc==descriptor(root,desc['store_id']),'TARIFF_SOURCE_SCOPE')
    need(all(read_surface.available(read_surface.method('ozon',op))for op in OPERATIONS),'TARIFF_SOURCE_UNAVAILABLE')
    return next(s for s in root['stores']if s['id']==desc['store_id'])

def _aad(row,desc):return canonical_json({'job':row['id'],'tenant':row['tenant'],'descriptor':desc,'pin':PIN}).encode()

def _seal(repo,row,desc,state):
    nonce=secrets.token_bytes(12)
    return {'nonce':base64.b64encode(nonce).decode(),
        'cipher':base64.b64encode(AESGCM(encryption_key(repo)).encrypt(nonce,canonical_json(state).encode(),_aad(row,desc))).decode()}

def _open(repo,row,desc,packed):
    try:
        need(type(packed)is dict and set(packed)=={'nonce','cipher'},'TARIFF_PROGRESS_INTEGRITY')
        state=strict_json(AESGCM(encryption_key(repo)).decrypt(base64.b64decode(packed['nonce'],validate=True),
            base64.b64decode(packed['cipher'],validate=True),_aad(row,desc)))
        need(tariff_cohort.open_state(state),'TARIFF_PROGRESS_INTEGRITY')
        return state
    except Exception:raise Rejected('TARIFF_PROGRESS_INTEGRITY')from None

def _packet(value):
    result=deepcopy(value);result['body']=base64.b64decode(result.pop('body_b64'),validate=True);return result

def _verifier(worker,row,root,desc,state,authorize):
    def verify(packet):
        store=_guard(worker,row,root,desc,authorize)
        record=state['receipts'].get(packet['receipt_id'])
        if record is None or packet['scope']!=desc['scope']or packet['operation']not in OPERATIONS:return False
        request=read_surface.request_for(store,packet['operation'],packet['request'])
        if record!={'source':request.source,'operation':request.operation,'request_hash':fingerprint(packet['request']),
            'response_hash':packet['response_sha256'],'received_at':packet['received_at']}:return False
        with worker.repo.connection()as connection:
            event=connection.execute('SELECT jid,source,state,http FROM calls WHERE id=?',(packet['receipt_id'],)).fetchone()
        return event is not None and event['jid']==row['id']and event['source']==request.source and event['state']=='RECEIVED'and event['http']==200
    return verify

from platform_core.marketplace_matrix.tariff_cohort import restore, step
