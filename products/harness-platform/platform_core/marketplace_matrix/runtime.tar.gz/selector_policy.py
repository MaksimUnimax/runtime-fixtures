"""Server-owned prompt-layout policy. No response cache, quotas or extra calls.

This is deliberately not a multi-version catalogue executor. Old jobs without
this field keep legacy payloads; a rollout still requires the existing safe gate.
"""
from copy import deepcopy
import hashlib
from semantics import Rejected

LEGACY='legacy_v1'
PREFIX='catalog_prefix_v2'
DEFAULT={'layout':LEGACY,'isolation':'legacy_none'}

def validate(value=None):
    if value is None or value=={}:return dict(DEFAULT)
    if type(value)is not dict or set(value)!={'layout','isolation'}:
        raise Rejected('SELECTOR_POLICY_INVALID')
    if value['layout']not in(LEGACY,PREFIX)or value['isolation']not in('legacy_none','tenant_v1'):
        raise Rejected('SELECTOR_POLICY_INVALID')
    return dict(value)

def for_new_job(engine):
    source=getattr(engine,'selector_policy',None)
    return validate(source()if source is not None else None)

def apply(body,policy,tenant):
    """Tenant comes from the authenticated server scope, never model content."""
    rule=validate(policy)
    if type(tenant)is not str or not tenant:raise Rejected('TENANT_DENIED')
    result=deepcopy(body);result['_prompt_layout']=rule['layout']
    if rule['isolation']=='tenant_v1':
        result['_selector_user_id']='alisa_t_'+hashlib.sha256(('alisa-selector-cache-tenant-v1\0'+tenant).encode()).hexdigest()
    return result
