"""Temporary template-only mode, with full-composition admission before any API.

Uses the existing queue, authority, source handlers, ledger and final-answer model.
Absent templates and invalid execution decisions are archived and reported separately.
"""
from pathlib import Path
from dataclasses import asdict
from datetime import date,datetime,timezone
from copy import deepcopy
import re,json,hashlib
from semantics import Scope,Store,Rejected,canonical_json,strict_json,fingerprint,normalize
from template_catalog import CATALOG,TEMPLATES,HASH,MODE,TEXT,CODE,TemplateGap,discovery,compile_selection,INPUT_CONTRACT
from template_protocol import SELECT_SYSTEM,selection_system,payload as model_payload
from model_answer import API_DATA,PENDING,ORIGINAL_QUESTION

SCHEMA='alice-template-execution/v1'
TRACE='_template_trace';STATE='_template_state'
CONTROL={'результат','результат отчета','статус отчета','дальше','отмени отчет','план запроса','диагностика аналитики','выход'}

def authorized(engine,plan):
    try:
        from legacy_voice import authorized as voice_authorized
        if not voice_authorized(engine,plan):return False
        if plan.get('schema')!=SCHEMA or plan['template_execution']!={'catalog_hash':HASH,'mode':MODE}:return False
        scope=Scope(plan['tenant'],plan['access_revision'],tuple(Store(**s)for s in plan['stores']))
        if not engine.scope_current(scope,plan.get('runtime_guard')):return False
        from parameter_collection_runtime import authorized as admitted_parameter_current
        if not admitted_parameter_current(engine,plan):return False
        fragments=plan.get('fragments',[])
        if type(fragments)is not list:return False
        if fragments:
            if not plan.get('selection_verified'):return False
            if plan.get('execution_digest')!=fingerprint({'selection':plan['selection'],'fragments':fragments,'catalog':HASH}):return False
            for f in fragments:
                if f['plan'] is not None:
                    if f['plan'].get('runtime_guard')!=plan.get('runtime_guard')or not engine.authorized(f['plan']):return False
        return True
    except Rejected as e:
        if e.code=='DEPENDENCY_UNAVAILABLE':raise
        return False
    except (KeyError,TypeError,ValueError):return False

def submit(engine,tenant,command,rid,body_hash,today,clarification=None,execution_context=None):
    if execution_context is None and normalize(command)in CONTROL:
        return engine.control_once(tenant,normalize(command),rid,body_hash)
    scope=engine.execution_scope(execution_context,tenant)
    if scope.tenant!=tenant:raise Rejected('TENANT_DENIED')
    # Security input checks, not topic selection or speech-template matching.
    if re.search(r'(sk-[\w-]{12,}|eyJ[\w-]{25,}\.|api.?key|authorization|bearer|парол|токен|секрет)',command,re.I):raise Rejected('SENSITIVE_INPUT','Не передавайте ключи или пароли.')
    original=ORIGINAL_QUESTION.get()or command
    context=original if type(original)is dict else{'question':original}
    plan={'schema':SCHEMA,'tenant':tenant,'access_revision':scope.revision,'stores':[asdict(s)for s in scope.stores],
          'question':context['question'],'timezone':'Europe/Moscow','calendar_date':today.isoformat(),
          'template_execution':{'catalog_hash':HASH,'mode':MODE},'selection_verified':False,
          'freshness_seconds':300,'request_identity':fingerprint([rid,body_hash]),'fragments':[]}
    draft={'route':'TEMPLATE_ONLY','question':command,'original_question':context['question'],'question_clarifications':context.get('clarifications',[]),'calendar_date':today.isoformat(),'refresh':False}
    from selector_policy import for_new_job
    draft['selector_prompt']=for_new_job(engine)
    if clarification is not None:draft['clarification']=clarification
    engine.pin_execution(plan,execution_context);engine.pin_execution(draft,execution_context)
    from parameter_collection_runtime import pin
    pin(plan)
    from legacy_voice import pin
    pin(plan,draft)
    if not engine.authorized(plan):raise Rejected('SOURCE_ACCESS')
    row,outcome=engine.repo.enqueue(tenant,rid,body_hash,draft,plan,fingerprint(asdict(scope)),update_pointer=execution_context is None)
    if execution_context is not None:return {'job_id':row['id'],'state':row['state'],'cache':outcome}
    text=engine.describe(tenant,row,deliver=True)
    return {'text':text,'tts':text,'job_id':row['id'],'state':row['state'],'cache':outcome}

def _current_progress(repo,row):
    with repo.connection()as c:
        current=c.execute('SELECT progress FROM jobs WHERE id=?AND owner=?',(row['id'],row['owner'])).fetchone()
    if current is None:raise Rejected('JOB_LEASE_LOST')
    return strict_json(current['progress'])if current['progress']else{}

def _save(repo,row,progress,until=None):
    # Provider capture may have added full API data inside the same step.
    current=_current_progress(repo,row)
    if API_DATA in current:progress[API_DATA]=current[API_DATA]
    repo.reschedule(row['id'],row['owner'],progress,until=until)

def _snapshot(repo,row,progress,operation,body):
    full=model_payload(operation,body)
    entry={'operation':operation,'prepared_at':datetime.fromtimestamp(repo.clock(),timezone.utc).isoformat(),
           'request_payload':full,'request_payload_sha256':hashlib.sha256(json.dumps(full,ensure_ascii=False,allow_nan=False).encode()).hexdigest()}
    from template_protocol import request_metadata
    entry['request_metadata']=request_metadata(operation,body)
    progress.setdefault(TRACE,[]).append(entry)
    with repo.connection(True)as c:
        repo._owned(c,row['id'],row['owner'])
        c.execute('UPDATE jobs SET progress=?WHERE id=?',(canonical_json(progress),row['id']))
    return len(progress[TRACE])-1

def _gap(worker,row,plan,progress,error):
    engine=worker.engine;repo=worker.repo
    if not authorized(engine,plan):raise Rejected('SOURCE_ACCESS')
    with repo.connection()as c:
        calls=[dict(r)for r in c.execute('SELECT id,source,at,state,http,elapsed_ms,response_bytes,error_code FROM calls WHERE jid=?ORDER BY id',(row['id'],))]
        inbox=[dict(r)for r in c.execute('SELECT rid,body_hash FROM inbox WHERE jid=?',(row['id'],))]
    from template_gaps import GapStore
    store=GapStore(Path(repo.path).with_name('template-gaps.sqlite3'))
    code,text=error.code,error.message
    packet={'schema':'alisa-template-gap-evidence/v1','mode':MODE,'temporary_mode':True,'code':code,'reason':error.reason,'details':error.details,
            'original_question':strict_json(row['draft']).get('original_question',plan['question']),
            'draft':strict_json(row['draft']),'accepted_context':plan,'model_calls':progress.get(TRACE,[]),
            'selection':progress.get('selection'),'verification':progress.get('verification'),'diagnostic_progress':progress,'call_receipts':calls,'request_receipts':inbox,
            'catalog':CATALOG,'catalog_hash':HASH,'runtime_release':Path(__file__).parent.name,
            'saved_at':datetime.fromtimestamp(repo.clock(),timezone.utc).isoformat()}
    case_id=store.save(row['tenant'],row['id'],row['created'],error.reason,HASH,packet)
    result={'complete':True,'pages':[text],'fetched_at':datetime.fromtimestamp(repo.clock(),timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'data':None,'failure_code':code,'template_gap':True,'temporary_mode':True,
            'model_result':{'ok':False,'status':code,'message':text,'data':None,'retryable':False,'temporary_mode':True,'case_id':case_id}}
    # Preserve the exact pilot phrase only for a real missing-template decision.
    # Other execution failures use the shared safe error catalogue.
    repo.complete_answer(row['id'],row['owner'],result)

def gap_result(engine,row):
    if row['state']!='READY'or(row.get('expires')or 0)<=engine.repo.clock()or not row['result']or not row['plan']:return None
    r=strict_json(row['result'])
    code=r.get('failure_code')
    if code not in (CODE,'TEMPLATE_EXECUTION_FAILED'):return None
    from failure_explanations import explain
    text=TEXT if code==CODE else explain(code)['text']
    if r.get('template_gap')is not True or r.get('pages')!=[text]:return None
    value=r.get('model_result',{})
    if value.get('status')!=code or value.get('message')!=text or value.get('ok')is not False:return None
    if not authorized(engine,strict_json(row['plan'])):return None
    return r['model_result']

def _compile_and_save_selection(worker,row,plan,progress,decision):
    if type(decision)is dict and decision.get('action')=='clarify' and (type(plan.get('runtime_guard'))is dict or __import__('legacy_voice').supported(worker.engine,plan)):
        from template_clarification import pause
        return pause(worker,row,plan,progress,decision)
    # Validate the selected registered recipes locally. No extra model call.
    progress['selection']=deepcopy(decision)
    fragments=compile_selection(worker.engine,plan,decision)
    if plan.get('station_guard') is not None:
        for fragment in fragments:
            if fragment['plan'] is not None:fragment['plan']['station_guard']=deepcopy(plan['station_guard'])
    progress['fragments']=fragments
    progress['preview']=[{'template_ids':f['template_ids'],'invocation_ids':f['invocation_ids'],'input':f['draft'],'kind':f['kind']}for f in fragments]
    progress['verification']={'method':'local_template_compilation'}
    newplan=deepcopy(plan);newplan.update(selection=decision,fragments=fragments,selection_verified=True)
    newplan['execution_digest']=fingerprint({'selection':newplan['selection'],'fragments':fragments,'catalog':HASH})
    if not authorized(worker.engine,newplan):raise Rejected('SOURCE_ACCESS')
    progress.update({STATE:'execute','fragment_index':0,'fragment_progress':None,'completed_fragments':[]})
    with worker.repo.connection(True)as c:
        worker.repo._owned(c,row['id'],row['owner'])
        c.execute('UPDATE jobs SET plan=?WHERE id=?',(canonical_json(newplan),row['id']))
        _save(worker.repo,row,progress)

def worker_step(worker,row,plan):
    if not authorized(worker.engine,plan):raise Rejected('SOURCE_ACCESS')
    progress=strict_json(row['progress'])if row['progress']else{STATE:'select',TRACE:[]}
    state=progress.get(STATE)
    try:
        if state=='verify':
            # Resume old persisted checkpoints through the same local checks.
            _compile_and_save_selection(worker,row,plan,progress,progress['selection']);return
        if state=='select':
            if getattr(worker.engine, 'chat_template_selection', None) is not None:
                _compile_and_save_selection(worker,row,plan,progress,worker.engine.chat_template_selection)
                return
            if plan.get('parameter_admission')is not None:
                from parameter_collection_runtime import decision
                _compile_and_save_selection(worker,row,plan,progress,decision(plan));return
            scope=Scope(plan['tenant'],plan['access_revision'],tuple(Store(**s)for s in plan['stores']))
            settings=progress.get('planning_settings')
            if settings is None:
                settings=worker.engine.answer_settings.read()if worker.engine.answer_settings else{'revision':0,'request_planning_prompt':''}
                progress['planning_settings']={'revision':settings['revision'],'request_planning_prompt':settings['request_planning_prompt']}
            ctx={'original_question':plan['question'],'clarifications':strict_json(row['draft']).get('question_clarifications',[]),
                 'server_date':plan['calendar_date'],'timezone':plan['timezone'],'allowed_stores':[{'id':s.id,'platform':s.platform}for s in scope.stores],
                 'templates':discovery(worker.engine,scope),'input_contract':INPUT_CONTRACT,'temporary_mode':MODE}
            from legacy_voice import supported
            if type(plan.get('runtime_guard'))is dict or supported(worker.engine,plan):ctx['clarification_supported']=True
            op='template_select'
            from selector_policy import apply,validate
            rule=validate(strict_json(row['draft']).get('selector_prompt'))
            prepared=progress.get('_selector_prepared')
            if prepared is None:
                body=apply({'system':selection_system(ctx),'instruction':progress['planning_settings']['request_planning_prompt'],'context':ctx},rule,plan['tenant'])
                # JSON text preserves insertion order across the canonical JSON
                # persistence layer, so a transport retry sends identical bytes.
                encoded=json.dumps(body,ensure_ascii=False,allow_nan=False)
                prepared={'body_json':encoded,'sha256':hashlib.sha256(encoded.encode()).hexdigest(),'policy':rule,'catalog_hash':HASH}
                progress['_selector_prepared']=prepared
            else:
                if (prepared.get('policy')!=rule or prepared.get('catalog_hash')!=HASH
                    or hashlib.sha256(prepared.get('body_json','').encode()).hexdigest()!=prepared.get('sha256')):
                    raise Rejected('SELECTOR_REQUEST_PIN_CHANGED')
                body=strict_json(prepared['body_json'])
                if body['context'].get('original_question')!=plan['question']:raise Rejected('SELECTOR_REQUEST_PIN_CHANGED')
                # This is not an access cache: authorized() and compile_selection
                # above/below still resolve current server rights and source proof.
            if progress.get('_selection_repair'):body=dict(body,_selection_repair=progress['_selection_repair'])
            index=_snapshot(worker.repo,row,progress,op,body)
            from providers import Request
            req=Request(op,getattr(worker.transport,'model_source','model:deepseek-flash'),'',body,0,None)
            def received(response):
                progress[TRACE][index]['response']=deepcopy(response);progress[TRACE][index]['received_at']=datetime.fromtimestamp(worker.repo.clock(),timezone.utc).isoformat()
                try:
                    if response.get('finish_reason')=='length':
                        state=hashlib.sha256(canonical_json(response).encode()).hexdigest()
                        seen=progress.setdefault('_selection_incomplete_states',[])
                        if state in seen:raise TemplateGap('MODEL_SELECTION_NO_PROGRESS')
                        seen.append(state)
                        progress['_selection_repair']={'code':'MODEL_SELECTION_INCOMPLETE',
                            'instruction':'Предыдущий выбор оборвался. Верни полный JSON выбора заново, сохранив все условия исходного вопроса. API ещё не вызывались.',
                            'previous_partial':response.get('content','')}
                        _save(worker.repo,row,progress);return
                    if response.get('finish_reason')!='stop':raise TemplateGap('MODEL_SELECTION_INCOMPLETE')
                    try:decision=strict_json(response.get('content',''))
                    except (Rejected,TypeError):raise TemplateGap('MODEL_SELECTION_INVALID')from None
                    _compile_and_save_selection(worker,row,plan,progress,decision)
                except TemplateGap as error:_gap(worker,row,plan,progress,error)
            worker._call(row,req,on_received=received)
            return
        if state!='execute'or not plan.get('selection_verified'):raise TemplateGap('TEMPLATE_STATE_INVALID')
        index=progress['fragment_index'];fragment=plan['fragments'][index]
        if fragment['kind']=='information':
            scope=Scope(plan['tenant'],plan['access_revision'],tuple(Store(**s)for s in plan['stores']))
            payload={'operation':'catalog_capabilities','data':discovery(worker.engine,scope)}
            current=_current_progress(worker.repo,row);current.setdefault(API_DATA,[]).append(payload)
            with worker.repo.connection(True)as c:c.execute('UPDATE jobs SET progress=?WHERE id=?',(canonical_json(current),row['id']))
            _finish_fragment(worker,row,plan,progress,{'capabilities':payload['data']});return
        _run_fragment(worker,row,plan,progress,fragment)
    except TemplateGap as error:_gap(worker,row,plan,progress,error)

def _finish_fragment(worker,row,plan,progress,data):
    progress['completed_fragments'].append({'template_ids':plan['fragments'][progress['fragment_index']]['template_ids'],'data':data})
    progress['fragment_index']+=1;progress['fragment_progress']=None
    if progress['fragment_index']==len(plan['fragments']):
        # Existing final-answer stage receives the original question and all full
        # captured API responses. This call performs no model/network operation.
        result_data={'templates':progress['completed_fragments']}
        parameters=[{'template_ids':item['template_ids'],'result':item['data']}for item in progress['completed_fragments']if any(TEMPLATES[tid]['kind']=='parameter'for tid in item['template_ids'])]
        if parameters:result_data['parameter_context']=parameters
        context={};calculations=[]
        # Speech notes belong only to explicit model selections. Expanded
        # dependencies execute on the server but do not inherit speech context.
        for invocation in plan['selection']['invocations']:
            tid=invocation['template_id']
            template=TEMPLATES[tid]
            if template.get('notes'):
                context[tid]={'template_id':tid,'version':template['version'],'notes':deepcopy(template['notes'])}
            from template_catalog import dependencies
            for calculation_id in dependencies(tid):
                calculation=TEMPLATES[calculation_id]
                if not calculation.get('calculation_contract'):continue
                calculations.append({'template_id':calculation_id,'version':calculation['version'],
                    'selected_template_id':tid,
                    'invocation_id':invocation['id'],'store_id':invocation['store_id'],
                    'input':deepcopy(invocation['input']),
                    'contract':deepcopy(calculation['calculation_contract'])})
        if context:result_data['template_context']=list(context.values())
        if calculations:result_data['calculation_context']=calculations
        source_args = {'economics_sources':progress['_economics_sources']}if '_economics_sources'in progress else{}
        worker.repo.stage_answer(row['id'],row['owner'],{'data':result_data,'fetched_at':datetime.fromtimestamp(worker.repo.clock(),timezone.utc).strftime('%Y-%m-%d %H:%M UTC')},**source_args)
    else:_save(worker.repo,row,progress)

class _FragmentRepo:
    """Adapter for existing worker handlers: one root job, never a second queue."""
    def __init__(self,worker,row,plan,progress,fragment):
        self.worker=worker;self.base=worker.repo;self.row=row;self.plan=plan;self.progress=progress;self.fragment=fragment;self.claimed=False
    def __getattr__(self,name):return getattr(self.base,name)
    def claim(self):
        if self.claimed:return None
        self.claimed=True
        draft=strict_json(self.row['draft']);draft.update(self.fragment['draft']);draft['answer_by_model']=True
        return {**dict(self.row),'plan':canonical_json(self.fragment['plan']),'draft':canonical_json(draft),'progress':canonical_json(self.progress['fragment_progress'])if self.progress['fragment_progress']is not None else None}
    def reschedule(self,jid,owner,progress=None,until=None):
        if progress is not None:self.progress['fragment_progress']=progress
        return _save(self.base,self.row,self.progress,until)
    def stage_answer(self,jid,owner,result,progress=None):
        return _finish_fragment(self.worker,self.row,self.plan,self.progress,result['data'])
    def complete(self,jid,owner,result):return self.stage_answer(jid,owner,result)

def _run_fragment(worker,row,plan,progress,fragment):
    if fragment['kind']=='parameterized':
        from parameter_report_runtime import step
        return step(worker,row,plan,progress,fragment)
    if fragment['kind']=='parameter':
        from parameter_source_runtime import step
        return step(worker,row,plan,progress,fragment)
    from engine import Worker
    sub=Worker(worker.engine,worker.transport);sub.repo=_FragmentRepo(worker,row,plan,progress,fragment)
    # All actual dispatches remain in the parent worker and current root job.
    sub._call=lambda child,request,store=None,**kw:worker._call(row,request,store,**kw)
    sub.step()
